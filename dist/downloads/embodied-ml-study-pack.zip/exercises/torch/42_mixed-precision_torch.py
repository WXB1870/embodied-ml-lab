# 混合精度训练
# 环境：Python + PyTorch CPU
# 实现 scaled_train_step(loss, optimizer, scaler, parameters, max_norm)：清零梯度、缩放反传、反缩放、全局裁剪、缩放器驱动更新，返回裁剪前范数。loss 已由前向构建；parameters 是参数列表。本题用真实 CPU GradScaler 测试更新顺序，并不代表运行过 CUDA。

import torch

def scaled_train_step(loss, optimizer, scaler, parameters, max_norm):
    # TODO: 正确排列 zero_grad、backward、unscale、clip、step、update
    raise NotImplementedError('请实现 scaled_train_step')


# ===== 断言测试 =====
torch.manual_seed(300)
p = torch.nn.Parameter(torch.tensor([3.0, 4.0]))
q = torch.nn.Parameter(p.detach().clone())
opt = torch.optim.SGD([p], lr=0.1)
ref = torch.optim.SGD([q], lr=0.1)
scaler = torch.amp.GradScaler('cpu', init_scale=128.0)
norm = scaled_train_step(p.square().sum() / 2, opt, scaler, [p], 2.5)
ref.zero_grad(set_to_none=True)
(q.square().sum() / 2).backward()
ref_norm = torch.nn.utils.clip_grad_norm_([q], 2.5)
ref.step()
torch.testing.assert_close(norm, torch.tensor(5.0))
torch.testing.assert_close(norm, ref_norm)
torch.testing.assert_close(p, q)
torch.testing.assert_close(p, torch.tensor([2.85, 3.8]), atol=1e-6, rtol=1e-6)
assert scaler.is_enabled()
print('PyTorch 通过：真实 CPU 缩放器、反缩放后裁剪与更新')

print("所有提供的测试通过。")
