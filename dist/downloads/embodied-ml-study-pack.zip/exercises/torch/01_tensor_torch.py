# 张量与广播
# 环境：Python + PyTorch CPU
# 实现 [B,T,D] 的池化。x 是浮点 Tensor，有效位置数值有限，无效位置允许包含 NaN；mask 是同设备的布尔 Tensor [B,T]。每个样本只平均自己的有效时刻；任一样本没有有效时刻时抛出 ValueError。输出必须保留梯度，无效位置梯度为零。输入形状和有效位置的有限性由题设保证。

import torch

def pool_valid(x, mask):
    # TODO: 用广播实现，不要转成列表或重新构造 Tensor
    raise NotImplementedError("请实现 pool_valid")


# ===== 断言测试 =====
x = torch.tensor([[[1., 2.], [3., 4.], [float('nan'), float('nan')]],
                  [[5., 6.], [float('nan'), 9.], [9., float('nan')]]],
                 dtype=torch.float64, requires_grad=True)
m = torch.tensor([[True, True, False], [True, False, False]])
out = pool_valid(x, m)
assert out.shape == (2, 2)
torch.testing.assert_close(out, torch.tensor([[2., 3.], [5., 6.]], dtype=x.dtype))
assert torch.isfinite(out).all()
out.sum().backward()
expected_grad = m.to(dtype=x.dtype).unsqueeze(-1).expand_as(x)
expected_grad = expected_grad / m.sum(dim=1)[:, None, None]
torch.testing.assert_close(x.grad, expected_grad)
assert torch.isfinite(x.grad).all()
# 改变无效填充值不会影响结果，也不应改变有效样本的平均分母。
changed = x.detach().clone()
changed[~m] = 1e9
torch.testing.assert_close(pool_valid(changed, m), out.detach())
# 长度为 1 的 Batch 和时间轴仍应保留输出形状。
single = torch.tensor([[[2., 7.]]], dtype=torch.float64, requires_grad=True)
torch.testing.assert_close(pool_valid(single, torch.tensor([[True]])), single[:, 0])
try:
    pool_valid(x, torch.zeros_like(m))
except ValueError:
    pass
else:
    raise AssertionError("应拒绝无有效时刻的样本")
print("PyTorch 测试通过：有效平均、无效 NaN、全部输入梯度与单例轴。")

print("所有提供的测试通过。")
