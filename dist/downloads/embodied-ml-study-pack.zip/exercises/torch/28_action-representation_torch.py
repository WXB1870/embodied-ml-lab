# 状态与动作表示
# 环境：Python + PyTorch CPU
# 实现 normalize_actions(a, mean, std, valid_dim)。a 为浮点 [B,H,D]，均值、标准差为同设备同类型 [D]，valid_dim 为同设备 bool [D]。只对有效维标准化，填充维输出零；无效动作与统计量允许为 NaN，有效值必须有限。用 1e-6 限制标准差下界，负标准差报错。实现应让无效维对输入与统计量的梯度均为零。

import torch

def normalize_actions(a, mean, std, valid_dim):
    # TODO: 核对语义和维度；先选择有效坐标，再标准化并写回零张量。
    raise NotImplementedError


# ===== 断言测试 =====
a = torch.tensor([[[3., 5., float('nan')], [1., 9., float('nan')]]],
                 dtype=torch.float64, requires_grad=True)
m = torch.tensor([1., 1., float('nan')], dtype=torch.float64, requires_grad=True)
s = torch.tensor([2., 4., float('nan')], dtype=torch.float64, requires_grad=True)
v = torch.tensor([True, True, False])
z = normalize_actions(a, m, s, v)
torch.testing.assert_close(z, torch.tensor([[[1.,1.,0.],[0.,2.,0.]]], dtype=a.dtype))
torch.testing.assert_close(z[...,v]*s[v]+m[v], a[...,v])
ga, gm, gs = torch.autograd.grad(z.square().sum(), (a, m, s))
torch.testing.assert_close(ga, torch.tensor([[[1.,.5,0.],[0.,1.,0.]]], dtype=a.dtype))
torch.testing.assert_close(gm, torch.tensor([-1.,-1.5,0.], dtype=a.dtype))
torch.testing.assert_close(gs, torch.tensor([-1.,-2.5,0.], dtype=a.dtype))
assert all(torch.isfinite(g).all() for g in (ga, gm, gs))

# A zero scale is a declared finite convention, not an invalid value.
constant = normalize_actions(torch.zeros(1,1,1), torch.zeros(1), torch.zeros(1),
                             torch.ones(1, dtype=torch.bool))
torch.testing.assert_close(constant, torch.zeros_like(constant))
for bad_a, bad_m, bad_s, bad_v in [
        (a.detach(), m.detach(), torch.tensor([-1.,4.,0.], dtype=a.dtype), v),
        (a.detach(), m.detach(), s.detach(), torch.ones(3, dtype=torch.bool)),
        (a.detach(), m.detach(), s.detach(), v.float()),
        (a.detach()[0], m.detach(), s.detach(), v)]:
    try:
        normalize_actions(bad_a, bad_m, bad_s, bad_v)
    except ValueError:
        pass
    else:
        raise AssertionError('invalid shape, mask, scale or valid NaN accepted')
print('passed: valid-axis encoding, round trip, analytic gradients and NaN isolation')

print("所有提供的测试通过。")
