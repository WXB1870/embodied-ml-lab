# KV Cache 与增量计算
# 环境：Python + PyTorch CPU
# 实现 cached_attention。q/k_new/v_new 已经包含正确的上游位置处理；函数追加缓存并构造非方形因果 Mask。position_offset 必须等于本例历史长度。返回 (输出,(合并K,合并V))。

import math
import torch

def cached_attention(q, k_new, v_new, past=None, position_offset=0):
    # TODO: 合并历史，使用绝对位置构造 Mask
    raise NotImplementedError("请实现缓存注意力")


# ===== 断言测试 =====
torch.manual_seed(38)
q, k, v = [torch.randn(1,2,5,4) for _ in range(3)]
expected = torch.nn.functional.scaled_dot_product_attention(q,k,v,is_causal=True)
first, cache = cached_attention(q[:,:,:3],k[:,:,:3],v[:,:,:3])
second, final_cache = cached_attention(q[:,:,3:],k[:,:,3:],v[:,:,3:],cache,3)
torch.testing.assert_close(torch.cat((first,second),-2),expected,atol=1e-6,rtol=1e-5)
assert final_cache[0].shape[-2] == 5
try:
    cached_attention(q[:,:,3:],k[:,:,3:],v[:,:,3:],cache,0)
    raise AssertionError("错误位置偏移应被拒绝")
except ValueError:
    pass
print("通过：缓存追加、非方形因果性、位置检查与完整前向一致性")

print("所有提供的测试通过。")
