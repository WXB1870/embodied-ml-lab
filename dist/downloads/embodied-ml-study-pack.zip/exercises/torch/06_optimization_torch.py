# 梯度下降、动量与 AdamW
# 环境：Python + PyTorch CPU
# 构造 AdamW 参数组：仅加入 requires_grad=True 的参数；本题约定 ndim<2 不衰减，其余使用指定衰减。每个参数只能出现一次。

import torch

def make_optimizer(model, lr, weight_decay):
    # TODO: 分组后返回 torch.optim.AdamW
    raise NotImplementedError("请实现 make_optimizer")


# ===== 断言测试 =====
from torch import nn
model = nn.Sequential(nn.Linear(3, 4), nn.LayerNorm(4), nn.Linear(4, 2))
model[0].weight.requires_grad_(False)
optimizer = make_optimizer(model, 1e-3, 0.1)
ids = [id(p) for group in optimizer.param_groups for p in group['params']]
expected = {id(p) for p in model.parameters() if p.requires_grad}
assert len(ids) == len(set(ids)) and set(ids) == expected
for group in optimizer.param_groups:
    assert group['lr'] == 1e-3
    for parameter in group['params']:
        wanted_decay = 0. if parameter.ndim < 2 else 0.1
        assert group['weight_decay'] == wanted_decay
print("PyTorch 测试通过：冻结、覆盖和分组规则正确。")

print("所有提供的测试通过。")
