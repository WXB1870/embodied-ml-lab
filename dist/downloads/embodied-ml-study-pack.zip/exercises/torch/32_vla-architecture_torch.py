# VLA：从视觉语言骨干到动作专家
# 环境：Python + PyTorch CPU
# 手写 joint_attention(qp,kp,vp,qs,ks,vs,prefix_valid,action_valid)。六个输入为有限浮点 [B,heads,L,d]；prefix 与 suffix 长度可不同，但 B、heads、d 相同。suffix 第一个 token 是始终有效的 state，后面是 H 个 action。prefix 只读有效 prefix；state 读 prefix+state；action 读全部有效 token。返回 (prefix_output,suffix_output)，无效 Query 输出零。不得调用 MultiheadAttention 或 SDPA。测试要求逐行独立参照、全屏蔽前缀、禁止路径零梯度和有效条件梯度。

import math
import torch

def joint_attention(qp, kp, vp, qs, ks, vs, prefix_valid, action_valid):
    # Validate [B, heads, length, d] and masks.
    # Concatenate projected streams, apply the three-block mask,
    # normalize over keys, then split the output by token boundary.
    raise NotImplementedError


# ===== 断言测试 =====
torch.manual_seed(13)
qp = torch.randn(2, 2, 3, 4, dtype=torch.float64, requires_grad=True)
kp = torch.randn_like(qp, requires_grad=True)
vp = torch.randn_like(qp, requires_grad=True)
qs = torch.randn(2, 2, 4, 4, dtype=torch.float64, requires_grad=True)
ks = torch.randn_like(qs, requires_grad=True)
vs = torch.randn_like(qs, requires_grad=True)
pv = torch.tensor([[1, 1, 0], [0, 0, 0]], dtype=torch.bool)
av = torch.tensor([[1, 1, 0], [1, 1, 1]], dtype=torch.bool)
p, s = joint_attention(qp, kp, vp, qs, ks, vs, pv, av)
assert p.shape == qp.shape and s.shape == qs.shape
assert torch.isfinite(p).all() and torch.isfinite(s).all()
assert (p[1] == 0).all() and (s[0, :, -1] == 0).all()
# Independent row-by-row reference, not the same matrix-mask implementation.
for b in range(2):
    keys = torch.cat((kp[b], ks[b]), dim=1)
    values = torch.cat((vp[b], vs[b]), dim=1)
    for i in range(4):
        if i > 0 and not av[b, i-1]:
            continue
        visible = pv[b].nonzero().flatten().tolist() + [3]
        if i > 0:
            visible += [4+j for j in range(3) if av[b, j]]
        logits = (qs[b, :, i:i+1] @ keys[:, visible].transpose(-1, -2)) / 2
        expected = (logits.softmax(-1) @ values[:, visible]).squeeze(1)
        torch.testing.assert_close(s[b, :, i], expected)
# Prefix cannot depend on suffix; state cannot depend on any action slot.
(p.square().sum() + s[:, :, :1].square().sum()).backward(retain_graph=True)
assert qs.grad[:, :, 1:].count_nonzero() == 0
assert ks.grad[:, :, 1:].count_nonzero() == 0
assert vs.grad[:, :, 1:].count_nonzero() == 0
for tensor in (qp, kp, vp, qs, ks, vs):
    tensor.grad = None
s[:, :, 1:].square().sum().backward()
assert vp.grad[0, :, :2].abs().sum() > 0
assert vs.grad[0, :, -1].count_nonzero() == 0
try:
    joint_attention(qp, kp, vp, qs, ks, vs, pv.float(), av)
except ValueError:
    pass
else:
    raise AssertionError("non-bool mask accepted")
print("joint attention reference and gradient checks passed")

print("所有提供的测试通过。")
