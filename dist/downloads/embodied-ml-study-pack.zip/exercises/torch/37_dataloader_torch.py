# 数据采样与批处理
# 环境：Python + PyTorch CPU
# 实现 collate_actions。输入为非空列表，每个 Tensor 是非空 [Ti,A]，且 A 相同；返回补齐动作和 bool 有效位。使用 pad_sequence。

import torch
from torch.nn.utils.rnn import pad_sequence

def collate_actions(sequences):
    # TODO: 验证输入，补齐动作，构造有效位
    raise NotImplementedError("请完成动作组批")


# ===== 断言测试 =====
seqs = [torch.zeros(2, 3), torch.ones(1, 3), torch.full((4, 3), 2.)]
actions, valid = collate_actions(seqs)
assert actions.shape == (3, 4, 3) and valid.dtype == torch.bool
assert valid.sum().item() == 7
assert valid[0, 0] and torch.equal(actions[0, 0], torch.zeros(3))
assert not valid[1, 1]
assert (actions[~valid] == 0).all()
print("通过：形状、长度、真实零动作与 Padding")

print("所有提供的测试通过。")
