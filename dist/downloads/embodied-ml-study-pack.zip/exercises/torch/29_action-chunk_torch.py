# 时间对齐与动作块
# 环境：Python + PyTorch CPU
# 实现 chunkify(actions, starts, horizon)。actions 是单条轨迹 [T,D]，starts 是合法起点 [B]。返回零填充标签 [B,H,D] 与有效性 Mask [B,H]，不可越过轨迹末尾。

import torch

def chunkify(actions, starts, horizon):
    # TODO: 向量化索引，返回 chunk 和 valid
    raise NotImplementedError


# ===== 断言测试 =====
a = torch.arange(5).float().unsqueeze(-1)
c,v = chunkify(a, torch.tensor([0,3,4]), 3)
torch.testing.assert_close(c.squeeze(-1), torch.tensor([[0.,1.,2.],[3.,4.,0.],[4.,0.,0.]]))
assert v.tolist() == [[True,True,True],[True,True,False],[True,False,False]]
assert c.shape == (3,3,1)
print('向量化 Action Chunk 检查通过。')

print("所有提供的测试通过。")
