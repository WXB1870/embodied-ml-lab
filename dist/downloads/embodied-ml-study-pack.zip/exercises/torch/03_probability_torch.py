# 概率、统计与训练目标
# 环境：Python + PyTorch CPU
# 只使用 logsumexp、gather 和基础运算实现平均分类 NLL。不要先 softmax，也不要调用 cross_entropy。

import torch

def categorical_nll(logits, target):
    # TODO: 返回一个可反向传播的标量
    raise NotImplementedError("请实现 categorical_nll")


# ===== 断言测试 =====
import torch.nn.functional as F
torch.manual_seed(3)
z = torch.randn(4, 5, dtype=torch.float64, requires_grad=True)
y = torch.tensor([0, 2, 1, 4])
a = categorical_nll(z, y)
b = F.cross_entropy(z, y)
assert a.ndim == 0 and torch.allclose(a, b)
ga = torch.autograd.grad(a, z, retain_graph=True)[0]
gb = torch.autograd.grad(b, z)[0]
assert torch.allclose(ga, gb, atol=1e-10)
assert torch.allclose(categorical_nll(z + 1000, y), b, atol=1e-10)
print("PyTorch 测试通过：损失和梯度均一致。")

print("所有提供的测试通过。")
