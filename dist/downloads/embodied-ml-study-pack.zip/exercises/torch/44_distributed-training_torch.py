# DDP 与全局统计
# 环境：Python + PyTorch CPU
# 实现 ddp_scaled_local_loss(local_error_sum, global_valid_count, world_size)，返回标准 DDP 平均梯度前应反传的局部损失。local_error_sum 是标量 Tensor，后两个参数为正整数。测试在单个 CPU 进程中用 autograd 明确模拟 rank 梯度平均，与全局 MSE 对比；此练习不运行多卡或 Gloo。

import torch

def ddp_scaled_local_loss(local_error_sum, global_valid_count, world_size):
    # TODO: 补偿标准 DDP 的 world_size 平均因子，保留计算图
    raise NotImplementedError('请实现 ddp_scaled_local_loss')


# ===== 断言测试 =====
torch.manual_seed(330)
p = torch.tensor(0.7, dtype=torch.float64, requires_grad=True)
targets = [torch.tensor([1.0], dtype=torch.float64),
           torch.tensor([2.0, -1.0, 3.0], dtype=torch.float64)]
total = sum(t.numel() for t in targets)
rank_gradients = []
for target in targets:
    local_sum = (p - target).square().sum()
    local_loss = ddp_scaled_local_loss(local_sum, total, 2)
    rank_gradients.append(torch.autograd.grad(local_loss, p)[0])
averaged = torch.stack(rank_gradients).mean()
reference_loss = (p - torch.cat(targets)).square().mean()
reference = torch.autograd.grad(reference_loss, p)[0]
torch.testing.assert_close(averaged, reference, atol=1e-12, rtol=1e-12)
assert p.grad is None
try:
    ddp_scaled_local_loss(p.square(), 0, 2)
except ValueError:
    pass
else:
    raise AssertionError('应拒绝零全局分母')
print('PyTorch 通过：单进程数学模拟的不等计数 DDP 梯度缩放')

print("所有提供的测试通过。")
