# 回报与 Bellman 方程
# 环境：Python + PyTorch CPU
# 实现 `td_targets(reward,next_value,terminated,truncated,gamma)`。四个张量均为 `[B]`，两个标志为布尔值。返回无梯度 target；外部 `truncated` 不取消 bootstrap，但真正 `terminated` 取消。 真正终态允许 next_value 为 NaN，必须在计算目标前排除；仍参与 bootstrap 的非有限值和非有限奖励应报错。

import torch

def td_targets(reward,next_value,terminated,truncated,gamma):
    # TODO: reset 标志与 bootstrap 标志要分开
    raise NotImplementedError


# ===== 断言测试 =====
r=torch.tensor([1.,1.,1.],requires_grad=True)
v=torch.tensor([10.,10.,10.],requires_grad=True)
term=torch.tensor([False,True,False])
trunc=torch.tensor([False,False,True])
y=td_targets(r,v,term,trunc,0.9)
torch.testing.assert_close(y,torch.tensor([10.,1.,10.]))
assert not y.requires_grad
y2=td_targets(r,v,term,torch.zeros_like(trunc),0.9)
torch.testing.assert_close(y,y2)
print('真正终止、外部截断与 target 梯度边界检查通过。')

# 终态无合法尾值时，不能用 0 * NaN 处理。
nan_at_terminal = v.detach().clone()
nan_at_terminal[1] = float("nan")
torch.testing.assert_close(td_targets(r,nan_at_terminal,term,trunc,0.9),y)
invalid = v.detach().clone()
invalid[2] = float("nan")
try:
    td_targets(r,invalid,term,trunc,0.9)
    raise AssertionError("非终止转移需要有限的 bootstrap")
except ValueError:
    pass
print("终态 NaN 排除与非终态非法值检查通过。")

print("所有提供的测试通过。")
