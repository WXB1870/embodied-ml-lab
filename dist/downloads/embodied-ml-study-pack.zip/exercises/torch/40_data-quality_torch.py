# 示教数据与采样
# 环境：Python + PyTorch CPU
# 实现 training_statistics(x, train_mask)。x 为 [N,D]，train_mask 为 [N] 布尔值。仅用训练行计算均值和总体标准差，标准差下界 1e-6；训练行非有限或没有训练行时拒绝计算。

import torch

def training_statistics(x, train_mask):
    # TODO: 先筛选训练行，再检查并计算统计量
    raise NotImplementedError


# ===== 断言测试 =====
x = torch.tensor([[1.,2.],[3.,6.],[999.,1000.]])
m = torch.tensor([True,True,False])
mean,std = training_statistics(x,m)
torch.testing.assert_close(mean,torch.tensor([2.,4.]))
torch.testing.assert_close(std,torch.tensor([1.,2.]))
x[-1] = torch.tensor([float('nan'),-100000.])
mean2,std2 = training_statistics(x,m)
torch.testing.assert_close(mean,mean2)
torch.testing.assert_close(std,std2)
print('训练统计量未受保留集数据影响。')

print("所有提供的测试通过。")
