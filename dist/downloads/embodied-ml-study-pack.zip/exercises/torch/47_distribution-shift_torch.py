# 分布偏移与 DAgger
# 环境：Python + PyTorch CPU
# 实现 `aggregate_dagger(old_obs,old_actions,visited,teacher)`。在 `no_grad` 下查询教师，检查标签尾部维度后返回拼接的数据与标签。采集数据应 `detach`，不能携带策略或教师计算图。

import torch

def aggregate_dagger(old_obs,old_actions,visited,teacher):
    # TODO: 教师重标注和数据聚合，不让数据集持有计算图
    raise NotImplementedError


# ===== 断言测试 =====
teacher=torch.nn.Linear(1,1,bias=False)
with torch.no_grad(): teacher.weight.fill_(-0.5)
old_x=torch.zeros(2,1)
old_y=torch.zeros(2,1)
visited=torch.tensor([[1.],[2.]],requires_grad=True)
x,y=aggregate_dagger(old_x,old_y,visited,teacher)
assert x.shape==y.shape==(4,1)
torch.testing.assert_close(y[-2:],torch.tensor([[-0.5],[-1.]]))
assert not x.requires_grad and not y.requires_grad
assert teacher.weight.grad is None and len(old_x)==2
print('教师监督与聚合数据的梯度边界检查通过。')

print("所有提供的测试通过。")
