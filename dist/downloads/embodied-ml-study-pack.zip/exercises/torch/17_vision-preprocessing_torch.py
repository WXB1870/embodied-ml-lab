# 视觉预处理与坐标变换
# 环境：Python + PyTorch CPU
# 实现 resize_with_keypoints(image,points,out_hw)，约定与演示相同。返回归一化后的 CHW 图像和变换后关键点；只使用 torch，不使用 torchvision、PIL 或 NumPy。

import torch
from torch.nn import functional as F

def resize_with_keypoints(image, points, out_hw):
    # TODO: Letterbox 图像与关键点使用相同的实际几何参数
    raise NotImplementedError("请实现视觉预处理")


# ===== 断言测试 =====
image = torch.zeros(2,4,3,dtype=torch.uint8)
image[...,0] = 255
image[...,1] = torch.tensor([0,85,170,255],dtype=torch.uint8)
points = torch.tensor([[0.,0.],[3.,1.]],requires_grad=True)
output,mapped = resize_with_keypoints(image,points,(6,6))
assert output.shape == (3,6,6)
torch.testing.assert_close(mapped,torch.tensor([[.25,1.25],[4.75,2.75]]))
torch.testing.assert_close(output[0,1:4],torch.ones(3,6))
torch.testing.assert_close(output[:,0],torch.full((3,6),-1.))
# 半像素映射 x_src=(x_out+0.5)/1.5-0.5，边缘取最近像素。
# 绿色斜坡在源图中依次为 0、1/3、2/3、1；归一化后得到以下采样值。
expected_green = torch.tensor([-1.,-2/3,-2/9,2/9,2/3,1.])
torch.testing.assert_close(output[1,1],expected_green,atol=1e-6,rtol=1e-6)
mapped.sum().backward()
torch.testing.assert_close(points.grad,torch.full((2,2),1.5))
try:
    resize_with_keypoints(image.float(),points,(6,6))
    raise AssertionError("必须拒绝未声明范围的浮点输入")
except ValueError:
    pass
print("通过：RGB、补边、半像素插值、关键点几何、梯度和输入合同")

print("所有提供的测试通过。")
