# 微调与 LoRA
# 环境：Python + PyTorch CPU
# 实现 lora_forward(x,W,b,A,B,alpha)。按 \(\alpha/r\) 缩放低秩分支，支持 x 的任意前导维度。函数只实现前向；哪些输入需要梯度由调用者设置。

import torch
from torch.nn import functional as F

def lora_forward(x,W,b,A,B,alpha):
    # TODO: 原线性层 + 低秩更新
    raise NotImplementedError


# ===== 断言测试 =====
torch.manual_seed(3)
x = torch.randn(2,5,4)
W = torch.randn(3,4)
b = torch.randn(3)
A = torch.randn(2,4,requires_grad=True)
B = torch.randn(3,2,requires_grad=True)
y = lora_forward(x,W,b,A,B,4.)
merged = F.linear(x,W+2*(B@A),b)
torch.testing.assert_close(y,merged)
torch.testing.assert_close(lora_forward(x,W,b,A,torch.zeros_like(B),4.),F.linear(x,W,b))
y.square().mean().backward()
assert A.grad is not None and B.grad is not None and W.grad is None
print('LoRA 前向、合并等价性与梯度检查通过。')

print("所有提供的测试通过。")
