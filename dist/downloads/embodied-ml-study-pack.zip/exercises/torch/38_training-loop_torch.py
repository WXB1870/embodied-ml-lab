# 训练循环与指标归约
# 环境：Python + PyTorch CPU
# 实现 train_step：切换训练模式、清零梯度、计算 MSE、反向、更新，并返回更新前 loss 的 Python float。不使用梯度累积。

import torch

def train_step(model, optimizer, x, y):
    # TODO: 完成一次普通精度参数更新
    raise NotImplementedError("请实现训练步骤")


# ===== 断言测试 =====
model = torch.nn.Linear(1, 1, bias=False)
with torch.no_grad():
    model.weight.zero_()
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
model.eval()
x, y = torch.tensor([[1.]]), torch.tensor([[2.]])
first = train_step(model, optimizer, x, y)
assert abs(first-4.0) < 1e-6 and model.training
torch.testing.assert_close(model.weight, torch.tensor([[0.4]]))
second = train_step(model, optimizer, x, y)
assert abs(second-2.56) < 1e-5
torch.testing.assert_close(model.weight, torch.tensor([[0.72]]))
print("通过：反向、参数更新、清零梯度与训练模式")

print("所有提供的测试通过。")
