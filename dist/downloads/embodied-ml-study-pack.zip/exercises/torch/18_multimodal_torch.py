# 视觉编码器与多模态融合
# 环境：Python + PyTorch CPU
# 实现 masked_pool(tokens, valid)。tokens 为浮点张量 [B,N,D]，valid 为布尔张量 [B,N]。按有效 token 求平均；无效位置可含 NaN。某样本没有有效 token，或有效 token 非有限时，抛出 ValueError。验证每个有效 token 的梯度为 \(\frac{1}{n_{\rm valid}}\)。

import torch

def masked_pool(tokens, valid):
    # TODO: 在求和前替换无效位置，按每个样本的有效数量归一化
    raise NotImplementedError


# ===== 断言测试 =====
nan = float('nan')
x = torch.tensor([[[1.,2.],[3.,4.],[nan,nan]],
                  [[5.,6.],[nan,nan],[nan,nan]]], requires_grad=True)
valid = torch.tensor([[True,True,False],[True,False,False]])
y = masked_pool(x, valid)
torch.testing.assert_close(y, torch.tensor([[2.,3.],[5.,6.]]))
y.sum().backward()
torch.testing.assert_close(x.grad, torch.tensor([[[.5,.5],[.5,.5],[0.,0.]],
                                                [[1.,1.],[0.,0.],[0.,0.]]]))
for values, mask in [(x, torch.zeros_like(valid)),
                     (torch.full_like(x, nan), valid), (x, valid.float())]:
    try:
        masked_pool(values, mask)
        raise AssertionError('invalid pooling input must be rejected')
    except ValueError:
        pass
print('passed: per-example denominator, analytic gradient and ignored nonfinite padding')

print("所有提供的测试通过。")
