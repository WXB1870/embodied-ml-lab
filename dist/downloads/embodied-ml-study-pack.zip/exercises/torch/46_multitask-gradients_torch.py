# 多任务梯度
# 环境：Python + PyTorch CPU
# 实现 shared_gradient_report(loss_a, loss_b, parameters, weight_b)，返回字典 g_a、g_b、combined（展平 Tensor）与 cosine（float 或 None）。parameters 为同一组非空、需要梯度的参数列表，loss 为标量，weight_b 为非负有限数。用 autograd.grad 读取而不写 .grad，允许某些参数未参与任务并在原位置填零；保留图供之后 total.backward 使用。 非有限梯度或合成结果应拒绝；余弦采用独立尺度化，避免大数中间溢出。

import torch

def shared_gradient_report(loss_a, loss_b, parameters, weight_b):
    # TODO: 分别读取梯度，None 用同形状零填充，再按固定顺序展平
    raise NotImplementedError('请实现 shared_gradient_report')


# ===== 断言测试 =====
torch.manual_seed(340)
p = torch.nn.Parameter(torch.tensor([1.0, -2.0], dtype=torch.float64))
unused = torch.nn.Parameter(torch.tensor([5.0], dtype=torch.float64))
la = p.square().sum()
lb = (p - 1).square().sum()
report = shared_gradient_report(la, lb, [p, unused], 0.25)
torch.testing.assert_close(report['g_a'], torch.tensor([2.0, -4.0, 0.0], dtype=torch.float64))
torch.testing.assert_close(report['g_b'], torch.tensor([0.0, -6.0, 0.0], dtype=torch.float64))
assert p.grad is None and unused.grad is None
(la + 0.25 * lb).backward()
torch.testing.assert_close(report['combined'][:2], p.grad)
assert report['combined'][2] == 0 and unused.grad is None
zero_case = shared_gradient_report((p * 0).sum(), p.square().sum(), [p], 1)
assert zero_case['cosine'] is None
expected_cosine = 24 / ((20 ** 0.5) * 6)
assert abs(report['cosine'] - expected_cosine) < 1e-12
huge = torch.tensor([1e200, -1e200], dtype=torch.float64)
large_case = shared_gradient_report((p * huge).sum(), -(p * huge).sum(), [p], 1)
assert abs(large_case['cosine'] + 1) < 1e-12
torch.testing.assert_close(large_case['combined'], torch.zeros_like(p))
print('PyTorch 通过：实际求导、未用参数、零范数、大数余弦与总梯度对照')

print("所有提供的测试通过。")
