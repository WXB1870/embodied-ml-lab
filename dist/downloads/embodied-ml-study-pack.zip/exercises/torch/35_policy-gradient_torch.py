# 策略梯度
# 环境：Python + PyTorch CPU
# 实现 `gaussian_actor_loss(mu,log_std,actions,advantages)`。mu/actions 为 `[B,D]`，`log_std` 为 [D] 或 `[B,D]`，advantages 为 `[B]`。`log_std` clamp 到 [−5,2]，对动作轴求和；停止 action 与 advantage 的梯度，仅实现未压缩对角 Gaussian 的 score-function 损失。

import torch
from torch.distributions import Normal

def gaussian_actor_loss(mu,log_std,actions,advantages):
    # TODO: 正标准差、联合 log_prob、正确的梯度边界
    raise NotImplementedError


# ===== 断言测试 =====
mu=torch.zeros(1,2,requires_grad=True)
log_std=torch.zeros(2,requires_grad=True)
actions=torch.tensor([[1.,-2.]],requires_grad=True)
advantages=torch.tensor([2.],requires_grad=True)
loss=gaussian_actor_loss(mu,log_std,actions,advantages)
loss.backward()
torch.testing.assert_close(mu.grad,torch.tensor([[-2.,4.]]))
assert log_std.grad is not None
assert actions.grad is None and advantages.grad is None
# rsample 的路径必须停止，才能得到这里声明的 score-function 项。
torch.manual_seed(4)
m=torch.zeros(1,requires_grad=True)
d=Normal(m,torch.ones(1))
a=d.rsample()
bad=torch.autograd.grad(-d.log_prob(a).sum(),m,retain_graph=True)[0]
good=torch.autograd.grad(-d.log_prob(a.detach()).sum(),m)[0]
torch.testing.assert_close(bad,torch.zeros_like(bad))
assert good.abs().item()>1e-6
print('动作轴求和、可学习方差和 sample/rsample 梯度边界检查通过。')

print("所有提供的测试通过。")
