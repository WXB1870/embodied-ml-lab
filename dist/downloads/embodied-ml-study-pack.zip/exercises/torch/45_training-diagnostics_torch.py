# 训练诊断
# 环境：Python + PyTorch CPU
# 实现 audit_gradients(model, optimizer)，在 backward 后、清零前检查所有 requires_grad=True 的参数。返回 missing_optimizer、no_gradient、nonfinite_gradient、zero_gradient 四个按参数名称排序的列表；不改变梯度、参数或优化器。检查结果用于描述参数状态，不直接判定训练是否失败。

import torch

def audit_gradients(model, optimizer):
    # TODO: 用参数对象 id 判断优化器成员；检查 None、有限性和零范数
    raise NotImplementedError('请实现 audit_gradients')


# ===== 断言测试 =====
torch.manual_seed(310)
model = torch.nn.ParameterDict({name: torch.nn.Parameter(torch.ones(2))
                               for name in ['good', 'zero', 'nan', 'missing', 'frozen']})
model['frozen'].requires_grad_(False)
model['good'].grad = torch.tensor([1.0, -1.0])
model['zero'].grad = torch.zeros(2)
model['nan'].grad = torch.tensor([float('nan'), 1.0])
opt = torch.optim.SGD([model['good'], model['zero'], model['nan']], lr=0.1)
before = model['good'].grad.clone()
result = audit_gradients(model, opt)
assert result == {'missing_optimizer':['missing'], 'no_gradient':['missing'],
                  'nonfinite_gradient':['nan'], 'zero_gradient':['zero']}
torch.testing.assert_close(model['good'].grad, before)
assert model['missing'].grad is None
print('PyTorch 通过：真实参数、优化器成员与四类梯度状态')

print("所有提供的测试通过。")
