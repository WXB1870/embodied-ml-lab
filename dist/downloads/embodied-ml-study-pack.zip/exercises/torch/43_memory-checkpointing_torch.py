# 训练显存与重计算
# 环境：Python + PyTorch CPU
# 实现 checkpointed_forward(block, x)，调用 activation checkpoint 并返回与 block(x) 等价的结果。要求 use_reentrant=False、保留随机数状态；x 可以不需要梯度，但 block 参数需要梯度。测试包含 Dropout、无输入梯度和保存量检查，不能直接返回普通前向冒充重计算。

import torch
from torch.utils.checkpoint import checkpoint

def checkpointed_forward(block, x):
   # TODO: 使用非重入 checkpoint，保留随机状态
   raise NotImplementedError('请实现 checkpointed_forward')


# ===== 断言测试 =====
torch.manual_seed(320)
block = torch.nn.Sequential(torch.nn.Linear(8, 32), torch.nn.Dropout(0.3),
                            torch.nn.GELU(), torch.nn.Linear(32, 4))
x = torch.randn(5, 8)  # 故意不要求输入梯度
def evaluate(fn):
    block.zero_grad(set_to_none=True)
    sizes = []
    def pack(t):
        sizes.append(t.numel() * t.element_size())
        return t
    torch.manual_seed(321)
    with torch.autograd.graph.saved_tensors_hooks(pack, lambda t: t):
        out = fn(block, x)
        loss = out.square().mean()
    loss.backward()
    return out.detach(), [p.grad.clone() for p in block.parameters()], sum(sizes)
a, ga, na = evaluate(lambda m, v: m(v))
b, gb, nb = evaluate(checkpointed_forward)
torch.testing.assert_close(a, b)
for p, q in zip(ga, gb):
    torch.testing.assert_close(p, q)
assert nb < na, '应真正减少反向保存量'
assert not x.requires_grad
print('PyTorch 通过：无输入梯度、Dropout 一致性与实际重计算')

print("所有提供的测试通过。")
