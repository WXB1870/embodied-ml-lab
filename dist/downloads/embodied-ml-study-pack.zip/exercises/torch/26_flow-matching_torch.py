# Flow Matching
# 环境：Python + PyTorch CPU
# 实现 flow_training_pair(noise, action, t)。noise/action 为 [B,H,D]，t 为 [B] 且位于 [0,1]。返回 \(x_t\) 与 velocity_target，采用噪声→数据的时间约定。

import torch

def flow_training_pair(noise, action, t):
    # TODO: 将 t 转成可广播的形状，并计算路径与速度
    raise NotImplementedError


# ===== 断言测试 =====
z = torch.zeros(3,2,2)
a = torch.full_like(z,2.)
x,u = flow_training_pair(z,a,torch.tensor([0.,0.5,1.]))
torch.testing.assert_close(x[0],z[0])
torch.testing.assert_close(x[1],torch.ones(2,2))
torch.testing.assert_close(x[2],a[2])
torch.testing.assert_close(u,torch.full_like(z,2.))

# 噪声不能总为零，否则遗漏噪声端点或速度中的负号也会通过
nonzero_noise = torch.tensor([[[1., -1.]], [[2., 4.]], [[-3., 2.]]])
nonconstant_action = torch.tensor([[[3., 5.]], [[-2., 6.]], [[7., -4.]]])
x_nonzero, u_nonzero = flow_training_pair(
    nonzero_noise, nonconstant_action, torch.tensor([0., 0.25, 1.]))
expected_x = torch.tensor([[[1., -1.]], [[1., 4.5]], [[7., -4.]]])
expected_u = torch.tensor([[[2., 6.]], [[-4., 2.]], [[10., -6.]]])
torch.testing.assert_close(x_nonzero, expected_x)
torch.testing.assert_close(u_nonzero, expected_u)

print('Flow Matching 路径、时间广播和速度符号检查通过。')

print("所有提供的测试通过。")
