# PyTorch 模块、参数与状态
# 环境：Python + PyTorch CPU
# 完成 NormalizedProjector。将 mean、scale 注册为持久 Buffer，创建一个 Linear(dim,4) 作为 proj，并在 forward 中标准化输入后投影。

import torch
from torch import nn

class NormalizedProjector(nn.Module):
    def __init__(self, mean, scale):
        super().__init__()
        # TODO: 注册统计量并创建投影层
        raise NotImplementedError("请初始化特征投影模块")

    def forward(self, x):
        # TODO: 使用已注册的状态
        raise NotImplementedError("请完成前向")


# ===== 断言测试 =====
torch.manual_seed(17)
model = NormalizedProjector(torch.tensor([1.,2.]), torch.tensor([2.,4.]))
assert set(dict(model.named_buffers())) == {"mean", "scale"}
assert set(dict(model.named_parameters())) == {"proj.weight", "proj.bias"}
assert {"mean", "scale"}.issubset(model.state_dict())
model = model.to(dtype=torch.float64)
assert model.mean.dtype == torch.float64 and model.scale.dtype == torch.float64
x = model.mean[None]
assert model(x).shape == (1, 4)
torch.testing.assert_close(model(x), model.proj.bias[None])
print("通过：注册、序列化、dtype 迁移与前向")

print("所有提供的测试通过。")
