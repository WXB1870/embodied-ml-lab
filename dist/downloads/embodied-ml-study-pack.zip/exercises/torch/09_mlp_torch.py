# MLP：表达、梯度与优化
# 环境：Python + PyTorch CPU
# 实现 SequenceClassifier(in_dim, hidden_dim, num_classes)：输入 features 为 [B,T,D] 的等长、全有效、有限浮点序列，B,T>0。先仅沿 T 轴平均，再执行带偏置 Linear(D,H)→SiLU→Linear(H,K)，返回 [B,K] 的未归一化 logits。必须正确注册模块，不得在输出端做 Softmax；不要求处理 Padding。

import torch
from torch import nn

class SequenceClassifier(nn.Module):
    def __init__(self, in_dim, hidden_dim, num_classes):
        super().__init__()
        # TODO: 注册两层带偏置 Linear 与隐藏 SiLU
        raise NotImplementedError("请初始化分类器")

    def forward(self, features):
        # TODO: 沿时间轴平均，返回类别 logits
        raise NotImplementedError("请实现 forward")


# ===== 断言测试 =====
torch.manual_seed(0)
model = SequenceClassifier(8, 16, 4).double()
linears = [m for m in model.modules() if isinstance(m, nn.Linear)]
assert len(linears) == 2
first, last = linears
assert tuple(first.weight.shape) == (16, 8)
assert tuple(last.weight.shape) == (4, 16)
assert first.bias is not None and last.bias is not None
assert sum(p.numel() for p in model.parameters()) == 212
with torch.no_grad():
    first.weight.copy_(torch.arange(128, dtype=torch.float64).reshape(16, 8) / 128 - 0.5)
    first.bias.copy_(torch.linspace(-0.3, 0.3, 16, dtype=torch.float64))
    last.weight.copy_(torch.arange(64, dtype=torch.float64).reshape(4, 16) / 64 - 0.5)
    last.bias.copy_(torch.tensor([-1.0, 0.5, 1.0, -0.5], dtype=torch.float64))
x = (torch.arange(80, dtype=torch.float64).reshape(2, 5, 8) / 80 - 0.5).requires_grad_()
y = model(x)
pooled = x.mean(dim=1)
z = pooled @ first.weight.T + first.bias
expected = (z * torch.sigmoid(z)) @ last.weight.T + last.bias
torch.testing.assert_close(y, expected)
assert y.shape == (2, 4)
torch.testing.assert_close(model(x.flip(1)), y)
loss = torch.nn.functional.cross_entropy(y, torch.tensor([1, 3]))
loss.backward()
assert x.grad is not None and torch.isfinite(x.grad).all() and x.grad.abs().sum() > 0
assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
assert model(torch.randn(1, 1, 8, dtype=torch.float64)).shape == (1, 4)
with torch.no_grad():
    last.weight.zero_()
    last.bias.copy_(torch.tensor([-2., 0., 3., -1.], dtype=torch.float64))
torch.testing.assert_close(model(x), last.bias.expand(2, 4))
print("通过：固定权重数值、时间池化、模块注册、梯度与 logits 约定")

print("所有提供的测试通过。")
