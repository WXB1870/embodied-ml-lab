# 梯度累积
# 环境：Python + PyTorch CPU
# 实现 accumulate_gradients(model, microbatches)。microbatches 是非空列表，每项为 (x, y, valid)，其中 y 和布尔 valid 同形状且数值有限。仅在 valid 为 True 的标量上计算全局 MSE，累积到 model 参数 .grad，返回总有效数；不更新参数。即使某一微批次没有有效元素也要正确处理；总有效数为零时抛出 ValueError。

import torch

def accumulate_gradients(model, microbatches):
    # TODO: 窗口开始清零，各微批次 sum 除以全局有效数
    raise NotImplementedError('请实现 accumulate_gradients')


# ===== 断言测试 =====
import copy
torch.manual_seed(290)
model = torch.nn.Linear(2, 1).double()
reference = copy.deepcopy(model)
x = torch.randn(6, 2, dtype=torch.float64)
y = torch.randn(6, 1, dtype=torch.float64)
valid = torch.tensor([[1], [0], [0], [1], [1], [1]], dtype=torch.bool)
parts = [slice(0, 1), slice(1, 3), slice(3, 6)]
batches = [(x[s], y[s], valid[s]) for s in parts]
before = [p.detach().clone() for p in model.parameters()]
assert accumulate_gradients(model, batches) == 4
((reference(x) - y).square()[valid].mean()).backward()
for p, q, old in zip(model.parameters(), reference.parameters(), before):
    torch.testing.assert_close(p.grad, q.grad, atol=1e-12, rtol=1e-12)
    torch.testing.assert_close(p, old)
try:
    accumulate_gradients(model, [(x, y, torch.zeros_like(valid))])
except ValueError:
    pass
else:
    raise AssertionError('应拒绝全无效窗口')
print('PyTorch 通过：不等微批次与零有效微批次的累积')

print("所有提供的测试通过。")
