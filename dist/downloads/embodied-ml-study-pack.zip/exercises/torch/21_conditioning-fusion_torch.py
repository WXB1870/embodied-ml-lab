# 条件注入：拼接、FiLM 与 AdaLN
# 环境：Python + PyTorch CPU
# 实现 adaptive_layer_norm(x,condition,modulator)。x=[B,T,D]，modulator(condition)=[B,2D]，前 D 是 scale，后 D 是 shift。使用无固定仿射的 LayerNorm，再做 `(1 + scale) * LN(x) + shift`。

import torch
from torch.nn import functional as F

def adaptive_layer_norm(x, condition, modulator, eps=1e-5):
    # TODO: 生成逐样本条件，正确广播并调制
    raise NotImplementedError("请实现 AdaLN")


# ===== 断言测试 =====
torch.manual_seed(40)
x = torch.randn(2,3,4,requires_grad=True)
condition = torch.randn(2,2,requires_grad=True)
modulator = torch.nn.Linear(2,8)
torch.nn.init.zeros_(modulator.weight)
torch.nn.init.zeros_(modulator.bias)
torch.testing.assert_close(adaptive_layer_norm(x,condition,modulator),
                           F.layer_norm(x,(4,),eps=1e-5))
torch.nn.init.normal_(modulator.weight,std=0.1)
before = adaptive_layer_norm(x,condition,modulator)
changed = condition.detach().clone()
changed[0] += 1
after = adaptive_layer_norm(x,changed,modulator)
torch.testing.assert_close(before[1],after[1])
assert not torch.allclose(before[0],after[0])
before.square().mean().backward()
assert condition.grad is not None and torch.isfinite(condition.grad).all()
assert modulator.weight.grad is not None
print("通过：零调制、广播隔离与条件梯度")

print("所有提供的测试通过。")
