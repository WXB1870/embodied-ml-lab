# 残差连接与深层优化
# 环境：Python + PyTorch CPU
# 实现 residual_forward。pre_norm=True 时返回 x+branch(norm(x))，否则返回 norm(x+branch(x))；不要原地修改 x。 保留 Norm 统计量和分支的全部梯度路径；测试包含非零线性分支的完整输入 Jacobian。

import torch
from torch import nn

def residual_forward(x, branch, norm, pre_norm=True):
    # TODO: 按两种结构完成前向
    raise NotImplementedError("请实现残差前向")


# ===== 断言测试 =====
torch.manual_seed(12)
x = torch.randn(2, 3, 4, requires_grad=True)
original = x.detach().clone()
norm = nn.LayerNorm(4)
zero_branch = lambda z: z * 0
a = residual_forward(x, zero_branch, norm, True)
b = residual_forward(x, zero_branch, norm, False)
torch.testing.assert_close(a, original)
torch.testing.assert_close(b, norm(original))
torch.testing.assert_close(x, original)
a.sum().backward()
torch.testing.assert_close(x.grad, torch.ones_like(x))
print("通过：两种结构、非原地操作与恒等梯度")

# 非零分支：验证两个复合 Jacobian 的乘法顺序，而不只测置零特例。
v = torch.tensor([0.2, -1.0, 2.0, 0.8], dtype=torch.float64, requires_grad=True)
w = torch.tensor([[0.1, 0.2, 0., -0.1], [-0.2, 0.1, 0.3, 0.],
                  [0., -0.1, 0.2, 0.1], [0.3, 0., -0.2, 0.1]], dtype=v.dtype)
eps = 1e-3
layer_norm = nn.LayerNorm(4, eps=eps, elementwise_affine=False).double()
branch = lambda z: w @ z

def norm_jacobian(z):
    centered = z - z.mean()
    r = (centered.square().mean() + eps).sqrt()
    p = torch.eye(4, dtype=z.dtype) - torch.ones(4, 4, dtype=z.dtype) / 4
    return p / r - torch.outer(centered, centered) / (4 * r ** 3)

for pre in (True, False):
    actual = torch.autograd.functional.jacobian(lambda z: residual_forward(z, branch, layer_norm, pre), v)
    expected = (torch.eye(4, dtype=v.dtype) + w @ norm_jacobian(v) if pre else
                norm_jacobian(v + w @ v) @ (torch.eye(4, dtype=v.dtype) + w))
    torch.testing.assert_close(actual, expected, rtol=1e-9, atol=1e-10)
print("通过：非零分支的 Pre-Norm / Post-Norm 完整 Jacobian")

print("所有提供的测试通过。")
