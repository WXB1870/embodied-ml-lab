# 部分观测与记忆
# 环境：Python + PyTorch CPU
# 实现 `reset_hidden(hidden, reset_mask, truncate)`。hidden 为 `[L,B,H]`，`reset_mask` 为 `[B]` 布尔值。`truncate=True` 时先 `detach`，再将需重置的环境 hidden 清零；False 时保留其余环境的梯度路径。

import torch

def reset_hidden(hidden, reset_mask, truncate):
    # TODO: 区分梯度边界和回合边界
    raise NotImplementedError


# ===== 断言测试 =====
h=torch.ones(2,3,4,requires_grad=True)
m=torch.tensor([False,True,False])
out=reset_hidden(h,m,False)
assert torch.count_nonzero(out[:,1])==0
out.sum().backward()
torch.testing.assert_close(h.grad[:,0],torch.ones(2,4))
torch.testing.assert_close(h.grad[:,1],torch.zeros(2,4))
detached=reset_hidden(h,m,True)
assert not detached.requires_grad
assert torch.equal(detached[:,0],h[:,0])
print('按环境 reset 与截断 BPTT 的梯度检查通过。')

print("所有提供的测试通过。")
