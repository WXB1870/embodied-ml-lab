# 线性代数与矩阵求导
# 环境：Python + PyTorch CPU
# 不用 autograd，返回半均方误差对 W、b 的解析梯度。W 为 [O,I]，X 为 [B,I]，Y 为 [B,O]。

import torch

def linear_grads(X, Y, W, b):
    # TODO: 返回与 W、b 形状相同的梯度
    raise NotImplementedError("请实现 linear_grads")


# ===== 断言测试 =====
torch.manual_seed(4)
X = torch.randn(5, 3, dtype=torch.float64)
Y = torch.randn(5, 2, dtype=torch.float64)
W = torch.randn(2, 3, dtype=torch.float64, requires_grad=True)
b = torch.randn(2, dtype=torch.float64, requires_grad=True)
loss = 0.5 * (X @ W.T + b - Y).square().mean()
loss.backward()
dW, db = linear_grads(X, Y, W.detach(), b.detach())
assert dW.shape == W.shape and db.shape == b.shape
assert torch.allclose(dW, W.grad, atol=1e-10)
assert torch.allclose(db, b.grad, atol=1e-10)
print("PyTorch 测试通过：多输出维度的分母正确。")

print("所有提供的测试通过。")
