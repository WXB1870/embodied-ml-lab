# PyTorch 自动微分与计算图
# 环境：Python + PyTorch CPU
# 冻结 backbone 参数，然后计算 head(backbone(adapter(x)))。必须使 Adapter 与 Head 都可获得梯度。禁止 detach 或把骨干前向放进 no_grad。

import torch
from torch import nn

def forward_frozen(adapter, backbone, head, x):
    # TODO: 冻结参数，同时保留必要的计算图
    raise NotImplementedError("请实现 forward_frozen")


# ===== 断言测试 =====
torch.manual_seed(2)
adapter = nn.Linear(3, 3, bias=False)
backbone = nn.Linear(3, 3, bias=False)
head = nn.Linear(3, 1, bias=False)
with torch.no_grad():
    backbone.weight.copy_(torch.eye(3))
x = torch.randn(4, 3)
output = forward_frozen(adapter, backbone, head, x)
output.square().sum().backward()
assert all(not p.requires_grad for p in backbone.parameters())
assert all(p.grad is None for p in backbone.parameters())
assert adapter.weight.grad is not None and adapter.weight.grad.norm() > 0
assert head.weight.grad is not None and head.weight.grad.norm() > 0
print("PyTorch 测试通过：冻结与梯度路径均正确。")

print("所有提供的测试通过。")
