# 视觉编码器与多模态融合
# 环境：Python 标准库
# 实现 pack_multiview(text_tokens, cameras)。先放文本 token，再按相机顺序拼接 token；同时返回每个相机的半开区间 (start,end)。不要修改输入列表。

def pack_multiview(text_tokens, cameras):
    # TODO: 返回 (packed_tokens, camera_spans)
    raise NotImplementedError("请完成多视角 token 打包")


# ===== 断言测试 =====
text_tokens = ["抓", "红杯"]
cameras = [["front0", "front1"], ["wrist0"], []]
packed, spans = pack_multiview(text_tokens, cameras)
assert packed == ["抓", "红杯", "front0", "front1", "wrist0"]
assert spans == [(2, 4), (4, 5), (5, 5)]
assert text_tokens == ["抓", "红杯"] and cameras[0] == ["front0", "front1"]
assert packed[spans[1][0]:spans[1][1]] == ["wrist0"]
assert pack_multiview([], []) == ([], [])
print("通过：顺序、半开区间、空视角与输入不变")

print("所有提供的测试通过。")
