# PyTorch 模块、参数与状态
# 环境：Python 标准库
# 每个规格含 kind、shape、trainable。实现 count_trainable(specs)，只累加 kind='parameter' 且 trainable=True 的形状元素乘积，Buffer 不计入。

def count_trainable(specs):
    # TODO: 按 kind 与 trainable 过滤，再计算元素数
    raise NotImplementedError("请统计可训练参数")


# ===== 断言测试 =====
specs = [
    {"kind":"parameter", "shape":[4,8], "trainable":True},
    {"kind":"parameter", "shape":[4], "trainable":True},
    {"kind":"parameter", "shape":[8,8], "trainable":False},
    {"kind":"buffer", "shape":[8], "trainable":False},
]
assert count_trainable(specs) == 36
assert count_trainable([]) == 0
assert count_trainable([{"kind":"parameter","shape":[],"trainable":True}]) == 1
assert count_trainable([{"kind":"buffer","shape":[99],"trainable":True}]) == 0
print("通过：冻结过滤、Buffer 排除和标量参数")

print("所有提供的测试通过。")
