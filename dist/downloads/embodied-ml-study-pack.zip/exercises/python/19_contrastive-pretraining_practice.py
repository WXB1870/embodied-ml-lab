# 图文预训练：CLIP 与 SigLIP
# 环境：Python 标准库
# 实现 symmetric_pair_ce(scores)。输入为非空方阵，正例在主对角线。分别计算行方向和列方向交叉熵后取平均，使用稳定的 log-sum-exp。

def symmetric_pair_ce(scores):
    # TODO: 正确配对为对角线，计算两个方向
    raise NotImplementedError("请实现图文配对损失")


# ===== 断言测试 =====
import math
assert abs(symmetric_pair_ce([[2.,0.],[0.,2.]])-math.log1p(math.exp(-2))) < 1e-12
assert abs(symmetric_pair_ce([[0.,0.],[0.,0.]])-math.log(2)) < 1e-12
expected = (2*math.log1p(math.exp(-2)) + math.log1p(math.exp(-1))
            + math.log1p(math.exp(-3))) / 4
assert abs(symmetric_pair_ce([[2.,0.],[1.,3.]])-expected) < 1e-12
assert symmetric_pair_ce([[1000.]]) == 0
print("通过：双向目标、非对称矩阵与稳定归约")

print("所有提供的测试通过。")
