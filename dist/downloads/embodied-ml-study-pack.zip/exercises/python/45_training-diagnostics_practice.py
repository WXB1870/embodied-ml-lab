# 训练诊断
# 环境：Python 标准库
# 实现 classify_records(records)，返回字典，键为 missing_optimizer、no_gradient、nonfinite_gradient、zero_gradient，对应按字母排序的参数名列表。每条记录含 name、trainable、in_optimizer 和 grad（None 或非空数列表）。只诊断 trainable=True 的记录；类别允许重叠，但非有限梯度不归入 zero_gradient。

def classify_records(records):
     # TODO: 区分 None、全零与非有限值；冻结参数不计入异常
     raise NotImplementedError('请实现 classify_records')


# ===== 断言测试 =====
records = [
    dict(name='good', trainable=True, in_optimizer=True, grad=[1, -2]),
    dict(name='missing', trainable=True, in_optimizer=False, grad=None),
    dict(name='zero', trainable=True, in_optimizer=True, grad=[0, 0]),
    dict(name='nan', trainable=True, in_optimizer=True, grad=[float('nan'), 1]),
    dict(name='frozen', trainable=False, in_optimizer=False, grad=None)]
assert classify_records(records) == {'missing_optimizer':['missing'], 'no_gradient':['missing'],
                                    'nonfinite_gradient':['nan'], 'zero_gradient':['zero']}
assert classify_records([]) == {k: [] for k in classify_records(records)}
print('通过：状态区分、重叠分类和冻结参数排除')

print("所有提供的测试通过。")
