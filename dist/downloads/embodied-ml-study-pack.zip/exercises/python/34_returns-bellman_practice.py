# 回报与 Bellman 方程
# 环境：Python 标准库
# 实现 `discounted_returns(rewards,gamma,bootstrap=0.0)`。输入是一段连续轨迹，按 \(G_t=r_t+\gamma G_{t+1}\) 倒序计算。\(\gamma\in[0,1]\)，完整终止片段使用 `bootstrap=0`。

def discounted_returns(rewards,gamma,bootstrap=0.0):
    # TODO: 从片段末端向前递推，不跨 episode
    raise NotImplementedError


# ===== 断言测试 =====
a=discounted_returns([1,2,3],0.9)
assert all(abs(x-y)<1e-10 for x,y in zip(a,[5.23,4.7,3.]))
b=discounted_returns([1,2,3],0.9,4.)
assert all(abs(x-y)<1e-10 for x,y in zip(b,[8.146,7.94,6.6]))
assert discounted_returns([1,2],0.0,99.)==[1.,2.]
assert discounted_returns([],0.9)==[]
print('回报、折扣和片段末 bootstrap 检查通过。')

print("所有提供的测试通过。")
