# 损失、掩码与归约
# 环境：Python 标准库
# errors 是 [T,D] 的误差列表，valid 标记有效时刻，weights 是非负维度权重。返回有效权重归一化后的平方误差；分母为零时抛出 ValueError。

def masked_weighted_error(errors, valid, weights):
    # TODO: 使用相同的有效权重计算分子和分母
    raise NotImplementedError("请实现 masked_weighted_error")


# ===== 断言测试 =====
e = [[1., 2.], [3., 4.], [100., 100.]]
assert abs(masked_weighted_error(e, [True, True, False], [1., 2.]) - 50/6) < 1e-12
assert masked_weighted_error(e, [True, True, False], [1., 0.]) == 5.
assert masked_weighted_error([[2.]], [True], [1.]) == 4.
for mask, weights in [([False, False, False], [1., 2.]), ([True]*3, [0., 0.])]:
    try:
        masked_weighted_error(e, mask, weights)
    except ValueError:
        pass
    else:
        raise AssertionError("零分母应显式处理")
print("通过：加权、Padding 排除和零分母处理。")

print("所有提供的测试通过。")
