# 条件注入：拼接、FiLM 与 AdaLN
# 环境：Python 标准库
# 实现 film_batch(features,gamma,beta)。features 为 [B,T,D] 的嵌套列表，gamma/beta 为 [B,D]；返回逐元素 `gamma[b][d] * features[b][t][d] + beta[b][d]`，不修改输入。

def film_batch(features, gamma, beta):
    # TODO: 条件只在同一样本的时间位置之间共享
    raise NotImplementedError("请实现 FiLM")


# ===== 断言测试 =====
x = [[[1,2],[3,4]],[[5,6],[7,8]]]
gamma,beta = [[2,1],[1,0]],[[0,-1],[3,4]]
y = film_batch(x,gamma,beta)
assert y == [[[2,1],[6,3]],[[8,4],[10,4]]]
changed = film_batch(x,[[4,1],[1,0]],beta)
assert changed[1] == y[1] and changed[0] != y[0]
assert x == [[[1,2],[3,4]],[[5,6],[7,8]]]
assert film_batch([[]],[[1,1]],[[0,0]]) == [[]]
print("通过：逐通道调制、样本隔离和不修改输入")

print("所有提供的测试通过。")
