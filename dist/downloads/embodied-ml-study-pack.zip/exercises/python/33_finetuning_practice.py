# 微调与 LoRA
# 环境：Python 标准库
# 实现 parameter_counts(in_dim,out_dim,rank)。返回包含 frozen 与 trainable 的字典。原层含偏置且全部冻结；低秩 A/B 不含偏置。维度与 rank 都必须是正整数。

def parameter_counts(in_dim, out_dim, rank):
    # TODO: 分别统计原层和两个低秩矩阵
    raise NotImplementedError


# ===== 断言测试 =====
assert parameter_counts(8,6,2) == {'frozen':54,'trainable':28}
assert parameter_counts(4,3,2) == {'frozen':15,'trainable':14}
assert parameter_counts(4,4,4) == {'frozen':20,'trainable':32}
try:
    parameter_counts(8,6,0)
    raise AssertionError('零秩应报错')
except ValueError:
    pass
print('参数量检查通过：较大的 rank 不保证参数更少。')

print("所有提供的测试通过。")
