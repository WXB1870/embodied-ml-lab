# 训练循环与指标归约
# 环境：Python 标准库
# 输入 batch_stats 中每项为 (平方误差总和, 有效元素数)。实现 aggregate_mse；总有效元素数为零时抛出 ValueError。

def aggregate_mse(batch_stats):
    # TODO: 汇总分子与分母，最后再相除
    raise NotImplementedError("请实现 MSE 汇总")


# ===== 断言测试 =====
assert aggregate_mse([(4.0, 2), (0.0, 2)]) == 1.0
assert abs(aggregate_mse([(9.0, 9), (9.0, 1)])-1.8) < 1e-12
assert aggregate_mse([(0.0, 0), (6.0, 3)]) == 2.0
try:
    aggregate_mse([(0.0, 0)])
    raise AssertionError("没有有效元素时不能给出正常指标")
except ValueError:
    pass
print("通过：按有效元素加权，避免 Batch 均值再平均")

print("所有提供的测试通过。")
