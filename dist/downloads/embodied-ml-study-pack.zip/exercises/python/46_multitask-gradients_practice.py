# 多任务梯度
# 环境：Python 标准库
# 实现 gradient_relation(g_a, g_b, weight)，返回 (combined, cosine)。两个输入为等长非空有限数列表，weight 为有限非负数；combined = g_a + weight*g_b。cosine 比较两个原始梯度，任一个范数为零时返回 None。非法输入抛 ValueError。 合成梯度溢出时抛 ValueError；余弦应避免直接相乘大数范数造成的中间溢出。

def gradient_relation(g_a, g_b, weight):
     # TODO: 同顺序合成梯度；零范数时明确表示夹角未定义
     raise NotImplementedError('请实现 gradient_relation')


# ===== 断言测试 =====
combined, cosine = gradient_relation([1, 0], [-2, 0], 0.5)
assert combined == [0, 0] and cosine == -1
assert gradient_relation([1, 0], [0, 2], 2) == ([1, 4], 0.0)
assert gradient_relation([0, 0], [1, 2], 3) == ([3, 6], None)
assert gradient_relation([1, 2], [1, 2], 0)[0] == [1, 2]
for args in [([], [], 1), ([1], [1, 2], 1), ([1], [float('nan')], 1)]:
    try:
        gradient_relation(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法向量')
assert gradient_relation([1e200, 0], [-1e200, 0], 1) == ([0, 0], -1.0)
assert abs(gradient_relation([1.7e308, 1.7e308], [1.7e308, 1.7e308], 0)[1] - 1) < 1e-12
try:
    gradient_relation([1e308], [1e308], 1)
except ValueError:
    pass
else:
    raise AssertionError('应拒绝合成梯度溢出')
print('通过：抵消、正交、零范数、大数余弦与输入边界')

print("所有提供的测试通过。")
