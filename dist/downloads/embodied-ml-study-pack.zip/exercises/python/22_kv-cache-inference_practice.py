# KV Cache 与增量计算
# 环境：Python 标准库
# 实现 incremental_allowed(past_len,new_len)。返回 new_len 行、past_len+new_len 列的布尔矩阵，第 i 个查询位置为 `past_len+i`；负长度和 `new_len=0` 应抛出 ValueError。

def incremental_allowed(past_len, new_len):
    # TODO: 使用绝对查询位置决定每行可读的键
    raise NotImplementedError("请完成增量 Mask")


# ===== 断言测试 =====
assert incremental_allowed(3,2) == [[True,True,True,True,False],[True,True,True,True,True]]
assert incremental_allowed(0,3) == [[True,False,False],[True,True,False],[True,True,True]]
assert incremental_allowed(5,1) == [[True]*6]
try:
    incremental_allowed(2,0)
    raise AssertionError("空增量应被拒绝")
except ValueError:
    pass
print("通过：历史偏移、分块和单 token Decode")

print("所有提供的测试通过。")
