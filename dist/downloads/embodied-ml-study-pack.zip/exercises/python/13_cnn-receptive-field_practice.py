# CNN：卷积、采样与空间表示
# 环境：Python 标准库
# 实现 conv_geometry(size,layers)。每层为 (kernel,stride,padding,dilation)，返回 (最终尺寸,感受野,累计步长)。一维计算代表图像的一条轴；无效参数或无输出位置时抛出 ValueError。

def conv_geometry(size, layers):
    # TODO: 同时维护 size、receptive、jump
    raise NotImplementedError("请完成卷积几何递推")


# ===== 断言测试 =====
assert conv_geometry(9, [(3,2,1,1), (3,1,0,1)]) == (3,7,2)
assert conv_geometry(7, [(3,1,2,2)]) == (7,5,1)
assert conv_geometry(8, [(4,4,0,1)]) == (2,4,4)
assert conv_geometry(5, []) == (5,1,1)
try:
    conv_geometry(2, [(5,1,0,1)])
    raise AssertionError("无有效输出应被拒绝")
except ValueError:
    pass
print("通过：尺寸、Dilation、累计步长与感受野")

print("所有提供的测试通过。")
