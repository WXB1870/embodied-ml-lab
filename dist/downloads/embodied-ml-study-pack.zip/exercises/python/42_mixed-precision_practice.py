# 混合精度训练
# 环境：Python 标准库
# 实现 unscale_and_clip(scaled_grad, scale, max_norm)，输入为非空的有限数列表，返回 (真实裁剪前范数, 裁剪后梯度列表)。scale 必须为有限正数，max_norm 为有限非负数；输入非法时抛 ValueError。零梯度应保持为零。只用标准库。反缩放结果或其范数超出浮点有限范围时，也应抛 ValueError。

def unscale_and_clip(scaled_grad, scale, max_norm):
     # TODO: 先除以 scale，再按真实梯度的 L2 范数统一缩放
     raise NotImplementedError('请实现 unscale_and_clip')


# ===== 断言测试 =====
norm, grad = unscale_and_clip([24, 32], 8, 2.5)
assert abs(norm - 5) < 1e-12 and grad == [1.5, 2.0]
assert unscale_and_clip([3, 4], 1, 10) == (5.0, [3.0, 4.0])
assert unscale_and_clip([0, 0], 16, 0) == (0.0, [0.0, 0.0])
for args in [([1], 0, 1), ([1], 1, -1), ([float('inf')], 1, 1), ([1e308], 1e-308, 1.0), ([1.7e308, 1.7e308], 1, 1)]:
    try:
        unscale_and_clip(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法输入')
print('通过：反缩放顺序、阈值和零梯度')

print("所有提供的测试通过。")
