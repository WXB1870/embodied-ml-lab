# 视觉预处理与坐标变换
# 环境：Python 标准库
# 实现 map_letterbox_point(point,original_hw,target_hw)。使用正数四舍五入 `int(value+0.5)` 确定缩放尺寸，居中补边，像素中心约定与 align_corners=False 对齐。返回 (u',v')。

def map_letterbox_point(point, original_hw, target_hw):
    # TODO: 实际缩放尺寸、补边与半像素变换
    raise NotImplementedError("请同步关键点")


# ===== 断言测试 =====
assert map_letterbox_point((2,1),(4,8),(8,8)) == (2.0,3.0)
assert map_letterbox_point((0,0),(4,4),(8,8)) == (0.5,0.5)
assert map_letterbox_point((3,2),(5,9),(5,9)) == (3.0,2.0)
u,v = map_letterbox_point((4,2),(5,9),(12,12))
assert abs(u-5.5) < 1e-12
assert abs(v-5.0) < 1e-12
print("通过：补边、半像素、恒等变换和整数尺寸")

print("所有提供的测试通过。")
