# Diffusion：DDPM、目标参数化与 DDIM
# 环境：Python 标准库
# 实现 add_noise(clean, noise, alpha_bar)，返回同长度列表。alpha_bar 必须位于 [0,1]；长度不一致要报错。端点分别应该恢复 clean 和 noise。

import math

def add_noise(clean, noise, alpha_bar):
    # TODO: 使用累计 alpha，而不是直接用 beta
    raise NotImplementedError


# ===== 断言测试 =====
assert add_noise([2.,-1.],[0.5,0.2],1.) == [2.,-1.]
assert add_noise([2.,-1.],[0.5,0.2],0.) == [0.5,0.2]
y = add_noise([2.],[0.],0.25)
assert abs(y[0]-1.) < 1e-12
try:
    add_noise([1.],[0.],1.1)
    raise AssertionError('非法系数应报错')
except ValueError:
    pass
print('加噪公式及两个端点检查通过。')

print("所有提供的测试通过。")
