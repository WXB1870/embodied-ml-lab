# 分词、自回归与标签对齐
# 环境：Python 标准库
# 实现 next_token_example(ids,valid_length,prompt_length)。返回 `input_ids=ids[:-1]`、同长度 attention_mask 和 targets。targets 对应原位置 \(1,\ldots,T-1\)；原索引小于 prompt_length 或不在 valid_length 内时为 −100。允许真实 EOS 与 Padding 同为 0。

def next_token_example(ids, valid_length, prompt_length):
    # TODO: 用原位置而不是 token 数值决定监督有效性
    raise NotImplementedError("请完成下一 token 对齐")


# ===== 断言测试 =====
a = next_token_example([1,2,3,9,0,0], 5, 3)
assert a["targets"] == [-100,-100,9,0,-100]
assert a["input_ids"] == [1,2,3,9,0]
assert a["attention_mask"] == [True]*5
b = next_token_example([1,2,8,6,0,0], 4, 2)
assert b["targets"] == [-100,8,6,-100,-100]
assert b["attention_mask"] == [True,True,True,True,False]
assert next_token_example([1],1,1)["targets"] == []
print("通过：首个回答、EOS/PAD 同 ID 与错位边界")

print("所有提供的测试通过。")
