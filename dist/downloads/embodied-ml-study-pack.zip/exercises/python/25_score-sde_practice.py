# Score、SDE 与概率流 ODE
# 环境：Python 标准库
# 仅用标准库实现 `reverse_vp_step(x,score,h,beta,noise)`。参数 `beta` 对应非负常数 \(\beta\)，\(h>0\) 表示正向增加的反向时钟 \(\tau=T-t\) 的步长；`score` 是当前前向时间 \(t\) 的状态 score，`noise` 是给定标准高斯抽样值。返回概率流 ODE 的 Euler 更新与反向 SDE 的 Euler–Maruyama 更新。拒绝非法步长和非有限值。

def reverse_vp_step(x, score, h, beta, noise):
    # TODO: 两种漂移的 score 系数不同；SDE 噪声尺度为 sqrt(beta*h)。
    raise NotImplementedError


# ===== 断言测试 =====
import math
ode, sde = reverse_vp_step(2.0, -2.0, 0.1, 1.0, 0.0)
assert math.isclose(ode, 2.0)
assert math.isclose(sde, 1.9)
ode, sde = reverse_vp_step(1.0, -0.4, 0.04, 2.0, 1.5)
assert math.isclose(ode, 1.024)
assert math.isclose(sde, 1.008 + math.sqrt(0.08)*1.5)
assert reverse_vp_step(3.0, 8.0, 0.1, 0.0, 99.0) == (3.0, 3.0)
for h, beta in [(0.0,1.0), (-0.1,1.0), (0.1,-1.0), (float("nan"),1.0)]:
    try:
        reverse_vp_step(0.0, 0.0, h, beta, 0.0)
        raise AssertionError("invalid step accepted")
    except ValueError:
        pass
print("passed: reverse clock, different score coefficients and sqrt(h) noise")

print("所有提供的测试通过。")
