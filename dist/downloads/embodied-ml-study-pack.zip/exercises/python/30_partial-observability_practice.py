# 部分观测与记忆
# 环境：Python 标准库
# 实现 `causal_velocity(positions,times,episodes)`。返回等长列表；第一项及回合切换处为 None，其余项使用当前与上一条记录的差分。相同回合内非递增时间要报错。

def causal_velocity(positions, times, episodes):
    # TODO: 不读取未来，不跨 episode 做差分
    raise NotImplementedError


# ===== 断言测试 =====
assert causal_velocity([0.,1.,3.,100.,102.],[0.,1.,2.,0.,1.],['a','a','a','b','b']) == [None,1.,2.,None,2.]
assert causal_velocity([],[],[]) == []
a=causal_velocity([0.,1.,3.],[0.,1.,2.],['a']*3)
b=causal_velocity([0.,1.,999.],[0.,1.,2.],['a']*3)
assert a[:2]==b[:2]
try:
    causal_velocity([0.,1.],[1.,1.],['a','a'])
    raise AssertionError('同回合时间重复应报错')
except ValueError:
    pass
print('因果性、回合边界和真实时间间隔检查通过。')

print("所有提供的测试通过。")
