# 生成建模、潜变量与 VAE
# 环境：Python 标准库
# 仅用 Python 标准库实现 `diagonal_gaussian_kl(mu, logvar)`。输入是相同非零长度的均值和对数方差列表，返回联合分布的 KL，使用自然对数并对潜变量维求和。拒绝维度错误、非有限参数和方差溢出。

def diagonal_gaussian_kl(mu, logvar):
    # TODO: 从 log-variance 恢复方差，逐维求和。
    raise NotImplementedError


# ===== 断言测试 =====
import math
assert diagonal_gaussian_kl([0.0, 0.0], [0.0, 0.0]) == 0.0
assert math.isclose(diagonal_gaussian_kl([1.0, -2.0], [0.0, 0.0]), 2.5)
expected = 0.5 * (0.25 + 4.0 - 1.0 - math.log(4.0))
assert math.isclose(diagonal_gaussian_kl([0.5], [math.log(4.0)]), expected)
assert math.isclose(diagonal_gaussian_kl([0.5, 0.5], [math.log(4.0)]*2), 2*expected)
for mu, lv in [([], []), ([0.0], [0.0, 0.0]), ([math.nan], [0.0]),
               ([0.0], [math.inf]), ([0.0], [1000.0])]:
    try:
        diagonal_gaussian_kl(mu, lv)
        raise AssertionError("invalid input accepted")
    except ValueError:
        pass
print("passed: event-axis sum, log-variance convention and invalid inputs")

print("所有提供的测试通过。")
