# 动作执行与延迟
# 环境：Python 标准库
# 实现 `choose_action(plans,now,dt,max_age,epoch)`。每块含 obs、ready、start、epoch、values；仅选择已完成、未过期、版本一致且覆盖当前槽位的块，优先来源 obs 最新者。返回 (value,index,obs)，无候选返回 None。

import math

def choose_action(plans,now,dt,max_age,epoch):
    # TODO: 检查时间与版本，按当前槽位选择
    raise NotImplementedError


# ===== 断言测试 =====
p=[{'obs':0.,'ready':0.15,'start':0.,'epoch':0,'values':[0.,1.,2.,3.]}]
assert choose_action(p,0.21,0.1,0.3,0)==(2.,2,0.)
assert choose_action(p,0.11,0.1,0.3,0) is None
assert choose_action(p,0.41,0.1,0.3,0) is None
assert choose_action(p,0.21,0.1,0.3,1) is None
p.append({'obs':0.2,'ready':0.25,'start':0.2,'epoch':0,'values':[10.,11.,12.]})
assert choose_action(p,0.31,0.1,0.4,0)==(11.,1,0.2)
print('准备状态、过期、指令版本和动作槽位检查通过。')

print("所有提供的测试通过。")
