# PyTorch 自动微分与计算图
# 环境：Python 标准库
# 模型预测 y=v*w*u*x，损失 0.5*(y-target)^2。w 冻结，u 和 v 可训练。返回 (du,dv)，不要把 w 冻结误解为对 u 的梯度也为零。

def chain_grads(x, u, w, v, target):
    # TODO: 保留冻结因子 w 在链式法则中的乘法作用
    raise NotImplementedError("请实现 chain_grads")


# ===== 断言测试 =====
assert chain_grads(2., 3., 4., 5., 1.) == (4760., 2856.)
assert chain_grads(2., 3., 4., 5., 120.) == (0., 0.)
assert chain_grads(2., 3., 0., 5., 1.) == (0., 0.)
print("通过：冻结参数的数值仍参与其他参数的梯度。")

print("所有提供的测试通过。")
