# DDP 与全局统计
# 环境：Python 标准库
# counts[r] 是 rank r 的有效元素数。实现 ddp_mean_weights(counts)，返回每个局部 mean 应乘的权重，使随后按 rank 平均得到全局有效元素平均。counts 为非空非负整数列表，总数必须大于零；零计数 rank 的权重为零。本题只是标准库数学练习，不启动分布式进程。

def ddp_mean_weights(counts):
     # TODO: DDP 后面还会除以进程数，需要把这个因子补回
     raise NotImplementedError('请实现 ddp_mean_weights')


# ===== 断言测试 =====
assert ddp_mean_weights([2, 6]) == [0.5, 1.5]
assert ddp_mean_weights([4, 4, 4]) == [1.0, 1.0, 1.0]
assert ddp_mean_weights([0, 5]) == [0.0, 2.0]
weights = ddp_mean_weights([2, 6])
combined = sum(w * g for w, g in zip(weights, [2, 6])) / 2
assert combined == (2 * 2 + 6 * 6) / 8 == 5.0
for counts in [[], [0, 0], [-1, 2]]:
    try:
        ddp_mean_weights(counts)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法计数')
print('通过：DDP 平均与全局有效元素平均的缩放推导')

print("所有提供的测试通过。")
