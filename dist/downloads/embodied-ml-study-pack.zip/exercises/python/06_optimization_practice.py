# 梯度下降、动量与 AdamW
# 环境：Python 标准库
# 输入参数、当前梯度、上一时刻 m/v，以及从 1 开始的 step。返回 (新参数, 新m, 新v)。参数采用解耦衰减。

import math

def adamw_step(theta, grad, m, v, step, lr=0.1,
               beta1=0.9, beta2=0.999, eps=1e-8, weight_decay=0.01):
    # TODO: 更新矩、偏差修正、解耦衰减、自适应更新
    raise NotImplementedError("请实现 adamw_step")


# ===== 断言测试 =====
theta, m, v = adamw_step(2., 4., 0., 0., 1)
assert abs(theta - (1.998 - 0.1 * 4 / (4 + 1e-8))) < 1e-12
assert abs(m - 0.4) < 1e-12 and abs(v - 0.016) < 1e-12
zero, mz, vz = adamw_step(2., 0., 0., 0., 1)
assert zero == 1.998 and mz == 0. and vz == 0.
second, m2, v2 = adamw_step(theta, 1., m, v, 2)
assert abs(m2 - 0.46) < 1e-12
assert abs(v2 - (0.999 * v + 0.001)) < 1e-12
assert second < theta
print("通过：矩估计、偏差修正及解耦衰减。")

print("所有提供的测试通过。")
