# 示教数据与采样
# 环境：Python 标准库
# 实现 sample_weights(tasks, desired)。tasks 是记录的任务标签列表，desired 是总和为 1 的非负目标概率。返回每条记录的权重；缺失但有正目标概率的任务、未知标签或空数据要报错。

import math
from collections import Counter

def sample_weights(tasks, desired):
    # TODO: 每条记录应获得其任务概率除以该任务样本数
    raise NotImplementedError


# ===== 断言测试 =====
tasks = ['reach','reach','reach','grasp']
w = sample_weights(tasks,{'reach':0.5,'grasp':0.5})
assert abs(sum(w[:3])-0.5) < 1e-12
assert abs(w[3]-0.5) < 1e-12
assert abs(sum(w)-1.0) < 1e-12
assert sample_weights(['a','a'],{'a':1.0}) == [0.5,0.5]
try:
    sample_weights(['reach'],{'reach':0.5,'grasp':0.5})
    raise AssertionError('缺失目标任务应报错')
except ValueError:
    pass
print('逐样本权重与任务总概率检查通过。')

print("所有提供的测试通过。")
