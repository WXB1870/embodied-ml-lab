# 保存与恢复训练状态
# 环境：Python 标准库
# 实现 snapshot_training(weights, optimizer_state, step)。返回含 weights、optimizer、step 的字典，前两项必须深拷贝。step 必须为非负整数。

def snapshot_training(weights, optimizer_state, step):
    # TODO: 创建独立快照，不保留可变对象的共享引用
    raise NotImplementedError("请完成训练快照")


# ===== 断言测试 =====
weights = {"head": [[1.0, 2.0]]}
optimizer = {"momentum": {"head": [0.1, 0.2]}}
saved = snapshot_training(weights, optimizer, 7)
weights["head"][0][0] = 99.0
optimizer["momentum"]["head"][0] = 88.0
assert saved["weights"]["head"][0][0] == 1.0
assert saved["optimizer"]["momentum"]["head"][0] == 0.1
assert saved["step"] == 7
try:
    snapshot_training({}, {}, -1)
    raise AssertionError("负步数应被拒绝")
except ValueError:
    pass
print("通过：嵌套可变状态不共享引用，步数正确")

print("所有提供的测试通过。")
