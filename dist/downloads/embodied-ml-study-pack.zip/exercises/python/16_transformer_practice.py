# Transformer：注意力、残差与序列建模
# 环境：Python 标准库
# 实现 prefix_allowed(prefix_len, action_len)。前缀查询只能读取全部前缀；动作查询可读取全部前缀，以及自身和之前的动作。返回二维布尔列表，True=允许。

def prefix_allowed(prefix_len, action_len):
    # TODO: 行是查询位置，列是被读取的位置
    raise NotImplementedError("请构造前缀可见性")


# ===== 断言测试 =====
m = prefix_allowed(2, 3)
assert m[0] == [True, True, False, False, False]
assert m[1] == [True, True, False, False, False]
assert m[2] == [True, True, True, False, False]
assert m[4] == [True, True, True, True, True]
assert prefix_allowed(0, 2) == [[True, False], [True, True]]
assert prefix_allowed(2, 0) == [[True, True], [True, True]]
print("通过：前缀隔离、动作因果性和边界长度")

print("所有提供的测试通过。")
