# 梯度累积
# 环境：Python 标准库
# grads[k] 是第 k 个微批次已经按有效元素平均的梯度向量，counts[k] 是其有效元素数。实现 weighted_gradient，返回全局有效元素等权的梯度。counts 为非负整数；总数为零或输入长度、向量宽度不一致时抛出 ValueError。

def weighted_gradient(grads, counts):
     # TODO: 恢复各微批次梯度总和，再按全局有效数平均
     raise NotImplementedError('请实现 weighted_gradient')


# ===== 断言测试 =====
assert weighted_gradient([[2, 4], [8, -2]], [3, 1]) == [3.5, 2.5]
assert weighted_gradient([[999, 999], [4, -6]], [0, 2]) == [4, -6]
assert weighted_gradient([[1], [7], [4]], [2, 1, 3]) == [3.5]
for gs, ns in [([[1]], [0]), ([[1], [2, 3]], [1, 1]), ([[1]], [-1]), ([[1]], [])]:
    try:
        weighted_gradient(gs, ns)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝无效计数或形状')
print('通过：不等计数、零权重和输入边界')

print("所有提供的测试通过。")
