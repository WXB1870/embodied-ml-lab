# 策略梯度
# 环境：Python 标准库
# 实现 `categorical_logit_gradient(probabilities,chosen,advantage)`，返回损失 \(-A\log p(\mathrm{chosen})\) 对 logits 的梯度。输入概率应非负且和为 1，chosen 合法。

import math

def categorical_logit_gradient(probabilities,chosen,advantage):
    # TODO: 使用 softmax 对数概率的导数
    raise NotImplementedError


# ===== 断言测试 =====
assert categorical_logit_gradient([0.5,0.5],1,2.0)==[1.0,-1.0]
assert categorical_logit_gradient([0.5,0.5],1,-2.0)==[-1.0,1.0]
g=categorical_logit_gradient([0.2,0.3,0.5],2,1.)
assert abs(sum(g))<1e-12 and g[2]<0
print('正优势增大动作概率，负优势减小动作概率；梯度方向检查通过。')

print("所有提供的测试通过。")
