# 激活与初始化
# 环境：Python 标准库
# 输入一组数，返回 (激活列表, 导数列表)。约定 x=0 时导数为 0。

def relu_and_grad(values):
    # TODO: 计算前向值与逐元素局部导数
    raise NotImplementedError("请实现 relu_and_grad")


# ===== 断言测试 =====
y, g = relu_and_grad([-2., -0.1, 0., 0.1, 2.])
assert y == [0., 0., 0., 0.1, 2.]
assert g == [0., 0., 0., 1., 1.]
assert relu_and_grad([]) == ([], [])
upstream = [2., 2., 2., 2., 2.]
assert [a*b for a, b in zip(g, upstream)] == [0., 0., 0., 2., 2.]
print("通过：前向、零点约定与链式法则。")

print("所有提供的测试通过。")
