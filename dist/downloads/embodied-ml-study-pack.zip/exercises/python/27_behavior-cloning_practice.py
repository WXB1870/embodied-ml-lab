# 行为克隆
# 环境：Python 标准库
# 实现 mse_optimum(actions)，返回最小化平均平方误差的常数预测及其 MSE。空列表要抛出 ValueError。用左右绕行的两条示教解释返回值。

def mse_optimum(actions):
    # TODO: 先求最优常数，再计算平均平方误差
    raise NotImplementedError


# ===== 断言测试 =====
assert mse_optimum([-1.0, 1.0]) == (0.0, 1.0)
assert mse_optimum([1.0, 3.0]) == (2.0, 1.0)
assert mse_optimum([2.0, 2.0, 2.0]) == (2.0, 0.0)
try:
    mse_optimum([])
    raise AssertionError('空输入应报错')
except ValueError:
    pass
print('4 组检查通过：你算出了 MSE 的常数最优解。')

print("所有提供的测试通过。")
