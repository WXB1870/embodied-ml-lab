# 残差连接与深层优化
# 环境：Python 标准库
# 对分支 \(F(x)=x^2\)，实现 residual_value_grad(x, alpha)，返回 \(y=x+\alpha x^2\) 及 \(\frac{dy}{dx}\)。测试还会用有限差分检验导数。

def residual_value_grad(x, alpha):
    # TODO: 返回残差输出和对 x 的导数
    raise NotImplementedError("请实现残差与导数")


# ===== 断言测试 =====
y, g = residual_value_grad(2.0, 0.5)
assert y == 4.0 and g == 3.0
assert residual_value_grad(7.0, 0.0) == (7.0, 1.0)
x, a, h = -0.3, 0.2, 1e-5
numerical = (
    residual_value_grad(x+h, a)[0] - residual_value_grad(x-h, a)[0]
) / (2*h)
assert abs(numerical - residual_value_grad(x, a)[1]) < 1e-8
assert residual_value_grad(-1.0, 0.5)[1] == 0.0
print("通过：残差导数、恒等路径和可能的梯度抵消")

print("所有提供的测试通过。")
