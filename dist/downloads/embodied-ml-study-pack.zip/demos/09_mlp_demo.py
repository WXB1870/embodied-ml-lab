import torch
from torch import nn

torch.manual_seed(7)
# STEP 1: 构造两个通用的非线性合成函数
features = torch.randn(128, 8)
target = torch.stack([
    features[:, 0] + 0.2 * features[:, 1].square(),
    features[:, 2].sin() + 0.1 * features[:, 3] * features[:, 4],
], dim=-1)
model = nn.Sequential(nn.Linear(8, 32), nn.SiLU(), nn.Linear(32, 2))
parameter_count = sum(p.numel() for p in model.parameters())
assert parameter_count == (8 * 32 + 32) + (32 * 2 + 2) == 354
print("parameters:", parameter_count)

# STEP 2: 固定训练数据，检查前向、求导和更新是否工作
optimizer = torch.optim.AdamW(model.parameters(), lr=0.03, weight_decay=0.)
initial_loss = (model(features) - target).square().mean().item()
for step in range(200):
    optimizer.zero_grad(set_to_none=True)
    prediction = model(features)
    loss = (prediction - target).square().mean()
    loss.backward()
    optimizer.step()

# STEP 3: 同一训练集的拟合检查，不作为样本外泛化结果
model.eval()
with torch.no_grad():
    final_loss = (model(features) - target).square().mean().item()
    sample = model(features[:2])
assert sample.shape == (2, 2) and torch.isfinite(sample).all()
assert final_loss < initial_loss
print("training MSE:", round(initial_loss, 5), "->", round(final_loss, 5))
print("two function outputs:", sample)

