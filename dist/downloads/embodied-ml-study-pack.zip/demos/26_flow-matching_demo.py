import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 模型输入 [动作的两个维度, 时间, 条件]
model = nn.Sequential(nn.Linear(4,48), nn.SiLU(), nn.Linear(48,48), nn.SiLU(), nn.Linear(48,2))
optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.0)

# STEP 2: 噪声在 t=0，数据在 t=1，速度目标固定为 action-noise
for _ in range(300):
    c = torch.rand(96,1) * 2 - 1
    action = torch.cat([2*c, -c], dim=-1) + 0.05*torch.randn(96,2)
    noise = torch.randn_like(action)
    t = torch.rand(96,1)
    x_t = (1-t)*noise + t*action
    target_velocity = action-noise
    predicted_velocity = model(torch.cat([x_t,t,c],dim=-1))
    loss = (predicted_velocity-target_velocity).square().mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

# STEP 3: 推理没有真实 action，只能使用模型速度
model.eval()
c = torch.tensor([[-0.8],[0.0],[0.8]])
x = torch.randn(3,2)
steps = 32
with torch.no_grad():
    for k in range(steps):
        t = torch.full((len(c),1), k/steps)
        velocity = model(torch.cat([x,t,c],dim=-1))
        x = x + velocity / steps

# STEP 4: 打印合成结果，检查维度与有限值
print('last velocity MSE:', round(loss.item(),5))
print('condition:', c.squeeze(-1).tolist())
print('generated actions:', x.tolist())
print('shape:', tuple(x.shape))
assert x.shape == (3,2) and torch.isfinite(x).all()

