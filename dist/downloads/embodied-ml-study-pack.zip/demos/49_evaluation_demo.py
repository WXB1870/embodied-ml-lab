import math
import torch

torch.manual_seed(7)

# STEP 1: 明确每个元素是一条完整试验，两个方法使用同一情景索引
baseline = torch.tensor([1,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0],dtype=torch.float64)
candidate = baseline.clone()
candidate[torch.tensor([2,4,6])] = 1
candidate[0] = 0
assert ((baseline == 0) | (baseline == 1)).all()
assert baseline.shape == candidate.shape

# STEP 2: Wilson 区间假定这些试验可作为独立同分布伯努利样本
def wilson(successes, trials, z=1.96):
    p = successes/trials
    denominator = 1+z*z/trials
    center = (p+z*z/(2*trials))/denominator
    half = z*math.sqrt(p*(1-p)/trials+z*z/(4*trials*trials))/denominator
    return max(0.,center-half),min(1.,center+half)

n = len(candidate)
rate = candidate.mean().item()
interval = wilson(int(candidate.sum().item()),n)

# STEP 3: 以试验对为单位抽样，不打乱 baseline/candidate 的对应关系
generator = torch.Generator().manual_seed(7)
indices = torch.randint(n,(4000,n),generator=generator)
paired_difference = candidate-baseline
bootstrap_delta = paired_difference[indices].mean(dim=1)
ci = torch.quantile(bootstrap_delta,torch.tensor([0.025,0.975],dtype=torch.float64))

# STEP 4: 同时报告分子分母、效应大小与区间
print('candidate successes/trials:', int(candidate.sum()), '/', n)
print('candidate success rate:', round(rate,3), 'Wilson:', tuple(round(v,3) for v in interval))
print('paired improvement:', round(paired_difference.mean().item(),3))
print('paired percentile-bootstrap interval:', [round(v,3) for v in ci.tolist()])
print('Synthetic example: intervals do not establish real-world generalization.')

