import copy
import torch
from torch import nn

torch.manual_seed(29)
# STEP 1: 固定模型和数据，两个模型从相同参数开始
model = nn.Linear(3, 2).double()
reference = copy.deepcopy(model)
x = torch.randn(7, 3, dtype=torch.float64)
y = torch.randn(7, 2, dtype=torch.float64)
valid = torch.tensor([[1,1],[1,0],[0,1],[1,1],[0,0],[1,0],[1,1]], dtype=torch.bool)
total = int(valid.sum())
windows = [slice(0, 3), slice(3, 5), slice(5, 7)]
opt = torch.optim.SGD(model.parameters(), lr=0.1)
ref_opt = torch.optim.SGD(reference.parameters(), lr=0.1)

# STEP 2: 每个微批次都除以整个窗口的有效元素总数
ref_opt.zero_grad(set_to_none=True)
full_loss = (reference(x) - y).square()[valid].sum() / total
full_loss.backward()
opt.zero_grad(set_to_none=True)
for part in windows:
    errors = (model(x[part]) - y[part]).square()
    local_loss = errors[valid[part]].sum() / total
    local_loss.backward()
for p, q in zip(model.parameters(), reference.parameters()):
    torch.testing.assert_close(p.grad, q.grad, atol=1e-12, rtol=1e-12)

# STEP 3: 累积结束再裁剪和更新，比较最终参数
norm = nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.3)
ref_norm = nn.utils.clip_grad_norm_(reference.parameters(), max_norm=0.3)
torch.testing.assert_close(norm, ref_norm)
opt.step()
ref_opt.step()
for p, q in zip(model.parameters(), reference.parameters()):
    torch.testing.assert_close(p, q, atol=1e-12, rtol=1e-12)
print('各微批次有效元素:', [int(valid[s].sum()) for s in windows])
print('总有效元素:', total, '裁剪前范数:', round(norm.item(), 6))
print('通过：累积梯度和更新后的参数均与完整批次一致')

