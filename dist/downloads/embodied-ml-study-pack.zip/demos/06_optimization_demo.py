import math
import torch

torch.manual_seed(0)
# STEP 1: 标量目标与 AdamW 配置
parameter = torch.tensor([2.], dtype=torch.float64, requires_grad=True)
lr, weight_decay = 0.1, 0.01
beta1, beta2, eps = 0.9, 0.999, 1e-8
optimizer = torch.optim.AdamW([parameter], lr=lr, betas=(beta1, beta2),
                              eps=eps, weight_decay=weight_decay)
manual_parameter, m, v = 2., 0., 0.

# STEP 2: 两条独立路径执行同样的更新
for step in range(1, 4):
    optimizer.zero_grad(set_to_none=True)
    loss = 0.5 * (parameter - 1.).square().sum()
    loss.backward()
    grad = manual_parameter - 1.
    m = beta1 * m + (1 - beta1) * grad
    v = beta2 * v + (1 - beta2) * grad * grad
    m_hat = m / (1 - beta1 ** step)
    v_hat = v / (1 - beta2 ** step)
    manual_parameter *= 1 - lr * weight_decay
    manual_parameter -= lr * m_hat / (math.sqrt(v_hat) + eps)
    optimizer.step()
    assert abs(parameter.item() - manual_parameter) < 1e-10
    print("update", step, "parameter", round(parameter.item(), 8))

# STEP 3: Warmup 以优化器更新次数计数
peak_lr, warmup_updates = 1e-3, 4
def lr_for_update(index):
    return peak_lr * min((index + 1) / warmup_updates, 1.)

print("warmup:", [lr_for_update(i) for i in range(6)])
print("saved optimizer state:", sorted(optimizer.state[parameter].keys()))

