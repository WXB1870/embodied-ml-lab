import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(30)
# STEP 1: 本次固定运行 CPU；CUDA 分支需有可用 GPU
device_type = 'cpu'  # 本地有 GPU 时可改为 'cuda'
dtype = torch.bfloat16 if device_type == 'cpu' else torch.float16
model = nn.Linear(4, 2).to(device_type)
x = torch.randn(8, 4, device=device_type)
y = torch.randn(8, 2, device=device_type)
optimizer = torch.optim.SGD(model.parameters(), lr=0.05)
scaler = torch.amp.GradScaler('cuda', enabled=(device_type == 'cuda'))
before = model.weight.detach().clone()

# STEP 2: 前向自动选精度；反传、反缩放与裁剪在外部
optimizer.zero_grad(set_to_none=True)
with torch.autocast(device_type=device_type, dtype=dtype):
    prediction = model(x)
    loss = F.mse_loss(prediction, y)
scaler.scale(loss).backward()
scaler.unscale_(optimizer)
grad_norm = nn.utils.clip_grad_norm_(model.parameters(), 1.0)
scaler.step(optimizer)
scaler.update()
assert torch.isfinite(loss)
assert all(torch.isfinite(p.grad).all() for p in model.parameters())
assert not torch.equal(before, model.weight)
print('参数 / 输出 / 损失 dtype:', model.weight.dtype, prediction.dtype, loss.dtype)
print('裁剪前范数:', round(float(grad_norm), 6))

# STEP 3: 单独观察范围与精度，避免把 BF16 当作更精确的 FP16
values = torch.tensor([1e5, 1e-8, 1.001], dtype=torch.float32)
fp16 = values.to(torch.float16).float()
bf16 = values.to(torch.bfloat16).float()
assert torch.isinf(fp16[0]) and fp16[1] == 0
assert torch.isfinite(bf16).all() and bf16[1] > 0
print('原数值:', values.tolist())
print('FP16 还原:', fp16.tolist())
print('BF16 还原:', bf16.tolist())
print('本例只验证 CPU BF16；CUDA 分支需要在 GPU 上另行验证')

