# [1] 条件参数在每个样本内广播，B 与 T 特意不同
import torch
from torch import nn
torch.manual_seed(40)

class ConditionalBlock(nn.Module):
    def __init__(self, dim=4, condition_dim=2):
        super().__init__()
        self.norm = nn.LayerNorm(dim,elementwise_affine=False)
        self.modulate = nn.Sequential(nn.SiLU(),nn.Linear(condition_dim,3*dim))
        self.ffn = nn.Sequential(nn.Linear(dim,8),nn.SiLU(),nn.Linear(8,dim))
        nn.init.zeros_(self.modulate[-1].weight)
        nn.init.zeros_(self.modulate[-1].bias)

    def forward(self,x,condition):
        scale,shift,gate = self.modulate(condition).chunk(3,dim=-1)
        normalized = self.norm(x)
        h = normalized*(1+scale[:,None,:])+shift[:,None,:]
        return x + gate[:,None,:]*self.ffn(h)

# [2] 零门控保持恒等；先检查门控层而不是要求所有梯度非零
model = ConditionalBlock()
x = torch.randn(2,3,4)
condition = torch.randn(2,2,requires_grad=True)
initial = model(x,condition)
torch.testing.assert_close(initial,x)
initial.square().mean().backward()
assert model.modulate[-1].bias.grad[-4:].norm() > 0
torch.testing.assert_close(condition.grad,torch.zeros_like(condition))
print("初始恒等与门控梯度正确")

# [3] 打开条件分支后，只改变第一个样本的条件
with torch.no_grad():
    nn.init.normal_(model.modulate[-1].weight,std=0.1)
    model.modulate[-1].bias[-4:].fill_(0.2)
changed = condition.detach().clone()
changed[0,0] += 1.0
before,after = model(x,condition),model(x,changed)
torch.testing.assert_close(before[1],after[1])
assert not torch.allclose(before[0],after[0])
model.zero_grad(set_to_none=True)
condition.grad = None
model(x,condition).square().mean().backward()
assert condition.grad is not None and condition.grad.norm() > 0
print("条件只影响相应样本，打开分支后梯度能够回到条件")

