import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(17)
torch.set_num_threads(1)
dtype, eps = torch.float64, 1e-4
x = (2 * torch.randn(2, 3, 4, dtype=dtype) + 5).requires_grad_()
gamma = torch.tensor([0.7, -1.2, 1.6, 0.4], dtype=dtype, requires_grad=True)
beta = torch.tensor([0.2, 0., -0.3, 0.5], dtype=dtype, requires_grad=True)
g = torch.randn_like(x)

# LayerNorm 前向：每个 B,T 位置独立沿 D 归约。
centered = x - x.mean(-1, keepdim=True)
r = torch.sqrt(centered.square().mean(-1, keepdim=True) + eps)
z = centered / r
ours = gamma * z + beta
reference = F.layer_norm(x, (4,), gamma, beta, eps)
torch.testing.assert_close(ours, reference, rtol=1e-10, atol=1e-10)
ours_grad = torch.autograd.grad((ours * g).sum(), (x, gamma, beta))
reference_grad = torch.autograd.grad((reference * g).sum(), (x, gamma, beta))
for actual, expected in zip(ours_grad, reference_grad):
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)

# 手推 VJP：统计量的两条导数路径不可 detach。
q = g * gamma
dx = (q - q.mean(-1, keepdim=True) - z * (q * z).mean(-1, keepdim=True)) / r
dgamma, dbeta = (g * z).sum((0, 1)), g.sum((0, 1))
for actual, expected in zip((dx, dgamma, dbeta), reference_grad):
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)
torch.testing.assert_close(dx.sum(-1), torch.zeros(2, 3, dtype=dtype), atol=1e-10, rtol=0)

# RMSNorm 的 VJP 少了去均值项，仍包含分母依赖输入的导数。
rr = torch.sqrt(x.square().mean(-1, keepdim=True) + eps)
rms = x / rr
rms_auto = torch.autograd.grad((rms * g).sum(), x)[0]
rms_hand = g / rr - x * (g * x).mean(-1, keepdim=True) / rr.pow(3)
torch.testing.assert_close(rms_hand, rms_auto, rtol=1e-10, atol=1e-10)

# 常量行输出为零，不代表其所有扰动方向的导数为零。
constant = torch.full((4,), 3., dtype=dtype, requires_grad=True)
jac = torch.autograd.functional.jacobian(lambda a: F.layer_norm(a, (4,), eps=eps), constant)
p = torch.eye(4, dtype=dtype) - torch.ones(4, 4, dtype=dtype) / 4
torch.testing.assert_close(jac, p / eps ** 0.5, rtol=1e-10, atol=1e-10)

# BN 训练前向的总体方差，与 running_var 的无偏估计分别核对。
batch = torch.tensor([[1., 4.], [3., 0.], [6., 2.]], dtype=dtype)
bn = nn.BatchNorm1d(2, eps=eps, momentum=0.2, affine=False).to(dtype)
mean = batch.mean(0)
biased_var = batch.var(0, correction=0)
unbiased_var = batch.var(0, correction=1)
train_output = bn(batch)
torch.testing.assert_close(train_output, (batch - mean) / torch.sqrt(biased_var + eps))
torch.testing.assert_close(bn.running_mean, 0.2 * mean)
torch.testing.assert_close(bn.running_var, 0.8 * torch.ones(2, dtype=dtype) + 0.2 * unbiased_var)
saved_mean, saved_var = bn.running_mean.clone(), bn.running_var.clone()
bn.eval()
torch.testing.assert_close(bn(batch), (batch - saved_mean) / torch.sqrt(saved_var + eps))
torch.testing.assert_close(bn.running_mean, saved_mean)
torch.testing.assert_close(bn.running_var, saved_var)

# 同一目标样本的 BN 输出随其他样本改变；逐 token LN 不受此影响。
changed = batch.clone()
changed[2] += torch.tensor([10., -8.], dtype=dtype)
batch_norm = nn.BatchNorm1d(2, affine=False, track_running_stats=False).to(dtype)
batch_norm.eval()  # 未跟踪运行统计时，eval 仍读取当前批次。
assert not torch.allclose(batch_norm(batch)[0], batch_norm(changed)[0])
torch.testing.assert_close(F.layer_norm(batch, (2,))[0], F.layer_norm(changed, (2,))[0])
print("通过：LN 三组梯度、RMS VJP、常量行 Jacobian、BN 两种方差和批次依赖。")

