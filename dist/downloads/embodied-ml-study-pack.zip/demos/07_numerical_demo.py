import torch

torch.manual_seed(5)
# STEP 1: 三个输出使用不同物理尺度
train = torch.randn(64, 3) * torch.tensor([0.1, 10., 100.])
train += torch.tensor([0.5, 0., 1000.])
mean = train.mean(dim=0)
scale = train.std(dim=0, unbiased=False).clamp_min(1e-6)
z = (train - mean) / scale
assert torch.allclose(z.mean(dim=0), torch.zeros(3), atol=2e-6)
assert torch.allclose(z.std(dim=0, unbiased=False), torch.ones(3), atol=1e-6)
restored = z * scale + mean
assert torch.allclose(restored, train, atol=1e-5)
print("mean:", mean.tolist(), "scale:", scale.tolist())

# STEP 2: 验证集只使用训练统计量，不重新 fit
validation = train[:4] + torch.tensor([0.2, 0., 0.])
validation_z = (validation - mean) / scale
assert validation_z.shape == validation.shape
raw_error = torch.tensor([0.01, 1., 10.])
normalized_mse = (raw_error / scale).square().mean()
weighted_raw_mse = (raw_error.square() / scale.square()).mean()
assert torch.allclose(normalized_mse, weighted_raw_mse)

# STEP 3: 常数维度与非有限值需要明确处理
constant = torch.ones(8, 1)
constant_scale = constant.std(0, unbiased=False).clamp_min(1e-6)
assert torch.isfinite((constant - constant.mean(0)) / constant_scale).all()
def require_finite(name, tensor):
    if not torch.isfinite(tensor).all():
        raise ValueError(name + " 首次出现非有限值")

require_finite("normalized training data", z)
try:
    require_finite("bad example", torch.tensor([1., float("inf")]))
except ValueError as error:
    print(error)

