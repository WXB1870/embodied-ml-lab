import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 冻结原层，A 随机、B 为零
class LoRALinear(nn.Module):
    def __init__(self, in_dim, out_dim, rank=2, alpha=2.):
        super().__init__()
        self.base = nn.Linear(in_dim,out_dim)
        self.base.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(rank,in_dim)*0.1)
        self.B = nn.Parameter(torch.zeros(out_dim,rank))
        self.scale = alpha/rank
    def forward(self,x):
        return self.base(x) + self.scale*F.linear(F.linear(x,self.A),self.B)

layer = LoRALinear(4,3)
x = torch.randn(32,4)
target = torch.randn(32,3)
frozen_weight = layer.base.weight.detach().clone()
torch.testing.assert_close(layer(x),layer.base(x))

# STEP 2: 检查第一步梯度，区分零梯度与没有梯度
optimizer = torch.optim.AdamW([p for p in layer.parameters() if p.requires_grad],lr=0.03)
loss = (layer(x)-target).square().mean()
loss.backward()
print('first A/B grad norms:', layer.A.grad.norm().item(), layer.B.grad.norm().item())
assert layer.A.grad is not None and layer.B.grad is not None
assert layer.base.weight.grad is None
optimizer.step()

# STEP 3: 小型监督训练，只更新适配器
for _ in range(60):
    loss = (layer(x)-target).square().mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()
torch.testing.assert_close(layer.base.weight, frozen_weight)

# STEP 4: 合并后线性层应与适配器前向等价
with torch.no_grad():
    merged = layer.base.weight + layer.scale*(layer.B @ layer.A)
    merged_output = F.linear(x,merged,layer.base.bias)
    torch.testing.assert_close(merged_output,layer(x),atol=1e-6,rtol=1e-5)
print('trainable parameters:', sum(p.numel() for p in layer.parameters() if p.requires_grad))
print('frozen weight unchanged; merge check passed')

