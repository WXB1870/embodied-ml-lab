import copy
import math
import torch
from torch import nn

torch.set_num_threads(1)
torch.manual_seed(41)
dtype = torch.float64
width, batch = 12, 48
x_train = 0.7 * torch.randn(batch, width, dtype=dtype)
teacher = torch.linalg.qr(torch.randn(width, width, dtype=dtype)).Q
y_train = torch.sin(x_train @ teacher)
upstream = torch.randn(batch, width, dtype=dtype)
upstream = upstream / upstream.norm()

class Stack(nn.Module):
    def __init__(self, depth, alpha, skip):
        super().__init__()
        self.layers = nn.ModuleList(nn.Linear(width, width) for _ in range(depth))
        self.readout = nn.Linear(width, width)
        self.alpha, self.skip = alpha, skip
        self.to(dtype)
        for index, layer in enumerate(self.layers):
            generator = torch.Generator().manual_seed(1000 + index)
            with torch.no_grad():
                layer.weight.copy_(torch.randn(width, width, generator=generator, dtype=dtype) / math.sqrt(width))
                layer.bias.zero_()
        generator = torch.Generator().manual_seed(2000)
        with torch.no_grad():
            self.readout.weight.copy_(torch.randn(width, width, generator=generator, dtype=dtype) / math.sqrt(width))
            self.readout.bias.zero_()

    def features(self, x):
        for layer in self.layers:
            update = self.alpha * torch.tanh(layer(x))
            x = x + update if self.skip else update
        return x

    def forward(self, x):
        return self.readout(self.features(x))

def probe(model):
    x = x_train.detach().clone().requires_grad_()
    parameters = (model.layers[0].weight, model.layers[-1].weight)
    # 相同输出方向的 VJP，避免把不同初始预测误差混入 Jacobian 比较。
    gradients = torch.autograd.grad((model(x) * upstream).sum(), (x, *parameters))
    assert all(torch.isfinite(g).all() for g in gradients)
    with torch.no_grad():
        activation_rms = model.features(x_train).square().mean().sqrt().item()
    return [g.norm().item() for g in gradients] + [activation_rms]

def train(model, steps=100):
    # 同一数据、优化器、学习率和更新次数；不对每种结构单独调参。
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.)
    before = model.layers[0].weight.detach().clone()
    with torch.no_grad():
        initial = (model(x_train) - y_train).square().mean().item()
    for _ in range(steps):
        optimizer.zero_grad(set_to_none=True)
        loss = (model(x_train) - y_train).square().mean()
        loss.backward()
        assert torch.isfinite(loss)
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
        optimizer.step()
    with torch.no_grad():
        final = (model(x_train) - y_train).square().mean().item()
        displacement = (model.layers[0].weight - before).norm().item()
    assert math.isfinite(final) and math.isfinite(displacement)
    return initial, final, displacement

print("depth scale model | input_VJP first_W_grad last_W_grad feature_RMS | MSE_before MSE_after first_W_update")
for depth in (2, 8, 24):
    # 不同深度也复用相同前缀随机初始化；每个成对实验只改变 skip 开关。
    template = Stack(depth, alpha=1., skip=False)
    for scale_name, alpha in (("one", 1.), ("sqrt_depth", 1 / math.sqrt(depth))):
        plain, residual = copy.deepcopy(template), copy.deepcopy(template)
        plain.alpha = residual.alpha = alpha
        residual.skip = True
        assert all(torch.equal(a, b) for a, b in zip(plain.parameters(), residual.parameters()))
        for name, model in (("plain", plain), ("residual", residual)):
            diagnostics = probe(model)
            optimization = train(model)
            values = " ".join(f"{v:.5g}" for v in (*diagnostics, *optimization))
            print(depth, scale_name, name, "|", values)

# 恒等项不构成梯度下界：这两个是独立的线性反例，不是上面的 tanh 网络。
z = torch.tensor([1., -2.], dtype=dtype, requires_grad=True)
cancel = z + (-z)
torch.testing.assert_close(torch.autograd.grad(cancel.sum(), z)[0], torch.zeros_like(z))
h = z
for _ in range(12):
    h = h + h
torch.testing.assert_close(torch.autograd.grad(h.sum(), z)[0], torch.full_like(z, 2. ** 12))
print("通过：配对初值、有限训练、抵消反例和 2^12 梯度放大；表内数值仅适用于这个合成实验。")

