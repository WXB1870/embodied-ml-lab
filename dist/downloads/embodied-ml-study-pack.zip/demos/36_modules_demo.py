# [1] 统计量作为 Buffer，多个层使用 ModuleList
import copy
import torch
from torch import nn
torch.manual_seed(17)

class FeatureProjector(nn.Module):
    def __init__(self, dim=8):
        super().__init__()
        self.register_buffer("feature_mean", torch.zeros(dim))
        self.register_buffer("feature_scale", torch.ones(dim))
        self.layers = nn.ModuleList([nn.Linear(dim, dim), nn.Linear(dim, dim)])
        self.head = nn.Linear(dim, 4)

    def forward(self, x):
        x = (x - self.feature_mean) / self.feature_scale.clamp_min(1e-6)
        for layer in self.layers:
            x = torch.nn.functional.gelu(layer(x))
        return self.head(x)

# [2] 全部模块构造完毕之后再创建优化器
model = FeatureProjector()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
x = torch.randn(4, 8)
before_output = model(x).detach().clone()
snapshot = copy.deepcopy(model.state_dict())
before_weight = model.head.weight.detach().clone()
assert "layers.0.weight" in snapshot
assert "feature_mean" in snapshot
assert "feature_mean" not in dict(model.named_parameters())

# [3] 更新后，独立快照仍能恢复旧的函数
optimizer.zero_grad(set_to_none=True)
model(x).square().mean().backward()
optimizer.step()
assert not torch.equal(model.head.weight, before_weight)
restored = FeatureProjector()
restored.load_state_dict(snapshot)
torch.testing.assert_close(restored(x), before_output)
print("参数名:", list(dict(model.named_parameters())))
print("Buffer:", list(dict(model.named_buffers())))
print("注册与独立快照检查通过")

