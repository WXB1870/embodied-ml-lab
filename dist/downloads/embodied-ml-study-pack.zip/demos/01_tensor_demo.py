import torch

torch.manual_seed(0)
# STEP 1: 用不相同的轴长度，让错误更容易暴露
B, T, D, O = 2, 3, 4, 2
x = torch.arange(B * T * D, dtype=torch.float32).reshape(B, T, D)
W = torch.randn(D, O)
bias = torch.tensor([0.1, -0.2])
y = x @ W + bias
assert y.shape == (B, T, O)
# einsum 直接在式子中标注被求和的 d 轴
y_check = torch.einsum("btd,do->bto", x, W) + bias
assert torch.allclose(y, y_check)
print("projection:", tuple(x.shape), "->", tuple(y.shape))

# STEP 2: 交换轴不是重新切分内存
xt = x.permute(0, 2, 1)
assert xt[1, 2, 0] == x[1, 0, 2]
assert torch.equal(xt.permute(0, 2, 1), x)
wrong = x.reshape(B, D, T)
print("reshape equals permute:", torch.equal(wrong, xt))
print("permuted is contiguous:", xt.is_contiguous())

# STEP 3: 每个样本的权重显式占据 B 轴
sample_weight = torch.tensor([1.0, 2.0])[:, None, None]
weighted = x * sample_weight
assert torch.equal(weighted[0], x[0])
assert torch.equal(weighted[1], x[1] * 2)
pooled = x.mean(dim=1)
assert pooled.shape == (B, D)
print("pooled first sample:", pooled[0].tolist())

