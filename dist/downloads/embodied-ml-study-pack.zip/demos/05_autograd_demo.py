import torch
from torch import nn

torch.manual_seed(0)
# STEP 1: Adapter -> 冻结骨干 -> 预测头
adapter = nn.Linear(4, 4, bias=False)
backbone = nn.Linear(4, 4, bias=False)
head = nn.Linear(4, 1, bias=False)
with torch.no_grad():
    backbone.weight.copy_(torch.eye(4))
backbone.requires_grad_(False)
x = torch.randn(6, 4)
target = torch.randn(6, 1)

# STEP 2: 冻结权重，但保留对骨干输入的导数
prediction = head(backbone(adapter(x)))
loss = (prediction - target).square().mean()
loss.backward()
assert adapter.weight.grad is not None
assert backbone.weight.grad is None
assert head.weight.grad is not None
print("adapter grad norm:", adapter.weight.grad.norm().item())

# STEP 3: 故意 detach，观察前面的训练路径消失
for module in (adapter, backbone, head):
    module.zero_grad(set_to_none=True)
feature = backbone(adapter(x)).detach()
(head(feature) - target).square().mean().backward()
assert adapter.weight.grad is None
assert head.weight.grad is not None
print("after detach, adapter grad:", adapter.weight.grad)
adapter.eval()
assert adapter.weight.requires_grad
print("eval does not freeze parameters:", adapter.weight.requires_grad)

