"""Check ELBO, its gap, pathwise gradients and amortized inference in one model."""
import math
import torch
from torch import nn

torch.manual_seed(19)
torch.set_num_threads(1)
torch.set_default_dtype(torch.float64)

# 1. z ~ N(0,1), x|z ~ N(z,tau^2); its exact posterior is available.
tau = 0.6
x = torch.tensor([-1.7, -0.8, 0.0, 0.5, 1.4])
posterior_variance = tau**2 / (1 + tau**2)
posterior_mean = x / (1 + tau**2)
mu = torch.tensor([-0.5, -0.3, 0.1, 0.3, 0.9], requires_grad=True)
logvar = torch.tensor([-0.4, -0.8, 0.0, -1.2, -0.6], requires_grad=True)
variance = logvar.exp()
expected_log_likelihood = -0.5 * (
    math.log(2 * math.pi * tau**2) + ((x - mu).square() + variance) / tau**2)
kl_prior = 0.5 * (mu.square() + variance - 1 - logvar)
elbo = expected_log_likelihood - kl_prior
log_evidence = -0.5 * (math.log(2 * math.pi * (1 + tau**2))
                      + x.square() / (1 + tau**2))
kl_posterior = 0.5 * (
    (variance + (mu - posterior_mean).square()) / posterior_variance - 1
    + math.log(posterior_variance) - logvar)
torch.testing.assert_close(log_evidence - elbo, kl_posterior)
assert (elbo <= log_evidence + 1e-12).all()
print("ELBO gaps:", kl_posterior.detach().tolist())

# 2. Two fixed points integrate these quadratic functions exactly.
# This is a moment check (E eps=0, E eps^2=1), not a generic Gaussian MC rule.
eps = torch.tensor([-1.0, 1.0])[:, None]
z = mu[None, :] + (0.5 * logvar).exp()[None, :] * eps
log_likelihood = -0.5 * (
    math.log(2 * math.pi * tau**2) + (x[None, :] - z).square() / tau**2)
pathwise_elbo = log_likelihood.mean(0) - kl_prior
torch.testing.assert_close(pathwise_elbo, elbo)
grad_mu, grad_logvar = torch.autograd.grad(pathwise_elbo.sum(), (mu, logvar))
manual_mu = (x - mu) / tau**2 - mu
manual_logvar = 0.5 * (1 - variance * (1 + 1 / tau**2))
torch.testing.assert_close(grad_mu, manual_mu)
torch.testing.assert_close(grad_logvar, manual_logvar)
print("pathwise gradients equal the analytic expectation gradients")

# 3. Fit an amortized encoder; the generative model above is deliberately fixed.
encoder = nn.Linear(1, 2)
optimizer = torch.optim.Adam(encoder.parameters(), lr=0.04)
for step in range(700):
    parameters = encoder(x[:, None])
    q_mu, q_logvar = parameters[:, 0], parameters[:, 1]
    expected_nll = 0.5 * (
        math.log(2 * math.pi * tau**2)
        + ((x - q_mu).square() + q_logvar.exp()) / tau**2)
    kl = 0.5 * (q_mu.square() + q_logvar.exp() - 1 - q_logvar)
    loss = (expected_nll + kl).mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

with torch.no_grad():
    fitted = encoder(x[:, None])
    mean_error = (fitted[:, 0] - posterior_mean).abs().max().item()
    logvar_error = (fitted[:, 1] - math.log(posterior_variance)).abs().max().item()
torch.testing.assert_close(fitted[:, 0], posterior_mean, rtol=0, atol=2e-3)
torch.testing.assert_close(fitted[:, 1], torch.full_like(x, math.log(posterior_variance)),
                           rtol=0, atol=2e-3)
print("encoder max mean/log-variance error:", mean_error, logvar_error)
print("passed: ELBO identity, pathwise gradients and exact-posterior recovery")

