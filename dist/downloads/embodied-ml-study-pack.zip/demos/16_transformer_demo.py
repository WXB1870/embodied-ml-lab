# [1] 使用 MultiheadAttention；它的布尔 Mask 中 True=禁止
import torch
from torch import nn
torch.manual_seed(14)

class TinyBlock(nn.Module):
    def __init__(self, dim=8, heads=2):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, dropout=0.0, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, 4 * dim), nn.GELU(), nn.Linear(4 * dim, dim)
        )

    def forward(self, x, blocked=None):
        z = self.norm1(x)
        update, _ = self.attn(z, z, z, attn_mask=blocked, need_weights=False)
        h = x + update
        return h + self.ffn(self.norm2(h))

# [2] 对同一个模型只改变最后一个 token 的一个通道
model = TinyBlock().eval()
x = torch.randn(2, 5, 8)
changed = x.clone()
changed[:, -1, 0] += 3.0
blocked = torch.ones(5, 5, dtype=torch.bool).triu(diagonal=1)

# [3] 因果时前面输出不变，双向时允许变化
with torch.no_grad():
    causal_a, causal_b = model(x, blocked), model(changed, blocked)
    bidir_a, bidir_b = model(x), model(changed)
torch.testing.assert_close(causal_a[:, :-1], causal_b[:, :-1])
difference = (bidir_a[:, 0] - bidir_b[:, 0]).abs().max().item()
assert difference > 1e-6
print("因果模式前面位置一致:", True)
print("双向模式首位置最大变化:", difference)
print("Block 输出形状:", causal_a.shape)

