import torch

torch.manual_seed(7)

# STEP 1: 将基座系位置变化表达为工具系变化
R = torch.tensor([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
p_now = torch.tensor([0.5, 0.2, 0.3])
p_next = torch.tensor([0.51, 0.2, 0.3])
delta_base = p_next - p_now
delta_tool = R.T @ delta_base
reconstructed_position = p_now + R @ delta_tool
torch.testing.assert_close(reconstructed_position, p_next)

# STEP 2: 第四维是统一动作空间中的填充维度，不是夹爪
train_actions = torch.tensor([[0.01, 0.03, -0.01, 0.],
                              [0.03, 0.01,  0.01, 0.],
                              [0.02, 0.02,  0.00, 0.]])
valid_dim = torch.tensor([True, True, True, False])
mean = train_actions.mean(dim=0)
std = train_actions.std(dim=0, unbiased=False).clamp_min(1e-6)

# STEP 3: 编码与解码使用同一统计量
normalized = (train_actions - mean) / std
normalized = torch.where(valid_dim, normalized, torch.zeros_like(normalized))
recovered = normalized * std + mean
torch.testing.assert_close(recovered[:, valid_dim], train_actions[:, valid_dim])

# STEP 4: 检查动作 mask 在损失中的分母
prediction = normalized + torch.tensor([0.1, 0.2, 0.3, float('nan')])
mask = valid_dim.expand_as(prediction)
loss = (prediction[mask] - normalized[mask]).square().mean()
print('base delta:', delta_base.tolist())
print('tool delta:', delta_tool.tolist())
print('round trip passed; masked loss:', round(loss.item(), 6))
torch.testing.assert_close(loss, torch.tensor((0.01 + 0.04 + 0.09) / 3))

