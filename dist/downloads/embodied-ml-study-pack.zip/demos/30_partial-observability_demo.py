import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 相同当前位置，配上两种相反速度和相反制动标签
position = torch.linspace(-1,1,32,dtype=torch.float64).repeat_interleave(2)
velocity = torch.tensor([-1.,1.],dtype=torch.float64).repeat(32)
dt = 0.1
previous_position = position-dt*velocity
expert_action = -velocity
current_features = torch.stack([position,torch.ones_like(position)],dim=1)
history_features = torch.stack([position,(position-previous_position)/dt],dim=1)

# STEP 2: 最小二乘给出两个输入方案各自能拟合的结果
w_current = torch.linalg.lstsq(current_features,expert_action).solution
w_history = torch.linalg.lstsq(history_features,expert_action).solution
current_mse = (current_features@w_current-expert_action).square().mean()
history_mse = (history_features@w_history-expert_action).square().mean()
print('current-only/history MSE:', current_mse.item(),history_mse.item())
assert current_mse > 0.99 and history_mse < 1e-20

# STEP 3: GRU hidden 必须属于当前回合，不能继承无关轨迹
rnn = nn.GRU(input_size=1,hidden_size=4,batch_first=True)
first_episode = torch.tensor([[[1.],[2.],[3.]]])
next_episode = torch.tensor([[[9.],[8.],[7.]]])
_,h_old = rnn(first_episode)
fresh_output,h_fresh = rnn(next_episode)  # hidden 默认为零
contaminated_output,_ = rnn(next_episode,h_old.detach())
print('hidden shape:',tuple(h_fresh.shape))
print('cross-episode contamination:',(fresh_output-contaminated_output).abs().max().item())
assert not torch.allclose(fresh_output,contaminated_output)

# STEP 4: 截断 BPTT 只去掉图连接，按环境 reset 才清除数值
hidden = h_old.detach()
assert not hidden.requires_grad
assert torch.equal(hidden,h_old)
reset = torch.tensor([True])
hidden = torch.where(reset[None,:,None],torch.zeros_like(hidden),hidden)
assert torch.count_nonzero(hidden) == 0
print('detach retains values; reset clears episode memory')

