"""Synthetic two-dimensional policy: split -> fit -> restore -> closed loop.

CPU-only teaching experiment. The dynamics are s_next = s + action.
The experiment checks software contracts, not performance on a robot.
"""
import copy
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import torch
from torch import nn

torch.set_num_threads(1)
torch.manual_seed(83)
HORIZON, ACTION_DIM = 3, 2
CONFIG = {"horizon": HORIZON, "action_dim": ACTION_DIM,
          "observation": "previous_state,current_state,goal",
          "action": "world_delta", "unit": "synthetic_length", "dt": 1.0}


def model_factory(config):
    # This expert is linear in the observation; a linear model isolates the pipeline.
    return nn.Linear(6, config["horizon"] * config["action_dim"])


def make_episodes():
    generator = torch.Generator().manual_seed(83)
    episodes = []
    for episode_id in range(60):
        state = 2 * torch.rand(2, generator=generator) - 1
        goal = 2 * torch.rand(2, generator=generator) - 1
        previous = state.clone()
        observations, actions = [], []
        for _ in range(12):
            action = 0.25 * (goal-state)
            observations.append(torch.cat([previous, state, goal]))
            actions.append(action)
            previous, state = state, state+action
        episodes.append({"id": episode_id, "obs": torch.stack(observations),
                         "actions": torch.stack(actions), "goal": goal})
    return episodes


def windows(episodes):
    obs, actions, masks = [], [], []
    for episode in episodes:
        length = len(episode["obs"])
        for t in range(length):
            count = min(HORIZON, length-t)
            chunk = torch.full((HORIZON, ACTION_DIM), float("nan"))
            valid = torch.zeros(HORIZON, 1, dtype=torch.bool)
            chunk[:count] = episode["actions"][t:t+count]
            valid[:count] = True
            obs.append(episode["obs"][t]); actions.append(chunk); masks.append(valid)
    return torch.stack(obs), torch.stack(actions), torch.stack(masks)


def fit_statistics(train):
    obs, actions, valid = train
    selected_actions = actions[valid[..., 0]]  # [valid frames,D]
    return {"obs_mean": obs.mean(0), "obs_std": obs.std(0, correction=0).clamp_min(1e-4),
            "action_mean": selected_actions.mean(0),
            "action_std": selected_actions.std(0, correction=0).clamp_min(1e-4)}


def prepare_data(episode_splits):
    # The complete preparation entry point receives every split, but fits only train.
    prepared = {name: windows(items) for name, items in episode_splits.items()}
    return prepared, fit_statistics(prepared["train"])


def predict(model, stats, obs):
    normalized = (obs-stats["obs_mean"]) / stats["obs_std"]
    q = model(normalized).reshape(-1, HORIZON, ACTION_DIM)
    return q * stats["action_std"] + stats["action_mean"]


def masked_error(prediction, target, valid):
    mask = valid.expand_as(prediction)
    if not mask.any():
        raise ValueError("empty supervision")
    p, y = prediction[mask], target[mask]
    if not (torch.isfinite(p).all() and torch.isfinite(y).all()):
        raise ValueError("nonfinite valid supervision")
    return (p-y).square().mean()


def restore(path):
    artifact = torch.load(path, map_location="cpu", weights_only=True)
    if artifact["config"] != CONFIG:
        raise ValueError("incompatible observation/action contract")
    model = model_factory(artifact["config"])
    model.load_state_dict(artifact["model"])
    model.eval()
    return model, artifact


def restore_check(path):
    model, artifact = restore(path)
    with torch.no_grad():
        actual = predict(model, artifact["statistics"], artifact["probe"])
    torch.testing.assert_close(actual, artifact["expected"], atol=1e-6, rtol=1e-6)
    print("fresh-process prediction matches saved probe")


def run():
    episodes = make_episodes()
    train_episodes, validation_episodes, test_episodes = episodes[:40], episodes[40:50], episodes[50:]
    split = {"train": [e["id"] for e in train_episodes],
             "validation": [e["id"] for e in validation_episodes],
             "test": [e["id"] for e in test_episodes]}
    assert not (set(split["train"]) & set(split["validation"]) | set(split["train"]) & set(split["test"]))
    episode_splits = {"train": train_episodes, "validation": validation_episodes, "test": test_episodes}
    prepared, stats = prepare_data(episode_splits)
    train, validation, test = (prepared[name] for name in ("train", "validation", "test"))
    # Re-run the actual preparation entry point with altered held-out inputs.
    altered_splits = copy.deepcopy(episode_splits)
    for name in ("validation", "test"):
        for episode in altered_splits[name]:
            episode["obs"].add_(1000)
            episode["actions"].add_(1000)
    _, altered_stats = prepare_data(altered_splits)
    for key, value in altered_stats.items():
        torch.testing.assert_close(value, stats[key])

    model = model_factory(CONFIG)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.03)
    x, y, valid = train
    # Only selected targets are transformed; invalid NaN values never enter a loss.
    normalized_x = (x-stats["obs_mean"]) / stats["obs_std"]
    mask = valid.expand_as(y)
    safe_y = torch.where(mask, y, stats["action_mean"])
    normalized_y = (safe_y-stats["action_mean"]) / stats["action_std"]
    losses = []
    for step in range(600):
        optimizer.zero_grad(set_to_none=True)
        q = model(normalized_x).reshape_as(y)
        loss = masked_error(q, normalized_y, valid)
        loss.backward(); optimizer.step()
        if step in (0, 599): losses.append(float(loss.detach()))
    model.eval()
    with torch.no_grad():
        validation_mse = float(masked_error(predict(model, stats, validation[0]), validation[1], validation[2]))
        test_mse = float(masked_error(predict(model, stats, test[0]), test[1], test[2]))
        probe = test[0][:8].clone()
        expected = predict(model, stats, probe)
    assert losses[-1] < losses[0]
    assert validation_mse < 1e-4  # A contract test for this deliberately realizable toy problem.
    artifact = {"model": {k: v.detach().clone() for k, v in model.state_dict().items()},
                "statistics": stats, "config": CONFIG, "split": split,
                "probe": probe, "expected": expected}
    with tempfile.TemporaryDirectory() as directory:
        checkpoint = Path(directory)/"policy.pt"
        torch.save(artifact, checkpoint)
        # Exercise actual serialization and a new Python process, not just a state_dict alias.
        subprocess.run([sys.executable, __file__, "--restore-check", str(checkpoint)], check=True)
        restored, saved = restore(checkpoint)
        final_errors = []
        with torch.no_grad():
            for episode in test_episodes:
                previous = episode["obs"][0, :2].clone()
                state = episode["obs"][0, 2:4].clone()
                goal = episode["goal"]
                for _ in range(24):
                    obs = torch.cat([previous, state, goal])[None]
                    action = predict(restored, saved["statistics"], obs)[0, 0]
                    previous, state = state, state+action  # Execute one slot, then re-observe.
                final_errors.append(float((state-goal).norm()))
        # Fault injection: identical shapes do not establish compatible units.
        broken = copy.deepcopy(artifact); broken["config"]["unit"] = "other_unit"
        torch.save(broken, checkpoint)
        try: restore(checkpoint)
        except ValueError: pass
        else: raise AssertionError("unit mismatch must be rejected")
    print(json.dumps({"train_loss_first_last": losses, "validation_action_mse": validation_mse,
                      "test_action_mse": test_mse, "closed_loop_mean_final_distance": sum(final_errors)/len(final_errors),
                      "episodes": {key: len(value) for key, value in split.items()}}, indent=2))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--restore-check": restore_check(sys.argv[2])
    else: run()

