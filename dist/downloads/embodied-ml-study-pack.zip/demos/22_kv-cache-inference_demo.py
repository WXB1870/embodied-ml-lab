# [1] 单层教学注意力，显式使用绝对位置
import math
import torch
from torch import nn
torch.manual_seed(38)

class CachedAttention(nn.Module):
    def __init__(self, dim=8, heads=2):
        super().__init__()
        self.dim, self.heads = dim, heads
        self.position = nn.Embedding(64, dim)
        self.qkv = nn.Linear(dim, 3*dim, bias=False)
        self.proj = nn.Linear(dim, dim, bias=False)

    def forward(self, x, past=None, start=0):
        batch, count, dim = x.shape
        past_len = 0 if past is None else past[0].shape[-2]
        if start != past_len:
            raise ValueError("本例位置起点必须等于历史缓存长度")
        positions = torch.arange(start, start+count)
        z = x + self.position(positions)[None]
        q, k, v = self.qkv(z).chunk(3, dim=-1)
        split = lambda a: a.reshape(batch,count,self.heads,dim//self.heads).transpose(1,2)
        q, k, v = map(split, (q,k,v))
        if past is not None:
            k, v = torch.cat((past[0],k),-2), torch.cat((past[1],v),-2)
        allowed = torch.arange(k.shape[-2])[None] <= positions[:,None]
        scores = (q @ k.transpose(-1,-2))/math.sqrt(q.shape[-1])
        values = scores.masked_fill(~allowed,float("-inf")).softmax(-1) @ v
        merged = values.transpose(1,2).reshape(batch,count,dim)
        return self.proj(merged), (k,v), allowed

# [2] 使用 3、2、1 的分块，检验非方形 Mask
model = CachedAttention().eval()
x = torch.randn(1,6,8)
with torch.no_grad():
    full, _, _ = model(x)
    a, prefix_cache, _ = model(x[:,:3])
    b, cache, mask = model(x[:,3:5], prefix_cache, start=3)
    c, _, _ = model(x[:,5:], cache, start=5)
    torch.testing.assert_close(torch.cat((a,b,c),1), full, atol=1e-6, rtol=1e-5)
    expected_mask = torch.tensor([[1,1,1,1,0],[1,1,1,1,1]],dtype=torch.bool)
    assert torch.equal(mask,expected_mask)

# [3] 修改前缀后复用旧缓存，会偏离重新计算的结果
    changed = x.clone()
    changed[:,0,0] += 4.0
    fresh, _, _ = model(changed)
    stale, _, _ = model(changed[:,3:],prefix_cache,start=3)
    assert not torch.allclose(stale, fresh[:,3:])
print("增量 Mask:", mask.tolist())
print("完整与分块一致；改变前缀后旧缓存失效")

