from collections import Counter
import torch
from torch.utils.data import WeightedRandomSampler

torch.manual_seed(7)

# STEP 1: 每条记录保留 episode 和 task，而不仅保存动作
records = []
for episode, task_name, length in [(0,'reach',6),(1,'grasp',2),(2,'reach',4),(3,'grasp',3)]:
    for t in range(length):
        records.append({'episode':episode,'task':task_name,
                        'action':torch.tensor([episode*0.1, t*0.01])})
train_episodes, validation_episodes = {0,1,2}, {3}
assert train_episodes.isdisjoint(validation_episodes)
train = [r for r in records if r['episode'] in train_episodes]
validation = [r for r in records if r['episode'] in validation_episodes]

# STEP 2: 先做有限值检查，统计量只在训练数据上拟合
train_actions = torch.stack([r['action'] for r in train])
assert torch.isfinite(train_actions).all()
mean = train_actions.mean(dim=0)
std = train_actions.std(dim=0,unbiased=False).clamp_min(1e-6)
validation_actions = torch.stack([r['action'] for r in validation])
validation_normalized = (validation_actions-mean)/std

# STEP 3: p_k/n_k 才能让两种任务各占期望 50%
counts = Counter(r['task'] for r in train)
desired = {'reach':0.5,'grasp':0.5}
weights = torch.tensor([desired[r['task']]/counts[r['task']] for r in train],dtype=torch.double)
generator = torch.Generator().manual_seed(7)
sampler = WeightedRandomSampler(weights,10000,replacement=True,generator=generator)
selected = list(sampler)
observed = Counter(train[i]['task'] for i in selected)

# STEP 4: 报告真实抽样，而不是仅报告配置中的目标比例
print('training frame counts:', dict(counts))
print('observed sample fractions:', {k:round(observed[k]/len(selected),3) for k in desired})
print('training mean/std:', mean.tolist(), std.tolist())
print('validation uses training statistics:', tuple(validation_normalized.shape))
assert abs(observed['reach']/len(selected)-0.5) < 0.04

