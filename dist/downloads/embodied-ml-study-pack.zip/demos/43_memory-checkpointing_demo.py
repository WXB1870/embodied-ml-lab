import torch
from torch import nn
from torch.utils.checkpoint import checkpoint

torch.manual_seed(32)
# STEP 1: 两次运行使用同一个模型和同一数据，不进行参数更新
block = nn.Sequential(nn.Linear(64, 128), nn.GELU(),
                      nn.Linear(128, 128), nn.GELU(), nn.Linear(128, 16))
x = torch.randn(32, 64)
target = torch.randn(32, 16)

# STEP 2: hook 统计为反向保存的逻辑字节；这不是 GPU 峰值
def run(use_checkpoint):
    block.zero_grad(set_to_none=True)
    local_x = x.detach().clone().requires_grad_(True)
    saved_bytes = []
    def pack(tensor):
        saved_bytes.append(tensor.numel() * tensor.element_size())
        return tensor
    def unpack(tensor):
        return tensor
    with torch.autograd.graph.saved_tensors_hooks(pack, unpack):
        if use_checkpoint:
            output = checkpoint(block, local_x, use_reentrant=False)
        else:
            output = block(local_x)
        loss = (output - target).square().mean()
    loss.backward()
    grads = [p.grad.detach().clone() for p in block.parameters()]
    return output.detach(), grads, sum(saved_bytes)

# STEP 3: 节省保存量的同时，应保留目标计算与梯度
plain, grad_plain, bytes_plain = run(False)
remat, grad_remat, bytes_remat = run(True)
torch.testing.assert_close(plain, remat)
for a, b in zip(grad_plain, grad_remat):
    torch.testing.assert_close(a, b)
assert bytes_remat < bytes_plain
print('普通前向逻辑保存字节:', bytes_plain)
print('重计算逻辑保存字节:', bytes_remat)
print('通过：输出和参数梯度一致；此数值不是 CUDA 峰值显存')

