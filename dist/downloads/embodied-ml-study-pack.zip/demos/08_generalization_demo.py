import torch
from torch import nn

torch.manual_seed(6)
# STEP 1: 8 条轨迹，每条 5 帧
N = 40
episode_id = torch.arange(8).repeat_interleave(5)
permutation = torch.randperm(N)
naive_train, naive_val = permutation[:30], permutation[30:]
overlap = set(episode_id[naive_train].tolist()) & set(episode_id[naive_val].tolist())
print("frame split shared episodes:", sorted(overlap))

# STEP 2: 完整轨迹保持在一个集合中
train_mask = episode_id < 6
val_mask = ~train_mask
train_episodes = set(episode_id[train_mask].tolist())
val_episodes = set(episode_id[val_mask].tolist())
assert train_episodes.isdisjoint(val_episodes)
assert int(train_mask.sum()) == 30 and int(val_mask.sum()) == 10
print("group split:", sorted(train_episodes), sorted(val_episodes))

# STEP 3: eval 行为与 no_grad 分别设置
model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Dropout(0.5), nn.Linear(8, 1))
x = torch.ones(4, 4)
model.train()
first, second = model(x), model(x)
print("training outputs identical:", torch.equal(first, second))
model.eval()
with torch.no_grad():
    eval_first, eval_second = model(x), model(x)
assert torch.equal(eval_first, eval_second)
assert all(p.requires_grad for p in model.parameters())
print("evaluation outputs identical:", torch.equal(eval_first, eval_second))

