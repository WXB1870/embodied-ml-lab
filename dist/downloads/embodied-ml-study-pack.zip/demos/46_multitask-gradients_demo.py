import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(34)
# STEP 1: 连续向量回归与四类状态分类共享主干
trunk = nn.Linear(3, 4)
action_head = nn.Linear(4, 2)
state_head = nn.Linear(4, 4)
x = torch.randn(5, 3)
action_target = torch.randn(5, 2)
state_target = torch.tensor([0, 1, 2, 3, 1])
hidden = torch.tanh(trunk(x))
loss_action = (action_head(hidden) - action_target).square().mean()
loss_state = F.cross_entropy(state_head(hidden), state_target)
shared = tuple(trunk.parameters())

# STEP 2: 读取相同共享坐标，核验加权梯度恒等式
ga_parts = torch.autograd.grad(loss_action, shared, retain_graph=True)
gs_parts = torch.autograd.grad(loss_state, shared, retain_graph=True)
ga = torch.cat([g.reshape(-1) for g in ga_parts])
gs = torch.cat([g.reshape(-1) for g in gs_parts])
denominator = ga.norm() * gs.norm()
cosine = None if float(denominator) == 0 else float(torch.dot(ga, gs) / denominator)
assert all(p.grad is None for p in shared)
weight = 0.25
(loss_action + weight * loss_state).backward()
combined = torch.cat([p.grad.reshape(-1) for p in shared])
torch.testing.assert_close(combined, ga + weight * gs)
print('回归 / 分类 loss:', float(loss_action.detach()), float(loss_state.detach()))
print('共享梯度范数:', float(ga.norm()), float(gs.norm()), '余弦:', cosine)

# STEP 3: 确定性相反目标，区分数学反例与随机网络观察
point = torch.tensor([0.0, 0.0], requires_grad=True)
toward_positive = (point - 1).square().sum()
toward_negative = (point + 1).square().sum()
gp = torch.autograd.grad(toward_positive, point, retain_graph=True)[0]
gn = torch.autograd.grad(toward_negative, point)[0]
torch.testing.assert_close(gp, torch.tensor([-2.0, -2.0]))
torch.testing.assert_close(gn, -gp)
torch.testing.assert_close(gp + gn, torch.zeros(2))
print('构造案例：相反梯度等权组合为', (gp + gn).tolist())
print('通过：真实回归与分类梯度组合，以及确定性抵消反例')

