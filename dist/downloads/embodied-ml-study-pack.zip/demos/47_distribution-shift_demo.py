import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 理想轨迹只包含零偏移，无法识别反馈增益
actor=nn.Linear(1,1,bias=False)
nn.init.zeros_(actor.weight)
obs=torch.zeros(16,1)
labels=torch.zeros(16,1)
expert=lambda x:-0.5*x
print('initial demonstration loss:',(actor(obs)-labels).square().mean().item())

# STEP 2: 执行动作产生访问状态，标签始终由专家查询得到
@torch.no_grad()
def rollout(policy, disturbance, steps=20):
    x=torch.zeros(1,1)
    visited=[]
    for _ in range(steps):
        visited.append(x.clone())
        x=x+policy(x)+disturbance
    return torch.cat(visited),x.item()

_,before=rollout(actor,0.06)  # 独立保留的评估扰动
optimizer=torch.optim.SGD(actor.parameters(),lr=0.2)

# STEP 3: 两轮访问状态重标注，始终保留原始数据
for round_id in range(2):
    visited,_=rollout(actor,0.04)  # 训练采集条件
    with torch.no_grad():
        expert_labels=expert(visited)
    obs=torch.cat([obs,visited])
    labels=torch.cat([labels,expert_labels])
    for _ in range(100):
        loss=(actor(obs)-labels).square().mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
    print('round/data size/feedback:',round_id+1,len(obs),actor.weight.item())

# STEP 4: 用未加入训练的扰动比较，不把合成结果外推到硬件
_,after=rollout(actor,0.06)
print('held-out terminal deviation:',round(before,4),'->',round(after,4))
assert abs(after)<abs(before)
print('This is a synthetic feedback example, not a hardware deployment.')

