# [1] 构造带小扰动的匹配向量，作为可验证教学数据
import torch
from torch.nn import functional as F
torch.manual_seed(36)
B, D = 4, 8
image_raw = torch.randn(B, D, requires_grad=True)
text_raw = (image_raw.detach() + 0.03*torch.randn(B, D)).requires_grad_()
logit_scale = torch.tensor(1.5, requires_grad=True)
image = F.normalize(image_raw, dim=-1)
text = F.normalize(text_raw, dim=-1)

# [2] 每行和每列各做一次正确配对分类
scores = logit_scale.exp() * (image @ text.T)
labels = torch.arange(B)
clip_loss = (F.cross_entropy(scores, labels)
             + F.cross_entropy(scores.T, labels)) / 2
shuffled_scores = logit_scale.exp() * (image @ text.roll(1, 0).T)
shuffled_loss = (F.cross_entropy(shuffled_scores, labels)
                 + F.cross_entropy(shuffled_scores.T, labels)) / 2
assert shuffled_loss > clip_loss
torch.testing.assert_close(image.norm(dim=-1), torch.ones(B))

# [3] SigLIP 式逐对目标：正例 +1、负例 -1，按 B 归约
pair_logits = 4.0 * (image @ text.T) - 2.0
sign = 2.0 * torch.eye(B) - 1.0
sigmoid_loss = F.softplus(-sign * pair_logits).sum() / B
assert torch.isfinite(sigmoid_loss)

# [4] 验证两路特征和尺度都连接到对比目标
clip_loss.backward()
assert image_raw.grad is not None and text_raw.grad is not None
assert logit_scale.grad is not None
assert torch.isfinite(image_raw.grad).all()
print("匹配 / 错配 CLIP loss:", round(clip_loss.item(), 4), round(shuffled_loss.item(), 4))
print("成对 Sigmoid loss:", round(sigmoid_loss.item(), 4))
print("配对、单位化与梯度检查通过")

