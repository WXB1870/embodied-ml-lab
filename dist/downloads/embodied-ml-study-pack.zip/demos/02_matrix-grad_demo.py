import torch

torch.manual_seed(0)
# STEP 1: 定义小型双精度回归问题
X = torch.tensor([[1., 2.], [-1., 1.], [2., 0.]], dtype=torch.float64)
Y = torch.tensor([[3.], [0.], [4.]], dtype=torch.float64)
W = torch.tensor([[0.3, -0.2]], dtype=torch.float64, requires_grad=True)
b = torch.tensor([0.1], dtype=torch.float64, requires_grad=True)
pred = X @ W.T + b
loss = 0.5 * (pred - Y).square().mean()
loss.backward()

# STEP 2: 用与 mean 相同的分母推导矩阵梯度
with torch.no_grad():
    G = (pred - Y) / pred.numel()
    dW = G.T @ X
    db = G.sum(dim=0)
assert torch.allclose(W.grad, dW)
assert torch.allclose(b.grad, db)
print("dW:", dW.tolist(), "db:", db.tolist())

# STEP 3: 只扰动一个权重，独立检查该偏导
@torch.no_grad()
def value(w):
    return 0.5 * (X @ w.T + b - Y).square().mean()

eps = 1e-6
plus, minus = W.detach().clone(), W.detach().clone()
plus[0, 0] += eps
minus[0, 0] -= eps
finite_difference = (value(plus) - value(minus)) / (2 * eps)
assert torch.allclose(finite_difference, W.grad[0, 0], atol=1e-7)
print("finite difference:", finite_difference.item())
print("三种结果一致；参数此时尚未执行 optimizer.step()。")

