import torch
from torch import nn

torch.manual_seed(7)

# STEP 1: 三个独立转移例子：继续、真正终止、外部截断
rewards=torch.tensor([1.,1.,1.])
next_values=torch.tensor([10.,10.,10.],requires_grad=True)
terminated=torch.tensor([False,True,False])
truncated=torch.tensor([False,False,True])
gamma=0.9

# STEP 2: reset 条件可以合并，bootstrap 条件不能照抄
needs_reset=terminated|truncated
with torch.no_grad():
    targets=rewards+gamma*torch.where(terminated,torch.zeros_like(next_values),next_values)
    wrong_targets=rewards+gamma*(~needs_reset).float()*next_values
print('correct targets:',targets.tolist())
print('wrong done-mask targets:',wrong_targets.tolist())
torch.testing.assert_close(targets,torch.tensor([10.,1.,10.]))

# STEP 3: 当前价值可训练，target 分支不接收该损失的梯度
value=nn.Embedding(3,1)
current_values=value(torch.arange(3)).squeeze(-1)
loss=(current_values-targets).square().mean()
loss.backward()
assert value.weight.grad is not None
assert next_values.grad is None and not targets.requires_grad

# STEP 4: 对同一段奖励，分别计算终止回报和截断 bootstrap 回报
def segment_returns(rewards,gamma,bootstrap):
    result=[]
    future=float(bootstrap)
    for reward in reversed(rewards):
        future=float(reward)+gamma*future
        result.append(future)
    return list(reversed(result))

print('terminal returns:',segment_returns([1,2,3],gamma,0.0))
print('truncated returns:',segment_returns([1,2,3],gamma,4.0))
print('Use the final observation before reset for the bootstrap value.')

