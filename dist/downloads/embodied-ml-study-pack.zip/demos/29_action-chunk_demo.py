import torch

torch.manual_seed(7)

# STEP 1: 每一行代表同一决策时刻的观测和待发送动作
T, O, H = 8, 3, 4
observations = torch.stack([torch.arange(T), torch.arange(T) + 100], dim=1).float()
actions = (10 * torch.arange(T)).float().unsqueeze(-1)

# STEP 2: 只允许在本轨迹内索引，越界位置填零并提供 mask
def make_window(t):
    if not 0 <= t < T:
        raise ValueError('current time outside episode')
    obs_index = torch.arange(t - O + 1, t + 1)
    act_index = torch.arange(t, t + H)
    obs_valid = (obs_index >= 0) & (obs_index < T)
    act_valid = (act_index >= 0) & (act_index < T)
    obs = observations[obs_index.clamp(0, T - 1)]
    act = actions[act_index.clamp(0, T - 1)]
    obs = torch.where(obs_valid[:, None], obs, torch.zeros_like(obs))
    act = torch.where(act_valid[:, None], act, torch.zeros_like(act))
    return obs, act, obs_valid, act_valid

# STEP 3: 检查轨迹开头和结尾，而不仅检查中间帧
samples = [make_window(0), make_window(6)]
history, target, history_mask, target_mask = [torch.stack(x) for x in zip(*samples)]
assert history.shape == (2, O, 2)
assert target.shape == (2, H, 1)
assert history_mask[0].tolist() == [False, False, True]
assert target_mask[1].tolist() == [True, True, False, False]

# STEP 4: 执行长度是部署选择，不改变训练标签长度
execution_horizon = 2
commands_to_send = target[:, :execution_horizon]
print('history:', history.tolist())
print('target:', target.squeeze(-1).tolist())
print('target mask:', target_mask.tolist())
print('execute first steps:', commands_to_send.squeeze(-1).tolist())

