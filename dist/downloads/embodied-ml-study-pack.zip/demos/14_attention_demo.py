# [1] 先投影，再拆头；用小尺寸看清每个轴
import math
import torch
from torch import nn
from torch.nn import functional as F
torch.manual_seed(13)
B, T, D, H = 2, 4, 8, 2
d = D // H
x = torch.randn(B, T, D)
qkv = nn.Linear(D, 3 * D, bias=False)
q, k, v = qkv(x).chunk(3, dim=-1)

def split_heads(z):
    return z.reshape(B, T, H, d).transpose(1, 2)

q, k, v = map(split_heads, (q, k, v))

# [2] 这里 True 表示允许读取，构造下三角因果规则
allowed = torch.ones(T, T, dtype=torch.bool).tril()
assert allowed.any(dim=-1).all()
scores = (q @ k.transpose(-1, -2)) / math.sqrt(d)
scores = scores.masked_fill(~allowed, float("-inf"))
weights = scores.softmax(dim=-1)
head_output = weights @ v
torch.testing.assert_close(weights.sum(-1), torch.ones(B, H, T))
assert torch.equal(weights[..., ~allowed], torch.zeros_like(weights[..., ~allowed]))

# [3] 官方 SDPA 使用相同的 True=允许语义
reference = F.scaled_dot_product_attention(
    q, k, v, attn_mask=allowed, dropout_p=0.0
)
torch.testing.assert_close(head_output, reference, atol=1e-6, rtol=1e-5)
merged = head_output.transpose(1, 2).contiguous().reshape(B, T, D)
output_projection = nn.Linear(D, D, bias=False)
y = output_projection(merged)
print("Q / 权重 / 输出:", q.shape, weights.shape, y.shape)
print("手写注意力与 SDPA 一致")

