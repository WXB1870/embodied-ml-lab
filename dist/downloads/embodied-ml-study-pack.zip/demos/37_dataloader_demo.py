# [1] 样本在初始化时生成，避免每次读取悄悄改变监督
import torch
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
torch.manual_seed(18)

class ToyEpisodes(Dataset):
    def __init__(self):
        self.items = []
        for i, length in enumerate([3, 1, 4]):
            self.items.append({
                "state": torch.randn(4),
                "actions": torch.randn(length, 3),
                "text": torch.tensor([1, 2+i], dtype=torch.long),
            })

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        return self.items[index]

# [2] 显式组批，长度决定 Mask，而不是判断数值是否为零
def collate(samples):
    actions = pad_sequence([x["actions"] for x in samples], batch_first=True)
    lengths = torch.tensor([len(x["actions"]) for x in samples])
    valid = torch.arange(actions.shape[1])[None, :] < lengths[:, None]
    return {
        "state": torch.stack([x["state"] for x in samples]),
        "actions": actions,
        "valid": valid,
        "text": pad_sequence([x["text"] for x in samples], batch_first=True),
    }

# [3] 先用单进程确认结构，再考虑加载性能
loader = DataLoader(ToyEpisodes(), batch_size=3, shuffle=False,
                    collate_fn=collate, num_workers=0)
batch = next(iter(loader))
assert batch["actions"].shape == (3, 4, 3)
assert batch["valid"].sum().item() == 8
assert (batch["actions"][~batch["valid"]] == 0).all()
print({key: tuple(value.shape) for key, value in batch.items()})
print("有效步数:", batch["valid"].sum().item())
print("逐元素损失的有效分母:", batch["valid"].sum().item() * 3)

