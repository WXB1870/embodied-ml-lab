# [1] 离散 ID 的查表与连续位置
import math
import torch
from torch import nn
torch.manual_seed(15)
ids = torch.tensor([[1, 2, 3, 4], [4, 3, 2, 1]], dtype=torch.long)
embedding = nn.Embedding(32, 8)
q = embedding(ids)
k = torch.randn_like(q)
positions = torch.arange(ids.shape[1], dtype=q.dtype)

# [2] 相邻两个通道组成一个旋转平面
def rope(x, position_ids, base=10000.0):
    dim = x.shape[-1]
    assert dim % 2 == 0
    frequency = base ** (-torch.arange(0, dim, 2, device=x.device, dtype=x.dtype) / dim)
    angle = position_ids.to(x)[:, None] * frequency[None, :]
    cos, sin = angle.cos()[None], angle.sin()[None]
    even, odd = x[..., 0::2], x[..., 1::2]
    paired = torch.stack((even*cos - odd*sin, even*sin + odd*cos), dim=-1)
    return paired.flatten(-2)

# [3] 旋转保持范数；整体平移位置不改变 Q/K 相对角度
qr, kr = rope(q, positions), rope(k, positions)
torch.testing.assert_close(qr.norm(dim=-1), q.norm(dim=-1))
score = qr @ kr.transpose(-1, -2)
shifted = rope(q, positions+7) @ rope(k, positions+7).transpose(-1, -2)
torch.testing.assert_close(score, shifted, atol=2e-6, rtol=1e-5)

# [4] 生成时间是另外一个条件，不是 token 序号
t = torch.tensor([0.2, 0.8])
time_features = torch.stack((t, torch.sin(math.pi*t), torch.cos(math.pi*t)), dim=-1)
time_mlp = nn.Sequential(nn.Linear(3, 16), nn.SiLU(), nn.Linear(16, 8))
time_condition = time_mlp(time_features)[:, None, :]
print("token / 时间条件:", q.shape, time_condition.shape)
print("RoPE 范数与相对位置检查通过")

