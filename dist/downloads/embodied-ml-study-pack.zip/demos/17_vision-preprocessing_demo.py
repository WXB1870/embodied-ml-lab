# [1] 只使用 PyTorch；固定 uint8 RGB 与像素中心合同
import torch
from torch.nn import functional as F
torch.manual_seed(39)

def preprocess(image, points, out_hw=(12,12)):
    if image.dtype != torch.uint8 or image.ndim != 3 or image.shape[-1] != 3:
        raise ValueError("需要 HWC uint8 RGB")
    h, w = image.shape[:2]
    oh, ow = out_hw
    ratio = min(oh/h, ow/w)
    nh, nw = max(1,int(h*ratio+0.5)), max(1,int(w*ratio+0.5))
    top, left = (oh-nh)//2, (ow-nw)//2
    x = image.permute(2,0,1)[None].float()/255.0
    x = F.interpolate(x,size=(nh,nw),mode="bilinear",align_corners=False,antialias=True)
    x = F.pad(x,(left,ow-nw-left,top,oh-nh-top),value=0.0)
    x = (x-0.5)/0.5  # 本例合同；真实模型使用其预训练约定
    sx, sy = nw/w, nh/h
    affine = torch.tensor([[sx,0,left+(sx-1)/2],
                           [0,sy,top+(sy-1)/2],[0,0,1]],dtype=points.dtype)
    homogeneous = torch.cat((points,torch.ones(len(points),1)),dim=1)
    mapped = (homogeneous @ affine.T)[:,:2]
    return x[0], mapped, affine

# [2] 不对称 RGB 图案与关键点，验证几何正反变换
image = torch.zeros(5,9,3,dtype=torch.uint8)
image[...,0] = 255
image[...,1] = torch.arange(9,dtype=torch.uint8)[None,:]*20
points = torch.tensor([[0.,0.],[4.,2.],[8.,4.]])
processed, mapped, affine = preprocess(image,points)
mapped_h = torch.cat((mapped,torch.ones(len(mapped),1)),dim=1)
restored = (mapped_h @ torch.linalg.inv(affine).T)[:,:2]
torch.testing.assert_close(restored,points,atol=1e-6,rtol=1e-5)
assert processed.shape == (3,12,12)
assert processed.min() >= -1 and processed.max() <= 1

# [3] 名称表固定顺序；缺失视角使用占位与显式有效位
cameras = {"camera_b":image.clone(),"camera_a":image}
names = ["camera_a","camera_b","camera_c"]
views, valid = [], []
for name in names:
    present = name in cameras
    views.append(preprocess(cameras[name],points)[0] if present
                 else torch.full_like(processed,-1.0))
    valid.append(present)
stacked = torch.stack(views)
assert valid == [True,True,False]
print("变换后关键点:", mapped.round(decimals=3).tolist())
print("多视角:", tuple(stacked.shape),"有效位:",valid)
print("像素合同、几何回映与相机顺序检查通过")

