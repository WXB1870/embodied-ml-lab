# [1] 手写一个有效二维互相关，没有翻转卷积核
import torch
from torch.nn import functional as F
torch.manual_seed(35)
x = torch.arange(1, 26, dtype=torch.float32).reshape(1, 1, 5, 5)
kernel = torch.tensor([[1., 0., -1.], [2., 0., -2.], [1., 0., -1.]])
weight = kernel[None, None]
manual = torch.empty(1, 1, 3, 3)
for row in range(3):
    for col in range(3):
        patch = x[0, 0, row:row+3, col:col+3]
        manual[0, 0, row, col] = (patch * kernel).sum()
reference = F.conv2d(x, weight)
torch.testing.assert_close(manual, reference)
print("单层输出形状:", tuple(reference.shape))

# [2] 两层卷积：先更新感受野，再更新输入间隔
layers = [(3, 2, 1), (3, 1, 1)]  # kernel, stride, dilation
receptive, jump = 1, 1
for k, stride, dilation in layers:
    receptive += (k - 1) * dilation * jump
    jump *= stride
assert (receptive, jump) == (7, 2)

# [3] 用全正权重和线性路径观察实际依赖支持
image = torch.zeros(1, 1, 9, 9, requires_grad=True)
ones = torch.ones(1, 1, 3, 3)
hidden = F.conv2d(image, ones, stride=2, padding=1)
output = F.conv2d(hidden, ones, stride=1, padding=0)
output[0, 0, 1, 1].backward()
support = image.grad[0, 0] != 0
expected = torch.zeros(9, 9, dtype=torch.bool)
expected[1:8, 1:8] = True
assert torch.equal(support, expected)
print("中间 / 最终形状:", tuple(hidden.shape), tuple(output.shape))
print("理论感受野:", receptive, "非零梯度像素:", support.sum().item())
print("卷积与感受野检查通过")

