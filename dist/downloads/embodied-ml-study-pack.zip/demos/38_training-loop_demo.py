# [1] 独立的合成训练集与验证集
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
torch.manual_seed(19)
true_weight = torch.randn(4, 2)
x = torch.randn(173, 4)
y = x @ true_weight + 0.2 + 0.01 * torch.randn(173, 2)
train_loader = DataLoader(TensorDataset(x[:128], y[:128]),
                          batch_size=24, shuffle=True, num_workers=0)
val_loader = DataLoader(TensorDataset(x[128:], y[128:]),
                        batch_size=16, shuffle=False, num_workers=0)
model = nn.Linear(4, 2)
optimizer = torch.optim.AdamW(model.parameters(), lr=0.03, weight_decay=0)

# [2] 按元素总数汇总，保存并恢复模型原来的模式
def evaluate(model, loader):
    was_training = model.training
    model.eval()
    error_sum, count = 0.0, 0
    with torch.no_grad():
        for inputs, targets in loader:
            errors = (model(inputs) - targets).square()
            error_sum += errors.sum().item()
            count += errors.numel()
    model.train(was_training)
    return error_sum / count

# [3] 清零、前向、反向、有限性检查、裁剪、更新
for epoch in range(80):
    model.train()
    train_sum, train_count = 0.0, 0
    for inputs, targets in train_loader:
        optimizer.zero_grad(set_to_none=True)
        errors = (model(inputs) - targets).square()
        loss = errors.mean()
        assert torch.isfinite(loss), "发现非有限 loss"
        loss.backward()
        grad_norm = nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
        assert torch.isfinite(grad_norm), "发现非有限梯度"
        optimizer.step()
        train_sum += errors.detach().sum().item()
        train_count += errors.numel()
    if epoch in (0, 19, 79):
        print(epoch, "train MSE", round(train_sum/train_count, 6),
              "val MSE", round(evaluate(model, val_loader), 6))
assert evaluate(model, val_loader) < 0.01
print("训练循环与验证检查通过")

