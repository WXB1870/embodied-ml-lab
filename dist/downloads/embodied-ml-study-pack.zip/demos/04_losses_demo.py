import torch

torch.manual_seed(0)
pred = torch.tensor([[[1., 2.], [3., 4.], [float("nan"), float("nan")]],
                     [[2., 1.], [float("nan"), float("nan")],
                      [float("nan"), float("nan")]]], requires_grad=True)
valid = torch.tensor([[True, True, False], [True, False, False]])
target = torch.where(valid[..., None], torch.zeros_like(pred),
                     torch.full_like(pred, float("nan")))
dim_weight = torch.tensor([1., 2.])

# STEP 1: 先构造实际有效集合，再做差与平方。
weight = valid.unsqueeze(-1).to(pred.dtype) * dim_weight
active = weight > 0
denominator = weight.sum()
if denominator <= 0:
    raise ValueError("没有正权重的有效监督")
safe_pred = torch.where(active, pred, torch.zeros_like(pred))
safe_target = torch.where(active, target, torch.zeros_like(target))
error = safe_pred - safe_target
loss = (error.square() * weight).sum() / denominator
assert torch.allclose(loss, torch.tensor(56. / 9.))

# STEP 2: 两种错误独立验证：先计算 NaN 再乘零；使用 Padding 分母。
unsafe_loss = ((pred - target).square() * weight).sum() / denominator
assert torch.isnan(unsafe_loss)
wrong_mean = (error.square() * weight).mean()
assert torch.allclose(wrong_mean, torch.tensor(56. / 12.))

# STEP 3: 直接按解析式核对全部预测梯度。
loss.backward()
expected_grad = 2 * error.detach() * weight / denominator
torch.testing.assert_close(pred.grad, expected_grad)
assert torch.isfinite(pred.grad).all()
assert torch.equal(pred.grad[~active], torch.zeros_like(pred.grad[~active]))
print("正确损失:", loss.item(), "错误 Padding mean:", wrong_mean.item())
print("有效标量数:", int(active.sum()), "加权分母:", denominator.item())

