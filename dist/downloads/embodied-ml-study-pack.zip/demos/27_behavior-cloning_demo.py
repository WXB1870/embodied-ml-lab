import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 构造合成示教，条件是 [当前位置, 目标位置]
condition = torch.rand(256, 2) * 2 - 1
expert_action = (0.4 * (condition[:, 1:] - condition[:, :1])).clamp(-0.2, 0.2)
policy = nn.Sequential(nn.Linear(2, 32), nn.Tanh(), nn.Linear(32, 1))
optimizer = torch.optim.AdamW(policy.parameters(), lr=0.01, weight_decay=0.0)
with torch.no_grad():
    initial_loss = (policy(condition) - expert_action).square().mean().item()

# STEP 2: 在固定示教上学习条件动作映射
for _ in range(200):
    prediction = policy(condition)  # [256, 1]
    loss = (prediction - expert_action).square().mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

# STEP 3: 让预测动作影响下一步输入，构成闭环
policy.eval()
position, goal = -0.8, 0.7
trajectory = [position]
with torch.no_grad():
    for _ in range(15):
        inputs = torch.tensor([[position, goal]])
        action = policy(inputs).clamp(-0.2, 0.2).item()
        position += action  # 这里只是合成的一维积分系统
        trajectory.append(position)
    final_loss = (policy(condition) - expert_action).square().mean().item()

# STEP 4: 分开报告拟合误差与这一条合成轨迹
print('prediction shape:', tuple(policy(condition).shape))
print('training MSE:', round(initial_loss, 6), '->', round(final_loss, 6))
print('rollout positions:', [round(p, 3) for p in trajectory])
print('final goal error:', round(abs(position - goal), 4))
assert torch.isfinite(torch.tensor(trajectory)).all()

