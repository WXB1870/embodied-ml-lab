# [1] 随机初始化的接口教学，不代表已训练好的 VLM
import torch
from torch import nn
from torch.nn import functional as F
torch.manual_seed(16)
B, D = 2, 24
images = torch.randn(B, 3, 16, 16)
vision = nn.Conv2d(3, 12, kernel_size=4, stride=4)
vision.requires_grad_(False)
vision.eval()
projector = nn.Linear(12, D)
patch_position = nn.Parameter(torch.randn(1, 16, D) * 0.02)
text_embedding = nn.Embedding(32, D)
fusion = nn.MultiheadAttention(D, 4, dropout=0.0, batch_first=True)
classifier = nn.Linear(D, 2)

# [2] 输入前没有可训练模块；只关闭固定视觉编码器的图记录
def classify(images, token_ids):
    with torch.no_grad():
        raw = vision(images).flatten(2).transpose(1, 2)
    visual = projector(raw) + patch_position
    # 固定长度、无 padding 的教学文本；真实变长输入需要有效位
    query = text_embedding(token_ids).mean(dim=1, keepdim=True)
    pooled, _ = fusion(query, visual, visual, need_weights=False)
    return classifier(pooled[:, 0]), visual, query

# [3] 两类合成标签使用整数类别，CrossEntropy 接收原始 logits
token_ids = torch.tensor([[2, 4, 7], [2, 9, 7]], dtype=torch.long)
labels = torch.tensor([0, 1], dtype=torch.long)
logits, visual, query = classify(images, token_ids)
loss = F.cross_entropy(logits, labels)
loss.backward()
assert logits.shape == (B, 2)
assert all(p.grad is None for p in vision.parameters())
tracked = [projector.weight, patch_position, text_embedding.weight,
           fusion.in_proj_weight, classifier.weight]
assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in tracked)
assert all(p.grad.norm() > 0 for p in tracked)

# [4] 固定图像，只替换一个样本的文本，检查条件路径与样本隔离
changed_ids = token_ids.clone()
changed_ids[0, 1] = 11
with torch.no_grad():
    changed, _, _ = classify(images, changed_ids)
    torch.testing.assert_close(changed[1], logits.detach()[1])
    assert not torch.allclose(changed[0], logits.detach()[0])
print("视觉 / 查询 / 分类 logits:", visual.shape, query.shape, logits.shape)
print("冻结边界、可训练梯度和文本条件路径检查通过")

