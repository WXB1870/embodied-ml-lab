"""Conditional DDPM on the same 2D mixture used by the Flow Matching course."""
import json
from pathlib import Path
import torch
from torch import nn

SEED = 20261106
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


def sample_data(condition, generator=None):
    first = torch.rand(len(condition), generator=generator) < WEIGHTS[condition, 0]
    component = (~first).long()
    return MEANS[condition, component] + DATA_STD * torch.randn(
        len(condition), 2, generator=generator)


class NoisePredictor(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, k, condition, levels):
        tau = k.to(x.dtype)[:, None] / (levels - 1)
        clock = torch.cat((tau, torch.sin(torch.pi*tau), torch.cos(torch.pi*tau)), -1)
        context = nn.functional.one_hot(condition, 2).to(x.dtype)
        return self.net(torch.cat((x, clock, context), -1))  # [B,7] -> [B,2]


def oracle_noise(x, alpha_bar, condition):
    alpha, sigma = alpha_bar.sqrt(), (1-alpha_bar).sqrt()  # [B,1]
    q = alpha.square()*DATA_STD**2 + sigma.square()
    residual = x[:, None, :] - alpha[:, :, None]*MEANS.to(x)[condition]
    logits = WEIGHTS.to(x)[condition].log() - residual.square().sum(-1)/(2*q)
    posterior = logits.softmax(-1)  # p(component | x,k,c)
    return (posterior[:, :, None]*(sigma/q)[:, :, None]*residual).sum(1)


def run(output="ddpm_mixture_results.json", train_steps=1800):
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    levels = 64
    beta = torch.linspace(0.001, 0.2, levels)
    alpha = 1-beta
    alpha_bar = alpha.cumprod(0)
    previous = torch.cat((torch.ones(1), alpha_bar[:-1]))
    posterior_variance = beta*(1-previous)/(1-alpha_bar)
    assert posterior_variance[0] == 0
    assert torch.all((beta > 0) & (beta < 1))
    model = NoisePredictor()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.002)

    def batch(size, generator=None):
        condition = torch.randint(2, (size,), generator=generator)
        clean = sample_data(condition, generator)
        k = torch.randint(levels, (size,), generator=generator)
        noise = torch.randn(size, 2, generator=generator)
        ab = alpha_bar[k, None]  # coefficients broadcast across D=2, not B
        noisy = ab.sqrt()*clean + (1-ab).sqrt()*noise
        return noisy, k, condition, noise

    probe = batch(4096, torch.Generator().manual_seed(SEED+1))
    with torch.no_grad():
        before = (model(*probe[:3], levels)-probe[3]).square().mean().item()
    for _ in range(train_steps):
        noisy, k, condition, noise = batch(256)
        loss = (model(noisy, k, condition, levels)-noise).square().mean()
        assert torch.isfinite(loss)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()

    model.eval()
    with torch.no_grad():
        estimate = model(*probe[:3], levels)
        oracle = oracle_noise(probe[0], alpha_bar[probe[1], None], probe[2])
        after = (estimate-probe[3]).square().mean().item()
        oracle_target_mse = (oracle-probe[3]).square().mean().item()
        model_oracle_mse = (estimate-oracle).square().mean().item()
        assert after < before  # this fixed experiment; not a general convergence theorem
        generator = torch.Generator().manual_seed(SEED+2)
        condition = torch.arange(1024) % 2
        initial = torch.randn(1024, 2, generator=generator)
        target = sample_data(condition, generator)
        x = initial.clone()
        for k in reversed(range(levels)):
            index = torch.full((len(x),), k, dtype=torch.long)
            eps_hat = model(x, index, condition, levels)
            mean = (x-beta[k]/(1-alpha_bar[k]).sqrt()*eps_hat)/alpha[k].sqrt()
            # No fresh noise at k=0; the terminal clean estimate is the mean.
            x = mean if k == 0 else mean + posterior_variance[k].sqrt()*torch.randn(
                x.shape, generator=generator)
        assert x.shape == (1024, 2) and torch.isfinite(x).all()

    result = {"seed": SEED, "torch": torch.__version__, "device": "cpu",
              "dtype": "float32", "levels": levels, "train_steps": train_steps,
              "terminal_alpha_bar": alpha_bar[-1].item(),
              "probe": {"before_mse": before, "after_mse": after,
                        "oracle_target_mse": oracle_target_mse,
                        "learned_to_oracle_mse": model_oracle_mse},
              "data_std": DATA_STD, "means": MEANS.tolist(), "weights": WEIGHTS.tolist(),
              "conditions": [],
              "limits": ["One fixed-seed teaching experiment, not a policy benchmark.",
                         "The finite schedule has a small, nonzero terminal signal.",
                         "DDPM's finite Gaussian reverse steps are approximations.",
                         "Noise and velocity MSE have different units and time weights."]}
    for c in (0, 1):
        select = condition == c
        nearest = (x[select, None, :]-MEANS[c]).square().sum(-1).argmin(-1)
        result["conditions"].append({"id": c, "noise": initial[select][:200].tolist(),
                                     "data": target[select][:200].tolist(),
                                     "generated": x[select][:200].tolist(),
                                     "nearest_mode_fractions": torch.bincount(
                                         nearest, minlength=2).div(select.sum()).tolist()})
    Path(output).write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"probe": result["probe"], "generated_shape": list(x.shape),
                      "terminal_alpha_bar": result["terminal_alpha_bar"]}, indent=2))
    return result


if __name__ == "__main__":
    run()

