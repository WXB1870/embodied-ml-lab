import torch
import torch.nn.functional as F

torch.manual_seed(0)
# STEP 1: 每条样本的 logits 对应一个类别分布
logits = torch.tensor([[2., 0., -1.], [0.5, 1., 3.]],
                      dtype=torch.float64, requires_grad=True)
target = torch.tensor([0, 2], dtype=torch.long)
log_prob = F.log_softmax(logits, dim=-1)
selected = log_prob.gather(1, target[:, None]).squeeze(1)
manual_ce = -selected.mean()
builtin_ce = F.cross_entropy(logits, target)
assert torch.allclose(manual_ce, builtin_ce)
print("cross entropy:", manual_ce.item())

# STEP 2: 共同平移 logits 不改变概率
shifted = F.log_softmax(logits + 10000, dim=-1)
assert torch.allclose(shifted, log_prob, atol=1e-10)
manual_ce.backward()
print("gradient:", logits.grad.tolist())

# STEP 3: 明确 KL 的方向与 API 的输入约定
p = torch.tensor([[0.8, 0.2]], dtype=torch.float64)
q = torch.tensor([[0.5, 0.5]], dtype=torch.float64)
manual_kl = (p * (p.log() - q.log())).sum(dim=-1).mean()
# kl_div 的第一个输入是 log(q)，第二个输入是 p
api_kl = F.kl_div(q.log(), p, reduction="batchmean")
assert torch.allclose(manual_kl, api_kl)
print("KL(p||q):", manual_kl.item())
choices = torch.tensor([-1.0, 1.0])
print("two-mode MSE optimal point:", choices.mean().item())

