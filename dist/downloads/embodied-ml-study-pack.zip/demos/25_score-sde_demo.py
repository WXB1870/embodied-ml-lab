"""One conditional mixture, two marginal paths, exact score/velocity/PDE checks."""
import json
import math
from pathlib import Path
import torch

torch.set_num_threads(1)
torch.set_default_dtype(torch.float64)
torch.manual_seed(20261106)
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


def coefficients(t, path):
    # t is ALWAYS noise -> data here. The diffusion forward clock is tau=1-t.
    if path == "linear":
        return t, 1-t, torch.ones_like(t), -torch.ones_like(t)
    if path == "vp":
        angle = math.pi*t/2
        a, s = angle.sin(), angle.cos()
        return a, s, math.pi*s/2, -math.pi*a/2
    raise ValueError("path must be linear or vp")


def mixture(x, t, condition, path):
    a, s, ad, sd = coefficients(t, path)  # t is a scalar tensor in this example
    q = a.square()*DATA_STD**2 + s.square()
    means, weights = MEANS.to(x)[condition], WEIGHTS.to(x)[condition]
    residual = x[:, None, :] - a*means  # [B,K=2,D=2]
    logits = weights.log()-residual.square().sum(-1)/(2*q)
    logp = torch.logsumexp(logits, -1)-x.shape[-1]/2*torch.log(2*math.pi*q)
    rho = logits.softmax(-1)
    score = -(rho[:, :, None]*residual).sum(1)/q
    clean_mean = (rho[:, :, None]*(means+a*DATA_STD**2/q*residual)).sum(1)
    noise_mean = (rho[:, :, None]*(s/q*residual)).sum(1)
    velocity = ad*clean_mean+sd*noise_mean  # conditional expectation, not pair target
    return logp, score, clean_mean, noise_mean, velocity


def divergence(vector, x):
    return sum(torch.autograd.grad(vector[:, j].sum(), x, create_graph=True,
                                   retain_graph=True)[0][:, j] for j in range(x.shape[1]))


def run(output="score_mixture_results.json"):
    rows = []
    for path in ("linear", "vp"):
        x = torch.tensor([[0.2,-0.3], [1.4,0.2], [-1.2,0.4]], requires_grad=True)
        condition = torch.tensor([0, 1, 0])
        t = torch.tensor(0.4, requires_grad=True)
        logp, score, clean, noise, velocity = mixture(x,t,condition,path)
        a, s, ad, sd = coefficients(t,path)
        exact_score = torch.autograd.grad(logp.sum(),x,create_graph=True)[0]
        torch.testing.assert_close(score,exact_score,atol=1e-11,rtol=1e-10)
        torch.testing.assert_close(noise,-s*score,atol=1e-11,rtol=1e-10)
        torch.testing.assert_close(clean,(x+s.square()*score)/a,atol=1e-11,rtol=1e-10)
        from_score = ad/a*x+(ad/a*s.square()-s*sd)*score
        torch.testing.assert_close(velocity,from_score,atol=1e-11,rtol=1e-10)

        # Continuity equation on the GENERATION clock for both paths.
        p = logp.exp()
        dpdt = torch.stack([torch.autograd.grad(p[i],t,retain_graph=True)[0]
                           for i in range(len(p))])
        continuity = -divergence(p[:,None]*velocity,x)
        torch.testing.assert_close(dpdt,continuity,atol=1e-11,rtol=1e-9)
        row = {"path": path, "score_max_error": (score-exact_score).abs().max().item(),
               "continuity_max_error": (dpdt-continuity).abs().max().item()}

        if path == "vp":
            # Forward tau=1-t: beta(tau)=pi*tan(pi*tau/2)=pi*s/a.
            # beta diverges at tau=1: use interior times, not this endpoint formula.
            beta = math.pi*s/a
            forward_drift = -0.5*beta*x
            gradp = torch.autograd.grad(p.sum(),x,create_graph=True,retain_graph=True)[0]
            fp = -divergence(p[:,None]*forward_drift,x)+0.5*beta*divergence(gradp,x)
            torch.testing.assert_close(-dpdt,fp,atol=1e-11,rtol=1e-9)
            torch.testing.assert_close(velocity,0.5*beta*(x+score),atol=1e-11,rtol=1e-10)
            row["forward_fp_max_error"] = (-dpdt-fp).abs().max().item()
        rows.append(row)

    # Endpoints match, intermediate densities differ. No neural net is trained here.
    x = torch.tensor([[0.2,-0.3], [1.4,0.2], [-1.2,0.4]])
    condition = torch.tensor([0,1,0])
    for endpoint in (0.0,1.0):
        t = torch.tensor(endpoint)
        torch.testing.assert_close(mixture(x,t,condition,"linear")[0],
                                   mixture(x,t,condition,"vp")[0])
    t = torch.tensor(0.5)
    assert not torch.allclose(mixture(x,t,condition,"linear")[0],
                              mixture(x,t,condition,"vp")[0])
    # Pairwise paths with the SAME fixed noise must not be called Brownian sample paths.
    clean, noise = torch.randn(3,2), torch.randn(3,2)
    h = 1e-5
    for path in ("linear","vp"):
        a,s,ad,sd = coefficients(t,path)
        ap,sp,_,_ = coefficients(t+h,path)
        am,sm,_,_ = coefficients(t-h,path)
        finite_difference = ((ap*clean+sp*noise)-(am*clean+sm*noise))/(2*h)
        torch.testing.assert_close(finite_difference,ad*clean+sd*noise,atol=1e-9,rtol=1e-9)
    # Retain the stationary-Gaussian sign check from the original implementation.
    beta = 1.3
    stationary_score = -x
    forward_drift = -0.5*beta*x
    torch.testing.assert_close(forward_drift-0.5*beta*stationary_score,torch.zeros_like(x))
    torch.testing.assert_close(-forward_drift+beta*stationary_score,-0.5*beta*x)
    result = {"torch":torch.__version__,"device":"cpu","dtype":"float64",
              "means":MEANS.tolist(),"weights":WEIGHTS.tolist(),"data_std":DATA_STD,
              "checks":rows,"endpoints_equal":True,"middle_paths_differ":True,
              "limits":["Analytic identity checks, not trained generation results.",
                         "The VP interpolation gives SDE marginals, not Brownian trajectories.",
                         "Score-to-output division is only used at interior times."]}
    Path(output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    return result


if __name__ == "__main__":
    run()

