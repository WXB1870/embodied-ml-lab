import math
import torch

torch.manual_seed(7)

# STEP 1: 三个返回时间不同的预测，第三个属于新指令
plans=[
 {'obs':0.0,'ready':0.15,'start':0.0,'epoch':0,'values':torch.arange(6).float()*0.1},
 {'obs':0.2,'ready':0.33,'start':0.2,'epoch':0,'values':torch.arange(6).float()*0.1+0.25},
 {'obs':0.4,'ready':0.53,'start':0.4,'epoch':1,'values':0.2-torch.arange(6).float()*0.1},
]
dt,max_age=0.1,0.35

# STEP 2: 按当前时间选槽位，不重新播放已经过去的前缀
def pick(now,epoch):
    candidates=[]
    for p in plans:
        if p['ready']>now or p['obs']>now or p['epoch']!=epoch or now-p['obs']>max_age:
            continue
        index=math.floor((now-p['start'])/dt+1e-9)
        if 0<=index<len(p['values']):
            candidates.append((p['obs'],index,p['values'][index]))
    return max(candidates,key=lambda x:x[0]) if candidates else None

# STEP 3: 位置与参考变化率区间取交集，不声称约束了实测动力学
def bounded_reference(previous,target):
    if not torch.isfinite(target).all():
        raise ValueError('non-finite target')
    lower=torch.maximum(torch.tensor(-0.5),previous-0.5*dt)
    upper=torch.minimum(torch.tensor(0.5),previous+0.5*dt)
    if (lower>upper).any():
        raise ValueError('incompatible reference constraints')
    return torch.maximum(lower,torch.minimum(upper,target))

# STEP 4: 新指令切换后拒绝旧结果；过期也不能靠平滑变新
previous=torch.tensor(0.0)
for tick in range(9):
    now=tick*dt
    epoch=1 if tick>=5 else 0
    selected=pick(now,epoch)
    if selected is None:
        print(round(now,1),'WAIT: no valid action')
        continue  # 真实系统的等待行为由执行状态机定义
    source,index,target=selected
    previous=bounded_reference(previous,target)
    print(round(now,1),'source',source,'slot',index,'reference',round(previous.item(),3))
assert pick(0.1,0) is None
assert pick(0.2,0)[1]==2
assert pick(0.5,1) is None
assert pick(0.8,1) is None

