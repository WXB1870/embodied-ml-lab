"""一个连续训练案例：同一数据、模型、有效位和目标贯穿全部验证。

运行：python training-shared-project.py（只需 PyTorch，使用 CPU）。
本例选择可实现的 4→2 线性回归，隔离训练工程；不表示机器人策略。
"""
import copy
import io
import json
from contextlib import nullcontext
from itertools import islice

import torch
from torch import nn
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import Dataset, DataLoader


# 01 数据：每个 episode 是一条变长序列，不把 Padding 当真实零值。
class ToyEpisodes(Dataset):
    def __init__(self, count=44, seed=211):
        generator = torch.Generator().manual_seed(seed)
        scale = torch.tensor([1., 10., .1, 3.])
        weight = torch.tensor([[.7, -.1], [-.3, .6], [.5, .2], [.2, -.4]])
        self.items = []
        for index in range(count):
            length = [1, 4, 2, 5, 3][index % 5]
            features = torch.randn(length, 4, generator=generator)
            target = features @ weight + torch.tensor([.2, -.4])
            target += .01 * torch.randn(length, 2, generator=generator)
            self.items.append({"id": index, "x": features * scale, "y": target})

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        return self.items[index]


def collate_episodes(items):
    if not items or any(len(item["x"]) == 0 for item in items):
        raise ValueError("本例拒绝空 Batch 或空 episode")
    lengths = torch.tensor([len(item["x"]) for item in items])
    x = pad_sequence([item["x"] for item in items], batch_first=True,
                     padding_value=float("nan"))
    y = pad_sequence([item["y"] for item in items], batch_first=True,
                     padding_value=float("nan"))
    valid = torch.arange(x.shape[1])[None, :] < lengths[:, None]
    return {"x": x, "y": y, "valid": valid,
            "ids": [item["id"] for item in items]}


def fit_statistics(train_items):
    # 只访问训练切分的真实 token，不从补齐后的数组估计统计量。
    x = torch.cat([item["x"] for item in train_items])
    y = torch.cat([item["y"] for item in train_items])
    return {"x_mean": x.mean(0), "x_scale": x.std(0, correction=0).clamp_min(1e-6),
            "y_mean": y.mean(0), "y_scale": y.std(0, correction=0).clamp_min(1e-6)}


# 02 模型：沿用训练循环主例的 Linear(4,2)，只增加已定义的状态管理。
class TokenRegressor(nn.Module):
    def __init__(self, statistics):
        super().__init__()
        for name, value in statistics.items():
            self.register_buffer(name, value.clone())
        self.head = nn.Linear(4, 2)

    def forward(self, x, valid):
        if x.ndim != 3 or valid.dtype != torch.bool or valid.shape != x.shape[:2]:
            raise ValueError("需要 [B,T,4] 输入与 bool [B,T] 有效位")
        if x.shape[-1] != 4 or not torch.isfinite(x[valid]).all():
            raise ValueError("有效输入必须为有限四维特征")
        # 在 Linear 之前隔离 NaN；只在 loss 处乘零仍可能污染权重梯度。
        clean = x.masked_fill(~valid[..., None], 0)
        return self.head((clean - self.x_mean) / self.x_scale)


def masked_error_sum(model, prediction, batch):
    target, valid = batch["y"], batch["valid"]
    if prediction.shape != target.shape or not valid.any():
        raise ValueError("预测/目标必须同形，并且至少有一项监督")
    selected = target[valid]  # 先选择，再做减法/平方，不能先计算 NaN 误差。
    if not torch.isfinite(selected).all():
        raise ValueError("有效标签出现非有限值")
    target_normalized = (selected - model.y_mean) / model.y_scale
    # BF16 输出在敏感归约之前转 FP32；double 对照则保留 float64。
    compute_dtype = torch.float64 if prediction.dtype == torch.float64 else torch.float32
    error = prediction[valid].to(compute_dtype) - target_normalized.to(compute_dtype)
    return error.square().sum(), error.numel()


def amp_context(enabled):
    return torch.autocast("cpu", dtype=torch.bfloat16) if enabled else nullcontext()


# 03 一次更新：分母属于整个累积窗口，不属于单个微批次。
def train_window(model, optimizer, batches, scheduler=None, cpu_amp=False):
    denominator = sum(int(batch["valid"].sum()) * 2 for batch in batches)
    if denominator == 0:
        raise ValueError("当前累积窗口没有监督")
    model.train()
    optimizer.zero_grad(set_to_none=True)
    numerator = 0.
    before = [p.detach().clone() for p in model.parameters()]
    for batch in batches:
        with amp_context(cpu_amp):
            prediction = model(batch["x"], batch["valid"])
        total, _ = masked_error_sum(model, prediction, batch)
        assert torch.isfinite(total), "非有限 loss：先审查输入/标签和分母"
        (total / denominator).backward()
        numerator += total.detach().item()
    assert all(p.grad is not None and torch.isfinite(p.grad).all()
               for p in model.parameters()), "梯度缺失或非有限"
    # 同一窗口只裁剪一次；CPU BF16 不使用 FP16 GradScaler。
    grad_norm = nn.utils.clip_grad_norm_(model.parameters(), 10., error_if_nonfinite=True)
    optimizer.step()
    if scheduler is not None:
        scheduler.step()  # 按实际 optimizer update 推进。
    displacement = sum((p.detach() - old).square().sum().item()
                       for p, old in zip(model.parameters(), before)) ** .5
    return {"sum": numerator, "count": denominator,
            "grad_norm": float(grad_norm), "update_norm": displacement}


def make_loader(items, generator, shuffle):
    return DataLoader(items, batch_size=5, shuffle=shuffle, drop_last=False,
                      num_workers=0, collate_fn=collate_episodes, generator=generator)


def train_epoch(model, optimizer, scheduler, loader, update_step, cpu_amp=False):
    iterator, sums, counts, order = iter(loader), 0., 0, []
    while batches := list(islice(iterator, 2)):
        result = train_window(model, optimizer, batches, scheduler, cpu_amp)
        sums += result["sum"]
        counts += result["count"]
        order.extend(index for batch in batches for index in batch["ids"])
        update_step += 1
    return {"mse": sums / counts, "count": counts, "order": order,
            "update_step": update_step}


@torch.no_grad()
def evaluate(model, loader):
    was_training = model.training
    model.eval()
    sums, counts = 0., 0
    for batch in loader:
        prediction = model(batch["x"], batch["valid"])
        total, count = masked_error_sum(model, prediction, batch)
        sums += total.item()
        counts += count
    model.train(was_training)  # 本例只有 Linear，没有需要单独恢复的混合模式。
    return sums / counts


# 04 从同一状态分叉：full batch 与不等有效长度 microbatch 的更新对照。
def verify_accumulation(model, items):
    full, accumulated, wrong = [copy.deepcopy(model).double() for _ in range(3)]
    def as_double(batch):
        return {key: value.double() if key in ("x", "y") else value
                for key, value in batch.items()}
    whole = as_double(collate_episodes(items[:7]))
    parts = [as_double(collate_episodes(items[:2])), as_double(collate_episodes(items[2:7]))]
    full_opt = torch.optim.SGD(full.parameters(), lr=.05)
    accumulated_opt = torch.optim.SGD(accumulated.parameters(), lr=.05)
    train_window(full, full_opt, [whole])
    train_window(accumulated, accumulated_opt, parts)
    grad_difference = parameter_difference = 0.
    for reference, actual in zip(full.parameters(), accumulated.parameters()):
        torch.testing.assert_close(actual.grad, reference.grad, rtol=1e-12, atol=1e-12)
        torch.testing.assert_close(actual, reference, rtol=1e-12, atol=1e-12)
        grad_difference = max(grad_difference, (actual.grad - reference.grad).abs().max().item())
        parameter_difference = max(parameter_difference, (actual - reference).abs().max().item())
    # 故意错误的控制组：局部 mean 再除微批次数，使短微批次过度加权。
    for part in parts:
        total, count = masked_error_sum(wrong, wrong(part["x"], part["valid"]), part)
        (total / count / len(parts)).backward()
    wrong_difference = max((p.grad - q.grad).abs().max().item()
                           for p, q in zip(wrong.parameters(), full.parameters()))
    assert wrong_difference > 1e-3
    return {"valid_counts": [int(part["valid"].sum()) * 2 for part in parts],
            "gradient_max_abs_error": grad_difference,
            "parameter_max_abs_error": parameter_difference,
            "wrong_local_mean_gradient_error": wrong_difference}


# 05 相同输入、初值、目标：单独改变算子精度，核对 dtype 和数值差别。
def verify_cpu_amp(model, batch):
    plain, mixed = copy.deepcopy(model), copy.deepcopy(model)
    losses, grads = [], []
    for current, enabled in [(plain, False), (mixed, True)]:
        with amp_context(enabled):
            prediction = current(batch["x"], batch["valid"])
        total, count = masked_error_sum(current, prediction, batch)
        loss = total / count
        loss.backward()
        assert prediction.dtype == (torch.bfloat16 if enabled else torch.float32)
        assert loss.dtype == torch.float32
        assert all(p.dtype == p.grad.dtype == torch.float32 for p in current.parameters())
        losses.append(loss.detach().item())
        grads.append(torch.cat([p.grad.flatten() for p in current.parameters()]))
    relative_error = float((grads[0] - grads[1]).norm() / grads[0].norm())
    assert relative_error < .03  # 仅约束这个小例子；并非任意模型的 BF16 误差界。
    updated = copy.deepcopy(model)
    result = train_window(updated, torch.optim.SGD(updated.parameters(), lr=.05),
                          [batch], cpu_amp=True)
    assert result["update_norm"] > 0
    return {"fp32_loss": losses[0], "cpu_bf16_loss": losses[1],
            "gradient_relative_error": relative_error,
            "parameter_gradient_dtype": "float32", "autocast_output_dtype": "bfloat16",
            "cpu_amp_update_norm": result["update_norm"]}


# 06 诊断：同一个 Batch 中无效 NaN 被隔离；有效 NaN 必须立即拒绝。
def verify_masks(model, batch):
    x = batch["x"].clone().requires_grad_()
    baseline = model(x, batch["valid"])
    zero_pad = batch["x"].masked_fill(~batch["valid"][..., None], 0)
    torch.testing.assert_close(model(zero_pad, batch["valid"]), baseline)
    total, count = masked_error_sum(model, baseline, batch)
    dx, = torch.autograd.grad(total / count, x)
    assert torch.isfinite(dx).all() and torch.count_nonzero(dx[~batch["valid"]]) == 0
    poisoned = {key: value.clone() if isinstance(value, torch.Tensor) else value
                for key, value in batch.items()}
    poisoned["y"][0, 0, 0] = float("nan")
    try:
        masked_error_sum(model, baseline, poisoned)
    except ValueError:
        pass
    else:
        raise AssertionError("有效 NaN 标签不应被静默跳过")
    return {"valid_elements": count, "padding_input_gradient": 0,
            "invalid_label_rejected": True}


def verify_optimizer_diagnosis(model, batch):
    # 只改变优化器成员；相同模型、数据和 loss 仍能产生 bias 梯度。
    broken = copy.deepcopy(model)
    optimizer = torch.optim.SGD([broken.head.weight], lr=.05)
    members = {id(p) for group in optimizer.param_groups for p in group["params"]}
    old_bias = broken.head.bias.detach().clone()
    broken.zero_grad(set_to_none=True)
    total, count = masked_error_sum(broken, broken(batch["x"], batch["valid"]), batch)
    (total / count).backward()
    optimizer.step()
    assert broken.head.bias.grad is not None
    assert broken.head.bias.grad.norm() > 0
    assert id(broken.head.bias) not in members
    torch.testing.assert_close(broken.head.bias, old_bias, rtol=0, atol=0)
    return {"bias_has_gradient": True, "bias_in_optimizer": False,
            "bias_update_norm": 0., "diagnosis": "optimizer_omits_parameter"}


# 07 checkpoint：限制在 epoch 边界，保存 sampler generator 和优化状态。
def save_training(model, optimizer, scheduler, generator, epoch, update_step):
    stream = io.BytesIO()
    torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(), "torch_rng": torch.get_rng_state(),
                "loader_rng": generator.get_state(), "epoch": epoch,
                "update_step": update_step, "data_revision": "toy-episodes-v1",
                "boundary": "epoch_end", "cpu_amp": False}, stream)
    return stream.getvalue()


def assert_state_equal(left, right):
    if isinstance(left, torch.Tensor):
        torch.testing.assert_close(left, right, rtol=0, atol=0)
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            assert_state_equal(left[key], right[key])
    elif isinstance(left, (tuple, list)):
        assert len(left) == len(right)
        for a, b in zip(left, right):
            assert_state_equal(a, b)
    else:
        assert left == right


def main():
    torch.set_num_threads(1)
    torch.manual_seed(213)
    dataset = ToyEpisodes()
    train_items, validation_items = dataset.items[:32], dataset.items[32:]
    assert set(item["id"] for item in train_items).isdisjoint(
        item["id"] for item in validation_items)
    statistics = fit_statistics(train_items)
    model = TokenRegressor(statistics)
    assert sum(p.numel() for p in model.parameters()) == 10
    probe = collate_episodes(train_items[:7])
    evidence = {"mask": verify_masks(model, probe),
                "accumulation": verify_accumulation(model, train_items),
                "cpu_amp": verify_cpu_amp(model, probe),
                "diagnosis": verify_optimizer_diagnosis(model, probe)}
    generator = torch.Generator().manual_seed(217)
    loader = make_loader(train_items, generator, shuffle=True)
    val_loader = make_loader(validation_items, torch.Generator().manual_seed(219), False)
    optimizer = torch.optim.AdamW(model.parameters(), lr=.04, weight_decay=0.)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=40, gamma=.8)
    initial = evaluate(model, val_loader)
    update_step = 0
    for epoch in range(3):
        result = train_epoch(model, optimizer, scheduler, loader, update_step)
        update_step = result["update_step"]
        assert sorted(result["order"]) == list(range(32))
        assert result["count"] == sum(len(item["y"]) * 2 for item in train_items)
    saved = save_training(model, optimizer, scheduler, generator, 3, update_step)
    expected = train_epoch(model, optimizer, scheduler, loader, update_step)

    # 构造操作可能消耗随机数，必须先构造/加载，最后恢复 RNG。
    restored = TokenRegressor(statistics)
    restored_opt = torch.optim.AdamW(restored.parameters(), lr=.04, weight_decay=0.)
    restored_scheduler = torch.optim.lr_scheduler.StepLR(restored_opt, step_size=40, gamma=.8)
    restored_generator = torch.Generator()
    state = torch.load(io.BytesIO(saved), weights_only=True, map_location="cpu")
    assert state["data_revision"] == "toy-episodes-v1" and state["boundary"] == "epoch_end"
    restored.load_state_dict(state["model"])
    restored_opt.load_state_dict(state["optimizer"])
    restored_scheduler.load_state_dict(state["scheduler"])
    restored_generator.set_state(state["loader_rng"])
    restored_loader = make_loader(train_items, restored_generator, True)
    torch.set_rng_state(state["torch_rng"])
    actual = train_epoch(restored, restored_opt, restored_scheduler,
                         restored_loader, state["update_step"])
    assert_state_equal(expected, actual)
    assert_state_equal(model.state_dict(), restored.state_dict())
    assert_state_equal(optimizer.state_dict(), restored_opt.state_dict())
    assert_state_equal(scheduler.state_dict(), restored_scheduler.state_dict())
    evidence["resume"] = {"next_epoch_identical": True, "saved_epoch": state["epoch"],
                          "saved_update_step": state["update_step"],
                          "next_update_step": actual["update_step"]}
    update_step = actual["update_step"]
    for _ in range(20):
        result = train_epoch(restored, restored_opt, restored_scheduler,
                             restored_loader, update_step)
        update_step = result["update_step"]
    final = evaluate(restored, val_loader)
    assert final < initial * .02
    evidence["training"] = {"initial_validation_normalized_mse": initial,
                            "final_validation_normalized_mse": final,
                            "optimizer_updates": update_step,
                            "valid_training_scalars_per_epoch": result["count"]}
    evidence["scope"] = {"device": "cpu", "torch": str(torch.__version__),
                         "workers": 0, "restore_boundary": "epoch_end",
                         "cuda_amp": "not_run", "real_ddp": "environment_blocked"}
    print(json.dumps(evidence, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

