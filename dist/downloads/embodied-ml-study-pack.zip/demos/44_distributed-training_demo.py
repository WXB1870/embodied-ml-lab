import os
import tempfile
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import TensorDataset, DistributedSampler

# STEP 1: 每个 worker 是真实进程，Gloo 仍需本机进程通信
def worker(rank, world_size, rendezvous):
    torch.set_num_threads(1)
    torch.manual_seed(33)
    dist.init_process_group('gloo', init_method='file://' + rendezvous,
                            rank=rank, world_size=world_size)
    try:
        x = torch.tensor([[1., 0.], [0., 1.], [1., 1.], [2., -1.]])
        y = torch.tensor([[1.], [2.], [3.], [0.]])
        model = nn.Linear(2, 1)
        reference = nn.Linear(2, 1)
        reference.load_state_dict(model.state_dict())
        ddp = DDP(model)
        # STEP 2: 输入由 sampler 分片；backward 中同步梯度
        sampler = DistributedSampler(TensorDataset(x, y), num_replicas=world_size,
                                     rank=rank, shuffle=False, drop_last=False)
        sampler.set_epoch(0)
        indices = list(sampler)
        optimizer = torch.optim.SGD(ddp.parameters(), lr=0.1)
        optimizer.zero_grad(set_to_none=True)
        loss = (ddp(x[indices]) - y[indices]).square().mean()
        loss.backward()
        optimizer.step()
        # STEP 3: 与完整批次更新对齐，再按分子与分母归约日志
        ref_opt = torch.optim.SGD(reference.parameters(), lr=0.1)
        ref_opt.zero_grad(set_to_none=True)
        (reference(x) - y).square().mean().backward()
        ref_opt.step()
        for p, q in zip(model.parameters(), reference.parameters()):
            torch.testing.assert_close(p, q)
        stats = torch.tensor([loss.item() * len(indices), float(len(indices))])
        dist.all_reduce(stats, op=dist.ReduceOp.SUM)
        if rank == 0:
            print('CPU Gloo 进程数:', world_size, '全局 MSE:', float(stats[0] / stats[1]))
            print('通过：两进程更新与单进程完整批次一致')
    finally:
        dist.destroy_process_group()

if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='eml-ddp-') as folder:
        mp.spawn(worker, args=(2, os.path.join(folder, 'rendezvous')), nprocs=2, join=True)

