import torch
from torch import nn

torch.manual_seed(31)
x = torch.randn(6, 3)
y = 2 * x[:, :1] - x[:, 1:2]
# STEP 1: 三种实验共享初始化与数据，控制唯一故障因素
def run_case(mode):
    torch.manual_seed(310)
    model = nn.ModuleDict({'trunk': nn.Linear(3, 4), 'head': nn.Linear(4, 1)})
    params = list(model['trunk'].parameters()) if mode == 'omit_head' else list(model.parameters())
    optimizer = torch.optim.SGD(params, lr=0.05)
    members = {id(p) for group in optimizer.param_groups for p in group['params']}
    before = {name: p.detach().clone() for name, p in model.named_parameters()}
    model.zero_grad(set_to_none=True)
    hidden = torch.tanh(model['trunk'](x))
    if mode == 'detach_trunk':
        hidden = hidden.detach()
    prediction = model['head'](hidden)
    loss = (prediction - y).square().mean()
    assert torch.isfinite(loss)
    loss.backward()
    optimizer.step()
    # STEP 2: 同时观察图连接、优化器成员和真实位移
    rows = {}
    for name, p in model.named_parameters():
        grad = p.grad
        rows[name] = {'in_optimizer': id(p) in members,
                      'has_grad': grad is not None,
                      'finite_grad': bool(torch.isfinite(grad).all()) if grad is not None else None,
                      'delta': float((p.detach() - before[name]).norm())}
    return rows

# STEP 3: 用有针对性的断言区分三种训练状态
for mode in ['correct', 'detach_trunk', 'omit_head']:
    report = run_case(mode)
    print(mode, report)
    if mode == 'correct':
        assert all(r['has_grad'] and r['in_optimizer'] and r['delta'] > 0 for r in report.values())
    elif mode == 'detach_trunk':
        assert not report['trunk.weight']['has_grad']
        assert report['trunk.weight']['in_optimizer']
        assert report['trunk.weight']['delta'] == 0
    else:
        assert report['head.weight']['has_grad']
        assert not report['head.weight']['in_optimizer']
        assert report['head.weight']['delta'] == 0
print('通过：断图和漏加优化器产生不同证据，不能混为一谈')

