import torch
import torch.nn.functional as F

torch.manual_seed(52)

def split_visual_tokens(hidden, grid_hw, num_registers):
    """Contract: [CLS, registers, row-major patches], all already encoded."""
    if hidden.ndim != 3:
        raise ValueError("expected [B,N,D]")
    gh, gw = grid_hw
    if gh <= 0 or gw <= 0 or num_registers < 0:
        raise ValueError("invalid grid or register count")
    start = 1 + num_registers
    if hidden.shape[1] != start + gh * gw:
        raise ValueError("token count disagrees with the declared layout")
    patches = hidden[:, start:]
    grid = patches.transpose(1, 2).reshape(hidden.shape[0], hidden.shape[2], gh, gw)
    return {"cls": hidden[:, 0], "registers": hidden[:, 1:start],
            "patches": patches, "grid": grid}

for registers in (0, 4):
    # A non-square grid catches implementations that infer sqrt(N) blindly.
    x = torch.randn(2, 1 + registers + 6, 8, dtype=torch.float64,
                    requires_grad=True)
    features = split_visual_tokens(x, (2, 3), registers)
    assert features["cls"].shape == (2, 8)
    assert features["registers"].shape == (2, registers, 8)
    assert features["grid"].shape == (2, 8, 2, 3)
    torch.testing.assert_close(features["grid"].flatten(2).transpose(1, 2),
                               features["patches"])
    torch.testing.assert_close(features["grid"][1, :, 1, 2],
                               x[1, 1 + registers + 5])
    features["grid"].mean(dim=(2, 3)).sum().backward()
    expected = torch.zeros_like(x)
    expected[:, 1 + registers:] = 1 / 6
    torch.testing.assert_close(x.grad, expected)
    print(f"registers={registers}: tokens={tuple(x.shape)}, grid={tuple(features['grid'].shape)}")

for grid_hw, registers in [((2, 3), 0), ((2, 2), 4), ((0, 3), 4)]:
    try:
        split_visual_tokens(x, grid_hw, registers)
        raise AssertionError("incorrect metadata must be rejected")
    except ValueError:
        pass

# LayerNorm over channels is a different operation from unit-length scaling.
ln = F.layer_norm(x.detach(), (8,))
unit = F.normalize(ln, p=2, dim=-1)
torch.testing.assert_close(ln.mean(dim=-1), torch.zeros_like(ln[..., 0]), atol=1e-12, rtol=0)
torch.testing.assert_close(unit.norm(dim=-1), torch.ones_like(unit[..., 0]))
assert not torch.allclose(ln.norm(dim=-1), unit.norm(dim=-1))
print("passed: spatial order, prefix gradient exclusion, layout errors, LayerNorm vs L2")

