import torch
from torch import nn
from torch.distributions import Categorical

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 观测正负决定哪一个离散动作得到奖励
actor=nn.Linear(1,2)
critic=nn.Linear(1,1)
optimizer=torch.optim.Adam(list(actor.parameters())+list(critic.parameters()),lr=0.03)

# STEP 2: 用当前策略采样；这个一步任务中 reward=return
for _ in range(160):
    obs=torch.rand(128,1)*2-1
    distribution=Categorical(logits=actor(obs))
    actions=distribution.sample()
    correct=(obs[:,0]>0).long()
    rewards=(actions==correct).float()
    values=critic(obs).squeeze(-1)
    advantages=rewards-values

    # actor 不通过 advantage 更新 critic；critic 有自己的回归损失。
    actor_loss=-(distribution.log_prob(actions)*advantages.detach()).mean()
    critic_loss=(values-rewards.detach()).square().mean()
    optimizer.zero_grad(set_to_none=True)
    (actor_loss+0.5*critic_loss).backward()
    optimizer.step()

# STEP 3: 独立网格只用于检查合成决策，不是机器人评估
with torch.no_grad():
    test_obs=torch.linspace(-1,1,101).unsqueeze(-1)
    greedy=actor(test_obs).argmax(dim=-1)
    accuracy=(greedy==(test_obs[:,0]>0).long()).float().mean()
print('synthetic greedy accuracy:',round(accuracy.item(),3))

# STEP 4: 对单个正优势样本检查梯度方向
logits=torch.zeros(1,2,requires_grad=True)
dist=Categorical(logits=logits)
loss=-(dist.log_prob(torch.tensor([1]))*torch.tensor([2.])).mean()
loss.backward()
print('logit gradients:',logits.grad.tolist())
torch.testing.assert_close(logits.grad,torch.tensor([[1.,-1.]]))
print('Gradient descent increases the positive-advantage action logit.')

