import math
import torch
from torch.nn import functional as F

torch.manual_seed(19)
torch.set_num_threads(1)
dtype = torch.float64
points = torch.tensor([-3., -1., 0., 1., 3.], dtype=dtype, requires_grad=True)
sigmoid = torch.sigmoid(points)
normal_cdf = (1 + torch.erf(points / math.sqrt(2))) / 2
normal_pdf = torch.exp(-points.square() / 2) / math.sqrt(2 * math.pi)
expected = {
    "ReLU": (points > 0).to(dtype),
    "SiLU": sigmoid + points * sigmoid * (1 - sigmoid),
    "GELU": normal_cdf + points * normal_pdf,
}
for name, fn in (("ReLU", F.relu), ("SiLU", F.silu), ("GELU", F.gelu)):
    derivative = torch.autograd.grad(fn(points).sum(), points)[0]
    torch.testing.assert_close(derivative, expected[name], rtol=1e-12, atol=1e-12)
    print(name, "derivative:", derivative.tolist())

# 两种尺度复用相同的标准正态权重方向；偏置均为零，三层均为 ReLU。
width, depth = 64, 3
directions = torch.randn(depth, width, width, dtype=dtype)
x = torch.randn(256, width, dtype=dtype)
he_std = math.sqrt(2 / width)

def run(std):
    h, statistics = x, []
    for direction in directions:
        h = F.relu(h @ (std * direction).T)
        statistics.append((h.mean().item(), h.square().mean().item(), h.std(correction=0).item()))
    return h, statistics

tiny, tiny_stats = run(0.001)
he, he_stats = run(he_std)
# 对这个无偏置 ReLU 网络，正齐次性给出精确的整体缩放关系。
torch.testing.assert_close(tiny, he * (0.001 / he_std) ** depth, rtol=1e-10, atol=1e-14)
print("per layer (mean, second_moment, std)")
print("tiny:", tiny_stats)
print("He-scale:", he_stats)
print("通过：三种激活导数和匹配方向的尺度关系；二阶矩保持是初始化统计近似。")

