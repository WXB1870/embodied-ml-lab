# [1] 人工词表仅用于展示监督对齐，不替代真实模型 Tokenizer
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils.rnn import pad_sequence
torch.manual_seed(37)
vocab = {"<pad>":0, "<bos>":1, "任务":2, "抓取":3,
         "红":4, "杯":5, "<eos>":6, "蓝":7, "块":8}
texts = ["<bos> 任务 抓取 红 杯 <eos>", "<bos> 任务 蓝 块 <eos>"]
rows = [torch.tensor([vocab[t] for t in text.split()]) for text in texts]
input_ids = pad_sequence(rows, batch_first=True, padding_value=0)
valid = input_ids != vocab["<pad>"]
labels = input_ids.clone()
labels[:, :3] = -100  # 本例前 3 个 token 是 prompt
labels[~valid] = -100

# [2] 小型因果模型：保持原位置，先产生每个位置的 logits
B, T = input_ids.shape
embedding = nn.Embedding(len(vocab), 12, padding_idx=0)
position = nn.Embedding(T, 12)
block = nn.TransformerEncoderLayer(12, 3, 24, dropout=0.0, batch_first=True)
head = nn.Linear(12, len(vocab))
hidden = embedding(input_ids) + position(torch.arange(T))[None]
blocked = torch.ones(T, T, dtype=torch.bool).triu(1)
hidden = block(hidden, src_mask=blocked, src_key_padding_mask=~valid)
logits = head(hidden)

# [3] 自写的 loss 明确只移位一次
predictions = logits[:, :-1].contiguous()
targets = labels[:, 1:].contiguous()
token_losses = F.cross_entropy(
    predictions.reshape(-1, len(vocab)), targets.reshape(-1),
    ignore_index=-100, reduction="none")
count = (targets != -100).sum()
loss = token_losses.sum() / count
reference = F.cross_entropy(predictions.reshape(-1, len(vocab)),
                            targets.reshape(-1), ignore_index=-100)
torch.testing.assert_close(loss, reference)
assert count.item() == 5
loss.backward()
assert embedding.weight.grad is not None
print("移位后目标:", targets.tolist())
print("有效目标数:", count.item(), "loss:", round(loss.item(), 4))
print("prompt / EOS / Padding 与移位检查通过")

