"""Conditional action objectives and closed-loop interfaces; CPU, no robot library.
The Gaussian samplers below are analytic oracles, not trained robot policies.
"""
import math
import torch
from torch import nn

torch.manual_seed(47)
torch.set_num_threads(1)
dtype = torch.float64
B, O, H, D = 3, 2, 4, 2
history = torch.randn(B, O, D, dtype=dtype) * 0.2
goal = torch.tensor([[0.7,-0.5],[-0.2,0.4],[0.1,0.8]], dtype=dtype)
condition = torch.cat([history.flatten(1), goal], dim=-1)


def mean_plan(position, goal, horizon=H, gain=0.35):
    # Each action is a displacement for one fixed control period.
    decay = (1-gain) ** torch.arange(horizon, dtype=position.dtype)
    return gain * (goal-position)[:, None, :] * decay[None, :, None]


def masked_mse(prediction, target, valid):
    if prediction.shape != target.shape or valid.shape != target.shape or valid.dtype != torch.bool:
        raise ValueError('expected matching [B,H,D] tensors and boolean validity')
    if not bool(valid.any()):
        raise ValueError('no supervised action coordinates')
    p, y = prediction[valid], target[valid]  # select before subtracting / squaring
    if not bool(torch.isfinite(p).all() & torch.isfinite(y).all()):
        raise ValueError('nonfinite value at a supervised coordinate')
    return (p-y).square().mean()


class ActionField(nn.Module):
    def __init__(self, condition_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(H*D+condition_dim+1, 32),
                                 nn.SiLU(), nn.Linear(32, H*D))

    def forward(self, state, time, cond):
        joined = torch.cat([state.flatten(1), time[:, None], cond], dim=-1)
        return self.net(joined).reshape(-1, H, D)


# 1. The same action shape supports different targets and different time directions.
clean = mean_plan(history[:, -1], goal) + 0.15 * torch.randn(B,H,D,dtype=dtype)
noise = torch.randn_like(clean)
time = torch.tensor([0.2,0.5,0.8],dtype=dtype)
t = time[:, None, None]
valid_time = torch.tensor([[1,1,1,1],[1,1,0,0],[1,1,1,0]],dtype=torch.bool)
valid_dim = torch.tensor([[1,1],[1,1],[1,0]],dtype=torch.bool)
valid = valid_time[..., None] & valid_dim[:, None, :]
flow_state, flow_target = (1-t)*noise+t*clean, clean-noise
alpha, sigma = (math.pi*t/2).cos(), (math.pi*t/2).sin()
diffusion_state, diffusion_target = alpha*clean+sigma*noise, noise
for name, state, target in [('flow',flow_state,flow_target),
                             ('diffusion',diffusion_state,diffusion_target)]:
    model = ActionField(condition.shape[-1]).to(dtype)
    c = condition.detach().clone().requires_grad_()
    prediction = model(state, time, c)
    prediction.retain_grad()
    # Nonfinite ignored targets are a loss-interface test; model inputs are finite.
    labels = torch.where(valid, target, torch.full_like(target,float('nan')))
    loss = masked_mse(prediction, labels, valid)
    optimizer = torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=0.0)
    old = model.net[-1].weight.detach().clone()
    loss.backward()
    assert bool(torch.isfinite(c.grad).all()) and c.grad.norm() > 0
    assert torch.equal(prediction.grad[~valid],torch.zeros_like(prediction.grad[~valid]))
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    optimizer.step()
    assert not torch.equal(old, model.net[-1].weight)
    print(name,'one-step loss:',round(loss.item(),6),'target shape:',tuple(target.shape))

# 2. Fixed condition: both samplers target N(mean, data_std^2 I).
#    This oracle isolates numerical integration from network approximation.
mu = mean_plan(history[:, -1],goal)
data_std = 0.15
z = torch.randn_like(mu)


def velocity(x, t, mean):
    variance = (1-t)**2 + (t*data_std)**2
    coefficient = (-(1-t)+t*data_std**2) / variance
    return mean + coefficient*(x-t*mean)


def sample_flow(mean, initial_noise, steps):
    x, dt = initial_noise.clone(), 1.0/steps
    for index in range(steps):
        t = index*dt
        first = velocity(x,t,mean)
        second = velocity(x+dt*first,t+dt,mean)
        x = x+0.5*dt*(first+second)  # Heun: two evaluations per step
    return x


def sample_ddim(mean, initial_noise, steps):
    x = initial_noise.clone()
    for index in range(steps,0,-1):
        t, s = index/steps, (index-1)/steps
        a, b = math.cos(math.pi*t/2), math.sin(math.pi*t/2)
        next_a, next_b = math.cos(math.pi*s/2), math.sin(math.pi*s/2)
        variance = a*a*data_std**2+b*b
        # Posterior means under this Gaussian test distribution.
        eps_hat = b/variance*(x-a*mean)
        clean_hat = mean+(a*data_std**2/variance)*(x-a*mean)
        # This form also works at a=0 without division by a.
        x = next_a*clean_hat+next_b*eps_hat  # deterministic DDIM, eta=0
    return x


exact = mu+data_std*z  # analytic endpoint for these isotropic Gaussian paths
errors = {}
for name, sampler in [('flow-Heun',sample_flow),('DDIM',sample_ddim)]:
    errors[name] = []
    for steps in (16,64):
        estimate = sampler(mu,z,steps)
        error = (estimate-exact).square().mean().sqrt().item()
        errors[name].append(error)
        print(name,'steps:',steps,'oracle endpoint RMSE:',round(error,7))
    assert errors[name][1] < errors[name][0]
# Do not interpret the two rows as an equal-compute benchmark: Heun uses 2N calls.

# 3. Replanning changes which observations condition the next block.
#    Zero initial noise deliberately selects the oracle's mean trajectory here.

def rollout(commit, steps=12):
    position = torch.tensor([[-0.8,0.4]],dtype=dtype)
    target = torch.tensor([[0.7,-0.5]],dtype=dtype)
    trajectory, calls, clock = [position.clone()], 0, 0
    while clock < steps:
        mean = mean_plan(position,target)
        plan = sample_flow(mean,torch.zeros_like(mean),16)
        calls += 1
        for action in plan[0,:min(commit,steps-clock)]:
            position = position+action[None]
            if clock == 1:  # one declared disturbance, after the second command
                position = position+torch.tensor([[-0.5,0.3]],dtype=dtype)
            trajectory.append(position.clone())
            clock += 1
    return torch.cat(trajectory), calls


frequent, calls1 = rollout(1)
sparse, calls4 = rollout(4)
target = goal[0]
# At the first command after the disturbance, only K=1 has observed it.
assert (frequent[3]-target).norm() < (sparse[3]-target).norm()
print('replanning calls K=1 / K=4:',calls1,calls4)
print('post-disturbance error K=1 / K=4:',
      round((frequent[3]-target).norm().item(),6),round((sparse[3]-target).norm().item(),6))
print('passed: targets, valid-loss gradients, oracle samplers and receding horizon')

