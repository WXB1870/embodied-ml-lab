# [1] 一个有 Dropout 和随机输入的小训练过程
import copy
import io
import random
import torch
from torch import nn
torch.manual_seed(20)
random.seed(20)

def build():
    model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Dropout(0.2), nn.Linear(8, 2))
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=2, gamma=0.8)
    return model, optimizer, scheduler

def step(model, optimizer, scheduler):
    model.train()
    x = torch.randn(5, 4) + random.random() * 0.01
    target = x[:, :2] * 0.3
    optimizer.zero_grad(set_to_none=True)
    loss = (model(x)-target).square().mean()
    loss.backward()
    optimizer.step()
    scheduler.step()
    return float(loss.detach())

# [2] 保存独立快照与实际使用的随机状态
model, optimizer, scheduler = build()
for _ in range(3):
    step(model, optimizer, scheduler)
checkpoint = {
    "model": copy.deepcopy(model.state_dict()),
    "optimizer": copy.deepcopy(optimizer.state_dict()),
    "scheduler": copy.deepcopy(scheduler.state_dict()),
    "torch_rng": torch.get_rng_state().clone(),
    "python_rng": random.getstate(), "global_step": 3,
    "config": {"data_revision": "toy-v1", "normalization": "none"},
}
buffer = io.BytesIO()
torch.save(checkpoint, buffer)
expected_loss = step(model, optimizer, scheduler)
expected_state = copy.deepcopy(model.state_dict())

# [3] 先构造和加载，最后恢复 RNG，避免构造过程消耗它
resumed, opt2, sched2 = build()
loaded = torch.load(io.BytesIO(buffer.getvalue()), map_location="cpu", weights_only=True)
resumed.load_state_dict(loaded["model"])
opt2.load_state_dict(loaded["optimizer"])
sched2.load_state_dict(loaded["scheduler"])
torch.set_rng_state(loaded["torch_rng"])
random.setstate(loaded["python_rng"])
actual_loss = step(resumed, opt2, sched2)
assert abs(actual_loss-expected_loss) < 1e-12
for name, value in resumed.state_dict().items():
    torch.testing.assert_close(value, expected_state[name], atol=0, rtol=0)
print("下一步 loss 一致:", actual_loss == expected_loss)
print("已完成更新步数:", loaded["global_step"] + 1)
print("CPU 单进程恢复检查通过")

