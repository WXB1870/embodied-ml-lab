# 视觉预处理与坐标变换

裁剪、缩放、插值与像素位置的一致性。

视觉预处理是把原始图像转换为模型输入的过程，包括解码、颜色与轴布局转换、尺寸变换和数值标准化。几何变换还会改变像素坐标，因此标签、相机参数和有效区域可能需要同步变换。它定义模型实际看见什么，而非只改变数组形状。本章先建立像素约定，再追踪缩放、裁剪、补边和多视图组织，最后进行图像与标签的对应检查。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [CNN：卷积、采样与空间表示](https://wxb1870.github.io/embodied-ml-lab/learn/cnn-receptive-field/)

## 像素布局与数值含义

像素布局规定颜色通道与空间坐标怎样排列，数值约定规定每个像素值的范围和含义。RGB 与 BGR、HWC 与 CHW、整数与标准化浮点数是不同接口。先定义模型接收哪一种，再执行转换。



相同 [H,W,3] 数组可以表示 RGB，也可以表示 BGR；相同 float32 张量可以处于 [0,255]、[0,1] 或标准化后的范围。模型看到的是数字，不知道读取库做过什么。明确输入颜色空间、布局、dtype、范围以及无效值策略，才能判断一次除法、通道交换或归一化是否合理。



预训练视觉编码器的处理器属于模型接口：尺寸、裁剪方式、插值、抗锯齿、均值和标准差都应与 checkpoint 配套保存。教学示例约定 uint8 RGB，转换为 CHW，再除以 255 并映射到 [-1,1]；这不是所有视觉模型的通用默认值，也不能据此覆盖现成处理器。



例如，OpenAI 发布的 CLIP 在 `clip.load` 中同时返回模型和配套预处理：先用双三次插值缩放，再中心裁剪、转 RGB，最后按其通道统计量标准化。中心裁剪可能移除画面边缘，不能与本章保留画布的 Letterbox 混为一谈。接入空间预测任务时，应根据实际处理链同步更新标注；更换裁剪方式则属于输入分布的改变，需要重新验证。具体实现见[CLIP 官方处理器](https://github.com/openai/CLIP/blob/main/clip/clip.py)。



常见双重处理是 Dataset 已 rescale，模型 processor 又 rescale 一次。它不会报 shape 错误，但会把动态范围压缩数百倍。最有效的检查不是只看最终 min/max，而是在解码、变换、归一化三个边界记录数值统计，并用通道不对称的人工图案观察每一步。





### 例：一个红像素如何暴露重复归一化

1. uint8 RGB 红像素为 [255,0,0]，除以 255 得 [1,0,0]。

2. 使用 `mean=std=0.5` 逐通道标准化后得到 [1,-1,-1]。如果读取成 BGR，亮通道会落在第三维。

3. 一个原本为 0.5 的浮点通道若又除以 255，再做上述标准化，会从正确的 0 变成约 -0.996。

dtype 是存储类型，数值范围是约定；必须分开验证。

### 用 float32 推断图像已经位于零到一

转换 dtype 只改变表示格式，不会改变物理范围。重复 rescale 仍会输出有限张量，因此梯度和 shape 检查常发现不了。

输入纯红、纯绿和中灰图，核对每通道预期值；记录 processor 是否已经执行 rescale/normalize。

## 换轴、插值与抗锯齿

换轴重新排列坐标维度，插值根据原像素估计新网格的数值，抗锯齿则在降采样前抑制过高频率。这些操作分别改变布局、采样网格与信号频率。下面按图像实际经过的过程区分它们。



HWC 转 CHW 是轴置换，应使用 permute(2,0,1)，不能用 reshape(3,H,W) 重排解释内存。reshape 保留元素线性次序，可能把相邻像素误当成不同通道。送入 F.interpolate 前还需增加 Batch 轴，输入形状为 [1,C,H,W]；size=(height,width)，不能直接沿用其他图像库常见的宽高顺序。



双线性插值把周围采样值加权用于连续图像；分割类别 ID 不是连续量，把类别 0 和 2 插成 1 会制造不存在的类别，应使用合适的最近邻规则。深度、有效位与稀疏关键点也不能无差别套用 RGB 的插值方式，尤其应避免无效深度参与普通平均。



缩小图像时，高频纹理可能混叠为伪纹理，antialias 处理可减轻这种问题。它与 align_corners 是不同开关：前者涉及重采样滤波，后者涉及坐标对齐。参数不一致可能让训练与部署输入略有不同；比较两条处理链时应直接核对输出像素，而不是仅检查最终尺寸。





## 拉伸、裁剪与 Letterbox

Resize 拉伸图像到目标尺寸，裁剪只保留指定区域，Letterbox 则保持缩放比例并补足画布。它们对物体形状、可见范围与空白区域的影响不同。先明确模型与标签要求，再比较三种几何变换。



直接 resize 到目标宽高最简单，但会改变物体纵横比；保持比例后裁剪可以填满画布，却会删除边缘内容；Letterbox 保持主要比例并补边，但有效图像占比会变化。没有一种变换对所有模型都最好，应先满足预训练接口，再根据任务的可见性与标签约定选择。



Letterbox 先取 \(r=\min\!\left(\frac{H_{\mathrm{out}}}{H_{\mathrm{in}}},\frac{W_{\mathrm{out}}}{W_{\mathrm{in}}}\right)\)，再把缩放后的高宽取整。由于整数舍入，实际 \(s_x=\frac{\mathrm{new\_width}}{\mathrm{old\_width}}\) 与 \(s_y=\frac{\mathrm{new\_height}}{\mathrm{old\_height}}\) 可能略有不同。关键点计算必须使用实际尺寸对应的比例，不能把理想 r 当成两个轴完全相同的精确比例。



居中补边也可能左右或上下相差一个像素：总缺口为奇数时，floor 得到的前侧补边与后侧不同。元数据应保存实际新尺寸、left/top/right/bottom 及变换矩阵。若只存“resize 到 224”这类模糊说明，之后很难把预测映射回原图并诊断系统偏移。





## 像素中心与半像素项

像素中心约定规定整数坐标代表像素中心还是边界；半像素项用于在这些参照之间换算。缩放比例正确也可能因参照不同而产生偏移。下面以同一坐标约定推导关键点怎样随图像变换。



本节把整数 u、v 解释为像素中心，图像边界因此位于 -0.5 与 \(W-0.5\)。align_corners=False 的常见缩放约定保持像素区域边界一致：先将中心坐标加 0.5 转成相对边界的位置，乘实际比例，再减 0.5 回到中心坐标，最后加补边。这解释了公式中的半像素项。



若坐标采用连续图像边界为零、或另一个 API 用角点中心对齐，就必须换用相应映射；半像素项不是所有关键点系统必加的修正。align_corners=True 在非退化尺寸下对应角点中心之间的比例，不能只改变插值参数而继续使用另一套标注公式。



齐次矩阵 A 把缩放和平移统一起来。点的正向变换用 A，反变换用 A 的逆；多个几何变换按执行顺序相乘，注意列向量与行向量约定。正反变换一致是必要检查，但若两边共享同一个错误约定，仍可能都通过，因此还需要明确已知位置的人工图案。



$$
u^{\prime}=(u+\tfrac12)s_x-\tfrac12+p_x,\quad v^{\prime}=(v+\tfrac12)s_y-\tfrac12+p_y
$$



### 例：5×9 图像放入 12×12 画布

1. 理想 \(r=\frac{12}{9}\)，舍入后实际新尺寸为 7×12，所以 \(s_x=\frac{12}{9}\)，\(s_y=\frac75\)。

2. 上下共补 5，取 `top=2`、`bottom=3`，左右均不补。原图中心点 \((u,v)=(4,2)\)。

3. \(u^{\prime}=(4+0.5)\frac{12}{9}-0.5=5.5\)；\(v^{\prime}=(2+0.5)\frac75-0.5+2=5.0\)。

横纵实际比例和不对称补边都参与映射；最终点不必落在画布的几何中心。

### 几何增强返回元数据和有效性

单独返回变换后的图像，无法可靠恢复点、框或相机几何。对于被裁掉的目标，还必须判断监督是否仍然可见。

保存 A 和原始/实际新尺寸；核对几个已知角点、中心点及逆变换，并显示点在新图中的位置。

## 图像、相机与物理坐标

图像坐标描述平面像素位置，相机坐标与物理坐标描述三维空间中的位置。图像缩放或裁剪直接改变前者，如何更新内参和标签则取决于对应投影模型。不能把二维变换直接当成三维点的平移。



二维关键点随图像几何变换；矩形框通常需要变换其角点，再按任务约定裁剪到图像范围，并同步更新可见位。分割掩码必须与图像共享同一组随机几何参数，却采用适合离散标签的插值。对图像和标签各自调用一次随机裁剪，即使使用同一种变换类，也可能抽到不同裁剪。



相机投影满足齐次关系 \(p\sim KX_{\mathrm{camera}}\)。若对投影像素施加仿射 A，则新的像素投影为 \(p^{\prime}\sim AKX_{\mathrm{camera}}\)；在一致坐标约定下，可把对应变换合并到内参表示。实际标定、畸变校正与裁剪顺序还会影响接口，应保存完整流程，而不是只修改一个焦距数字。



图像裁掉左边十个像素，不会把世界坐标中的物体平移十米或十个像素。三维物理点、相机外参、二维投影有不同的坐标空间。几何图像增强可以改变观测可见性和投影关系，却不自动改变真实场景；物理旋转或更换相机才需要相应的三维坐标变换。





## 补边、缺失视角与有效位

补边是为满足输入尺寸加入人工像素，缺失视角则表示某个相机观测不存在。有效位用来保留真实数据与占位数据的区别。填充值和有效位承担不同职责，归一化前后的“零”也具有不同含义。



补零发生在归一化前后，含义不同。在 [0,1] 图像上补 0 是黑色，之后按 `mean=std=0.5` 标准化会得到 -1；在标准化张量上补 0 则对应原空间中灰。两者都可以作为明确设计，但不能训练用一种、部署用另一种；也不能直接将“零张量”解释为无信息。



一张缺失图像即使全零，视觉编码器仍可能通过偏置、位置编码和归一化输出非零 token。缺失视角应有显式有效位，并在融合和池化中按约定处理。若一个样本全部视角缺失，应选择报错、备用输入或定义好的空条件；把所有键遮成不可见后继续 softmax，可能产生无意义结果或 NaN。



部分 Letterbox 区域属于填充，是否为这些区域生成有效 token 取决于具体编码器接口。一个 patch 跨越图像与补边时也不是简单全有或全无；教学中可以说明保留整个画布，实际模型则应沿用其训练时约定。不能临时新增 token mask 后宣称与预训练处理完全等价。



SigLIP 2 的 NaFlex 变体展示了另一种明确设计：根据 Patch 大小和 Token 预算缩放图像，尽量保持原始纵横比，再输出 Patch 序列、空间坐标与补齐 Mask；注意力和汇聚也使用该 Mask。它与固定方形输入的标准变体具有不同的处理协议，并不是给任意 ViT 传入非方形图片即可等价实现。使用时应保留官方处理器产生的坐标和有效位，详见[论文第 2.4.2 节](https://arxiv.org/html/2502.14786v1)与[官方 NaFlex 预处理](https://github.com/google-research/big_vision/blob/main/big_vision/pp/proj/image_text/ops_naflex.py)。





## 多视角与多帧顺序

多视角、多帧输入是把不同来源或时刻的图像组织成联合观测。相机身份、时间与存储位置需要有稳定对应，否则相同数组槽位会在不同调用中承载不同观测。下面明确这种输入组织约定。



多相机输入要用固定名称表建立位置映射，再逐项读取当前可用图像；不能按字典当前迭代顺序直接 stack。否则少一台相机后，后续视角可能整体换位，位置或相机 embedding 的语义随之改变。明确相机名称、帧时间、外参和有效位，可以让这种错误在进入模型前就被检测。



多帧任务还需说明时间排序与帧间隔。将未来一帧误放到当前观测，可能让离线误差很好但部署无法复现；复用过期图像也不能仅因为 shape 一样就当成同步输入。时间戳、采样规则和缺帧策略应与其他状态输入的对齐规则一致。



增强是否在多个视角或时间步共享，要根据物理与监督目标决定。各帧独立亮度扰动与独立随机裁剪的影响不同；后者会引入额外的相对运动。若希望学习真实运动或跨视角几何，应记录并合理共享几何变换，不能把所有张量拉平成一个大 Batch 后盲目施加互不相关的增强。





### 用当前字典顺序或缺失黑图表达相机身份

输入顺序变化会把相同 token 位置绑定到不同相机；全零占位也不能阻止编码器产生特征，二者需要分别处理。

打乱输入字典顺序并删除一个视角，确认固定名称表对应的槽位不变，有效位变化，融合结果不依赖无效占位内容。

## 预处理与标签的几何对照

坐标往返一致只能证明两段代码相互匹配，不能排除它们共享同一个错误约定。用已知通道、尺寸和关键点的人工输入作为独立参照，才能把预处理的语义正确性一并检验。



先用确定性人工输入检查约定：三通道不同常数检验颜色；非方形尺寸检验宽高顺序；棋盘或线条检验缩放；已知关键点检验位置；缺失相机检验有效位。仅凭自然图像的视觉检查，可能遗漏半像素偏差、轻微错位和轴顺序错误。



接着在同一原始输入上对比训练与推理处理链的最终张量和元数据。允许的差异应能解释，例如训练专用随机增强；验证与部署路径应尽可能确定。保存处理器配置到 checkpoint，避免权重恢复后无意中使用另一套均值、分辨率或裁剪方式。



示例接口采用 uint8 RGB、双线性 Letterbox、像素中心关键点和显式视角有效位。畸变校正、相机标定或其他骨干所需的颜色与插值配置，应在相应处理器中单独对齐。



视觉预处理的结果应同时保留数值含义和坐标对应：模型输入按训练约定生成，标签随同一几何过程变换，视角与有效位保持身份。能从原像素追到最终张量，才能解释视觉预测的位置与尺度。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 原始单相机图像 | [H,W,3]，uint8 RGB | 例子的输入约定。 |
| 网络单视角输入 | [3,Ht,Wt]，float32 | Letterbox 后按本例归一化到 [−1,1]。 |
| 关键点 | [N,2] | 按 (u,v) 排列，整数表示像素中心。 |
| 多视角与有效位 | [V,3,Ht,Wt] / [V] | 顺序由相机名称列表定义。 |

## 完整代码与精读

```python
# [1] 只使用 PyTorch；固定 uint8 RGB 与像素中心合同
import torch
from torch.nn import functional as F
torch.manual_seed(39)

def preprocess(image, points, out_hw=(12,12)):
    if image.dtype != torch.uint8 or image.ndim != 3 or image.shape[-1] != 3:
        raise ValueError("需要 HWC uint8 RGB")
    h, w = image.shape[:2]
    oh, ow = out_hw
    ratio = min(oh/h, ow/w)
    nh, nw = max(1,int(h*ratio+0.5)), max(1,int(w*ratio+0.5))
    top, left = (oh-nh)//2, (ow-nw)//2
    x = image.permute(2,0,1)[None].float()/255.0
    x = F.interpolate(x,size=(nh,nw),mode="bilinear",align_corners=False,antialias=True)
    x = F.pad(x,(left,ow-nw-left,top,oh-nh-top),value=0.0)
    x = (x-0.5)/0.5  # 本例合同；真实模型使用其预训练约定
    sx, sy = nw/w, nh/h
    affine = torch.tensor([[sx,0,left+(sx-1)/2],
                           [0,sy,top+(sy-1)/2],[0,0,1]],dtype=points.dtype)
    homogeneous = torch.cat((points,torch.ones(len(points),1)),dim=1)
    mapped = (homogeneous @ affine.T)[:,:2]
    return x[0], mapped, affine

# [2] 不对称 RGB 图案与关键点，验证几何正反变换
image = torch.zeros(5,9,3,dtype=torch.uint8)
image[...,0] = 255
image[...,1] = torch.arange(9,dtype=torch.uint8)[None,:]*20
points = torch.tensor([[0.,0.],[4.,2.],[8.,4.]])
processed, mapped, affine = preprocess(image,points)
mapped_h = torch.cat((mapped,torch.ones(len(mapped),1)),dim=1)
restored = (mapped_h @ torch.linalg.inv(affine).T)[:,:2]
torch.testing.assert_close(restored,points,atol=1e-6,rtol=1e-5)
assert processed.shape == (3,12,12)
assert processed.min() >= -1 and processed.max() <= 1

# [3] 名称表固定顺序；缺失视角使用占位与显式有效位
cameras = {"camera_b":image.clone(),"camera_a":image}
names = ["camera_a","camera_b","camera_c"]
views, valid = [], []
for name in names:
    present = name in cameras
    views.append(preprocess(cameras[name],points)[0] if present
                 else torch.full_like(processed,-1.0))
    valid.append(present)
stacked = torch.stack(views)
assert valid == [True,True,False]
print("变换后关键点:", mapped.round(decimals=3).tolist())
print("多视角:", tuple(stacked.shape),"有效位:",valid)
print("像素合同、几何回映与相机顺序检查通过")

```

- 第 1–24 行：缩放尺寸按正数四舍五入确定，再用实际 nh、nw 计算 sx、sy；补边可能左右或上下不完全对称。
- 第 25–36 行：仿射变换使用像素中心约定，与示例的插值对齐方式配套；逆变换验证标签同步。
- 第 37–50 行：占位图是本例归一化后的黑色 −1，同时将该视角标为无效，后续需把有效位传入模型。

预期观察：输出图像 [3,12,12]；三个视角堆成 [3,3,12,12]，有效位 [True,True,False]；关键点逆变换返回原坐标。

## 浏览器 Python 练习

实现 map_letterbox_point(point,original_hw,target_hw)。使用正数四舍五入 `int(value+0.5)` 确定缩放尺寸，居中补边，像素中心约定与 align_corners=False 对齐。返回 (u',v')。

```python
def map_letterbox_point(point, original_hw, target_hw):
    # TODO: 实际缩放尺寸、补边与半像素变换
    raise NotImplementedError("请同步关键点")

```

### 提示

- target_hw 是高、宽，point 却是横坐标 u、纵坐标 v，不要交换。
- 舍入后分别用 `nw/w` 和 `nh/h`；不能让关键点继续使用舍入前 ratio。

### 参考实现与解释

```python
def map_letterbox_point(point, original_hw, target_hw):
    h, w = original_hw
    oh, ow = target_hw
    if min(h,w,oh,ow) <= 0:
        raise ValueError("尺寸必须为正")
    ratio = min(oh/h, ow/w)
    nh, nw = max(1,int(h*ratio+0.5)), max(1,int(w*ratio+0.5))
    top, left = (oh-nh)//2, (ow-nw)//2
    u, v = point
    return ((u+0.5)*(nw/w)-0.5+left,
            (v+0.5)*(nh/h)-0.5+top)

```

在 5×9 到 12×12 的例子中，实际缩放为 7×12，横纵比例略不同。使用真实尺寸和半像素约定才能与图像处理链一致。

### 断言测试

```python
assert map_letterbox_point((2,1),(4,8),(8,8)) == (2.0,3.0)
assert map_letterbox_point((0,0),(4,4),(8,8)) == (0.5,0.5)
assert map_letterbox_point((3,2),(5,9),(5,9)) == (3.0,2.0)
u,v = map_letterbox_point((4,2),(5,9),(12,12))
assert abs(u-5.5) < 1e-12
assert abs(v-5.0) < 1e-12
print("通过：补边、半像素、恒等变换和整数尺寸")

```

## 本地 PyTorch 练习

实现 resize_with_keypoints(image,points,out_hw)，约定与演示相同。返回归一化后的 CHW 图像和变换后关键点；只使用 torch，不使用 torchvision、PIL 或 NumPy。

```python
import torch
from torch.nn import functional as F

def resize_with_keypoints(image, points, out_hw):
    # TODO: Letterbox 图像与关键点使用相同的实际几何参数
    raise NotImplementedError("请实现视觉预处理")

```

### 提示

- 先将 HWC 转 CHW，再加 Batch 轴供 interpolate 使用；不要用 reshape 交换颜色与空间轴。
- 黑色补边发生在 [0,1] 像素范围，归一化后值为 −1；关键点只用实际 sx、sy 和补边偏移。

### 参考实现与解释

```python
import torch
from torch.nn import functional as F

def resize_with_keypoints(image, points, out_hw):
    if image.dtype != torch.uint8 or image.ndim != 3 or image.shape[-1] != 3:
        raise ValueError("需要 HWC uint8 RGB")
    h, w = image.shape[:2]
    oh, ow = out_hw
    ratio = min(oh/h,ow/w)
    nh, nw = max(1,int(h*ratio+0.5)), max(1,int(w*ratio+0.5))
    top, left = (oh-nh)//2,(ow-nw)//2
    x = image.permute(2,0,1)[None].float()/255
    x = F.interpolate(x,size=(nh,nw),mode="bilinear",align_corners=False,antialias=True)
    x = F.pad(x,(left,ow-nw-left,top,oh-nh-top))
    scale = points.new_tensor([nw/w,nh/h])
    offset = points.new_tensor([left,top])
    mapped = (points+0.5)*scale-0.5+offset
    return ((x-0.5)/0.5)[0],mapped

```

红色通道检测通道顺序，补边行检测归一化时机；绿色横向斜坡检查真实插值是否遵守 align_corners=False 的像素中心映射，避免图像与关键点各用一套坐标。关键点坐标及梯度同时验证几何比例。拒绝 float 输入是为了避免在未知像素范围下重复缩放。

### 断言测试

```python
image = torch.zeros(2,4,3,dtype=torch.uint8)
image[...,0] = 255
image[...,1] = torch.tensor([0,85,170,255],dtype=torch.uint8)
points = torch.tensor([[0.,0.],[3.,1.]],requires_grad=True)
output,mapped = resize_with_keypoints(image,points,(6,6))
assert output.shape == (3,6,6)
torch.testing.assert_close(mapped,torch.tensor([[.25,1.25],[4.75,2.75]]))
torch.testing.assert_close(output[0,1:4],torch.ones(3,6))
torch.testing.assert_close(output[:,0],torch.full((3,6),-1.))
# 半像素映射 x_src=(x_out+0.5)/1.5-0.5，边缘取最近像素。
# 绿色斜坡在源图中依次为 0、1/3、2/3、1；归一化后得到以下采样值。
expected_green = torch.tensor([-1.,-2/3,-2/9,2/9,2/3,1.])
torch.testing.assert_close(output[1,1],expected_green,atol=1e-6,rtol=1e-6)
mapped.sum().backward()
torch.testing.assert_close(points.grad,torch.full((2,2),1.5))
try:
    resize_with_keypoints(image.float(),points,(6,6))
    raise AssertionError("必须拒绝未声明范围的浮点输入")
except ValueError:
    pass
print("通过：RGB、补边、半像素插值、关键点几何、梯度和输入合同")

```

## 练习：推导与分析

### 为什么图像正确 resize 后，关键点直接乘同一个理想 ratio 仍可能不对？本节为什么还有 0.5？

输出尺寸必须取整数，实际 \(s_x=\frac{\mathrm{nw}}w\) 与 \(s_y=\frac{\mathrm{nh}}h\) 可能略有差别，还要加上 Letterbox 的 left、top。只乘舍入前 ratio 会遗漏真实比例和补边。

本节把整数点解释为像素中心，并配合 align_corners=False。映射采用 \((u+0.5)s_x-0.5+\mathrm{left}\)；使用边界坐标或不同插值对齐规则时必须重新确定公式，不能把半像素项当作所有坐标系统的固定常数。

代码定位：检查实际 resized.shape、sx/sy、补边宽度和关键点正反变换。

- 说明整数尺寸、横纵实际比例和补边三项。
- 把半像素项与明确的坐标约定联系起来。

### 某个相机视角缺失时，补一张黑图是否足够？若对图像做裁剪，物理三维位置标签是否也要平移同样的像素数？

黑图只是占位内容，还要有显式有效位，并让后续融合忽略缺失视角。相机顺序应由固定名称表定义，避免缺一个键后其余视角的索引整体变化。

像素裁剪改变图像坐标和可见性，不会把真实场景中的物理三维位置按像素数平移。二维关键点、相机内参与物理三维标签具有不同含义，需要分别处理；目标被裁掉时还应重新判断监督是否可由当前观测支持。

代码定位：跟踪 names、valid、每个视角的仿射元数据，以及标签的坐标系定义。

- 同时提出占位与有效位，保持相机名称映射。
- 正确区分像素变换与物理三维坐标变换。

## 练习：辨析与纠错

### 用 reshape 替代 HWC 到 CHW 的 permute

reshape 不交换轴语义，可能把连续像素解释成颜色通道。用红绿蓝分离的人工输入检查各输出通道。

### 理想缩放比例直接用于所有标注

整数尺寸舍入使 sx 与 sy 可能不同，补边又引入平移。基于实际 resize 结果构造 A，并核对已知点。

### 对分割类别使用双线性插值

类别 ID 之间的数值平均没有类别意义。图像和掩码共享几何参数，但掩码需要离散标签适用的插值。

### 以为黑图不会影响融合

偏置和位置编码能把黑图转为非零特征。传递有效位，改变无效占位内容时有效输出应保持一致。

### 训练与部署各自实现一套处理

均值、补边空间、插值或颜色顺序的细小差异可能形成系统偏差。随 checkpoint 保存处理约定，并对相同原始输入逐项对照。

## 原始资料

- [Transformers：Image processor](https://huggingface.co/docs/transformers/en/main_classes/image_processor)
- [PyTorch：interpolate](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.interpolate.html)
- [OpenPI：PyTorch preprocessing](https://github.com/Physical-Intelligence/openpi/blob/main/src/openpi/models_pytorch/preprocessing_pytorch.py)
- [OpenAI CLIP：随模型返回的官方图像处理链](https://github.com/openai/CLIP/blob/main/clip/clip.py)
- [SigLIP 2：NaFlex 的分辨率、坐标与补齐 Mask（v1, §2.4.2）](https://arxiv.org/abs/2502.14786v1)
- [Big Vision：NaFlex 图像预处理](https://github.com/google-research/big_vision/blob/main/big_vision/pp/proj/image_text/ops_naflex.py)
