# 归一化：统计轴、梯度与不变性

LayerNorm、RMSNorm 与 BatchNorm 的计算、梯度和状态。

归一化层是一类根据指定激活集合的统计量调整数值尺度、再可选地施加可学习变换的网络模块。LayerNorm 在一个位置的通道内统计，BatchNorm 跨样本等位置统计，RMSNorm 则使用均方根而不去均值；统计集合不同，就得到不同函数。它们常用于改善优化中的尺度问题，也会改变信息和梯度。本章先建立共同流程，再分别推导前向、反向和训练推理行为。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [数值精度与标准化](https://wxb1870.github.io/embodied-ml-lab/learn/numerical/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/)

## 统计轴与样本依赖

统计轴是一次归一化共同计算均值或尺度的那些维度，统计集合则是这些轴覆盖的元素。它决定一个输出是否依赖其他样本或时间位置。认识归一化时，应先圈出这组元素，再讨论具体公式。

![对同一个 B×T×D 张量，LayerNorm 按每个 token 的 D 个通道归一化；训练态 BatchNorm 按每个通道的 B×T 个位置归一化。](../assets/figures/normalization-definition.svg)

每个高亮区域表示一次共同计算统计量的集合：左图横着取同一 token 的通道，右图竖着取同一通道的样本与位置。右图对应转置为 [B,D,T] 后的训练态 BatchNorm1d。借鉴 [Wu & He, Figure 2](https://arxiv.org/abs/1803.08494) 的分组表达方式，按本文序列张量独立绘制。

归一化层不是把所有数据都变成同一个分布，而是在指定的一组元素中计算统计量，再对这组元素做变换。对 [B,T,D] 的 token 特征，LayerNorm(D) 为每个 b,t 单独使用 D 个通道；同一 Batch 里的另一条样本不会参与。若写 LayerNorm([T,D])，统计范围就同时包含时间与通道，功能、参数形状和对序列长度的要求都已改变。先给每个轴写语义，再画出一组参与均值计算的元素，公式才有确定含义。



输入标准化与网络内部 Norm 也应分开：前者通常使用训练集估计并固定的均值尺度，后者根据当前激活或运行状态计算。把输入按数据集标准化，并不等于可以省掉内部归一化；反过来，内部有 LayerNorm 也不会替数据管线修正米与毫米、RGB 与 BGR 等语义问题。读源码时先找 normalized_shape、dim、keepdim，再问统计量来自哪一批数，避免仅凭类名判断行为。





### 归一化轴先于层名

同为 [B,T,D] 输入，不同归约轴会改变样本之间和位置之间的依赖。形状能广播，不代表统计语义正确。

固定一个 token，仅修改另一条样本。标准 LayerNorm(D) 的当前输出应不变；再修改该 token 的一个通道，观察整行怎样变化。

## LayerNorm 的均值、方差与仿射参数

LayerNorm 是对每个位置的一组特征计算均值和方差、据此标准化，再施加可学习缩放与偏移的归一化层。它不需要从其他样本估计当前统计。下面按这三个操作手算前向，再说明方差分母与稳定项。



对一行 D 维向量，先算 \(\mu=\frac{1}{D}\sum_i x_i\)，再算 \(v=\frac{1}{D}\sum_i(x_i-\mu)^2\)，最后得到 \(z_i=\frac{x_i-\mu}{\sqrt{v+\epsilon}}\)。这里使用总体式的 D 分母；PyTorch 手写对照应使用 var(correction=0)，不能直接沿用默认样本方差。\(\epsilon\) 在平方根内，与标准差上额外加 \(\epsilon\) 并不等价。\(\epsilon\) 能限制小方差时的除法，但不会把已有 NaN 自动变成有效数。



可学习的 \(\gamma\)、\(\beta\) 在标准化后逐通道缩放平移，输出 \(y_i=\gamma_i z_i+\beta_i\)。因此“输出一定零均值、单位方差”只近似适用于仿射变换之前，且 \(\epsilon\) 非零时方差本来就小于 1。对于全相等的一行，去均值后的量为零，输出等于 \(\beta\)；这不是模型崩溃，而是这一步抹去了该行的共同偏移。层应否放在某个接口，需要结合信息含义判断。



$$
\mu=\frac1D\sum_i x_i,\quad v=\frac1D\sum_i(x_i-\mu)^2,\quad y_i=\gamma_i\frac{x_i-\mu}{\sqrt{v+\epsilon}}+\beta_i
$$



### 例：手算 [1,3] 的归一化

1. 均值为 2，总体方差为 \(\frac{(1-2)^2+(3-2)^2}{2}=1\)。

2. 取 \(\gamma=[1,1]\)、\(\beta=[0,0]\) 且暂忽略 \(\epsilon\)，输出是 [−1,1]。

3. 若错误使用 \(D-1\) 分母，方差变成 2，输出变为约 [−0.707,0.707]。

看似只差一个默认参数，已经改变整层数值；与官方实现对照时必须统一方差约定。

## BatchNorm 的批次统计与运行统计

BatchNorm 是按通道汇集一个批次等位置的统计量来标准化激活的层。训练通常使用当前批次统计，并维护供评估使用的运行统计。它因此同时包含可训练仿射参数与非梯度更新的状态。



BatchNorm 按通道聚合样本统计。对 [B,C,L] 的 BatchNorm1d，每个通道从 B×L 个位置估计均值方差；它会把不同样本、不同时间的数值联系起来。训练前向使用当前批次统计，默认还更新 running_mean、running_var。运行统计是影响推理的 Buffer，而非优化器通过梯度学习的参数；即使所有权重 requires_grad=False，只要模块仍在训练模式，这些状态仍可能变化。



对一个固定通道，将参与统计的 \(N\) 个元素记为 \(x_1,\ldots,x_N\)。训练前向依次计算 \(\mu_B=N^{-1}\sum_i x_i\)、\(v_B=N^{-1}\sum_i(x_i-\mu_B)^2\)，再输出 \(y_i=\gamma(x_i-\mu_B)/\sqrt{v_B+\epsilon}+\beta\)。这里的 \(\gamma,\beta\) 是该通道共享的两个参数。LayerNorm 把同一 token 的通道放在统计集合里，BatchNorm 则把同一通道的不同样本及指定位置放在一起；形式相似，计算依赖却不同。



PyTorch 中训练前向方差用有偏估计，更新 running_var 所用的批次方差采用无偏估计，两者不要混为一谈。运行平均的更新可写为 \(\mathrm{new}=(1-m)\,\mathrm{old}+m\,\mathrm{batch}\)，这里的 momentum 是新统计量的权重，和优化器动量含义不同。对于只有两个元素的小批次，两种方差估计相差明显，所以手动复现 BN 时应分别对照训练输出和 Buffer 更新，而不是强行让两者使用同一分母。



默认评估模式使用已保存的 \(\mu_{\rm run},v_{\rm run}\)，当前样本只经过固定统计量定义的仿射变换，不再影响其他样本的输出。这个选择使单样本推理成为可能，但前提是运行统计与部署输入相匹配。`track_running_stats=False` 时评估仍用当前批次统计，不能套用这一独立性结论。反向传播为何也随模式改变，会在后面的 Jacobian 推导中继续解释。



$$
\begin{aligned}y_i^{\rm train}&=\gamma\frac{x_i-\mu_B}{\sqrt{v_B+\epsilon}}+\beta,\\y_i^{\rm eval}&=\gamma\frac{x_i-\mu_{\rm run}}{\sqrt{v_{\rm run}+\epsilon}}+\beta,\\\mu_{\rm run}^{\rm new}&=(1-m)\mu_{\rm run}^{\rm old}+m\mu_B.\end{aligned}
$$



### 例：一次运行均值更新

1. 旧 running_mean=10，当前批次均值=2，momentum=0.1。

2. 更新结果是 \(0.9\times10+0.1\times2=9.2\)；训练时当前批次仍按均值 2 归一化。

3. 切换 eval 后将使用积累的运行统计，当前输入批次均值不会替换 9.2。

训练输出统计和未来推理所用的统计是两个不同状态。

## LayerNorm 的 Jacobian 与不变方向

LayerNorm 的输入 Jacobian 描述输入每个通道的微小变化怎样影响所有输出通道。因为均值和方差也取自输入，各通道即使没有显式线性混合，导数仍相互关联。下面对这条完整依赖求导，再解释不变方向。



对一行 \(x\in\mathbb R^D\)，记 \(\mathbf 1\in\mathbb R^D\) 为全 1 向量，\(P=I-\frac{\mathbf1\mathbf1^\top}{D}\) 为去均值投影，\(c=Px\)，\(v=\frac{c^\top c}{D}\)，\(r=\sqrt{v+\epsilon}\)，\(z=\frac{c}{r}\)。先忽略学习仿射参数。\(P^\top=P\)、\(P^2=P\) 且 \(P\mathbf1=0\)；c 的坐标和为零，因此 \(c^\top P=c^\top\)。这些关系让后面的微分可以逐步化简。



第一步，均值微分 \(d\mu=\frac{\mathbf1^\top dx}{D}\)，因此 \(dc=P\,dx\)。第二步，对总体方差作乘积微分：\[dv=\frac{dc^\top c+c^\top dc}{D}=\frac{2c^\top dc}{D}=\frac{2c^\top dx}{D}\]第三步，对平方根求导得到 \(dr=\frac{dv}{2r}=\frac{c^\top dx}{Dr}\)。输入不仅进入分子 c，也通过方差进入分母 r，两条路径都需要保留。



第四步，对 \(z=\frac{c}{r}\) 用乘积法则：\(dz=\frac{dc}{r}-\frac{c\,dr}{r^2}\)。代入前面两项，得到 \[J_N=\frac{P}{r}-\frac{cc^\top}{Dr^3}=\frac{P-zz^\top/D}{r}\]这里不是把样本均值和方差看成常数，而是在同一次前向对应的局部函数上求完整导数。



若实际输出 \(y=\gamma\odot z+\beta\)，\(\gamma,\beta\in\mathbb R^D\)，上游梯度 \(g=\nabla_y\mathcal L\)，则先令 \(q=\gamma\odot g\)，再得到 \[\nabla_x\mathcal L=\frac{q-\operatorname{mean}(q)\mathbf1-z\operatorname{mean}(q\odot z)}{r}\]对 [B,T,D]，均值仍只沿 D；\(\gamma\)、\(\beta\) 被 B×T 个位置共享，它们的梯度分别对这些位置累加 \(g\odot z\) 和 g。mean 的轴和广播反向的 sum 轴必须分开。



这个矩阵说明了具体丢掉什么：\(J\mathbf1=0\) 对任何 \(\epsilon\) 都成立，因此共同平移严格不可见；\(Jc=\frac{\epsilon}{r^3}c\)，所以整体尺度方向在方差远大于 \(\epsilon\) 时被强烈压缩。对非恒定输入，若令 \(\epsilon=0\)，均值方向与中心化向量方向都是零方向，J 的秩为 \(D-2\)；保留 \(\epsilon>0\) 后，尺度方向只近似消失。以上结论针对仿射变换前的标准化，学习到的 \(\gamma\) 还会改变不同输出通道的梯度尺度。



常量行 \(c=0\) 时，归一化结果确实为零，但 \(J_N=\frac{P}{\sqrt{\epsilon}}\)，沿去均值方向的扰动仍可产生较大响应。因此 \(\epsilon\) 使运算有定义，并不保证每个局部增益都很小。若 \(\gamma\) 的某些分量为零，还会额外删除输出方向；秩的结论应注明是否包含仿射层。



同一推导也解释前面的 BatchNorm。固定通道后，把参与统计的 \(N=BL\) 个元素看成一个向量，并令 \(r=\sqrt{v_B+\epsilon}\)、\(z=(x-\mu_B\mathbf1)/r\)。通道仿射系数 \(\gamma\) 为标量，因此训练 Jacobian 为 \[J_{\rm BN,train}=\frac{\gamma}{r}\left(I-\frac{\mathbf1\mathbf1^\top}{N}-\frac{zz^\top}{N}\right).\]均值与尺度项连接不同样本的位置。默认 eval 把运行统计当作输入无关的常数，得到 \(J_{\rm BN,eval}=\gamma I/\sqrt{v_{\rm run}+\epsilon}\)；若未跟踪运行统计，则 eval 仍采用前一种依赖结构。



回到 LayerNorm 的单行计算，把 \(\mu\)、v detach 后，前向数值仍相同，Jacobian 却变成 \(\frac{I}{r}\)：共同平移也会被错误地传播。仅对所有标准化输出求和做测试不够，因为正确梯度可能恰好为零。下面直接比较整个 Jacobian，并分别测试共同平移与尺度方向；\(\epsilon\) 取较大值是为了让本应很小的尺度项清晰可见。



$$
\begin{aligned}dc&=P\,dx,\qquad dv=\frac{2c^\top dx}{D},\qquad dr=\frac{c^\top dx}{Dr},\\ dz&=\left(\frac Pr-\frac{cc^\top}{Dr^3}\right)dx,\\ \nabla_x\mathcal L&=\frac{q-\operatorname{mean}(q)\mathbf1-z\operatorname{mean}(q\odot z)}{r},\qquad q=\gamma\odot g.\end{aligned}
$$

```python
import torch

x = torch.tensor([1., 2., 4., 7.], dtype=torch.float64)
eps = 0.2

def normalize(v):
    centered = v - v.mean()
    return centered / (centered.square().mean() + eps).sqrt()

D = x.numel()
c = x - x.mean()
r = (c.square().mean() + eps).sqrt()
z = c / r
P = torch.eye(D, dtype=x.dtype) - torch.ones(D, D, dtype=x.dtype) / D
manual = (P - torch.outer(z, z) / D) / r
actual = torch.autograd.functional.jacobian(normalize, x)
torch.testing.assert_close(actual, manual)
torch.testing.assert_close(actual @ torch.ones_like(x), torch.zeros_like(x))
torch.testing.assert_close(actual @ c, eps * c / r.pow(3))
print("Jacobian 最大误差:", (actual - manual).abs().max().item())
print("尺度方向导数:", actual @ c)

```

P 先删除共同平移方向；outer(z,z)/D 再修正输入改变归一化尺度的路径。把 eps 改为 0 后，最后一行的尺度方向导数也应接近零。该验证不含学习仿射参数，因此不会把 \(\gamma\) 的作用混入标准化的几何性质。



### 前向相同不能证明反向正确

把统计量当常数会删掉它们依赖输入的求导路径。均值和方差也属于计算图。

用不同通道权重构造标量目标，比较手写实现和 nn.LayerNorm 的 x.grad；测试常量行与极小方差行。

## RMSNorm 保留的方向与丢失的尺度

RMSNorm 是使用一组特征的均方根调整其尺度、通常再施加逐通道缩放的归一化层。它与 LayerNorm 的核心区别是没有去均值。先明确这一步保留与消去什么方向，再比较两者的 Jacobian。



RMSNorm 用 \(r=\sqrt{x^\top x/D+\epsilon}\) 缩放输入，标准化结果为 \(z=x/r\)，不执行去均值。与 LayerNorm 一样，稳定项进入平方根，后续还可以有可学习的逐通道缩放。省掉去均值，改变的是这一步对输入方向的处理，而不是保证全部幅度信息都被保留。



[1,1] 经 LayerNorm 标准化得到 [0,0]，经 RMSNorm 则近似 [1,1]；[2,2] 的 RMSNorm 仍近似 [1,1]。在 \(\epsilon=0\) 且输入非零时，RMSNorm 删除一个径向自由度，而非 LayerNorm 的两个自由度。它保留相对于原点的方向，LayerNorm 保留中心化后的方向；这正是两者不能只按输出 shape 互换的原因。



推导时令 \(r=\sqrt{\frac{x^\top x}{D}+\epsilon}\)，有 \(dr=\frac{x^\top dx}{Dr}\)，再对 x/r 求导：\(dz=\frac{dx}{r}-\frac{x(x^\top dx)}{Dr^3}\)。与 LayerNorm 的区别是第一项不再经过 P，分母的导数仍然存在。若手写 RMSNorm 仅把上游梯度除以 r，仍会遗漏第二条路径。



整理微分得到 \(J=I/r-xx^\top/(Dr^3)\)。它没有 LayerNorm 的去均值投影 \(P\)，因此共同平移通常会改变输出；同时 \(Jx=\epsilon x/r^3\)，整体正比例缩放在稳定项可以忽略时仍难以区分。这个结果与前面的数值例子一致，也说明只把上游梯度除以 \(r\) 会遗漏分母变化的贡献。



更精确地，对 \(a>0\)，\(\operatorname{RMSNorm}(ax)=\frac{x}{\sqrt{x^\top x/D+\epsilon/a^2}}\)；只有 \(\epsilon=0\) 且 \(x\ne0\) 时才严格等于 \(\operatorname{RMSNorm}(x)\)。这里指仿射前的标准化。LayerNorm 对整体正缩放也有相同的 \(\epsilon/a^2\) 修正，并对共同平移严格不变；负缩放还会翻转标准化方向。应把“近似尺度不变”与实现中的严格等式分开。



学习缩放、偏置约定、统计精度和 \(\epsilon\) 都属于具体实现。某些实现使用较高精度计算统计量再转回输入 dtype。对照预训练权重时应同时匹配这些约定；低精度的舍入误差不等于数学定义不同。



$$
J_{\mathrm{RMS}}=\frac Ir-\frac{xx^T}{D r^3},\qquad r=\sqrt{\frac{x^Tx}{D}+\epsilon}
$$



## 训练模式、冻结参数与小 Batch

训练模式决定归一化使用哪份统计并是否更新运行状态，参数冻结决定哪些参数接受梯度，关闭求导则控制计算图记录。这三类控制作用于不同对象。只有分别选择它们，才能确定冻结编码器的实际函数。



model.eval() 会切换 BN 和 Dropout 等模块的行为，不会关闭自动微分；torch.no_grad() 控制计算图记录，不会把 BN 自动切成推理模式。对带 BN 的冻结视觉编码器，若希望输出函数固定，通常还要保持其 eval 状态，并检查外层 model.train() 是否又递归把它切回训练模式。若选择更新运行统计，这也是一种适配策略，应明确记录和验证，而不是当成无意的副作用。



小 Batch 下统计量可能噪声较大，验证结果也可能对批次组合敏感。track_running_stats=False 时，BN 在 eval 仍使用当前批次统计，不能以为调用 eval 就消除了跨样本依赖。对存在 Padding 的时序张量，普通 BN 不知道哪些位置是假数据；Padding 也会进入统计。此时需要重新选择归约范围、显式有效统计或不同归一化方案，而不是仅把最终 Loss 的 Padding 权重设成零。





### 冻结权重不等于冻结整个函数

BN Buffer 和 Dropout 行为不由 requires_grad 决定。模式改变可在权重不变时改变输出。

比较一次前向前后的 named_buffers，分别测试 train/eval 和 no_grad；固定同一样本，改变同批伙伴，检查是否出现非预期依赖。

## 归一化的位置与信息保留

归一化的位置包括放在哪些轴上，以及放在残差分支内部还是残差相加之后。前者决定信息依赖范围，后者决定哪些路径要穿过归一化。它们是模型函数的组成部分，不能只看作数值设置。



在因果序列中，对 [B,T,D] 每个位置独立做 LayerNorm(D) 不会引入未来 token；但若把 T 一起放入 normalized_shape，当前位置的均值和方差就使用未来位置，因果 Mask 再正确也无法修复这条泄漏路径。归一化不是 Attention，因此排查未来泄漏时不能只看注意力矩阵。类似地，在图像上跨空间归一化会使一个像素受其他位置影响，需要与希望保留的空间结构相一致。



将归一化放在残差分支内部或整个残差和之后，也会改变恒等路径及梯度传播。输入数据的绝对偏置、幅度是否有任务意义，必须在结构选择时考虑。如果某一物理量的规模本身有意义，可以通过保留原始统计、残差旁路或其他特征通路提供它；不能期待已经丢掉的信息由后面的 Linear 自动恢复。最终应以固定预处理的对照和目标指标判断，不能把“训练更稳定”直接等同于“表示更合适”。





## 归一化实现的数值对照

公式给出了应当实现的函数，但轴、方差约定或模式上的一个差异就会使代码实现另一个函数。数值对照应分别检查前向、反向和状态更新，而不是依赖某一次训练曲线。由最小张量逐步恢复实际配置，可以把数学定义与模型接口连起来。



最小验证应覆盖归约轴、方差估计、\(\epsilon\) 位置、仿射参数形状、dtype 和模型模式。先使用 float64、小张量、关闭随机算子，把手算与官方模块逐元素比较，再用随机上游梯度检查反向。常量行、小方差行、不同 Batch 组合和不同序列长度分别暴露不同问题；只有一组随机输入通过并不足以证明接口正确。对多维 normalized_shape，还要核对 \(\gamma\)、\(\beta\) 是否确实按预期共享。



代码对照检验该层的具体定义。接入预训练模型时应继续读取其配置和原始实现：哪一种 Norm、统计精度、\(\epsilon\)、是否有偏置，都属于权重兼容性的一部分。训练异常时记录归一化前后的均值、方差、最大绝对值与有限性，定位第一处失真，再判断是输入尺度、上游溢出还是错误轴。不要通过随意增大 \(\epsilon\) 把异常隐藏，也不要在没有对照的情况下替换全模型的 Norm。



归一化的完整定义包含统计集合、尺度公式、仿射变换和运行模式。先确定这四项，才能解释它怎样调整激活、改变梯度，以及是否保留任务所需的信息。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 输入特征 | [B,T,D] | 每个样本含 T 个 D 维 token。 |
| LN 的均值、方差 | [B,T,1] | 只沿最后一维统计，保留维度供广播。 |
| 可学习 \(\gamma\)、\(\beta\) | [D] | 跨样本和 token 共享。 |
| BatchNorm1d 输入 | [B,C] 或 [B,C,L] | 通道 C 固定，统计来自 B 或 B 与 L。 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(17)
torch.set_num_threads(1)
dtype, eps = torch.float64, 1e-4
x = (2 * torch.randn(2, 3, 4, dtype=dtype) + 5).requires_grad_()
gamma = torch.tensor([0.7, -1.2, 1.6, 0.4], dtype=dtype, requires_grad=True)
beta = torch.tensor([0.2, 0., -0.3, 0.5], dtype=dtype, requires_grad=True)
g = torch.randn_like(x)

# LayerNorm 前向：每个 B,T 位置独立沿 D 归约。
centered = x - x.mean(-1, keepdim=True)
r = torch.sqrt(centered.square().mean(-1, keepdim=True) + eps)
z = centered / r
ours = gamma * z + beta
reference = F.layer_norm(x, (4,), gamma, beta, eps)
torch.testing.assert_close(ours, reference, rtol=1e-10, atol=1e-10)
ours_grad = torch.autograd.grad((ours * g).sum(), (x, gamma, beta))
reference_grad = torch.autograd.grad((reference * g).sum(), (x, gamma, beta))
for actual, expected in zip(ours_grad, reference_grad):
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)

# 手推 VJP：统计量的两条导数路径不可 detach。
q = g * gamma
dx = (q - q.mean(-1, keepdim=True) - z * (q * z).mean(-1, keepdim=True)) / r
dgamma, dbeta = (g * z).sum((0, 1)), g.sum((0, 1))
for actual, expected in zip((dx, dgamma, dbeta), reference_grad):
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)
torch.testing.assert_close(dx.sum(-1), torch.zeros(2, 3, dtype=dtype), atol=1e-10, rtol=0)

# RMSNorm 的 VJP 少了去均值项，仍包含分母依赖输入的导数。
rr = torch.sqrt(x.square().mean(-1, keepdim=True) + eps)
rms = x / rr
rms_auto = torch.autograd.grad((rms * g).sum(), x)[0]
rms_hand = g / rr - x * (g * x).mean(-1, keepdim=True) / rr.pow(3)
torch.testing.assert_close(rms_hand, rms_auto, rtol=1e-10, atol=1e-10)

# 常量行输出为零，不代表其所有扰动方向的导数为零。
constant = torch.full((4,), 3., dtype=dtype, requires_grad=True)
jac = torch.autograd.functional.jacobian(lambda a: F.layer_norm(a, (4,), eps=eps), constant)
p = torch.eye(4, dtype=dtype) - torch.ones(4, 4, dtype=dtype) / 4
torch.testing.assert_close(jac, p / eps ** 0.5, rtol=1e-10, atol=1e-10)

# BN 训练前向的总体方差，与 running_var 的无偏估计分别核对。
batch = torch.tensor([[1., 4.], [3., 0.], [6., 2.]], dtype=dtype)
bn = nn.BatchNorm1d(2, eps=eps, momentum=0.2, affine=False).to(dtype)
mean = batch.mean(0)
biased_var = batch.var(0, correction=0)
unbiased_var = batch.var(0, correction=1)
train_output = bn(batch)
torch.testing.assert_close(train_output, (batch - mean) / torch.sqrt(biased_var + eps))
torch.testing.assert_close(bn.running_mean, 0.2 * mean)
torch.testing.assert_close(bn.running_var, 0.8 * torch.ones(2, dtype=dtype) + 0.2 * unbiased_var)
saved_mean, saved_var = bn.running_mean.clone(), bn.running_var.clone()
bn.eval()
torch.testing.assert_close(bn(batch), (batch - saved_mean) / torch.sqrt(saved_var + eps))
torch.testing.assert_close(bn.running_mean, saved_mean)
torch.testing.assert_close(bn.running_var, saved_var)

# 同一目标样本的 BN 输出随其他样本改变；逐 token LN 不受此影响。
changed = batch.clone()
changed[2] += torch.tensor([10., -8.], dtype=dtype)
batch_norm = nn.BatchNorm1d(2, affine=False, track_running_stats=False).to(dtype)
batch_norm.eval()  # 未跟踪运行统计时，eval 仍读取当前批次。
assert not torch.allclose(batch_norm(batch)[0], batch_norm(changed)[0])
torch.testing.assert_close(F.layer_norm(batch, (2,))[0], F.layer_norm(changed, (2,))[0])
print("通过：LN 三组梯度、RMS VJP、常量行 Jacobian、BN 两种方差和批次依赖。")

```

- 第 1–12 行：构造非零均值、非单位仿射参数的 float64 张量以及独立上游梯度。
- 第 13–24 行：比较手写与官方 LayerNorm 的前向、输入梯度、\(\gamma\) 梯度和 \(\beta\) 梯度。
- 第 25–32 行：直接实现推导出的 VJP，与 autograd 对照；沿通道求和为零检验共同平移不变性。
- 第 33–45 行：分别检验 RMS 的分母导数，以及常量输入行仍具有非零方向导数的反例。
- 第 46–61 行：用三个样本区分总体方差与无偏方差，独立核对运行统计更新和 eval 输出。
- 第 62–69 行：修改同批伙伴：BN 的目标样本响应会变，而逐 token LN 不会；同时展示无运行统计时 eval 的边界。

预期观察：LN 的三组导数和 RMS 的输入 VJP 与独立公式一致；常量行 Jacobian 为 \(\frac{P}{\sqrt\epsilon}\)；BN 前向、运行方差更新和 eval 方程分别通过断言。

## 浏览器 Python 练习

实现 layer_norm_rows(rows, eps)。每行独立计算均值与总体方差，不使用 NumPy。输入行不能为空；不加可学习仿射参数。返回新的二维列表。

```python
def layer_norm_rows(rows, eps=1e-5):
    # TODO: 对每一行独立计算均值、方差和归一化结果
    raise NotImplementedError("请完成按行 LayerNorm")

```

### 提示

- 每行需要自己的均值，不能先把所有行展平。
- 总体方差除以 len(row)，\(\epsilon\) 位于平方根内。

### 参考实现与解释

```python
import math

def layer_norm_rows(rows, eps=1e-5):
    result = []
    for row in rows:
        if not row:
            raise ValueError("不能归一化空行")
        mean = sum(row) / len(row)
        var = sum((value - mean) ** 2 for value in row) / len(row)
        scale = math.sqrt(var + eps)
        result.append([(value - mean) / scale for value in row])
    return result

```

检查平移不变性可以发现漏减均值的错误；常量行检查能发现缺少 \(\epsilon\) 的除零问题。

### 断言测试

```python
a = layer_norm_rows([[1.0, 2.0, 3.0], [8.0, 8.0, 8.0]])
assert abs(sum(a[0])) < 1e-10
assert a[1] == [0.0, 0.0, 0.0]
b = layer_norm_rows([[11.0, 12.0, 13.0]])[0]
assert all(abs(x-y) < 1e-10 for x, y in zip(a[0], b))
assert abs(a[0][0] + (1.0 / (2.0/3.0 + 1e-5) ** 0.5)) < 1e-10
try:
    layer_norm_rows([[]])
    raise AssertionError("空行应被拒绝")
except ValueError:
    pass
print("通过：统计维度、平移不变性、常量行和空行检查")

```

## 本地 PyTorch 练习

完成 last_dim_norm(x,gamma,beta,eps)：只沿最后一维做 LayerNorm，再应用形状为 [D] 的 gamma 和 beta。输入为有限浮点张量且 D>0、eps>0；不能调用 nn.LayerNorm 或 F.layer_norm，也不能 detach 均值、方差或输入。测试同时核对前向和 x、gamma、beta 的导数。

```python
import torch

def last_dim_norm(x, gamma, beta, eps=1e-5):
    # TODO: 保留被统计的维度以便广播
    raise NotImplementedError("请实现 LayerNorm")

```

### 提示

- mean 和 var 都只沿 dim=-1 计算，并设置 keepdim=True 以便广播。
- 使用总体方差 unbiased=False，\(\epsilon\) 加在方差内；gamma 与 beta 应按最后的 D 维作用。

### 参考实现与解释

```python
import torch

def last_dim_norm(x, gamma, beta, eps=1e-5):
    mean = x.mean(dim=-1, keepdim=True)
    var = x.var(dim=-1, keepdim=True, unbiased=False)
    normalized = (x - mean) * torch.rsqrt(var + eps)
    return normalized * gamma + beta

```

参考解保留均值和方差对输入的依赖。测试用独立上游张量对 x、\(\gamma\)、\(\beta\) 分别求导，与官方实现对照，可识别前向相同却 detach 统计量的错误；常量行和小方差行验证 \(\epsilon\) 的位置及局部导数，而跨样本干预检查归约轴。

### 断言测试

```python
torch.manual_seed(1)
dtype = torch.float64
for scale, offset in ((1., 0.), (1e-6, 4.), (0., 3.)):
    x = (scale * torch.randn(2, 3, 4, dtype=dtype) + offset).requires_grad_()
    gamma = torch.randn(4, dtype=dtype, requires_grad=True)
    beta = torch.randn(4, dtype=dtype, requires_grad=True)
    upstream = torch.randn_like(x)
    y = last_dim_norm(x, gamma, beta, 1e-4)
    ref = torch.nn.functional.layer_norm(x, (4,), gamma, beta, 1e-4)
    torch.testing.assert_close(y, ref, rtol=1e-8, atol=1e-10)
    actual = torch.autograd.grad((y * upstream).sum(), (x, gamma, beta))
    expected = torch.autograd.grad((ref * upstream).sum(), (x, gamma, beta))
    for a, b in zip(actual, expected):
        torch.testing.assert_close(a, b, rtol=1e-7, atol=1e-8)
    torch.testing.assert_close(actual[0].sum(-1), torch.zeros(2, 3, dtype=dtype), rtol=0, atol=1e-8)
    changed = x.detach().clone()
    changed[1] += 7.
    torch.testing.assert_close(last_dim_norm(changed, gamma, beta, 1e-4)[0], y[0])
print("通过：普通/小方差/常量行、三组梯度、平移方向与批次独立性")

```

## 练习：推导与分析

### 对 [8,20,64] 使用 LayerNorm(64)，哪些数一起计算均值？与 LayerNorm((20,64)) 有什么不同？

LayerNorm(64) 对每个样本的每个 token，使用它的 64 个通道计算统计量，共 8×20 组均值和方差。不同 token 和不同样本不被混合，保留维度后统计量形状为 [8,20,1]。

LayerNorm((20,64)) 会联合最后两个维度，对每个样本的 20×64 个数计算一组统计量，并使用匹配这个 normalized_shape 的仿射参数。两者不仅参数形状不同，输入信息被中心化和缩放的范围也不同。

代码定位：检查 normalized_shape、mean/var 的 dim 与 keepdim，以及 \(\gamma\)、\(\beta\) 的形状。

- 指出前者有 160 组统计量，后者有 8 组。
- 说明统计范围改变会改变函数，而不只是改变写法。

### 冻结视觉骨干参数后，为什么 BatchNorm 的输出或状态还可能变化？eval 与 requires_grad 各控制什么？

常规 BatchNorm 在 train 模式使用当前批统计量并更新运行均值和方差。这些运行统计量是 Buffer，更新不依赖 weight 或 bias 是否需要梯度，因此冻结参数不等于冻结全部模块状态。

requires_grad 控制参数是否需要梯度；eval 切换训练相关的模块行为，并不关闭自动微分。若冻结骨干需要稳定的运行统计量，还要检查外层 model.train() 是否又把它递归切回训练模式。

代码定位：比较 bn.running_mean 的前后快照，分别打印骨干 training 标记与参数 requires_grad。

- 明确指出 Buffer 与参数的区别。
- 说明冻结参数、eval 和关闭梯度不是同一机制。

### 手写 LayerNorm 将均值和方差 detach 后，为什么前向完全一致，却连“共同平移不改变输出”的梯度性质也丢失了？

每次重新前向时，detach 的统计量仍取当前输入的数值，所以输出一致。但 autograd 把该次统计量当作常数，只留下分子对输入的直接导数，得到 \(\frac{I}{r}\)。

完整求导包含均值与尺度两条路径，得到 \(\frac{P-zz^\top/D}{r}\)，乘全 1 向量严格为零。detach 版本乘全 1 得到 \(\frac1r\)，说明它计算的局部导数不再对应完整 LayerNorm 函数。

在 \(\epsilon=0\)、输入非恒定时，完整 Jacobian 还会消去中心化输入方向；\(\epsilon>0\) 时该方向导数为 \(\frac{\epsilon c}{r^3}\)，应避免把近似缩放不变性写成严格恒等。

代码定位：用 torch.autograd.functional.jacobian 比较矩阵，再测试 J@ones 与 J@(x−x.mean())。

- 指出前向数值相同与计算图相同是两个判断。
- 给出共同平移方向的零导数，并说明 \(\epsilon\) 对尺度方向的影响。

### 一行输入全相等、LayerNorm 输出为零时，输入 Jacobian 也一定为零吗？

仿射前 \(c=0\)、\(r=\sqrt\epsilon\)，因此 \(J=\frac{P}{\sqrt\epsilon}\)。共同平移方向被 P 删除，但改变各通道相对值的扰动可以产生非零导数。输出在某点为零不意味着该点的局部导数为零。

这个例子也说明 \(\epsilon\) 防止分母为零，但小 \(\epsilon\) 可能产生较大的局部增益。应检查方差、上游梯度和 \(\gamma\)，不能把所有异常都归结为 \(\epsilon\) 不够大。

代码定位：完整实现中 constant 输入的 Jacobian 与 \(\frac{P}{\sqrt\epsilon}\) 对照。

- 从 \(c=0\) 代入完整 Jacobian。
- 区别共同平移和改变通道相对值的方向。

## 练习：辨析与纠错

### 把 LayerNorm 的方差写成默认样本方差

官方层使用 D 分母；手写 torch.var 应对齐 correction=0。用 [1,3] 手算可立即发现 \(\sqrt2\) 的比例误差，并继续比较输入梯度。

### 把序列长度也归一化，意外看到未来

LayerNorm([T,D]) 会让每个位置的统计量依赖其他时间位置。因果任务应检查归一化轴，并用未来输入干预验证整个网络。

### 冻结权重后仍更新 BatchNorm 状态

requires_grad=False 不阻止 running_mean/var 在训练模式变化。检查模式递归和 Buffer 差异，明确是否允许统计适配。

### 用 no_grad 代替 eval

no_grad 只关闭梯度图记录，不改变 BN/Dropout 行为。验证时通常需要两者，之后恢复正确的训练模式。

### 认为 \(\gamma\)、\(\beta\) 之后仍一定零均值单位方差

逐通道仿射参数与 \(\epsilon\) 会改变最终统计。检查的应是具体公式，不应把近似性质写成不成立的断言。

## 原始资料

- [PyTorch：LayerNorm](https://docs.pytorch.org/docs/stable/generated/torch.nn.LayerNorm.html)
- [PyTorch：RMSNorm](https://docs.pytorch.org/docs/stable/generated/torch.nn.RMSNorm.html)
- [PyTorch：BatchNorm1d](https://docs.pytorch.org/docs/stable/generated/torch.nn.BatchNorm1d.html)
- [Layer Normalization 原始论文](https://arxiv.org/abs/1607.06450)
- [Root Mean Square Layer Normalization 原始论文](https://arxiv.org/abs/1910.07467)
