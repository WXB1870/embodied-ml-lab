# VLA：从视觉语言骨干到动作专家

以 π₀ 家族与完整小模型追踪 Token、联合注意力、梯度及生成

视觉—语言—动作模型（VLA）是一类利用图像与语言条件生成机器人动作的模型，常同时使用本体状态。视觉语言骨干提供观测表示，动作模块将这些条件转换为动作预测或生成场；动作专家是具有独立多层参数的一种模块形式，并不等同于所有 VLA 都有的简单输出头。本章以 π₀ 风格的彩色目标任务认识这条完整链，再分析输入组织、联合注意力、训练与采样，另行比较 π₀.₅ 和 FAST。

## 学习目标

- 从逐层投影与可见性推导 VLM 和动作专家之间的信息、梯度路径。
- 区分 π₀、π₀.₅ 与 π₀-FAST 的状态编码、时间条件和动作生成协议。
- 用完整 PyTorch 小模型核对多模态前向、有效监督、参数更新与采样。
- 证明固定前缀缓存的适用条件，并分清参数冻结、断图、eval 与优化器分组。

前置知识：[Transformer：注意力、残差与序列建模](https://wxb1870.github.io/embodied-ml-lab/learn/transformer/) · [条件注入：拼接、FiLM 与 AdaLN](https://wxb1870.github.io/embodied-ml-lab/learn/conditioning-fusion/) · [状态与动作表示](https://wxb1870.github.io/embodied-ml-lab/learn/action-representation/) · [生成式动作策略：ACT、Diffusion 与 Flow](https://wxb1870.github.io/embodied-ml-lab/learn/generative-policy/)

## 从“移动到红色目标”开始：观测怎样决定动作

VLM 是使用图像与文字进行表示或预测的视觉语言模型，VLA 进一步以动作作为输出目标。两者的连接需要定义动作变量及它怎样读取观测。我们先用“移动到指定颜色并闭合夹爪”认识完整输入输出，再拆开具体模型。





教学任务是在平面网格移动夹爪，动作是 \((\Delta x,\Delta y,g)\)：前两项为每控制步的网格位移，\(g=-1/+1\) 表示打开/闭合。状态是 \((x,y,v_x,v_y)\)，代码中初速度为零。四条样本各有两幅 \(8\times8\) 彩色网格、三个文字槽位和最多三步动作；第二个样本缺失一个视图，第四个只请求两步。两视图是同一网格的重复渲染，用来检查相机与有效位接口，不模拟真实相机几何或完整抓取。





设一次机器人决策的条件为 \(c_k=(I_k^{1:V},\ell_k,s_k)\)：\(k\) 是物理决策时刻，\(V\) 个相机图像为 \(I_k^{1:V}\)，\(\ell_k\) 是当前语言指令，\(s_k\in\mathbb R^{D_s}\) 是本体状态。模型预测动作块 \(A_k\in\mathbb R^{H\times D_a}\)，其中 \(H\) 是未来命令数，\(D_a\) 是每条命令的坐标数。生成时间 \(t\in[0,1]\) 与 \(k\) 无关；一个 \(t\) 对应整块动作的一次生成状态，而不是某个关节的执行时刻。动作单位、参考系与执行切片沿用[动作表示](#/learn/action-representation)和[动作分块](#/learn/action-chunk)的定义。





一个普通读出头可以把最终条件特征直接映射成 \([B,H,D_a]\) 的回归值。连续生成式动作专家则还读取当前噪声动作 \(X_t\) 和时间 \(t\)，在多层网络内反复更新动作表示，输出速度或其他生成参数。后者不是给 VLM 最后一层接一个 Linear 就完整实现的：动作输入、时间条件、跨模态读取和迭代求解都是模型计算的一部分。

![π₀ 风格的两条表示流在每层联合注意力中交互，视觉语言前缀不读取动态动作后缀，动作专家输出速度再经求解器得到动作块。](../assets/figures/vla-system-v2.svg)

观测前缀与动作后缀逐层交互，动作专家输出速度，经积分和解码得到动作块。



这也不是所有 VLA 的统一结构。离散动作模型可以用语言模型的输出词表做自回归预测；其他连续策略可以用独立 Cross-Attention 解码器读取最终条件特征。本章选取 π₀ 家族，重点分析“不同参数处理不同 token，在每层注意力中交互”的实现；其他概率目标已在[生成式动作策略](#/learn/generative-policy)中讨论。





官方实现的分析固定于 OpenPI commit 215abfb217dbac7d5f1273282331b9b1866c0479（2026-08-24）。下文“π₀.₅ 实现”指这一版本公开的 Flow Matching 路径；论文中的混合任务训练、后续 Knowledge Insulation 配方与这个公开训练入口不能合并成一个未加区分的架构。代码页使用从零初始化的小型教学模型，不加载官方权重，也不声称复现其机器人能力。









## 图像与语言如何形成可读取的前缀

观测前缀是动作计算可以读取的一组固定条件 Token，本章由图像区域表示和文字表示组成。前缀不是必须压成一个场景向量；保留多个位置，使动作查询有机会选择不同区域和词语。下面先定义它的来源与有效位。





令每个视角输出 \(P_v\) 个视觉 token，文字序列有 \(L\) 个存储槽位。图像编码器与投影形成 \(E_I^v\in\mathbb R^{B\times P_v\times d_p}\)，词嵌入形成 \(E_\ell\in\mathbb R^{B\times L\times d_p}\)，按序列轴拼成 \(P^{(0)}\in\mathbb R^{B\times N_p\times d_p}\)，其中 \(N_p=\sum_vP_v+L\)。这里的“token”表示序列中的一个向量位置；视觉 token 并不是必须先量化成语言词表 ID。





固定版本的 [embed_prefix](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0.py) 对各相机调用 SigLIP 图像编码器，再拼接 PaliGemma 文字嵌入；图像与文字共享前缀注意力块。SigLIP 内部的视觉空间建模，与后面 Gemma 层中的序列位置编码，属于两个不同计算阶段。实际图像尺寸、相机顺序、裁剪、像素尺度和缺失视角都需要与 checkpoint 训练协议一致。





前缀有效位 \(m^p\in\{0,1\}^{B\times N_p}\) 指出哪些存储位置确实存在。一个缺失相机的有效位应扩展到该相机的全部 patch；文字 Padding 也不能成为可读取的 Key。把无效位置的输入置零只能限制初值，投影偏置、位置编码和后续残差仍可产生非零向量，因此注意力有效位有独立作用。反过来，Mask 也不能清除在编码器内部已经发生的非有限运算。





沿用彩色目标输入，两幅 8×8 网格各经 4×4、stride 4 的 patch 投影得到 4 个 Token；接上三个文字槽位，形成 [4,11,16] 前缀。词表约定 0=Padding、1=移动、2=红、3=蓝、4=闭合；颜色编号选择目标，闭合是本任务共同的终步规则。颜色块落在哪个 patch、指令选择哪种颜色，应在前缀中保留为可区分的信息。小 patch 层没有 SigLIP 预训练语义；具有这条计算路径，只说明模型有机会利用输入，不保证它已经学会利用。





$$
P^{(0)}=\operatorname{concat}_{\rm seq}(E_I^1,\ldots,E_I^V,E_\ell),\qquad N_p=\sum_{v=1}^{V}P_v+L
$$





## 状态、噪声动作与生成时间：两种接入方式

本体状态描述机器人当前自身信息，噪声动作是生成过程正在更新的候选动作块，生成时间标记它所处的阶段。三者角色不同。π₀ 与 π₀.₅ 对状态和时间采用不同接入方式，下面分别定义而不混成一个条件 Token。





π₀ 的连续状态先经线性映射，形成一个 \([B,1,d_a]\) 的 state token。它与动作 token 都由动作专家参数处理，但属于不同可见性块。噪声动作 \(X_t\in\mathbb R^{B\times H\times D_a}\) 的每个时间槽先投影到 \(d_a\)，再与时间编码 \(\phi(t)\in\mathbb R^{B\times d_a}\) 沿特征轴拼接，并经过 MLP。时间向量在 \(H\) 个动作位置共享，状态 token 不经过这个 action-time MLP。于是 suffix 长度为 \(1+H\)，而不是把所有动作坐标展开成 \(H D_a\) 个 token。





π₀.₅ 的默认数据变换把归一化状态离散化后写入文本提示；这些状态 token 进入视觉语言前缀，suffix 中不再另加连续状态 token。动作输入只做线性投影，时间经过独立 MLP 后进入动作专家的 adaptive RMSNorm。这个结论同时依赖模型标志与数据变换：公开配置允许修改 discrete_state_input，不能看到 pi05=True 就假定任意自定义数据管线都已经提供状态。核对 [Pi0Config](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0_config.py)、[ModelTransformFactory](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/training/config.py) 与 [PaligemmaTokenizer](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/tokenizer.py) 三处，才能确定真实路径。





对一条专家隐藏向量 \(h\in\mathbb R^{d_a}\)，先计算 \(\bar h=h/\sqrt{d_a^{-1}\sum_i h_i^2+\epsilon}\)。时间条件 \(z_t\) 产生通道向量 \(\gamma(z_t),\beta(z_t),g(z_t)\)，得到调制输入 \(\widetilde h=(1+\gamma)\odot\bar h+\beta\)，残差支路再由 \(g\) 控制贡献。这里的 RMSNorm 不减均值；“归一化后仿射调制”与一般 FiLM 有联系，但不等于把所有 FiLM、AdaLN、AdaRMSNorm 当作同一个算子。具体广播、归一化轴与零门控梯度见[条件融合](#/learn/conditioning-fusion)。





固定版本的 [RMSNorm 和 Block](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/gemma.py) 将时间条件用于动作专家的 attention/FFN 前归一化及最终归一化，前缀对应的条件为 None。这样改变生成时间不会直接改变前缀归一化。后面的缓存证明依赖这条实际计算关系；如果在新设计中让时间也调制视觉语言前缀，缓存条件就需要重写。





教学实现选用 π₀ 风格：\(D_s=4,D_a=3,d_a=12\)，一个 state Token 加三个动作 Token 形成 [4,4,12] 后缀。第一个样本起点为 (0,0)，红色块中心在 \((-4/7,-4/7)\)，三条示范位移都是 \((-4/21,-4/21)\)，最后一步闭合。训练真正送入动作投影的是这些标签与噪声的插值，推理则从整块噪声开始；颜色中心不额外作为隐藏答案输入网络。正弦频率、激活和宽度属于教学设置，未实现 π₀.₅ 的状态分词与 AdaRMSNorm。





$$
\begin{aligned}S^{(0)}_{\pi_0}&=\operatorname{concat}_{\rm seq}\!\left(sW_s+b_s,\; f_{\rm time}\!\left[ X_tW_a+b_a\,;\,\phi(t)\right]\right)\\\widetilde h_{\pi_{0.5}}&=(1+\gamma(z_t))\odot\operatorname{RMSNorm}(h)+\beta(z_t),\qquad h^+=h+g(z_t)\odot F(\widetilde h)\end{aligned}
$$





## 独立参数为什么能够共同做注意力

动作专家是用独立参数处理动作相关位置的多层网络；联合注意力则让不同参数流投影后的 Q/K/V 在同一可见集合中匹配与读取。独立参数不等于完全隔离，共同读取也不等于共享全部权重。先认识这个结构，再展开各层矩阵。





在第 \(l\) 层，记前缀与后缀输入为 \(P^{(l)}\in\mathbb R^{B\times N_p\times d_p}\)、\(S^{(l)}\in\mathbb R^{B\times N_s\times d_a}\)。先各自归一化，再分别计算 \(Q_p=P_nW_{Qp}\)、\(K_p=P_nW_{Kp}\)、\(V_p=P_nW_{Vp}\)，以及对应的 \(Q_a,K_a,V_a\)。这里先写单头形式，\(W_{Qp},W_{Kp},W_{Vp}\in\mathbb R^{d_p\times d_h}\)，专家矩阵为 \(\mathbb R^{d_a\times d_h}\)；输入宽度不同，只需投影后的头维 \(d_h\) 对齐。





将投影结果沿序列轴连接，形成 \(Q=[Q_p;Q_a]\)、\(K=[K_p;K_a]\)、\(V=[V_p;V_a]\)。分数矩阵包含四类项：\(Q_pK_p^\top\)、\(Q_pK_a^\top\)、\(Q_aK_p^\top\)、\(Q_aK_a^\top\)。第二项在本架构中被 Mask 禁止，第三项使动作位置能够读取视觉语言信息，第四项使动作块内部联合建模。每个允许位置的 Softmax 都在它实际可见的所有 Key 上归一化。



### 例：动作 Query 为什么要在一个共同分母下读取

1. 把一个动作 Query 的可见集合暂时缩成两个 Key：一个来自视觉语言前缀，一个来自动作后缀。设两个缩放分数都为 0，Value 分别为 \((2,0)\) 与 \((0,4)\)。这是局部手算，不是声称训练后的头必然采用这些权重。

2. 联合 Softmax 使用同一个分母 \(e^0+e^0=2\)，权重为 \((1/2,1/2)\)，读出为 \((1,2)\)。前缀和动作可以使用不同投影参数，但投影后的 Key/Value 必须满足当前头的运算约定。

3. 若拆成两个各含一个 Key 的 Softmax，每份权重都为 1，相加得到 \((2,4)\)。它已经不同于联合读出；实际网络再加入不同的残差和更新顺序，差别还会继续传播。

“两类表示能够交换信息”只说明存在连接。共同归一化的范围、投影参数和更新次序共同定义具体架构。

以某个动作 Query 为例，它的输出是前缀 Value 与后缀 Value 的同一次加权和。把它替换为“先对前缀做一次 Cross-Attention，再对动作做一次 Self-Attention”通常不等价，因为两个独立 Softmax 的分母、残差次序和 Query 来源都改变了。后者是合法的另一种模型，不能只因都能读取图像就当成同一实现。





联合注意力得到各 token 的结果后，按原前缀/后缀边界拆开，分别经过自己的输出投影、残差、归一化和 FFN。下一层重复这一过程。动作第 \(l\) 层读取的是前缀第 \(l\) 层的输入经过 K/V 投影后的表示，而不是只读取最后一层 VLM 输出；多层耦合因此提供不同抽象深度的条件。 对第一个样本，这提供了让某个噪声动作位置同时读取红色区域、颜色词和夹爪状态的路径；具体读取权重仍由训练决定，不能预先把某一头命名为“红色识别头”。





固定版本的 [Attention 与 Module](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/gemma.py) 明确要求两组配置有相同深度、Query 头数、KV 头数和 head_dim，但允许 width 与 mlp_dim 不同。默认 Gemma 配置的前缀/专家宽度为 2048/1024，深度均为 18，Query 头数为 8、KV 头数为 1、head_dim 为 256。这是该源码配置的事实，不能从教学模型的普通多头实现推断真实模型的 KV 内存。





论文称这两组权重为 experts，源码也按 token 所属模态使用不同参数。这里的路由由输入类别确定，没有学习一个 router 为每个 token 挑选 top-k 个稀疏 FFN 专家；因此不宜未经说明就按常见稀疏 MoE 的负载均衡或专家并行机制来解释。它也不只是一个浅层 head，而是在多层 attention、FFN 和归一化中拥有独立参数的完整动作计算流。





$$
\begin{aligned}Q&=[Q_p;Q_a],\quad K=[K_p;K_a],\quad V=[V_p;V_a]\\O&=\operatorname{softmax}_{\rm key}\!\left(\frac{QK^\top}{\sqrt{d_h}}+M\right)V,\quad M_{ij}\in\{0,-\infty\}\\P^{(l+1)}&=\operatorname{Block}_p(P^{(l)},O_p),\qquad S^{(l+1)}=\operatorname{Block}_a(S^{(l)},O_a)\end{aligned}
$$





## 用三块 Mask 读懂信息流，而不只看序列顺序

块可见性是按 Token 所属区域规定允许读取关系的 Mask。本章 π₀ 路径包含观测、状态与动作三块，使动作能读取条件且观测不依赖动态动作。序列拼接顺序只给出位置，真正的信息路径由这些规则决定。





令 \(P\) 表示图像与语言块，\(S\) 表示一个连续状态 token，\(A\) 表示全部噪声动作 token。以行作为 Query、列作为 Key，π₀ 的允许读取关系为 \(\left[\begin{smallmatrix}1&0&0\\1&1&0\\1&1&1\end{smallmatrix}\right]\)。每个 1 代表对应子块全部开放：前缀内部双向，state 可读取前缀与自身，动作可读取全部前缀、state 和所有动作位置。因此动作块内部不是三角因果 Mask。

![左侧显示两组参数在每层投影到共同注意力空间；右侧显示 π₀ 的前缀、状态、动作三块可见性和 π₀.₅ 默认的两块可见性。](../assets/figures/vla-joint-mask-v2.svg)

π₀ 与 π₀.₅ 公开 Flow 路径的联合注意力。左侧为两组参数的投影与交互，右侧为各输入块的可见性矩阵。



为什么动作可以看“后面的动作”？这些输入是同一生成时间的 \(X_t\)，并不是部署时不可用的未来真实标签。生成器在一次求解迭代中已经持有整块噪声状态，联合处理它们是条件分布模型的一部分。泄漏要按变量语义判断：若把干净动作答案或包含答案的另一路 token 交给同一预测支路，才改变了推理时的可用信息。





对深度作归纳可以证明前缀始终不依赖后缀。第 0 层前缀只含观测；假设第 \(l\) 层前缀与 \(X_t,t\) 无关，由于该层所有前缀 Query 只读前缀 Key/Value，且归一化、FFN 都逐 token 运算，下一层仍与它们无关。state 分支在 π₀ 中也不读动作，且没有时间调制，所以同样保持静态。若任一中间层开放了后缀到前缀的路径，这个归纳便不能继续；最后一层再遮住并不能自动删除先前已经写入的信息。





OpenPI 的 make_attn_mask 用“块起点标志”的累积和产生组号 \(g_i\)，允许条件是 \(g_j\le g_i\)，再与 Query/Key 有效位相交。π₀ 的标志为前缀全 0、state 为 1、首个 action 为 1、其余 action 为 0；π₀.₅ 默认把离散 state 放进前缀，所以只剩前缀与动作两块。有效性与组号承担不同职责，不能用一个普通下三角矩阵替代。





教学输入中，第四个样本请求的动作时域只有两步，第三个存储槽位是显式 Padding，这个请求长度在训练和推理都已知。其 action_valid 同时用于输入可见性与监督。真实回合“将在第几步终止”可能只在离线标签中知道；此时该未来有效位只能参与 Loss，不能直接复制到在线可见性中。要先确定可部署的输入填充规则，再定义独立的监督有效位。





$$
M^{\rm allow}_{bij}=\mathbf 1[g_j\le g_i]\,m_{bi}m_{bj},\qquad g_i=\sum_{r\le i}{\rm block\_start}_r
$$





## RoPE 位置、动作索引与生成时间必须分别编码

RoPE 编码 Token 在序列中的位置关系，动作索引表示未来命令槽位，生成时间表示噪声到动作的进程。这些身份在动作 Token 上同时存在，不能共享一个未解释的时钟。下面将它们分别接到旋转与时间调制。





设序列位置为 \(p_i\)，每头旋转矩阵为 \(R(p_i)\)。RoPE 使用 \(q_i\leftarrow R(p_i)q_i\)、\(k_j\leftarrow R(p_j)k_j\)，从而打分中出现 \(q_i^\top R(p_i)^\top R(p_j)k_j\)。在每个二维子空间的同频旋转下，\(R(p_i)^\top R(p_j)=R(p_j-p_i)\)。它编码 token 位置差，不会自动知道控制周期、末端坐标系或生成噪声水平；这些仍由输入协议与时间条件提供。完整旋转推导见[位置编码](#/learn/transformer?tab=theory&section=position-and-rope)。





固定版本的完整前向使用 \(p_{bi}=\sum_{j\le i}m_{bj}-1\) 计算有效位置。缓存推理中，新 suffix 的位置从每个样本的有效前缀长度继续，再累积 suffix 有效位。若一个批次的前缀存储宽度都是 11，但两个样本实际有效长度为 11 与 6，就不能都把 state 的位置写成 11。Mask 决定可读取的槽位，position_ids 决定旋转相位，两者不能相互替代。





缓存中的 Key 已经完成本层位置旋转。下一次 ODE 调用只需旋转新 suffix 的 Q/K，不应把缓存 Key 按新偏移再旋转一次。动作位置 \(h\) 在不同生成迭代保持不变，而 \(t\) 与 \(X_t\) 一起变化；把每轮积分都当成向文本末尾追加 token，会同时改变序列长度、位置和可见性，已经不再计算原来的速度场。





教学 RoPE 采用相邻坐标对旋转，OpenPI 的 _apply_rope 使用前后半区配对。二者可通过一致的坐标重排表达同一种旋转构造，但现成权重对应具体布局，不能直接交换实现而忽略参数坐标。教学代码不加载 checkpoint，因此只要求全算与缓存采用同一布局；它的 time_action MLP 则独立处理 \([B]\) 的生成时间。





$$
\widetilde q_i^\top\widetilde k_j=q_i^\top R(p_j-p_i)k_j,\qquad p^{\rm suffix}_{bi}=\sum_jm^p_{bj}+\sum_{r\le i}m^s_{br}-1
$$





## 一次训练：从动作标签到所有参数的梯度

VLA 的 Flow 训练以已知示范动作构造带噪动作和速度标签，再让条件网络拟合这个速度。模型输出的是生成时间导数，尚不是可直接执行的动作。下面固定 OpenPI 的反向时间约定，追踪监督如何传回专家与骨干。





本节与 OpenPI 一致，令 \(A\) 为归一化示范动作、\(Z\sim\mathcal N(0,I)\) 为独立噪声，并构造 \(X_t=tZ+(1-t)A\)。因此 \(t=1\) 是噪声、\(t=0\) 是动作，对时间求导得到条件速度 \(U=Z-A\)。模型输入 \((c,X_t,t)\)，输出 \(v_\theta\in\mathbb R^{B\times H\times D_a}\)。给定当前输入时，平方回归的理想解为 \(\mathbb E[Z-A\mid X_t,t,c]\)，而不是假设推理时知道某条训练路径的终点。条件期望与连续性方程的证明保留在[Flow Matching](#/learn/flow-matching)。





用 \(\mathcal I\) 表示有效标量坐标的集合，损失为 \(|\mathcal I|^{-1}\sum_{i\in\mathcal I}(v_i-U_i)^2\)。输出梯度是 \(\partial L/\partial v_i=2(v_i-U_i)/|\mathcal I|\)，再经线性读出、专家层、前缀 K/V 和图像语言编码器回传。Loss 没有直接监督每个前缀位置，不代表前缀参数没有梯度：动作 Query 使用的 Value 与 Key 仍由这些参数决定。 在网格案例中，示范标签先按被指令选中的颜色中心计算位移，再与噪声构造训练对；因此图像位置、颜色指令和当前起点都参与标签定义。相比只用随机图像配状态函数标签，这个例子能够核对输入语义与目标的对应，但四条样本的拟合仍不足以检验指令泛化。





在单个注意力行，记 \(o_i=\sum_j\alpha_{ij}v_j\)，则 \(\partial o_i/\partial v_j=\alpha_{ij}I\)，并有 \(\partial o_i/\partial s_{ij}=\alpha_{ij}(v_j-o_i)\)，其中 \(s_{ij}\) 是 Softmax 前分数。前一个式子说明 Value 直接传递条件梯度，后一个式子说明 Key/Query 通过改变读取权重获得梯度。若仅有一个有效 Key，权重固定为 1，第二条路径为零；这是结构事实，不能把所有零梯度都判为训练失败。





无效动作标签如果含 NaN，必须在构造 \(X_t\) 之前处理，否则它已经进入模型并可能通过动作块 attention 污染有效位置；只在最后 Loss 乘零不够。教学代码对已知的填充槽位先安全替换，输入 Mask 同时阻止其作为 Key 被读取，再对有效输出选索引求平方。空监督批次直接报错。官方 compute_loss 本身先对动作坐标取均值，教学实验增加显式有效时域归约；这项工程协议不应误写成原源码默认实现。





公开实现从偏向噪声端的 Beta 变换采样时间，而教学实验固定四个内部时刻与一份噪声，重复优化同一小批次以检查训练链路。改变时间采样密度，会改变各时间区间在有限模型训练中的权重；只要给定条件的权重为正，理想逐点平方回归解仍是相应条件期望。固定小批实验没有证明对新时间、新场景或新噪声的泛化。





$$
\begin{aligned}X_t&=tZ+(1-t)A,\qquad U=\frac{dX_t}{dt}=Z-A\\L(\theta)&=\mathbb E\!\left[\frac1{|\mathcal I|}\sum_{i\in\mathcal I}(v_{\theta,i}(X_t,t,c)-U_i)^2\right]\\\frac{\partial o_i}{\partial s_{ij}}&=\alpha_{ij}(v_j-o_i),\qquad s_{ij}=q_i^\top k_j/\sqrt{d_h}\end{aligned}
$$





## 冻结、断图与缓存：沿同一计算图区分六件事

冻结参数是停止选定参数的求导或更新，断图是切断某段上游求导依赖，缓存是复用前向中间结果。这三类操作作用于不同关系。前缀不读取动作仍可接受动作损失的反向信号，后训练需要分别定义这些选择。





对前缀参数 \(\theta_p\) 与专家参数 \(\theta_a\)，动作损失的梯度包含 \(\nabla_{\theta_p}L=\sum_l (\partial K_p^{(l)}/\partial\theta_p)^\top\nabla_{K_p^{(l)}}L+(\partial V_p^{(l)}/\partial\theta_p)^\top\nabla_{V_p^{(l)}}L\)，其中各层投影还通过前缀隐藏状态相互依赖。前向 Mask 禁止动作写回前缀，不能消除这些反向链式项。要隔离某条梯度，需要显式改变计算图或目标，而不是只调整可见性。





设置 requires_grad_(False) 只让这些参数不累计梯度，冻结模块仍可把梯度传给它之前的可训练输入。若图像前还有可训练增强器或适配器，这条输入梯度可能仍然必要。对中间特征 detach()，或在 no_grad() 内重新计算该段，则会切断它之前的路径；eval() 只切换 Dropout、BatchNorm 等训练行为，本身不关闭 Autograd，也不冻结参数。





优化器参数组是另一个独立选择：具有梯度的参数若未加入 optimizer，step 不会更新它；更换模块后旧优化器还可能引用旧对象。应先清除旧梯度，核对 requires_grad，再核对参数对象与实际更新差值。教学代码给 prefix 与 expert 不同学习率，仅用来展示参数分组，不是对真实 VLA 学习率比例的建议。





make_cache 本身不必断图。确定性设置下，在同一次参数版本内建立保留计算图的前缀 K/V，再用 suffix loss 反传，可以与完整计算给出相同梯度；教学实验显式比较视觉投影权重梯度。推理时的 no_grad cache 不具备这条反向路径；跨 optimizer.step 复用旧缓存还会使用旧参数的表示。无论是否 retain_graph，都不能据此把过期特征解释为当前模型的精确计算。





不同参数出现零梯度还可能来自架构本身。本课只读取最终动作输出，最后一层前缀 FFN 的输出不再被后续层使用，因此这部分参数不参与当前动作损失；同层动作读取的是进入该层 attention 的前缀 K/V。要求每个参数在每个 batch 都非零会误报。检查应围绕预期路径，例如首层视觉投影、词嵌入和动作专家参数组的梯度，以及实际参数变化。





Knowledge Insulation 进一步区分“骨干仍学习”和“骨干不接受动作专家梯度”。官方研究使用离散动作与其他 token 预测目标训练骨干，同时阻断连续动作专家损失向骨干回传；这不等价于把全部骨干永久冻结。固定版本的公开 README 说明只支持 π₀.₅ 的 Flow 训练/推理路径，不能把论文完整的多目标配方自动投射到每一次公开微调调用。具体迁移与 LoRA 取舍继续阅读[微调与 PEFT](#/learn/finetuning)。







### 操作改变的是哪个对象

| 操作 | 参数梯度 | 上游输入梯度 | 前向行为与缓存 |

|---|---|---|---|

| requires_grad_(False) | 指定参数不累计新梯度 | 仍可经过该模块 | 随机层与缓冲区是否变化需另外控制 |

| tensor.detach() | 该张量之前的路径被切断 | 被切断 | 当前数值保留；参数更新后可能过期 |

| torch.no_grad() | 上下文中的操作不记录反向图 | 该段路径被切断 | 适合推理；不是 eval() 的替代 |

| model.eval() | 仍可计算 | 仍可计算 | 切换训练/推理行为，不自动禁用梯度 |

| optimizer 参数组 | 决定有梯度的哪些参数被 step 更新 | 不负责控制 | 参数换新后需同步 optimizer |

| 前缀 KV 缓存 | 取决于是否保留计算图 | 取决于缓存构造方式 | 只可复用依赖与参数版本未变的值 |



## 一次生成：固定前缀、重算动作，积分得到命令

动作采样是从噪声出发反复计算速度并积分，得到模型坐标中的动作块；前缀缓存只复用满足不变条件的观测 K/V。动态动作每轮仍需重算。最后还须解码动作语义、执行一部分并读取新观测。





从 \(X_1=Z\) 开始，取 \(N\) 个 Euler 步，\(\Delta t=-1/N\)、\(t_n=1+n\Delta t\)，迭代 \(X_{t_{n+1}}=X_{t_n}+\Delta t\,v_\theta(X_{t_n},t_n,c)\)。最终得到模型空间中的 \(X_0\)，再按训练统计量反归一化、恢复动作语义，并执行约定的前 \(K\) 条命令。\(N\)、\(H\)、\(K\) 分别是求解次数、预测时域和执行时域，不能由同一个“步数”代替。 对同一个红色目标，三维输出仍须按 \((\Delta x,\Delta y,g)\) 解码；生成时间的速度不是夹爪的物理速度。网格示范的三个增量相加能到达目标中心，但模型采样的增量是否也做到，需要单独评价，不能由 Loss 下降推出。





本教材其他 Flow 章节使用噪声在 \(\tau=0\)、数据在 \(\tau=1\) 的方向。令 \(\tau=1-t\)，则 \(dX/d\tau=-dX/dt\)，因此对应目标变为 \(A-Z\)，步长变为正。二者描述同一路径的相反时间参数化。端点、目标符号、时间编码输入和求解方向必须成套匹配，不能只给采样器加一个负号后忽略模型训练时使用的时间。

![训练从示范动作和噪声构造输入与速度标签，经完整前后向更新两参数组；推理先建立前缀缓存，再在 t 从1到0的循环中重算动态动作，最后解码执行。](../assets/figures/vla-training-inference-v2.svg)

训练用示范动作与噪声构造监督；推理读取前缀缓存，迭代生成动作，再解码执行。虚线表示训练中的梯度。



缓存成立的证明来自[可见性小节](#/learn/vla-architecture?section=visibility)的依赖归纳：固定观测、位置、Mask、参数与确定性状态后，每层前缀输入不依赖动态 suffix，于是该层 \(K_p^{(l)},V_p^{(l)}\) 不随 \(X_t,t\) 改变。预填充逐层保存这两个张量，后续只计算 suffix 的 Q/K/V、attention 和 FFN。注意力权重仍随新 Query 改变，不能一并缓存成固定权重；动作当前 K/V 也必须每轮替换，而不是逐轮追加。





π₀ 的连续 state 在数学上也满足静态条件，但这个 OpenPI 版本的 sample_actions 仅预填充 embed_prefix 产生的视觉语言前缀，state 仍随 suffix 重算。可缓存与已经实现缓存是不同陈述。π₀.₅ 默认 state 位于前缀；只要同一次观测条件不变，它随前缀一同复用。新图像、新指令、新状态、参数更新、位置规则变化或随机增强，都要求重新判断相应缓存是否有效。





对于 \(L_b\) 层、批量 \(B\)、KV 头数 \(n_{kv}\)、有效存储长度 \(N_p\)、头宽 \(d_h\)，普通前缀缓存保存 \(2L_bBn_{kv}N_pd_h\) 个数。缓存节省前缀的重复投影、FFN 和自注意力，却仍需让每个动作 Query 读取前缀。它不会让动作计算独立于图像 token 数，也不自动抵消缓存带来的内存与访存成本。





教学代码同时保留完整前向与 make_cache 路径，先比较一次速度，再比较整个 Euler 轨迹末端。改变真实图像后，旧缓存产生的结果与重新编码不同，形成负向测试。闭环获取下一次观测后要重新编码；不能因为语言指令未变，就把整段视觉语言缓存跨多个机器人决策重复使用。 在真实任务中，执行前 K 条命令后获得的是新的图像与状态 \(c_{k+K}\)，应重新编码并预测余下动作；这一步闭环更新不在当前固定网格实验的验收范围内。





$$
\begin{aligned}X_1&=Z,\quad \Delta t=-1/N,\quad X_{t+\Delta t}=X_t+\Delta t\,v_\theta(X_t,t,c)\\\tau&=1-t,\qquad v_{\tau}(x,\tau,c)=-v_t(x,1-\tau,c)\\\#\mathrm{cache\ elements}&=2L_bBn_{kv}N_pd_h\end{aligned}
$$





## 沿同一网格案例核对：标签、梯度与采样各说明什么

现在从头回看同一批输入：彩色方块决定候选位置，颜色词选择目标，状态给出起点，动作标签分步移动并在末步闭合。完整代码先检查这条标签约定，再检查网络训练、缓存和冻结；这些检查分别回答不同问题。





实验包含 4 个样本、两幅小图像、3 个文字槽位、4 维状态与 3 步 3 维动作。前缀宽度 16、专家宽度 12，二者均为 2 层、2 个 attention 头、每头 4 维。输入宽度不同，但共同 attention 内宽度均为 8。PrefixEncoder、TeachingVLA.suffix、StreamLayer.project、attend、StreamLayer.finish 和 readout 分别对应本章各个结构环节；没有调用 nn.MultiheadAttention。





代码将每个 2×2 色块的像素中心映射到 [−1,1] 网格坐标，以目标中心减去夹爪起点，再除以已知请求步数，产生每步位移。独立断言将有效位移相加，核对终点正是指令选中的颜色中心；改选另一颜色会得到不同标签。标签合成使用已知渲染坐标，网络输入仍只有图像、文字和状态。它没有把颜色中心另行交给网络，也没有把数据集的正确性当作模型已经学会任务的证据。





CPU、float64、单线程、种子 20261106、PyTorch 2.15.0 的一次运行中，40 次固定小批更新将 Loss 从 2.377119 降到 0.142637。首步视觉投影与词嵌入的梯度范数约为 0.202212、0.085220，两个参数组都有实际更新。这里固定四个时间点和一份噪声，验证的是小批训练链路；它没有测量新场景、新指令组合或新噪声的泛化。无效标签 NaN、缺失视图隔离与空监督拒绝仍分别检查。





固定参数与观测时，完整/缓存速度的最大差约为 7.77×10⁻¹⁶，8 步 Euler 末端差约为 2.64×10⁻¹⁶。改变有效图像后，错误使用旧缓存与重新编码的差约为 0.256031。保留计算图的缓存仍通过视觉投影梯度等价检查；冻结参数时图像输入可有梯度，no_grad 缓存则切断这条上游路径。这些数值来自上述一次运行，平台变化可能带来微小差别。





模型采样与标签累加是两种不同的检查：前者当前只验收有限输出、形状、时间方向和缓存等价，后者验证合成示范的移动规则。实验没有独立任务测试集、动力学或接触模型，因而没有“抓取成功率”。完整真实策略还需按训练统计量反归一化，恢复动作单位与参考系，再在更新观测的闭环中评估；相应机制分别放在[训练与推理一致性](#/learn/train-infer-contract)、[动作执行](#/learn/execution-latency)与[策略评估](#/learn/evaluation)，此处不重复其推导。





建议按代码页中的函数边界阅读：先手算小型三块 Mask，再跟踪一次联合 attention 的投影与拆分；随后核对 FM target 的符号和有效分母，最后运行缓存、冻结和过期条件对照。练习页提供 Mask 手写题与联合 attention 实现题，要求用数值相等、禁止路径零梯度和条件干预来解释结果，而不仅是让返回张量形状正确。









## π₀、π₀.₅ 与 π₀-FAST：同一来源，不同计算协议

π₀ 和本章所指公开 π₀.₅ 路径采用连续动作流，π₀-FAST 则将动作编码为离散 Token 再自回归生成。它们在同一家族中仍有不同输入和训练协议。下面把这些差异定位到已经定义的计算接口。





π₀-FAST 把归一化动作块经过 DCT、量化与 BPE 编码为离散序列，再用视觉语言模型做 next-token prediction。它没有本章连续 Flow 路径中的噪声动作输入、速度 target 或 ODE 循环。压缩 token 长度不必等于动作时域乘动作维度；解码得到的连续动作还需遵循相同的归一化与时间协议。FAST 的具体表示来自[官方论文](https://arxiv.org/abs/2501.09747v1)。





固定版本的 [Pi0FAST](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0_fast.py) 使用一套 PaliGemma 模型参数和词表读出，而非 Pi0 中的两配置 joint-attention 模块。训练将输入/目标错开一位，Loss Mask 选取 postfix（其中包括动作输出格式标记）；推理逐 token 生成，再由动作 tokenizer 解码。原始连续 actions 参数并不直接作为这个 compute_loss 的回归 target，动作监督已经进入 tokenized_prompt。





π₀.₅ 原论文还讨论文本、高层子任务、离散动作与连续动作的联合训练。附录 A-E 给出一条容易遗漏的限制：连续动作专家不读取携带干净动作答案的 FAST token；否则训练时会获得部署的 Flow 输入所没有的信息。图 2 仅展示公开 Flow-only 实现，因此没有把这条额外监督序列画进前缀。论文架构和开源推理图应各按自己的输入协议阅读。





本文不从这些结构直接推导训练速度、语言理解或成功率排名。自回归次数取决于压缩长度，Flow 成本取决于求解次数与专家规模，实际时延还取决于缓存、精度和内核。方法之间的比较应固定观测信息、动作语义、数据和评估协议，分别报告计算预算与闭环行为，而不是把一个模型名字当作收益保证。





完整 VLA 应能从观测一路追到动作：编码确定条件信息，交互模块读取条件，训练目标定义生成量，采样与解码恢复动作，执行后再更新观测。骨干、专家、Mask 与缓存都要放回这条链上理解，不能从家族名称推断具体实现。







### 固定 OpenPI 版本的默认接口

| 接口 | π₀ | π₀.₅ 公开 Flow 路径 | π₀-FAST |

|---|---|---|---|

| 图像与语言 | SigLIP / PaliGemma 前缀 | 同类视觉语言前缀 | 同类视觉语言前缀 |

| 本体状态 | 连续投影，独立 state suffix 块 | 默认离散化写入 prompt；可被配置改变 | 离散化写入 prompt |

| 动作输入 | 整块连续噪声动作 | 整块连续噪声动作 | 训练时错位的离散 postfix token |

| 动作参数 | 独立专家参数，各层共同 attention | 独立专家参数，各层共同 attention | 同一自回归骨干与词表读出 |

| 生成时间 | action/time 拼接后 MLP | 时间 MLP → 专家 AdaRMSNorm | 没有 Flow 时间输入 |

| 动作可见性 | 噪声动作块内双向 | 噪声动作块内双向 | 输出 token 因果可见 |

| 监督与采样 | 速度 MSE；t=1→0 积分 | 速度 MSE；t=1→0 积分 | postfix CE；逐 token 生成与解码 |



## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| images | [B,V,3,8,8] | 教学模型的多视角输入，V=2；真实 checkpoint 使用自己的预处理协议 |
| prefix | [B,11,16] | 每视角 4 个 patch，加 3 个文字槽位；带独立有效位 |
| state | [B,4] → [B,1,12] | π₀ 风格的单个连续状态 token |
| noisy action / velocity | [B,H,3] | H=3；动作状态、速度 target 和输出具有相同轴 |
| suffix | [B,1+H,12] | 一个 state token 加 H 个动作 token |
| per-stream Q/K/V | [B,2,N,4] | 2 个普通 attention 头，头宽 4；两流隐藏宽度不同但投影空间兼容 |
| joint attention mask | [B,11+1+H,11+1+H] | 行是 Query，列是 Key；块顺序与有效位共同决定允许读取的集合 |
| prefix cache, each layer | K,V: [B,2,11,4] | 逐层保存旋转后的 Key 与 Value，始终不追加旧动作状态 |

## 完整代码与精读

```python
"""A small, original pi0-style teaching model; no pretrained weights required.

Run: python vla-joint-attention.py  (dependency: PyTorch)
OpenPI convention: t=1 is noise, t=0 is action; target = noise - action.
The fixed requested horizon mask is known at inference, not future episode termination.
"""
import copy
import json
import math

import torch
from torch import nn


def rms(x):
    return x * torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + 1e-6)


def rope(x, positions):
    # x: [B, heads, L, d]; rotate adjacent pairs (a teaching convention).
    d = x.shape[-1]
    assert d % 2 == 0
    frequency = 10000.0 ** (-torch.arange(0, d, 2, device=x.device, dtype=x.dtype) / d)
    angle = positions[:, None, :, None] * frequency
    even, odd = x[..., 0::2], x[..., 1::2]
    return torch.stack((even * angle.cos() - odd * angle.sin(),
                        even * angle.sin() + odd * angle.cos()), dim=-1).flatten(-2)


def visibility(valid, groups):
    # Row=query, column=key. The three groups are prefix=0, state=1, action=2.
    return (groups[None, :] <= groups[:, None])[None] & valid[:, :, None] & valid[:, None, :]


def attend(q, k, v, allowed):
    scores = q @ k.transpose(-1, -2) / math.sqrt(q.shape[-1])
    allowed = allowed[:, None]
    has_key = allowed.any(dim=-1, keepdim=True)
    scores = scores.masked_fill(~allowed, -torch.inf)
    scores = torch.where(has_key, scores, torch.zeros_like(scores))
    weights = torch.softmax(scores, dim=-1)
    weights = torch.where(allowed, weights, torch.zeros_like(weights))
    return weights @ v  # An invalid query has a zero attention result.


class StreamLayer(nn.Module):
    def __init__(self, width, heads=2, head_dim=4):
        super().__init__()
        self.heads, self.head_dim = heads, head_dim
        inner = heads * head_dim
        self.qkv = nn.Linear(width, 3 * inner, bias=False)
        self.out = nn.Linear(inner, width, bias=False)
        self.ff = nn.Sequential(nn.Linear(width, 2 * width), nn.SiLU(),
                                nn.Linear(2 * width, width))
        self.scale1 = nn.Parameter(torch.ones(width))
        self.scale2 = nn.Parameter(torch.ones(width))

    def project(self, x, positions):
        b, length, _ = x.shape
        q, k, v = self.qkv(rms(x) * self.scale1).chunk(3, dim=-1)
        q, k, v = [y.reshape(b, length, self.heads, self.head_dim).transpose(1, 2)
                   for y in (q, k, v)]
        return rope(q, positions), rope(k, positions), v

    def finish(self, x, attention):
        merged = attention.transpose(1, 2).flatten(-2)
        x = x + self.out(merged)
        return x + self.ff(rms(x) * self.scale2)


class PrefixEncoder(nn.Module):
    def __init__(self, depth=2, width=16):
        super().__init__()
        self.patch = nn.Conv2d(3, width, kernel_size=4, stride=4)
        self.camera = nn.Embedding(2, width)
        self.word = nn.Embedding(32, width)
        self.layers = nn.ModuleList(StreamLayer(width) for _ in range(depth))

    def embed(self, images, words, image_valid, word_valid):
        b, views, channels, height, width = images.shape
        assert (views, channels, height, width) == (2, 3, 8, 8)
        pixels = torch.where(image_valid[:, :, None, None, None], images, 0.0)
        patches = self.patch(pixels.reshape(b * views, channels, height, width))
        patches = patches.flatten(2).transpose(1, 2).reshape(b, views, 4, -1)
        cameras = self.camera(torch.arange(views, device=images.device))
        patches = (patches + cameras[None, :, None]).flatten(1, 2)
        text = self.word(words)
        valid = torch.cat((image_valid.repeat_interleave(4, dim=1), word_valid), dim=1)
        prefix = torch.cat((patches, text), dim=1)
        return torch.where(valid[..., None], prefix, 0.0), valid


class TeachingVLA(nn.Module):
    def __init__(self):
        super().__init__()
        self.prefix = PrefixEncoder()
        self.state = nn.Linear(4, 12)
        self.action = nn.Linear(3, 12)
        self.time_action = nn.Sequential(nn.Linear(24, 12), nn.SiLU(), nn.Linear(12, 12))
        self.expert = nn.ModuleList(StreamLayer(12) for _ in range(2))
        self.readout = nn.Linear(12, 3)

    def suffix(self, state, x, t, action_valid):
        # State has no t dependence; only the H action slots receive generation time.
        frequency = torch.arange(1, 7, device=x.device, dtype=x.dtype) * math.pi
        phase = t[:, None] * frequency
        time = torch.cat((phase.sin(), phase.cos()), dim=-1)
        action = self.action(torch.where(action_valid[..., None], x, 0.0))
        time = time[:, None].expand(-1, x.shape[1], -1)
        action = self.time_action(torch.cat((action, time), dim=-1))
        suffix = torch.cat((self.state(state)[:, None], action), dim=1)
        valid = torch.cat((torch.ones_like(action_valid[:, :1]), action_valid), dim=1)
        return torch.where(valid[..., None], suffix, 0.0), valid

    def forward(self, images, words, state, x, t, image_valid, word_valid,
                action_valid, cache=None):
        suffix, sv = self.suffix(state, x, t, action_valid)
        if cache is None:
            prefix, pv = self.prefix.embed(images, words, image_valid, word_valid)
        else:
            prefix, pv = None, cache['valid']
        p = pv.shape[1]
        valid = torch.cat((pv, sv), dim=1)
        positions = valid.long().cumsum(dim=1) - 1
        groups = torch.cat((torch.zeros(p, device=x.device, dtype=torch.long),
                            torch.ones(1, device=x.device, dtype=torch.long),
                            torch.full((x.shape[1],), 2, device=x.device)))
        allowed = visibility(valid, groups)
        for index, (prefix_layer, expert_layer) in enumerate(zip(self.prefix.layers, self.expert)):
            qs, ks, vs = expert_layer.project(suffix, positions[:, p:])
            if cache is None:
                qp, kp, vp = prefix_layer.project(prefix, positions[:, :p])
                q, k, v = [torch.cat(pair, dim=2)
                           for pair in ((qp, qs), (kp, ks), (vp, vs))]
                result = attend(q, k, v, allowed)
                prefix = prefix_layer.finish(prefix, result[:, :, :p])
                suffix = expert_layer.finish(suffix, result[:, :, p:])
            else:
                kp, vp = cache['layers'][index]
                result = attend(qs, torch.cat((kp, ks), dim=2),
                                torch.cat((vp, vs), dim=2), allowed[:, p:])
                suffix = expert_layer.finish(suffix, result)
        velocity = self.readout(rms(suffix[:, 1:]))
        return torch.where(action_valid[..., None], velocity, 0.0)

    def make_cache(self, images, words, image_valid, word_valid):
        # This function itself preserves autograd. The caller chooses no_grad/detach.
        prefix, valid = self.prefix.embed(images, words, image_valid, word_valid)
        positions = valid.long().cumsum(dim=1) - 1
        allowed = valid[:, :, None] & valid[:, None, :]
        layers = []
        for layer in self.prefix.layers:
            q, k, v = layer.project(prefix, positions)
            layers.append((k, v))  # Save each layer's rotated K and unrotated V.
            prefix = layer.finish(prefix, attend(q, k, v, allowed))
        return {'layers': layers, 'valid': valid}

    def fm_loss(self, batch, noise, t):
        images, words, state, actions, iv, wv, av = batch
        if not av.any():
            raise ValueError('The batch has no supervised action slots')
        if not torch.isfinite(actions[av]).all():
            raise ValueError('A valid action contains a non-finite value')
        # Invalid labels may be NaN: replace before interpolation, not after squaring.
        clean = torch.where(av[..., None], actions, 0.0)
        noise = torch.where(av[..., None], noise, 0.0)
        time = t[:, None, None]
        x = time * noise + (1 - time) * clean
        target = noise - clean
        prediction = self(images, words, state, x, t, iv, wv, av)
        return (prediction[av] - target[av]).square().mean()

    @torch.no_grad()
    def sample(self, batch, noise, steps=8, use_cache=True):
        if steps < 1:
            raise ValueError('steps must be positive')
        if self.training:
            raise ValueError('Call eval() before the inference comparison')
        images, words, state, _, iv, wv, av = batch
        cache = self.make_cache(images, words, iv, wv) if use_cache else None
        x = torch.where(av[..., None], noise.clone(), 0.0)
        dt = -1.0 / steps
        for step in range(steps):
            time = x.new_full((x.shape[0],), 1.0 + step * dt)
            x = x + dt * self(images, words, state, x, time, iv, wv, av, cache)
        return x


def grad_norm(parameters):
    terms = [p.grad.square().sum() for p in parameters if p.grad is not None]
    return float(torch.stack(terms).sum().sqrt()) if terms else 0.0


def experiment():
    torch.manual_seed(20261106)
    torch.set_num_threads(1)
    model = TeachingVLA().double()
    # A planar teaching task: move to the named colour and then close the gripper.
    # Vocabulary: 0=padding, 1=move, 2=red, 3=blue, 4=close.
    words = torch.tensor([[1, 2, 4], [1, 3, 0], [1, 3, 4], [1, 2, 0]])
    # Top-left (row, column) of each 2x2 square: [sample, red/blue, row/column].
    locations = torch.tensor([[[1, 1], [5, 5]], [[1, 5], [5, 1]],
                              [[5, 1], [1, 5]], [[5, 5], [1, 1]]])
    images = torch.zeros(4, 2, 3, 8, 8, dtype=torch.float64)
    for b in range(4):
        for colour, channel in enumerate((0, 2)):  # RGB red or blue
            row, column = locations[b, colour].tolist()
            images[b, :, channel, row:row+2, column:column+2] = 1.0
    # Both views render the same grid; these are not calibrated physical cameras.
    iv = torch.tensor([[1, 1], [1, 0], [1, 1], [1, 1]], dtype=torch.bool)
    wv = words != 0
    av = torch.tensor([[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 0]], dtype=torch.bool)
    state = torch.tensor([[0.0, 0.0, 0.0, 0.0], [0.25, -0.25, 0.0, 0.0],
                          [-0.25, 0.25, 0.0, 0.0], [0.1, 0.2, 0.0, 0.0]],
                         dtype=torch.float64)  # [x, y, vx, vy], grid units
    selected = (words[:, 1] == 3).long()
    # Map square centres from pixel indices to the declared [-1,1] grid frame.
    centres = (locations.flip(-1).double() + 0.5) / 7.0 * 2.0 - 1.0
    target_xy = centres[torch.arange(4), selected]
    requested_steps = av.sum(-1)
    delta = (target_xy - state[:, :2]) / requested_steps[:, None]
    actions = torch.cat((delta[:, None].expand(-1, 3, -1),
                         -torch.ones(4, 3, 1, dtype=torch.float64)), dim=-1).clone()
    actions[torch.arange(4), requested_steps - 1, 2] = 1.0  # close on last step
    # Independent label checks: integrate displacements; switch the requested colour.
    reached = state[:, :2] + torch.where(av[..., None], actions[..., :2], 0.0).sum(1)
    torch.testing.assert_close(reached, target_xy)
    assert (target_xy - centres[torch.arange(4), 1 - selected]).abs().sum(-1).min() > 0
    actions[~av] = torch.nan
    batch = (images, words, state, actions, iv, wv, av)
    noise = torch.randn(4, 3, 3, dtype=torch.float64)
    time = torch.tensor([0.2, 0.4, 0.6, 0.8], dtype=torch.float64)
    prefix_params = list(model.prefix.parameters())
    expert_params = [p for name, p in model.named_parameters() if not name.startswith('prefix.')]
    optimizer = torch.optim.AdamW([{'params': prefix_params, 'lr': 2e-3},
                                  {'params': expert_params, 'lr': 4e-3}], weight_decay=0.0)
    prefix_before = model.prefix.patch.weight.detach().clone()
    readout_before = model.readout.weight.detach().clone()
    initial = float(model.fm_loss(batch, noise, time).detach())
    for step in range(40):
        optimizer.zero_grad(set_to_none=True)
        loss = model.fm_loss(batch, noise, time)
        loss.backward()
        if step == 0:
            gradients = {'vision': grad_norm(model.prefix.patch.parameters()),
                         'language': grad_norm(model.prefix.word.parameters()),
                         'prefix': grad_norm(prefix_params),
                         'expert': grad_norm(expert_params)}
            assert all(value > 0 and math.isfinite(value) for value in gradients.values())
        optimizer.step()
    final = float(model.fm_loss(batch, noise, time).detach())
    assert final < initial  # Only verifies this fixed four-sample optimization experiment.
    assert not torch.equal(prefix_before, model.prefix.patch.weight)
    assert not torch.equal(readout_before, model.readout.weight)
    model.eval()
    with torch.no_grad():
        cache = model.make_cache(images, words, iv, wv)
        full = model(images, words, state, noise, time, iv, wv, av)
        cached = model(images, words, state, noise, time, iv, wv, av, cache)
        torch.testing.assert_close(full, cached, rtol=1e-10, atol=1e-10)
        altered = images.clone()
        altered[0, 0] += 2.0
        stale = model(altered, words, state, noise, time, iv, wv, av, cache)
        fresh = model(altered, words, state, noise, time, iv, wv, av)
        assert (stale[0] - fresh[0]).abs().max() > 1e-6
        padded = images.clone()
        padded[~iv] = 999.0
        ignored = model(padded, words, state, noise, time, iv, wv, av)
        torch.testing.assert_close(ignored, full, rtol=1e-10, atol=1e-10)
    generated = model.sample(batch, noise, use_cache=True)
    generated_full = model.sample(batch, noise, use_cache=False)
    torch.testing.assert_close(generated, generated_full, rtol=1e-10, atol=1e-10)
    assert torch.isfinite(generated).all() and (generated[~av] == 0).all()
    # A graph-preserving cache is also gradient-equivalent in this deterministic model.
    model.zero_grad(set_to_none=True)
    model(images, words, state, noise, time, iv, wv, av).square().sum().backward()
    reference = model.prefix.patch.weight.grad.clone()
    model.zero_grad(set_to_none=True)
    cache = model.make_cache(images, words, iv, wv)
    model(images, words, state, noise, time, iv, wv, av, cache).square().sum().backward()
    torch.testing.assert_close(reference, model.prefix.patch.weight.grad, rtol=1e-9, atol=1e-9)
    frozen = copy.deepcopy(model).eval()
    frozen.zero_grad(set_to_none=True)
    frozen.prefix.requires_grad_(False)
    pixels = images.clone().requires_grad_()
    frozen(pixels, words, state, noise, time, iv, wv, av).square().sum().backward()
    assert all(p.grad is None for p in frozen.prefix.parameters())
    assert pixels.grad.abs().sum() > 0  # Frozen parameters do not sever input gradients.
    pixels2 = images.clone().requires_grad_()
    with torch.no_grad():
        detached_cache = frozen.make_cache(pixels2, words, iv, wv)
    frozen(pixels2, words, state, noise, time, iv, wv, av, detached_cache).sum().backward()
    assert pixels2.grad is None  # no_grad really removes this upstream route.
    empty = (*batch[:-1], torch.zeros_like(av))
    try:
        model.fm_loss(empty, noise, time)
    except ValueError:
        pass
    else:
        raise AssertionError('empty supervision must be rejected')
    report = {'seed': 20261106, 'torch': torch.__version__, 'dtype': 'float64',
              'shapes': {'images': list(images.shape), 'prefix': [4, 11, 16],
                         'suffix': [4, 4, 12], 'velocity': list(full.shape)},
              'loss_before': initial, 'loss_after_40_updates': final,
              'first_step_gradient_norms': gradients,
              'cache_velocity_max_error': float((full - cached).abs().max()),
              'cache_sample_max_error': float((generated - generated_full).abs().max()),
              'stale_cache_max_error': float((stale - fresh).abs().max()),
              'task': 'planar named-colour approach; dx, dy, gripper in grid units',
              'target_xy': target_xy.tolist(),
              'checks': ['label displacements reach the named colour',
                         'switching colour changes the target label',
                         'finite valid-mask FM loss', 'two parameter groups receive gradients',
                         'full/cache velocity and Euler equality', 'changed-image cache invalidation',
                         'missing-view isolation', 'graph-preserving cache gradient equality',
                         'frozen parameter versus input gradient', 'no_grad cuts input route',
                         'empty supervision rejected']}
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    experiment()

```

- 第 15–43 行：归一化、RoPE、三块可见性与注意力核心。空行在 Softmax 前使用有限占位，之后将禁止权重归零。
- 第 46–90 行：前缀宽度 16、专家宽度 12，各有投影与 FFN；两流进入兼容的头空间。图像编码器只是 patch 层。
- 第 93–186 行：沿 suffix、forward、make_cache、fm_loss、sample 追踪整条链。目标为 noise−action，Euler 采用负步长；缓存是否保留图由调用者决定。
- 第 194–318 行：同一网格案例：渲染红蓝目标、按颜色词构造标签并核对位移终点，然后验证 40 次更新、缓存、缺失视图与冻结。标签正确、梯度连通与策略成功分别需要证据。

预期观察：依赖仅 PyTorch。CPU float64、种子 20261106、PyTorch 2.15.0：40 次固定小批更新的 Loss 为 2.377119→0.142637；完整/缓存速度最大差约 7.77e−16，采样末端差约 2.64e−16。图像变化后错用旧缓存的差约 0.256031。标签终点、颜色选择及原有缓存/梯度断言均通过；固定小批拟合不表示模型在独立网格任务或真实机器人上成功。

## 浏览器 Python 练习

实现 block_attention_mask(valid, block_start)。valid 是 [B,N] 布尔列表，block_start 是长度 N 的布尔列表；其累积和为组号。返回 [B,N,N] 布尔矩阵，行 Query i 只能读有效、且组号不大于自身的 Key j；无效 Query 整行必须为 False。拒绝空输入、形状不符及非布尔值。先手算两个 prefix、一个 state、两个 action 的矩阵，再运行测试。

```python
def block_attention_mask(valid, block_start):
    # 1. validate shapes and bools
    # 2. cumulative group IDs
    # 3. combine group order with both validity axes
    raise NotImplementedError

```

### 提示

- 同一块中的 token 可以互相读取；不要把所有位置一律做下三角。
- 组号整体加一不会改变相对关系。
- Query 无效和 Key 无效对应两条不同的屏蔽轴。

### 参考实现与解释

```python
def block_attention_mask(valid, block_start):
    if not valid or not valid[0]:
        raise ValueError("nonempty batch and sequence required")
    n = len(valid[0])
    if len(block_start) != n or any(len(row) != n for row in valid):
        raise ValueError("inconsistent lengths")
    if any(type(value) is not bool for row in valid for value in row):
        raise ValueError("valid entries must be bool")
    if any(type(value) is not bool for value in block_start):
        raise ValueError("block_start entries must be bool")
    groups, total = [], 0
    for start in block_start:
        total += int(start)
        groups.append(total)
    return [[[bool(row[i] and row[j] and groups[j] <= groups[i])
              for j in range(n)] for i in range(n)] for row in valid]

```

块起点的累积和表达的是块间因果性。动作块中只有第一个位置开启新组，后续动作保持同组，因此能够双向交互。有效位同时作用于两条轴，使填充不能被读取，也不能生成伪有效输出。

### 断言测试

```python
start = [False, False, True, True, False]
actual = block_attention_mask([[True] * 5], start)[0]
expected = [[True, True, False, False, False],
            [True, True, False, False, False],
            [True, True, True, False, False],
            [True, True, True, True, True],
            [True, True, True, True, True]]
assert actual == expected
mask = block_attention_mask([[True, False, True, True, False]], start)[0]
assert all(not row[1] and not row[4] for row in mask)
assert not any(mask[1]) and not any(mask[4])
# The first boundary flag may shift every group equally without changing visibility.
assert block_attention_mask([[True]*5], [True, False, True, True, False])[0] == expected
for valid, start in [([], []), ([[True]], []), ([[True], [True, False]], [False]),
                     ([[1]], [False]), ([[True]], [0])]:
    try:
        block_attention_mask(valid, start)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid input accepted")
print("block mask checks passed")

```

## 本地 PyTorch 练习

手写 joint_attention(qp,kp,vp,qs,ks,vs,prefix_valid,action_valid)。六个输入为有限浮点 [B,heads,L,d]；prefix 与 suffix 长度可不同，但 B、heads、d 相同。suffix 第一个 token 是始终有效的 state，后面是 H 个 action。prefix 只读有效 prefix；state 读 prefix+state；action 读全部有效 token。返回 (prefix_output,suffix_output)，无效 Query 输出零。不得调用 MultiheadAttention 或 SDPA。测试要求逐行独立参照、全屏蔽前缀、禁止路径零梯度和有效条件梯度。

```python
import math
import torch

def joint_attention(qp, kp, vp, qs, ks, vs, prefix_valid, action_valid):
    # Validate [B, heads, length, d] and masks.
    # Concatenate projected streams, apply the three-block mask,
    # normalize over keys, then split the output by token boundary.
    raise NotImplementedError

```

### 提示

- 在 Q/K/V 已投影后沿 length 轴拼接，不是沿 head 或 feature 轴。
- 全屏蔽 Query 的 softmax 输入不能保持全负无穷；先选有限占位，随后清零该行权重。
- 先对 prefix 与 state 输出求导，动作 K/V 应无梯度；再对动作输出求导，允许的前缀 Value 应获得梯度。

### 参考实现与解释

```python
import math
import torch

def joint_attention(qp, kp, vp, qs, ks, vs, prefix_valid, action_valid):
    # suffix = one always-valid state token followed by H action tokens
    tensors = (qp, kp, vp, qs, ks, vs)
    if any(x.ndim != 4 for x in tensors):
        raise ValueError("Q/K/V must have shape [B, heads, length, d]")
    b, heads, p, d = qp.shape
    s = qs.shape[2]
    if min(b, heads, p, d) < 1 or s < 2:
        raise ValueError("nonempty prefix and at least one action required")
    if any(x.shape != qp.shape for x in (kp, vp)) or any(x.shape != qs.shape for x in (ks, vs)):
        raise ValueError("Q/K/V lengths must match within each stream")
    if qs.shape[:2] != qp.shape[:2] or qs.shape[-1] != d:
        raise ValueError("batch/head dimensions must be compatible")
    if any(x.device != qp.device or x.dtype != qp.dtype or not x.is_floating_point()
           or not torch.isfinite(x).all() for x in tensors):
        raise ValueError("finite, same-device floating Q/K/V required")
    if prefix_valid.shape != (b, p) or action_valid.shape != (b, s - 1):
        raise ValueError("mask shapes are inconsistent")
    if any(m.dtype != torch.bool or m.device != qp.device for m in (prefix_valid, action_valid)):
        raise ValueError("boolean same-device masks required")
    state_valid = torch.ones(b, 1, dtype=torch.bool, device=qp.device)
    valid = torch.cat((prefix_valid, state_valid, action_valid), dim=1)
    groups = torch.tensor([0] * p + [1] + [2] * (s - 1), device=qp.device)
    allowed = ((groups[None, :] <= groups[:, None])[None]
               & valid[:, :, None] & valid[:, None, :])[:, None]
    q, k, v = [torch.cat(pair, dim=2) for pair in ((qp, qs), (kp, ks), (vp, vs))]
    logits = q @ k.transpose(-1, -2) / math.sqrt(d)
    logits = logits.masked_fill(~allowed, -torch.inf)
    has_key = allowed.any(dim=-1, keepdim=True)
    logits = torch.where(has_key, logits, torch.zeros_like(logits))
    weight = torch.softmax(logits, dim=-1)
    weight = torch.where(allowed, weight, torch.zeros_like(weight))
    output = weight @ v
    return output[:, :, :p], output[:, :, p:]

```

这道实现题只验证共同 attention 空间中的数据流，两个流的 Linear、RMSNorm、FFN 与多层组合见完整代码。逐行参照使用显式合法 Key 索引，避免参照代码重复同一个矩阵 Mask 错误；梯度测试进一步验证被禁止的信息路径，不能由输出 shape 替代。

### 断言测试

```python
torch.manual_seed(13)
qp = torch.randn(2, 2, 3, 4, dtype=torch.float64, requires_grad=True)
kp = torch.randn_like(qp, requires_grad=True)
vp = torch.randn_like(qp, requires_grad=True)
qs = torch.randn(2, 2, 4, 4, dtype=torch.float64, requires_grad=True)
ks = torch.randn_like(qs, requires_grad=True)
vs = torch.randn_like(qs, requires_grad=True)
pv = torch.tensor([[1, 1, 0], [0, 0, 0]], dtype=torch.bool)
av = torch.tensor([[1, 1, 0], [1, 1, 1]], dtype=torch.bool)
p, s = joint_attention(qp, kp, vp, qs, ks, vs, pv, av)
assert p.shape == qp.shape and s.shape == qs.shape
assert torch.isfinite(p).all() and torch.isfinite(s).all()
assert (p[1] == 0).all() and (s[0, :, -1] == 0).all()
# Independent row-by-row reference, not the same matrix-mask implementation.
for b in range(2):
    keys = torch.cat((kp[b], ks[b]), dim=1)
    values = torch.cat((vp[b], vs[b]), dim=1)
    for i in range(4):
        if i > 0 and not av[b, i-1]:
            continue
        visible = pv[b].nonzero().flatten().tolist() + [3]
        if i > 0:
            visible += [4+j for j in range(3) if av[b, j]]
        logits = (qs[b, :, i:i+1] @ keys[:, visible].transpose(-1, -2)) / 2
        expected = (logits.softmax(-1) @ values[:, visible]).squeeze(1)
        torch.testing.assert_close(s[b, :, i], expected)
# Prefix cannot depend on suffix; state cannot depend on any action slot.
(p.square().sum() + s[:, :, :1].square().sum()).backward(retain_graph=True)
assert qs.grad[:, :, 1:].count_nonzero() == 0
assert ks.grad[:, :, 1:].count_nonzero() == 0
assert vs.grad[:, :, 1:].count_nonzero() == 0
for tensor in (qp, kp, vp, qs, ks, vs):
    tensor.grad = None
s[:, :, 1:].square().sum().backward()
assert vp.grad[0, :, :2].abs().sum() > 0
assert vs.grad[0, :, -1].count_nonzero() == 0
try:
    joint_attention(qp, kp, vp, qs, ks, vs, pv.float(), av)
except ValueError:
    pass
else:
    raise AssertionError("non-bool mask accepted")
print("joint attention reference and gradient checks passed")

```

## 练习：推导与分析

### 两组隐藏宽度不同，为什么还能做联合 attention？若分别对前缀和动作做两个 Softmax 再相加，是否等价？

各自的 Q/K/V 投影把隐藏宽度映射到兼容头空间，因此点积和 Value 加权是合法的；输出再用独立投影恢复各自宽度。

一次联合 Softmax 的分母包含全部允许 Key。两个独立 Softmax 会各自分配总质量 1，其和通常不同；额外门控或归一化也构成另一种参数化，不能直接视为原公式。

代码定位：StreamLayer.project 与 TeachingVLA.forward 的 torch.cat / attend / split；联合 attention 手写题。

- 写清两组投影矩阵形状和 Q/K/V 拼接轴。
- 用一个前缀 Key、一个动作 Key 的标量例子说明归一化分母不同。

### π₀ 的 state token 与 π₀.₅ 默认的 state token 分别在哪里？为什么这会改变可缓存范围？

π₀ 将连续状态投影到动作专家 suffix 中的独立块；π₀.₅ 默认把状态离散化写入文字前缀，不再添加连续 state suffix。实际数据变换允许配置差异，需要与模型一起核对。

π₀ state 在数学上静态且不读动作，可以设计缓存，但固定 OpenPI sample_actions 只预填充视觉语言 prefix；π₀.₅ 的离散 state 已包含在前缀缓存。新状态来到时相应缓存必须失效。

代码定位：官方 embed_prefix / embed_suffix / ModelTransformFactory；教学 make_cache 仅缓存 prefix。

- 分别指出状态进入的参数流与可见性块。
- 区分理论上可缓存与固定版本确实缓存的内容。

### 为什么“前缀不读取动作”不能推出“动作 Loss 不更新前缀”？冻结前缀参数是否阻止可训练图像适配器收到梯度？

动作 Query 读取前缀 K/V，损失通过 Value 与 Softmax 分数回传到前缀投影及编码器。前向可见性与反向链式法则方向不同。

requires_grad_(False) 只冻结指定参数；上游可训练输入仍能获得梯度。对特征 detach 或用 no_grad 构造缓存才会切断该路。若骨干还要接受离散 token 目标，Knowledge Insulation 也不等价于全冻结。

代码定位：experiment 中 frozen/pixels 与 detached_cache/pixels2 对照。

- 指出至少一条经前缀 Value 回传的梯度路径。
- 解释为什么 eval() 不能替代冻结或 no_grad。

### 将 OpenPI 的 t=1→0 改成本教材常用的 τ=0→1，需要同时改哪些量？

令 τ=1−t，则同一路径写成 \(X_\tau=(1-\tau)Z+\tau A\)，速度目标为 A−Z。相应网络时间输入与速度符号必须按新参数化转换，积分步长改为正。

只改积分循环起止值或只改 target 都可能让输入路径与学习场不匹配。可用常速度端点算例与完整采样对照检验，而不能只检查张量维度。

代码定位：fm_loss 的 x/target 与 sample 的 dt/time。

- 列出两个端点、导数目标、时间输入映射与步长。
- 能手算常速度下负步长从噪声到动作的正确终点。

### 保留计算图的 prefix cache 与 no_grad cache 在训练时有什么区别？为什么跨 optimizer.step 复用都需要重新检查？

同一次参数版本、确定性输入和合法 Mask 下，保留图的逐层 K/V 可以给出与完整前向相同的参数梯度。no_grad cache 只保留数值，不再把动作损失传回前缀编码器。

更新参数后，之前生成的 K/V 通常不再等于当前参数对相同观测的结果；retain_graph 只能保留旧图，不能把旧值变成新值。缓存有效性需要与输入、位置、模型状态及参数版本共同绑定。

代码定位：make_cache 不带 no_grad 装饰；sample 由调用方整体 no_grad；experiment 比较缓存梯度。

- 分别说明前向等价、反向等价与版本有效性。
- 解释为什么只比较缓存张量 shape 不足够。

### 为什么教学实验中语言梯度非零、Loss 降低、缓存对照通过，仍不能证明策略会正确执行指令？

梯度和数值等价验证的是计算路径。合成标签只由状态生成，没有图像与指令语义任务；模型可以在条件无关的输入上仍有梯度。

固定四个样本和固定噪声的拟合没有覆盖新条件或新噪声分布。语义能力要用能区分指令的受控数据，策略能力还需动作解码、独立任务与闭环评估。

代码定位：experiment 的标签构造、固定 noise/time 与 JSON 输出。

- 明确实验验证了什么，也明确没有验证什么。
- 提出固定观测与噪声、改变有意义指令的独立对照设计。

## 练习：辨析与纠错

### 把共同注意力写成共同权重

不同 token 使用各自投影与 FFN；兼容的是注意力头空间，而非所有隐藏宽度与参数。

### 把不读动作的前缀误认为不接受动作梯度

前向 Mask 限制信息写入；动作损失仍可沿前缀 K/V 反传。梯度隔离需要显式定义。

### 把论文配方当成公开入口全部功能

π₀.₅ 原论文、Knowledge Insulation 与公开 Flow-only 微调路径需要分别核对。checkpoint 的训练来源不能自动定义后续每次更新的目标。

### 把上次动作 K/V 累加到下一次 ODE 调用

迭代更新的是整块动作状态。固定前缀可保留，动态 suffix 应替换，而不是成为不断延长的历史。

### 把物理动作时域与 Flow 时间混用

H 决定一次输出多少命令，t 决定当前概率路径位置，N 决定求解调用数；三个轴不能相互替换。

### 只在最后乘 Mask 清除 NaN

无效 NaN 可能在构造噪声输入时就进入注意力。需要先安全构造输入，再独立选择有效监督，且不泄漏未来终止信息。

## 原始资料

- [π₀ 原论文：架构、专家、Mask 与采样（附录 B、D）](https://www.pi.website/download/pi0.pdf)
- [π₀.₅ 原论文 v1：混合训练与架构边界（附录 A-E）](https://arxiv.org/html/2504.16054v1)
- [FAST 原论文 v1：动作压缩与自回归建模](https://arxiv.org/html/2501.09747v1)
- [OpenPI 固定版本：模型输入、FM 时间方向与缓存](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0.py)
- [OpenPI 固定版本：双专家 attention、RoPE、AdaRMSNorm](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/gemma.py)
- [OpenPI 固定版本：π₀ / π₀.₅ 配置与默认状态路径](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0_config.py)
- [OpenPI 固定版本：状态与动作 tokenizer](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/tokenizer.py)
- [OpenPI 固定版本：FAST 的错位目标和 CE](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/models/pi0_fast.py)
- [OpenPI 固定版本：数据变换与配置组合](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/src/openpi/training/config.py)
- [OpenPI README：公开 π₀.₅ Flow-only 范围](https://github.com/Physical-Intelligence/openpi/blob/215abfb217dbac7d5f1273282331b9b1866c0479/README.md)
- [Knowledge Insulation 官方研究：梯度隔离与独立 token 目标](https://www.pi.website/research/knowledge_insulation)
