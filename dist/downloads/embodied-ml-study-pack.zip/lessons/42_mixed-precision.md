# 混合精度训练

分清数值范围、舍入精度，以及 loss scaling 真正改变了什么。

低精度计算能够减少部分存储和运算成本，但它也改变了哪些数值差异能够被表示。混合精度需要在计算收益与误差之间设置清楚的边界，而非把模型整体转换为一种较小的数据类型。本章从浮点格式解释舍入、下溢与溢出，再推导损失缩放及其与累积、裁剪的顺序关系。每项机制都与 FP32 参照联系起来，用于判断误差来自前向、反向还是实际参数更新。

前置知识：[数值精度与标准化](https://wxb1870.github.io/embodied-ml-lab/learn/numerical/) · [梯度累积](https://wxb1870.github.io/embodied-ml-lab/learn/gradient-accumulation/)

## 范围与精度分别由指数和尾数控制

降低浮点位数并不是均匀地降低所有数值的精度，位数如何分给指数和有效数字决定了不同误差。先看具体格式可表示的范围和间距，才能解释为什么 BF16 与 FP16 会在不同位置失效。



浮点格式包含符号、指数和有效数字。指数决定数量级范围，有效数字决定相邻可表示值之间的距离。FP16 最大有限值为 65504；BF16 与 FP32 的指数范围相近，但有效数字明显更少。因此 BF16 缓解了不少范围问题，却不等于有 FP32 的局部精度。



在 [1,2) 区间，BF16 相邻可表示数的间距为 \(2^{-7}=0.0078125\)，FP16 为 \(2^{-10}\)，FP32 为 \(2^{-23}\)；可以用 torch.finfo(dtype).eps 核对。间距会随数的量级改变，这不是所有数都具有同一绝对误差界。1.001 转成 BF16 会被舍入成 1，之后再转回 FP32 仍是 1。



下溢、溢出与舍入需要分开处理。梯度缩放可使某些小梯度在反向中落到更易表示的范围，但不能找回前向已经舍掉的残差，也不能修复先前产生的 Inf。若参数本身以低精度存储，过小的更新还可能被加法舍入吞掉；保留 FP32 参数和合适精度的优化器状态，解决的是另一段计算路径。



autocast 选择哪些算子使用低精度，收益取决于设备、内核、形状和数据传输。dtype 打印可以核对计算边界，实际精度、速度和显存则要在目标环境测量。





## autocast 按算子选择 dtype，不等于 model.half

不同算子对范围与精度的需求不同，整张网络没有必要统一使用同一种计算类型。autocast 提供按算子划定的边界，而参数存储与优化器状态仍需单独理解，不能由一个输出 dtype 推断全部过程。



autocast 在上下文中依据算子规则选择计算精度；某些矩阵乘法可以用低精度，某些敏感操作会保持或提升精度。模型参数可以继续以 FP32 保存，反向梯度与优化器状态也有各自的 dtype。手动将整个模型 half 会改变参数存储和更多运算，不能把它当作 autocast 的同义写法。



推荐的基础模式是在 autocast 中执行前向和 loss 计算，再在外部反向。不要为追求统一而反复手动 cast 中间张量，否则可能破坏算子策略或引入额外拷贝。自定义算子、未覆盖的操作和跨上下文输入需要检查实际 dtype；某个张量显示 float32，也不代表前面的所有乘加都使用了 FP32 精度。





### 查看关键算子的输入、输出和参数 dtype

混合精度是计算路径的配置，不能只检查模型权重一个 dtype。

在最小例子中打印线性层输出、loss、参数与梯度 dtype，核对实际精度边界。

## 梯度缩放为何能保护小梯度

反向链条中的很小数值可能在低精度中消失，即使最终需要的梯度仍有意义。利用求导对常数缩放的线性性，可以临时放大这条链条，再在更新前还原；这一推导也明确了它无法修复的前向问题。



设原损失为 L，乘上正缩放因子 s 后，反向得到 \(s\nabla L\)；若在更新前除以 s，数学目标保持不变。放大后的梯度可能落入低精度更容易表示的范围，减轻下溢。缩放因子太大又会导致梯度溢出，因此动态缩放器会根据有限性检查调整。这个机制保护的是数值表示，不会增强模型的信息或改变正确目标。



缩放不能修复前向阶段已经产生的 NaN/Inf。比如输入过大使矩阵乘法先溢出，或者 log 接收非法值，后续无论怎样缩放 loss 都无法恢复正确中间结果。BF16 常因指数范围较宽而不需要与 FP16 相同的缩放策略，但也不能据此宣称任何 BF16 模型都不会出现非有限值。



$$
\nabla_\theta(sL)=s\nabla_\theta L,\qquad g=\frac{\nabla_\theta(sL)}s
$$



### 例：缩放与还原的数值含义

1. 原始梯度假设为 \(10^{-8}\)，缩放因子 \(s=2^{16}=65536\)。

2. 缩放后梯度约为 \(6.55\times10^{-4}\)，落到更容易表示的量级。

3. 优化前除以 65536 才回到原本梯度；若忘记还原，相当于大幅改变更新尺度。

正确缩放不应改变优化问题，只改变中间数值的表示范围。

## unscale、裁剪与 step 的正确顺序

缩放后的梯度与原目标梯度具有不同数值单位，任何依赖绝对范数的操作都必须使用正确单位。由此可以推出还原、裁剪和更新的顺序，而不是只记住一段固定的 AMP 模板。



如果在缩放梯度上按原阈值裁剪，就相当于把真实梯度阈值缩小了 s 倍。应先完成反向，再 scaler.unscale_(optimizer)，然后对真实梯度裁剪，再 scaler.step 和 scaler.update。一次更新中对同一 optimizer 只应 unscale 一次；多个优化器则要明确每个参数由哪个优化器管理。



scaler.step 会检查其管理的梯度是否存在非有限值，并可能跳过实际 optimizer.step。日志中看到调用过 scaler.step，不足以证明参数发生更新。应记录跳步事件、缩放因子与真实参数位移；按更新步设计的学习率日程也要协调。连续跳步通常值得排查前向尺度或梯度异常，不能把“没有崩溃”当作有效学习。





### 例：在缩放梯度上裁剪的后果

1. 真实梯度范数为 2，缩放因子为 1024，看到的范数为 2048。

2. 若直接裁剪到 1，再除以 1024，真实梯度只剩 \(\frac1{1024}\)。

3. 先还原成范数 2，再裁剪到 1，才是原先设定的阈值。

裁剪阈值有单位，必须与梯度所处的缩放状态一致。

### 在 unscale 之前按真实阈值裁剪

这会严重削弱梯度，甚至让训练看似稳定但几乎不更新。

记录还原前后范数，确认裁剪使用的是实际梯度尺度。

## 累积和多任务不能混入不同缩放单位

多个微批次或损失共同作用于同一参数时，缩放单位还必须在贡献之间保持一致。额外调用 autograd.grad 返回的张量也可能绕开优化器的还原流程，需要沿每一条梯度路径核对。



一个有效批次内累积的所有梯度需要使用相同缩放因子。中途 unscale 或 update 会使 .grad 混合不同比例，无法再通过一次除法恢复。应在完整累积后才执行有限性检查、还原、裁剪和更新。同样，若多个损失共同训练一组参数，它们的相对权重应先按目标定义好，再按一致规则缩放。



autograd.grad 返回的梯度不一定存放在 optimizer 管理的 .grad 内，scaler.unscale_(optimizer) 不会自动处理这些返回值。做梯度惩罚或梯度范数诊断时，应明确返回的是缩放梯度还是原梯度，并按所需数学目标自行还原。误把缩放后的诊断值解释为真实任务强度，会导致权重判断失真。



排查这种组合问题时，先在 FP32、单任务、无累积条件下建立正确参照，再逐项开启低精度、累积和梯度诊断。一次启用全部机制时，即使最终 loss 变化，也难以确定是哪一处改变了计算含义。





## 敏感运算可以局部使用更高精度

当误差集中在少量敏感算子时，可以只提高这些边界的计算精度。关键在于精度提升必须发生在信息丢失之前；转回更宽的格式不能恢复已经被低精度舍去的差值。



平方误差的残差、均值方差、概率归一化或很长序列的加和，可能对精度更敏感。可以在明确边界把相关输入转为 FP32，使用稳定公式计算，再继续后续路径。局部提升应依据对照结果，而不是对整个模型无差别禁用低精度。需要注意 cast 的位置：若低精度残差已经舍入为零，再转 float 不会恢复丢失的差异。



类似地，低精度前向输出即使随后做 FP32 loss，也仍带有前面算子的舍入误差；这通常是混合精度设计的一部分，但必须评估是否可接受。比较模型时可同时检查 loss、若干激活、逐参数梯度与一次更新，找出误差首次显著增长的位置。单独要求所有元素逐位等于 FP32 不现实，单独要求“最终有限”又太弱。



```python
import torch

prediction = torch.tensor([1.001], dtype=torch.float32)
target = torch.tensor([1.000], dtype=torch.float32)
residual_fp32 = prediction - target
residual_after_cast = prediction.bfloat16().float() - target.bfloat16().float()
assert residual_fp32.item() > 0.0009
assert residual_after_cast.item() == 0.
assert torch.finfo(torch.bfloat16).eps == 2**-7
print("before rounding:", residual_fp32.item())
print("after BF16 rounding:", residual_after_cast.item())
```

两条路径最终都用 FP32 相减，但第二条的两个输入已经先被 BF16 舍入为同一个数，所以残差为零。若要保留这段差异，必须在信息丢失前保留更高精度；仅把最终 loss 转成 float 或增大 GradScaler 倍数都无法恢复它。



### 结果转成 float 就以为整段计算获得了 FP32 精度

cast 只能转换当前已存储的数，不能恢复之前舍入或溢出的信息。

把精度提升放在敏感运算之前，并对照提升前后的中间值及梯度。

## 如何区分前向溢出、反向下溢与真实优化问题

非有限输出、极小梯度和参数不动是不同现象，可能发生在不同计算阶段。固定输入和状态后逐段比较 FP32 与低精度路径，可以找到首次分歧，并据此选择公式、尺度或精度上的修复。



前向出现 Inf/NaN 时，先检查输入、预激活、归约和 loss；loss 有限而梯度非有限时，重点检查局部导数、缩放倍数和不稳定反向算子；梯度有限却参数不动时，再检查优化器、跳步、学习率和更新是否小于参数可表示间距。不同现象应对应不同实验，不能一概归结为显卡精度不够。



对照实验固定相同权重、样本和随机因素，分别执行 FP32 与混合精度路径。若 FP32 也失败，应优先修复数学与管线；若只有混合精度失败，逐层定位首次分歧，检查范围与算子策略。记录每次修改的证据，如恢复有限梯度、降低相对误差或改善实际更新，而不是只记录“换 BF16 后好了”。



对梯度极小但有限的情况，还需比较优化前后参数是否真的改变。仅检查 isfinite 不会发现更新在参数存储精度下被舍入掉；参数差与预期更新量对照能够补上这个盲区。





## 验证范围、性能测量与保存恢复

数值对照通过只是采用混合精度的一个条件，还需要在目标硬件上确认资源收益。保存精度配置与缩放器状态则保证后续恢复沿用同一计算协议，避免将不同数值路径误认为相同实验。



配套代码提供可执行的 CPU BF16 autocast 教学路径和清楚的 CUDA FP16 分支。CPU 检查能验证代码结构、dtype 与梯度关系，但不能证明某张 GPU 的吞吐、内核支持或数值表现。硬件性能应在目标环境固定批次形状、进行预热和同步计时，同时测峰值内存与有效样本吞吐。



保存训练状态时，除了权重与优化器，还要保存启用的 GradScaler 状态，避免恢复后无说明地改变尺度历史。记录 autocast dtype、关键精度例外和 loss 的归约方式。改变这些设置之后，重新检查固定样本的一步更新与独立验证表现；“同样的权重文件”不意味着所有数值路径都保持不变。



混合精度成功的证据是目标模型在可接受误差和任务指标下获得实际资源收益。训练不稳定、频繁跳步或额外 cast 开销过大时，应先定位瓶颈与数值问题，再决定在哪些模块使用低精度。



性能对照应避免被首次内核初始化、编译或文件读取主导。固定预热次数、测量区间与同步方式，记录训练完整 step 而非只测一个矩阵乘法。只有模型指标与资源收益同时可接受时，才构成这项精度配置的实际收益。



为了把精度放回同一训练任务，可运行[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)的 `verify_cpu_amp` 和 `train_window(cpu_amp=True)`。它从同一初值核对 FP32 与 CPU BF16 的输出 dtype，并比较 loss 与梯度，检查 FP32 参数与 loss 归约，并实际执行一次更新。程序打印的误差只是固定小模型的观察，断言不构成 BF16 的普遍误差界；CUDA FP16、GradScaler 溢出跳步与 GPU 延迟不在本次 CPU 验证范围内。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 模型参数 | FP32 [out, in] | 本例保留 FP32 权重，autocast 不等于永久转换参数。 |
| 线性层输出 | BF16 [B, A] | CPU autocast 下矩阵运算的输出示例。 |
| MSE 与参数梯度 | FP32 标量 / 参数形状 | 以实际 dtype 打印核查，不凭名称猜测。 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(30)
# STEP 1: 本次固定运行 CPU；CUDA 分支需有可用 GPU
device_type = 'cpu'  # 本地有 GPU 时可改为 'cuda'
dtype = torch.bfloat16 if device_type == 'cpu' else torch.float16
model = nn.Linear(4, 2).to(device_type)
x = torch.randn(8, 4, device=device_type)
y = torch.randn(8, 2, device=device_type)
optimizer = torch.optim.SGD(model.parameters(), lr=0.05)
scaler = torch.amp.GradScaler('cuda', enabled=(device_type == 'cuda'))
before = model.weight.detach().clone()

# STEP 2: 前向自动选精度；反传、反缩放与裁剪在外部
optimizer.zero_grad(set_to_none=True)
with torch.autocast(device_type=device_type, dtype=dtype):
    prediction = model(x)
    loss = F.mse_loss(prediction, y)
scaler.scale(loss).backward()
scaler.unscale_(optimizer)
grad_norm = nn.utils.clip_grad_norm_(model.parameters(), 1.0)
scaler.step(optimizer)
scaler.update()
assert torch.isfinite(loss)
assert all(torch.isfinite(p.grad).all() for p in model.parameters())
assert not torch.equal(before, model.weight)
print('参数 / 输出 / 损失 dtype:', model.weight.dtype, prediction.dtype, loss.dtype)
print('裁剪前范数:', round(float(grad_norm), 6))

# STEP 3: 单独观察范围与精度，避免把 BF16 当作更精确的 FP16
values = torch.tensor([1e5, 1e-8, 1.001], dtype=torch.float32)
fp16 = values.to(torch.float16).float()
bf16 = values.to(torch.bfloat16).float()
assert torch.isinf(fp16[0]) and fp16[1] == 0
assert torch.isfinite(bf16).all() and bf16[1] > 0
print('原数值:', values.tolist())
print('FP16 还原:', fp16.tolist())
print('BF16 还原:', bf16.tolist())
print('本例只验证 CPU BF16；CUDA 分支需要在 GPU 上另行验证')

```

- 第 1–15 行：device_type 固定为 cpu，参数和数据按设备放置。CPU 路径禁用 scaler；CUDA 路径才启用 FP16 梯度缩放，当前环境未运行该分支。
- 第 16–31 行：autocast 覆盖前向和损失；unscale_ 必须先于 clip_grad_norm_。示例核查实际 dtype、有限梯度和参数变化，未以 CPU 结果宣称 GPU 性能。
- 第 32–41 行：1e5 在 FP16 转换时溢出，1e-8 下溢为零；BF16 保留它们的量级，但 1.001 会受到更粗尾数的舍入。

预期观察：CPU 输出权重 FP32、预测 BF16、MSE FP32；一次更新完成。FP16 示例出现 inf 与 0，BF16 对相应量级保持有限非零值。

## 浏览器 Python 练习

实现 unscale_and_clip(scaled_grad, scale, max_norm)，输入为非空的有限数列表，返回 (真实裁剪前范数, 裁剪后梯度列表)。scale 必须为有限正数，max_norm 为有限非负数；输入非法时抛 ValueError。零梯度应保持为零。只用标准库。反缩放结果或其范数超出浮点有限范围时，也应抛 ValueError。

```python
def unscale_and_clip(scaled_grad, scale, max_norm):
     # TODO: 先除以 scale，再按真实梯度的 L2 范数统一缩放
     raise NotImplementedError('请实现 unscale_and_clip')

```

### 提示

- [24,32] 除以 8 得到 [3,4]，真实范数为 5。
- 只需一个统一比例；不要分别将每个坐标截断到区间。

### 参考实现与解释

```python
import math

def unscale_and_clip(scaled_grad, scale, max_norm):
    if not scaled_grad or not math.isfinite(scale) or scale <= 0:
        raise ValueError('缩放尺度必须为正数')
    if not math.isfinite(max_norm) or max_norm < 0:
        raise ValueError('阈值必须为非负数')
    if any(not math.isfinite(x) for x in scaled_grad):
        raise ValueError('梯度必须有限')
    grad = [x / scale for x in scaled_grad]
    if any(not math.isfinite(x) for x in grad):
        raise ValueError('反缩放结果超出浮点有限范围')
    norm = math.hypot(*grad)
    if not math.isfinite(norm):
        raise ValueError('梯度范数超出浮点有限范围')
    factor = min(1.0, max_norm / norm) if norm else 1.0
    return norm, [x * factor for x in grad]

```

按坐标截断与全局范数裁剪是不同操作。本题省略实现中的极小稳定常数，以展示准确几何关系；输入被约定为有限值，真实 GradScaler 还负责检测非有限梯度和动态调整尺度。即使输入各项有限，除法和范数也可能溢出。本题显式拒绝这些情况，避免再做 inf×0 得到 NaN；这与真正 GradScaler 的检测和跳步策略不是同一个完整实现。

### 断言测试

```python
norm, grad = unscale_and_clip([24, 32], 8, 2.5)
assert abs(norm - 5) < 1e-12 and grad == [1.5, 2.0]
assert unscale_and_clip([3, 4], 1, 10) == (5.0, [3.0, 4.0])
assert unscale_and_clip([0, 0], 16, 0) == (0.0, [0.0, 0.0])
for args in [([1], 0, 1), ([1], 1, -1), ([float('inf')], 1, 1), ([1e308], 1e-308, 1.0), ([1.7e308, 1.7e308], 1, 1)]:
    try:
        unscale_and_clip(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法输入')
print('通过：反缩放顺序、阈值和零梯度')

```

## 本地 PyTorch 练习

实现 scaled_train_step(loss, optimizer, scaler, parameters, max_norm)：清零梯度、缩放反传、反缩放、全局裁剪、缩放器驱动更新，返回裁剪前范数。loss 已由前向构建；parameters 是参数列表。本题用真实 CPU GradScaler 测试更新顺序，并不代表运行过 CUDA。

```python
import torch

def scaled_train_step(loss, optimizer, scaler, parameters, max_norm):
    # TODO: 正确排列 zero_grad、backward、unscale、clip、step、update
    raise NotImplementedError('请实现 scaled_train_step')

```

### 提示

- unscale_ 在 clip_grad_norm_ 之前，且每个优化器每次更新只调用一次。
- 使用 scaler.step(optimizer) 和 scaler.update()，不要额外再调用 optimizer.step()。

### 参考实现与解释

```python
import torch

def scaled_train_step(loss, optimizer, scaler, parameters, max_norm):
    optimizer.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    norm = torch.nn.utils.clip_grad_norm_(parameters, max_norm)
    scaler.step(optimizer)
    scaler.update()
    return norm

```

测试使用 128 倍 loss scaling，能识别先裁剪再反缩放的错误：那会把真实梯度压得过小。已知梯度 [3,4] 的范数为 5，裁剪后约为 [1.5,2]，因此 SGD 更新应约为 [2.85,3.8]。这里测试的是单次更新；累积训练应把清零与 scaler 更新移到整个窗口的边界。

### 断言测试

```python
torch.manual_seed(300)
p = torch.nn.Parameter(torch.tensor([3.0, 4.0]))
q = torch.nn.Parameter(p.detach().clone())
opt = torch.optim.SGD([p], lr=0.1)
ref = torch.optim.SGD([q], lr=0.1)
scaler = torch.amp.GradScaler('cpu', init_scale=128.0)
norm = scaled_train_step(p.square().sum() / 2, opt, scaler, [p], 2.5)
ref.zero_grad(set_to_none=True)
(q.square().sum() / 2).backward()
ref_norm = torch.nn.utils.clip_grad_norm_([q], 2.5)
ref.step()
torch.testing.assert_close(norm, torch.tensor(5.0))
torch.testing.assert_close(norm, ref_norm)
torch.testing.assert_close(p, q)
torch.testing.assert_close(p, torch.tensor([2.85, 3.8]), atol=1e-6, rtol=1e-6)
assert scaler.is_enabled()
print('PyTorch 通过：真实 CPU 缩放器、反缩放后裁剪与更新')

```

## 练习：推导与分析

### autocast 与 model.half() 为什么不能互换？

autocast 在作用域内按算子和设备规则选择运算精度，常规用法保留 FP32 参数。model.half() 则直接转换模块的浮点参数和缓冲区，改变了存储类型及后续运算条件。

演示同时打印权重、预测与损失的 dtype，展示一条计算链可以混合多种精度。CPU BF16 路径只验证流程；CUDA 的精度、速度和显存必须单独测量，不能由这个打印结果推断。

还要区分参数存储与已发生的计算。把低精度输出 .float() 只转换当前值，不会重新执行前面的矩阵乘法；1.001→BF16→FP32 已经变成 1。判断是否需要局部 FP32 时，应定位信息第一次丢失的位置。

代码定位：演示 STEP 1–2 的参数放置、autocast 作用域与 dtype 输出。

- 能分别指出参数存储精度和算子计算精度。
- 能解释为什么需要打印损失和梯度的实际 dtype。

### 如果 scaler 的尺度是 128，先裁剪再 unscale 会发生什么？

裁剪看到的是放大了 128 倍的梯度。如果它触发统一缩放，再除以 128，就把真实梯度范数压到了原阈值的约 \(\frac1{128}\)，训练步长会错误缩小。

PyTorch 练习以真实梯度 [3,4]、阈值 2.5 核查更新；正确参数约为 [2.85,3.8]。累积时还须在窗口内维持同一尺度，所有反传结束后只 unscale 一次。

代码定位：scaled_train_step 中 unscale_ → clip_grad_norm_ → scaler.step 的顺序。

- 能算出示例的裁剪前范数与正确更新。
- 能说明累积窗口内 scaler.update 的位置。

## 练习：辨析与纠错

### 将所有参数手动 half 当作 AMP

这改变了参数存储和更多计算路径。先使用明确的 autocast/GradScaler 配置，检查实际 dtype 与数值边界。

### 梯度缩放能修复前向 NaN

缩放发生在 loss 之后，无法恢复已经非法的中间值。沿前向寻找第一个非有限算子。

### scaler.step 被调用就算完成更新

缩放器可能跳过 step。记录有限性、尺度、真实参数位移和学习率计数。

### CPU 路径通过即证明 CUDA 可靠

不同硬件和内核有不同精度与性能特征。保留 CPU 教学验证范围，在目标 GPU 上再检查相同测试和性能。

## 原始资料

- [PyTorch：Automatic Mixed Precision](https://docs.pytorch.org/docs/stable/amp.html)
- [PyTorch：AMP examples](https://docs.pytorch.org/docs/stable/notes/amp_examples.html)
- [PyTorch：torch.finfo 与浮点精度属性](https://docs.pytorch.org/docs/2.15/type_info.html)
- [PyTorch：Numerical accuracy](https://docs.pytorch.org/docs/2.15/notes/numerical_accuracy.html)
