# 泛化与验证

让“训练有效”成为经得起独立场景检查的结论。

泛化是模型在未用于训练、且明确指定的目标条件上保持预测或决策性能的能力。验证是用保留数据估计这种能力，并据此选择模型；它取决于训练与测试究竟在哪些因素上不同。我们先定义要推广到的变化，再讨论分组划分、容量、正则化和数据增强，最后说明有限验证结果能够支持多强的结论。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [数值精度与标准化](https://wxb1870.github.io/embodied-ml-lab/learn/numerical/)

## 泛化首先要回答“变化的是哪一项条件”

泛化能力针对的是一个指定的目标分布，而非所有可能的新输入。新轨迹、新物体和新机器人分别改变不同条件。先声明训练之外要考察什么变化，数据划分与分数才有可解释的含义。



泛化不是一个脱离数据划分的统一分数。新轨迹、同物体新姿态、新背景、新物体、新指令和新机器人，是不同程度与类型的变化。评估前先声明训练覆盖了哪些因素、测试有意改变哪些因素，才能解释分数。把同一长轨迹随机抽帧分到训练与测试，主要检查相邻帧上的插值能力，不能据此声称跨场景泛化。



用数学形式区分两类目标。对已经固定的预测器 \(f\)，部署风险为 \(R(f)=\mathbb E_{(X,Y)\sim p_{\rm deploy}}[\ell(f(X),Y)]\)，训练经验风险为 \(\widehat R_{\rm train}(f)=N^{-1}\sum_i\ell(f(x_i),y_i)\)。二者的差异可能来自有限采样，也可能来自分布本身不同。若一组测试样本独立同分布地来自部署分布，且独立于 \(f\) 的训练和选择过程，测试平均对这个固定 \(R(f)\) 是无偏估计；若损失方差有限，其方差为单样本损失方差除以测试数。相关帧、反复选模或分布不匹配分别破坏不同前提，不能只通过增加帧数修复。



模型也可能利用任务无关但与标签相关的捷径，例如固定背景、相机时间戳或采集顺序。这在随机拆分中常有效，换场景后却失效。设计数据划分时，除样本数量外还要关注独立单元与因果关系：哪些信息在部署可用，哪些只是采集流程留下的标记，哪些因素需要通过受控测试打破关联。





### 例：分组误差不变，分布权重仍会改变总体风险

1. 构造两个条件组 A、B，其期望损失分别固定为 1 和 9；这里是说明汇总含义的假设分布，不是测得的机器人结果。

2. 若采样比例为 90% 与 10%，风险为 \(0.9\times1+0.1\times9=1.8\)。

3. 若部署比例变为各 50%，同一模型的风险变为 \(0.5\times1+0.5\times9=5\)。

4. 模型和各组能力都没有改变，变化来自评价分布；因此需要同时报告分组结果与目标权重。

泛化结论依赖评估分布，不能只比较一个脱离组别与权重的总体数字。

## 按组划分，阻止轨迹与预处理泄漏

分组划分是让同一轨迹、场景或其他相关来源的样本整体进入同一个数据集合的方法。它减少训练与验证共享近重复信息的泄漏，分组层级则应对应希望检验的泛化变化。



同一轨迹内的帧高度相关，通常应作为一个组整体进入某个集合；若目标是评估新场景，分组层级还应提高到场景、物体或采集日期。分组之后再做采样、窗口切片和数据增强，避免同一原始片段的不同版本分散到多个集合。文件名不同并不证明样本独立，重复轨迹和近重复数据也需审查。



预处理同样可能泄漏。标准化、特征选择和任何从数据拟合的变换应在训练集合上拟合，再用于验证和测试。即使没有直接用测试标签，使用完整测试输入拟合统计量也改变了评估条件。将切分与预处理放进明确流程，保存组 ID 和样本清单，才能在以后复现同一评估，而不是仅保存一个随机种子。



划分之前还要防止“同源不同文件”的隐性重复，例如同一演示导出两次、相邻窗口大量重叠，或一段视频不同压缩版本。可将原始采集 ID 作为最上游组标识，使所有后处理样本继承它；仅按最终文件路径去重，无法识别这些相关来源。





### 例：帧随机拆分与轨迹拆分的区别

1. 有两条各 100 帧的轨迹，每条内部背景和状态连续。

2. 逐帧随机 80/20 会使两条轨迹都出现在训练与验证，模型可利用各轨迹的共同特征。

3. 按轨迹拆分则训练只见一条、验证见另一条，实际检验的是未见轨迹上的迁移。

选择哪种划分由目标决定，但不能用较容易的划分支持更强的泛化结论。

### 将帧数当成独立样本数

相关帧增加数据量，却未必等量增加独立条件覆盖。

检查 train/val/test 的轨迹与场景 ID 交集，并按独立组汇总结果。

## 训练曲线提供线索，不直接给出原因

训练曲线记录模型在更新数据上的误差，验证曲线记录它在保留数据上的误差。两条曲线的差异提供诊断线索，却不能单独确定原因。下面把曲线现象对应到可区分的假设，而非直接给出配置处方。



训练误差和验证误差都高，可能是容量不足、优化未收敛、标签错误、输出范围不合适或预处理不一致；训练低而验证高，提示数据泄漏之外的分布差异、过拟合或评估管线问题。曲线只能排定待验证假设，不能单凭形状宣布“增大模型”或“增加 Dropout”就是答案。



先做固定少量样本的拟合实验，检查模型能否学到明确目标；再确认验证在 eval/no_grad 下、使用相同的输入单位和正确标签。如果训练损失含增强、Dropout 或额外正则项，而验证损失没有，两条曲线可能并非同一目标，甚至验证低于训练也可合理。比较之前先统一统计口径，分别报告任务误差和正则项。



训练和验证之间还有样本难度差异。例如训练集合含强增强或故意过采样的困难状态，而验证集合较容易，验证 loss 更低可能完全合理。应在同一模型模式下用未增强训练探针与验证探针对照，再判断真正的拟合差距。





## 容量、数据与正则化之间的取舍

模型容量是函数族能够表达的复杂程度，正则化是通过目标、结构或训练过程约束拟合的办法。容量与数据覆盖共同影响欠拟合和过拟合。比较时应先确认新增表达能力解决了哪一种误差。



更大模型能够表示更复杂函数，也能更容易记忆训练数据；能否泛化取决于数据覆盖、归纳偏置、优化与正则化。模型容量小不自动保证可靠，错误的表示或过强约束同样会造成欠拟合。对同一任务，先用线性模型或小网络建立基线，再比较更复杂结构，能够判断新增参数改善了哪一类错误。



权重衰减倾向于限制参数规模，Dropout 在训练中随机删去部分响应，早停根据验证表现选择训练时刻，数据增强扩展输入变化。这些机制影响不同，不能把所有改善都归为“减少过拟合”。比较时固定训练预算与数据划分，记录是否改变了有效目标；同一验证集上反复尝试很多配置也会逐渐对验证集过拟合。





### 先建可解释基线，再增加复杂度

基线能区分“数据本身可预测”与“复杂模块带来额外收益”。

使用同一划分、预算和指标，对比小模型与改进模型，并检查失败样本类别。

## 数据增强必须保持任务所需语义

数据增强是对训练输入进行有规则的变换，以增加相关变化的覆盖。其前提是标签应保持不变，或能按同一规则同步变换。这个语义约定决定增强是否有效，不能只依据图像外观合理与否。



增强假设某种输入变化不改变标签，或者标签能够同步变换。分类中的轻微亮度变化可能合理，但动作预测中的左右翻转可能改变坐标、左右臂身份和语言“左边”的含义。图像裁剪还可能移除决定目标的证据，此时保持原标签会把不可观测监督强加给模型。



因此增强应与坐标系、相机身份、时间顺序和指令一起设计。时间打乱会破坏依赖历史的任务，独立改变多个相机可能破坏跨视角一致性。先用少量样本可视化输入与标签的共同变化，再逐项加入增强，按对应扰动条件评估收益。增强强度越大不代表越好；它可能让学习任务与部署分布越来越不一致。





### 例：左右翻转不是总能保持动作标签

1. 输入图像中目标在左侧，标签是向相机坐标左方移动。

2. 水平翻转图像后，若动作标签和“左侧”指令不变，输入与监督可能矛盾。

3. 若明确使用可变换的坐标和语言协议，可同时更新相关标签；否则不应默认使用这一增强。

增强是否有效由任务语义决定，而不是由图像看起来是否自然决定。

### 从图像分类复制增强配置到动作学习

动作和语言标签可能依赖被增强改变的几何与身份。

逐项列出增强影响的字段，检查所有标签和条件是否保持一致。

## Dropout、BatchNorm 与验证模式

Dropout 是训练时随机屏蔽部分响应的正则化机制，BatchNorm 则以指定集合的统计量变换激活。二者都有训练与评估行为差异，因此验证既要选择正确模式，也要明确是否需要记录梯度。



Dropout 训练时随机屏蔽响应并按保留概率缩放，评估时通常使用完整响应；它对每次前向的随机性与激活分布都有影响。BatchNorm 的训练统计与评估运行统计也不同。因此评估应明确 model.eval()，但它不会自动禁止求导；常规验证还可配合 no_grad 降低图记录开销。



验证过程中忘记切换模式，可能让分数依赖 Batch 组成、随机 Mask 或统计量更新；之后忘记恢复 train，又可能影响后续训练。用固定输入重复评估，能够发现不期望的随机性，但算法自身的采样策略仍可能需要多次运行。对生成策略，固定噪声适合做模型版本对照，改变噪声则用于估计真实运行波动，二者回答不同问题。





## 指标要按部署目标和独立试验单位汇总

评估指标是把预测或行为结果汇总成可比较数值的规则，独立试验单位是提供一份独立证据的对象。按帧误差与按任务成功率衡量不同问题。下面先固定部署目标与试验单位，再讨论怎样汇总。



平均 loss 可能被容易维度或大量短期预测主导，未必对应任务成功。对于具身后训练，应结合每任务结果、失败类型、执行延迟与闭环行为。离线验证用于高效筛查，不自动替代闭环评估；部署中的模型动作会改变后续观测，离线数据上的误差无法完整覆盖这种分布变化。



报告统计时说明试验次数、独立环境与随机种子。把同一次失败轨迹的许多帧当作独立失败样本，会低估不确定性；多个种子也不能替代对新场景的覆盖。对比模型最好使用相同的任务初始条件或配对协议，并保留失败而不只展示成功案例。小样本的几个百分点差异，需要通过更多独立试验判断是否稳定。



若部署任务比例与训练集不同，按全部样本微平均会更多反映高频任务；先计算每任务指标再等权平均，则回答平均任务表现。两种汇总都可报告，但不能互相替代。模型 A 的总体均值更好而少数关键任务更差时，需要根据既定目标判断，不能事后挑选有利口径。



假设在 10 个场景中各评估 100 个高度相关的连续帧，这 1000 帧不等同于 1000 个独立场景试验。要估计跨场景稳定性，应查看各场景结果与差异，并在场景层面进行合适的重采样或汇总。忽略组内相关性，会制造过于精确的置信判断；增加同场景帧数不能替代增加独立场景。





## 验证集也会被反复选择过拟合

验证集用于选择模型和配置，测试集用于在方案固定后估计表现。反复依据同一组有限分数选方案，也会对这组数据产生选择过拟合。它不需要修改标签就能发生，因此应保留独立的最终评价。



训练集用于参数更新，验证集用于选模型与配置，最终测试集在方案固定后估计表现。反复查看测试结果并据此调整，就会把测试变成新的验证集。偏差并不要求人为篡改数据；只要根据有限样本的分数选择方案，就可能同时选择了有利的评估噪声。



可以用一个简化模型看清原因：设多个配置真实分数相同，测得分数为真实分数加零均值噪声 \(\varepsilon_k\)。选择最高验证分数，相当于选择最大的噪声项；\(\mathbb E[\max_k\varepsilon_k]\ge\max_k\mathbb E[\varepsilon_k]=0\)。候选之间独立不是这个不等式的必要条件，但相关性、噪声大小和筛选方式会影响偏差程度。重复选模后再把同一个最大验证分数当作无偏表现，就是问题所在。



保留独立测试、按泛化单位做合适的分组交叉验证，并记录配置筛选范围，可以让结论对应真实的选择过程。最终测试也不能无限次回看并继续调参。每个模型使用相同测试条件有助于做配对比较，但不能替代独立于选模过程的评估。



结构消融还应控制训练与推理预算。移除模块、改变数据源或调整增强时，若更新次数、有效样本数或搜索范围同时变化，指标差异就包含额外因素。一个可检验的结论应说明在哪种未见条件、哪种预算和哪种汇总指标下成立。



泛化判断始于目标条件，终于与这些条件匹配的独立证据。模型选择、增强和正则化都应服务于这个目标；验证分数说明的是已设计的比较，而非对任意新环境的保证。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| episode_id | [N] | 每条帧样本所属的完整轨迹 |
| train_mask / validation_mask | [N] | 互斥且按轨迹分配的布尔索引 |
| metric numerator / denominator | 两个标量 | 累加误差与真正被平均的有效元素数 |

## 完整代码与精读

```python
import torch
from torch import nn

torch.manual_seed(6)
# STEP 1: 8 条轨迹，每条 5 帧
N = 40
episode_id = torch.arange(8).repeat_interleave(5)
permutation = torch.randperm(N)
naive_train, naive_val = permutation[:30], permutation[30:]
overlap = set(episode_id[naive_train].tolist()) & set(episode_id[naive_val].tolist())
print("frame split shared episodes:", sorted(overlap))

# STEP 2: 完整轨迹保持在一个集合中
train_mask = episode_id < 6
val_mask = ~train_mask
train_episodes = set(episode_id[train_mask].tolist())
val_episodes = set(episode_id[val_mask].tolist())
assert train_episodes.isdisjoint(val_episodes)
assert int(train_mask.sum()) == 30 and int(val_mask.sum()) == 10
print("group split:", sorted(train_episodes), sorted(val_episodes))

# STEP 3: eval 行为与 no_grad 分别设置
model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Dropout(0.5), nn.Linear(8, 1))
x = torch.ones(4, 4)
model.train()
first, second = model(x), model(x)
print("training outputs identical:", torch.equal(first, second))
model.eval()
with torch.no_grad():
    eval_first, eval_second = model(x), model(x)
assert torch.equal(eval_first, eval_second)
assert all(p.requires_grad for p in model.parameters())
print("evaluation outputs identical:", torch.equal(eval_first, eval_second))

```

- 第 5–12 行：随机按帧划分会让同一轨迹出现在两侧；打印交集直接检查泄漏，而不是只看样本数。
- 第 13–21 行：布尔索引由 episode_id 决定，保证轨迹互斥。要评估新物体，还需按物体或场景继续分组。
- 第 22–33 行：eval 控制层行为，no_grad 控制计算图。参数的 requires_grad 不会因此自动改变。

预期观察：按帧切分可看到共享轨迹；按轨迹切分得到训练轨迹 0–5、验证轨迹 6–7。评估模式下两次前向结果相同。

## 浏览器 Python 练习

records 是含 episode 字段的字典列表。val_episodes 指定验证轨迹，返回 (train,val)，保持各集合中原始记录的顺序，不修改输入记录。

```python
def split_by_episode(records, val_episodes):
    # TODO: 同一 episode 的所有记录必须归到同一侧
    raise NotImplementedError("请实现 split_by_episode")

```

### 提示

- 先把验证轨迹 ID 转成集合，按每条记录的归属筛选。
- 不能按记录所在的行号或帧号随机分配。

### 参考实现与解释

```python
def split_by_episode(records, val_episodes):
    selected = set(val_episodes)
    train = [row for row in records if row['episode'] not in selected]
    validation = [row for row in records if row['episode'] in selected]
    return train, validation

```

这种切分避免同轨迹泄漏，但不同轨迹仍可能共享物体和背景；泛化目标决定是否需要更高层级的分组。

### 断言测试

```python
records = [{'episode': 1, 'frame': 0}, {'episode': 2, 'frame': 0},
           {'episode': 1, 'frame': 1}, {'episode': 3, 'frame': 0},
           {'episode': 2, 'frame': 1}]
train, val = split_by_episode(records, [2])
assert [r['episode'] for r in train] == [1, 1, 3]
assert [r['frame'] for r in val] == [0, 1]
assert {r['episode'] for r in train}.isdisjoint({r['episode'] for r in val})
assert len(train) + len(val) == len(records)
assert records[1] == {'episode': 2, 'frame': 0}
assert split_by_episode([], [2]) == ([], [])
print("通过：轨迹互斥、顺序保持和输入完整性。")

```

## 本地 PyTorch 练习

实现评估函数：临时切换 eval 与 no_grad，累积全部输出元素的平方误差/元素数，返回 Python float，并恢复调用前的模型整体 training 状态。空 loader 抛出 ValueError。

```python
import torch

def evaluate_mse(model, loader):
    # TODO: 注意最后一个小 Batch 的权重和模式恢复
    raise NotImplementedError("请实现 evaluate_mse")

```

### 提示

- 累积每个 Batch 的误差平方总和与 error.numel()，最后统一相除。
- 用 try/finally 恢复 model.training，并在评估前同时设置 eval 和 no_grad。

### 参考实现与解释

```python
import torch

def evaluate_mse(model, loader):
    was_training = model.training
    model.eval()
    total, count = 0., 0
    try:
        with torch.no_grad():
            for x, y in loader:
                error = model(x) - y
                total += error.square().sum().item()
                count += error.numel()
        if count == 0:
            raise ValueError("评估数据为空")
        return total / count
    finally:
        model.train(was_training)

```

evaluate_mse 按所有有效输出元素求平均，避免最后一个较小 Batch 被过度加权。测试用 Dropout 和模式探针验证 eval、无梯度以及调用后状态恢复。本题恢复整体 training 标志；真实系统若有长期冻结的子模块模式，还需按其配置恢复。

### 断言测试

```python
from torch import nn
class Probe(nn.Module):
    def __init__(self):
        super().__init__()
        self.drop = nn.Dropout(0.9)
        self.flags = []
    def forward(self, x):
        self.flags.append((self.training, torch.is_grad_enabled()))
        return self.drop(x)
model = Probe().train()
loader = [(torch.tensor([[1.], [2.]]), torch.zeros(2, 1)),
          (torch.tensor([[3.]]), torch.zeros(1, 1))]
score = evaluate_mse(model, loader)
assert isinstance(score, float) and abs(score - 14/3) < 1e-12
assert model.training and model.flags == [(False, False), (False, False)]
model.eval()
_ = evaluate_mse(model, loader)
assert not model.training
try:
    evaluate_mse(model, [])
except ValueError:
    pass
else:
    raise AssertionError("应拒绝空评估集")
assert not model.training
print("PyTorch 测试通过：指标加权、无梯度评估与模式恢复。")

```

## 练习：推导与分析

### 按轨迹切分已经互斥，为什么仍不足以证明新场景泛化？

不同轨迹仍可能包含同一个物体、背景、站位或采集会话。轨迹互斥只排除了最低层级的相邻帧泄漏，不会自动隔离更高层级的共同因素。

应先定义泛化目标，再按物体、布局或会话等相应单位保留测试组；所有依赖数据拟合的统计量只使用训练部分。报告结果时注明评估改变了哪一种条件。

代码定位：split_by_episode 与数据质量课程的组 ID 设计。

- 能区分帧、轨迹、对象和会话层级。
- 能给出与具体泛化目标一致的切分方案。

### 为什么两个不同大小 Batch 的平均 loss 不能总是直接再平均？

这样会让两个 Batch 等权，导致较小 Batch 内每个元素权重更高。例如 10 个元素的 MSE=1、2 个元素的 MSE=4，按元素的整体 MSE 是 \(\frac{18}{12}=1.5\)，而不是 2.5。

验证代码应保留分子总和与分母总数，再统一归约。如果研究目标就是每轨迹等权，则应显式按轨迹组织指标，而不是让 Batch 大小偶然决定权重。

代码定位：evaluate_mse 中 total、count 和最后的 total/count。

- 能手算不等大小 Batch 的整体指标。
- 能说明按元素、轨迹或任务平均各自代表什么。

## 练习：辨析与纠错

### 随机抽帧后声称跨场景泛化

相邻帧和相同背景会跨集合共享信息。先按真正独立的轨迹或场景分组，再生成窗口与增强。

### 验证 loss 高就立即加正则

也可能是预处理、模式、目标或划分错误。先检查数据与实现，做固定小批次实验，再以单因素对照评估正则化。

### 增强只改图像，不改相关标签

几何、语言、相机身份和动作定义可能同时变化。为每种增强写字段变换规则，并审查可观测性。

### 测试集反复调参却仍称最终无偏测试

模型选择会逐渐利用测试信息。固定方案后保留独立测试，记录尝试范围与选模依据。

## 原始资料

- [scikit-learn：Cross-validation and grouped data](https://scikit-learn.org/stable/modules/cross_validation.html)
- [scikit-learn：Data leakage](https://scikit-learn.org/stable/common_pitfalls.html)
- [PyTorch：Dropout](https://docs.pytorch.org/docs/stable/generated/torch.nn.Dropout.html)
- [Cawley & Talbot：Over-fitting in Model Selection and Selection Bias](https://www.jmlr.org/papers/v11/cawley10a.html)
- [Goodfellow、Bengio、Courville：经验风险与总体风险](https://www.deeplearningbook.org/contents/optimization.html)
