# 状态与动作表示

坐标系、旋转、单位和归一化如何进入损失与控制。

状态表示用数值描述机器人当前可获得的信息，动作表示则定义策略输出的每个数对应哪一种命令或控制参考。位置、位移和速度即使维度相同，也有不同单位、参考系与时间含义。本章先区分目标参考和实测响应，再建立坐标、旋转、归一化与离散化的定义，最后把模型数值按原约定恢复为动作。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [数值精度与标准化](https://wxb1870.github.io/embodied-ml-lab/learn/numerical/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/)

## 区分命令、参考与实测状态

控制参考是希望控制器追踪的目标，命令是传入控制接口的量，实测状态是系统实际响应的观测。命令可以承载位置或速度参考，却不等于传感器后来测到的值。先定义这些对象，再讨论位移与速度的换算。



位置增量 \(\Delta q\) 和速度 \(\dot q\) 需要通过控制周期关联：在简单零阶保持近似下，\(\Delta q\approx\dot q\,\Delta t\)。若把每步位移直接当成速度，或把原来 0.1 秒的数据不变地放到 0.02 秒执行，物理运动尺度会改变。采样频率、命令发送频率与底层伺服频率也应分开记录，插值增加命令次数并不等于增加策略决策频率。



示教记录还可能同时保存命令与实际状态。受碰撞限制时，命令可以继续变化而实测关节几乎不动；跟踪滞后时，两者相差一个动态过程。学习命令重现的是操作者的控制意图，学习实测下一状态则是在拟合已发生结果。选择哪种标签，应由部署控制接口和期望行为决定，不能因文件里哪个字段更方便就替换。





### 动作接口是一组联合约定

单位与控制周期会改变同一数值的实际效果，控制模式又决定该数值如何被解释。

为每维列出名称、单位、坐标系、发送频率、绝对/相对语义和下游控制模式，并抽样核对命令与实测日志。

## 位置增量需要在哪个坐标系表达

坐标系用原点和坐标轴约定一个向量的数值表达。同一物理位移在工具系和基座系可以有不同坐标，转换需要相应旋转。先说明向量在哪个系中定义，再计算相对动作。



设 R 将工具坐标系的向量转换到基座坐标系。已知两时刻末端位置 \(p_t\) 与 \(p_{t+1}\) 都以基座系表达，基座系位移是 \(p_{t+1}-p_t\)；工具系位移则是 \(R_t^\top(p_{t+1}-p_t)\)。反方向恢复时乘 \(R_t\)。转置在这里等于旋转矩阵的逆，依赖 R 正交的假设，不能对任意学习出的 3×3 矩阵直接这样做。



换坐标系时，位移向量只受旋转影响，点坐标还涉及平移。把外参的平移项也加到一个增量上，会错误引入固定偏置。主动旋转物体与被动改变坐标表示在公式外观上相似，但含义不同；明确 R 的输入、输出坐标系，再写下向量流向，有助于判断应使用 R 还是 \(R^\top\)。



当机器人姿态不断变化时，同一个工具系“向前”在基座系中的方向会随之改变。因此训练时用工具系增量、推理时却按基座系执行，会出现某些姿态下正确、在其他姿态下方向错误的故障。使用非单位旋转作为测试输入，能识别被恒等矩阵样例掩盖的坐标错误。



$$
\Delta p_{\rm body}=R_t^\top(p_{t+1}-p_t),\qquad p_{t+1}=p_t+R_t\Delta p_{\rm body}
$$



### 例：绕 z 轴旋转 90° 后的位移

1. 工具系 x 轴在基座系中指向 +y，工具系 y 轴指向 −x。

2. 若基座位移是 (+0.01,0,0) 米，乘 \(R^\top\) 得到工具系位移 (0,−0.01,0) 米。

3. 再乘 R，应恢复原基座位移；若直接下发 (+0.01,0,0) 为工具系动作，方向会变成基座 +y。

恒等旋转下两个实现可能碰巧相同，非平凡姿态才有辨别力。

## 完整相对位姿：顺序不可交换

位姿由位置和朝向共同组成，相对位姿是以前一个位姿为参照描述后一个位姿的变换。参照选在物体自身还是空间固定坐标，会改变乘法顺序。下面先定义两种相对变换，再验证恢复关系。



位姿 T 由旋转 R 和平移 p 组成，属于 \(\mathrm{SE}(3)\)。身体坐标下的相对变换定义为 \(\Delta T_{\rm body}=T_t^{-1}T_{t+1}\)，于是 \(T_{t+1}=T_t\Delta T_{\rm body}\)。空间坐标下的增量可以定义为 \(\Delta T_{\rm space}=T_{t+1}T_t^{-1}\)，对应 \(T_{t+1}=\Delta T_{\rm space}T_t\)。左右乘不是记号偏好，而是增量表达坐标系的不同。



展开身体增量可见其旋转为 \(R_t^\top R_{t+1}\)、平移为 \(R_t^\top(p_{t+1}-p_t)\)。因此平移与旋转具有清楚的共同参考。若只把两组欧拉角逐元素相减，然后与工具系位移拼接，通常没有实现上述群上的相对变换；有限旋转不可交换，Euler 角还有周期、轴顺序和奇异性问题。



对于很小的运动，可用局部旋转向量或李代数坐标表示增量，但它是局部参数化，仍需说明指数映射、参考坐标与单位。把局部近似推广到大角度运动前，应通过组合恢复、逆变换和多次更新的对照检查。与机器人接口连接时，尤其要核对库采用的四元数顺序和旋转约定。



$$
\Delta T_b=T_t^{-1}T_{t+1},\quad \Delta T_s=T_{t+1}T_t^{-1},\quad T_t\Delta T_b=\Delta T_sT_t
$$



### 相对位姿不是所有分量逐项相减

有限旋转的组合顺序会改变结果，Euler 角差不能普遍替代相对旋转。

选择两个不绕同一轴的旋转，分别编码和恢复，检查是否回到同一个变换矩阵。

## 旋转表示与损失要一起设计

旋转表示是用数值参数描述三维朝向的方法，例如角度、旋转矩阵或单位四元数。单位四元数存在两组符号对应同一旋转的情形，因此参数的欧氏距离不总等于物理朝向差。表示约束与损失需要共同定义。



同一个旋转可以由 q 与 −q 两个单位四元数表示。直接计算两者欧氏 MSE，会把物理上相同的姿态当成相距很远的标签；若没有单位范数约束，网络输出还可能不对应合法旋转。可以采用一致的表示处理和符号不变的旋转误差，但规范化与符号选择在边界处仍应做数值检查。



Euler 角维度少，但存在周期跳变和参数化奇异性。旋转矩阵有九个数和正交约束；连续六维表示通常还要经过正交化才能得到旋转。不存在只根据输出维数就能决定的最佳表示，关键是数据覆盖、模型优化、解码过程以及评价的几何误差是否匹配。



对 \(R_{\rm pred}\) 与 \(R_{\rm true}\)，可用相对旋转的角度衡量姿态差，计算 arccos 前要把理论上在 [−1,1] 的输入按数值误差裁剪。不要把旋转误差的弧度与位置误差的米直接解释成同一种量。训练目标可加权，但评估时应分别报告可解释的物理指标，以免一个标量掩盖某类严重偏差。





## 标准化定义了误差的几何

动作标准化是把不同单位的动作映射到模型使用的坐标尺度。标准化后计算等权误差，相当于在物理坐标中采用某种加权度量。下面区分数值尺度、测量噪声与任务容忍度，避免把它当成中性换单位。



以位置（米）、角度（度）与无量纲夹爪命令为例，目标分别为 0.01、90、1，先人为选取参考尺度 0.01、90、1。零预测的未归一化逐维平方误差为 0.0001、8100、1，标准化后均为 1。这只说明所选尺度改变了权重，不说明三个维度的物理重要性相同。若希望保留给定的物理损失权重 \(w_i\)，应在标准化坐标中使用 \(w_i s_i^2\)。角度的周期、旋转表示和接触约束仍需在动作语义层处理。



令 \(S=\operatorname{diag}(s_1,\ldots,s_D)\)，各 \(s_d>0\)，\(z=S^{-1}(a-\mu)\)。预测在物理坐标中的误差 \(e=\hat a-a\)，映射到标准化坐标后为 \(S^{-1}e\)。因此普通平方损失变成 \(e^\top M e\)，其中 \(M=S^{-\top}S^{-1}\)；关于 \(\hat a\) 的梯度是 \(2Me\)。标准化不仅使数值接近，还规定了哪些物理误差在优化中更昂贵。



例如两个动作维的尺度为 0.01 和 0.5，原始误差都是 0.01；标准化平方误差分别为 1 和 0.0004，第一维贡献是第二维的 2500 倍。若尺度来自训练标准差，这表示按数据变化幅度衡量误差，不等于按任务容忍度衡量误差。接触敏感维度即使数据方差大，也可能需要额外任务权重；数据统计量与控制代价不能互相代替。



损失贡献与共享参数梯度还需要区分。设网络输出 \(q_\theta\)，解码为 \(\hat a=\mu+S q_\theta\)。原始坐标损失对 q 的梯度为 \(2Se\)，标准化损失对 q 的梯度为 \(2S^{-1}e\)；再左乘网络 Jacobian 的转置才是参数梯度。某维误差大不必然主导每个参数，因为该维对应的 Jacobian 可能较小、为零或与其他维贡献抵消。下面保持同一输出 q 和同一物理预测，只更换误差度量，避免将模型结构变化混入对照。



单位换算应该保持这个几何。米变毫米时，动作、均值和尺度都乘 1000，z 与标准化误差不变；只换标签而不换统计量就改变了问题。统计量还要与动作顺序、有效维和训练版本绑定，长度相同不代表每个数都作用于正确坐标。



生成模型还多一层含义：若标准化空间的初始噪声 \(Z_0\sim\mathcal N(0,I)\)，还原到物理坐标后 \(A_0=\mu+SZ_0\)，其协方差是 \(SS^\top\)。修改 s 同时改变物理坐标中的起始分布、插值路径与速度尺度，不只是把 loss 乘了权重。沿同一条路径有 \(v_a=S v_z\)；平移 \(\mu\) 不进入导数。



尺度接近零时可设明确下界，但缺失或填充维仍需要独立 Mask。反变换也必须按正向操作的逆序进行：先把标准化值还原成增量，再用指定参考位姿恢复绝对命令。裁剪与分位数截断通常不可逆，往返对照应只要求在未截断区域恢复原值。



Standardization 使用 \(\frac{a-\mu}{s}\)；映射到 [−1,1] 的 Min-Max Scaling 使用 \(\frac{2(a-\mathrm{lo})}{\mathrm{hi}-\mathrm{lo}}-1\)，分别给物理平方误差施加 \(\frac{1}{s^2}\) 和 \(\frac{4}{(\mathrm{hi}-\mathrm{lo})^2}\) 的权重。分位数范围能够减小少数极值对尺度的影响，但裁剪会丢失尾部信息。常数维需要约定尺度下界和是否监督，缺失维需要独立 Mask；不同机器人混合时，先统一单位、动作含义和有效维，再决定使用公共统计量或已知机器人条件下的统计量。所有数据驱动统计仅在训练划分的有效元素上拟合，参见 [示教数据与采样](#/learn/data-quality)。



Padding 中即使有 NaN，也不能先计算平方误差再乘零 Mask，因为 NaN×0 仍为 NaN。有效位置应在危险运算前选择，分母按展开后的有效元素计数；没有有效监督的批次需要显式跳过或报错。下面同时检验无效元素不影响结果，而有效位置的非有限数值会被拒绝。



$$
\begin{aligned}L_{\rm raw}&=e^Te,&\nabla_q L_{\rm raw}&=2Se\\L_{\rm norm}&=e^TS^{-T}S^{-1}e,&\nabla_q L_{\rm norm}&=2S^{-1}e\\\nabla_\theta L&=J_{q_\theta}^T\nabla_q L,&\operatorname{Cov}(A_0)&=SS^T\end{aligned}
$$

```python
import torch

torch.set_default_dtype(torch.float64)
scale = torch.tensor([0.01, 90., 1.])
target = scale.clone()
q = torch.zeros(3, requires_grad=True)  # normalized network output
decoded = scale*q
error = decoded-target
raw_parts = error.square()
normalized_parts = (error/scale).square()
g_raw, = torch.autograd.grad(raw_parts.sum(), q, retain_graph=True)
g_norm, = torch.autograd.grad(normalized_parts.sum(), q)
torch.testing.assert_close(g_raw, -2*scale.square())
torch.testing.assert_close(g_norm, torch.full((3,), -2.))
torch.testing.assert_close(normalized_parts, torch.ones(3))
unit = torch.tensor([1000., 1., 1.])
torch.testing.assert_close((error.detach()*unit/(scale*unit)).square(), normalized_parts.detach())

def masked_mse(prediction, target, valid):
    selected = valid.expand_as(prediction)
    if not selected.any():
        raise ValueError("no valid target")
    p, y = prediction[selected], target[selected]
    if not (torch.isfinite(p).all() and torch.isfinite(y).all()):
        raise ValueError("nonfinite valid value")
    return (p-y).square().mean()

prediction = torch.tensor([[[1., 2.], [float('nan'), float('nan')]]], requires_grad=True)
labels = torch.tensor([[[0., 0.], [float('nan'), float('nan')]]])
valid = torch.tensor([[[True], [False]]])
loss = masked_mse(prediction, labels, valid)
gradient, = torch.autograd.grad(loss, prediction)
torch.testing.assert_close(loss, torch.tensor(2.5))
torch.testing.assert_close(gradient, torch.tensor([[[1., 2.], [0., 0.]]]))
try:
    masked_mse(prediction, labels, torch.ones_like(valid))
except ValueError:
    pass
else:
    raise AssertionError("valid NaN must be rejected")
print("raw per-coordinate loss:", raw_parts.detach().tolist())
print("normalized per-coordinate loss:", normalized_parts.detach().tolist())
print("gradient w.r.t. the same q:", g_raw.tolist(), g_norm.tolist())
print("invalid NaN excluded; valid NaN rejected")
```

两种损失共享同一 q、同一解码尺度与同一物理预测；对照的唯一变化是误差度量。Autograd 分别核对 \(2Se\) 和 \(2S^{-1}e\)，而不是把物理坐标梯度与网络输出梯度混为一谈。最后在平方运算前选取有效元素，检验无效 NaN 的梯度为零。这里给定参考尺度用于解释几何，真实统计量应按训练集协议拟合。



### 例：单位变化与损失尺度

1. 同一个位置误差为 0.01 米，也等于 10 毫米。

2. 未标准化 MSE 从 0.0001 变成 100，数值放大 10⁶ 倍，但物理误差没有变化。

3. 若均值、尺度与标签同时按同一单位转换，标准化后的误差应保持一致。

比较训练损失前先核对单位与尺度；只调任务权重可能是在补偿接口不一致。

### 把归一化做成可复查的模型状态

统计量、动作顺序与有效维一起定义生成空间，不能在在线小批次中重新拟合。

用固定物理样本验证编码值、反变换结果和单位；检查训练统计来源以及 checkpoint 中保存的数值。

## 动作分箱、词表映射与解码误差

动作分箱是把连续范围划成有限区间、用类别索引表示每个动作值的方法；解码再把索引映射回代表值。它建立连续动作与词表之间的接口，同时引入量化误差。先固定边界与中心约定，再分析误差。



离散动作模型需要把连续标签变成类别。一个基础方案是先把各维动作归一化，再将区间 [ℓ,u] 划为 N 个等宽区间，以区间索引 k 作为离散类别，解码时取区间中心。这里明确使用 N+1 个边界、N 个中心；不同实现对“分箱数”和端点的约定可能不同，迁移权重时必须连同原 Tokenizer 一起读取。



分箱索引与模型词表 ID 是两个对象。下面的教学实现使用 \(i=i_0+k\) 将动作类别映射到一个独立 ID 段；实际模型也可能使用反向映射或复用词表末端。训练标签、输出头允许的 ID 和解码器必须严格互逆。若逐维编码动作块，还要固定时间优先或维度优先的展开顺序，并单独处理特殊 Token 与 Padding，不能把它们解码成动作。



对区间内的标量，中心解码的绝对量化误差不超过半个区间宽度。越界值会先被裁剪，发生饱和，此时相对原值的总误差不再受这一上界约束。若物理动作通过 \(a_{\rm phys}=\mu+s a\) 恢复，对应的区间内误差上界为 \(\frac{|s|\Delta}{2}\)；因此分箱数、动作尺度和控制精度需要一起检查。这个上界只描述正确类别的编码误差，并不保证模型预测错类别时仍有同样精度。



逐时刻、逐维分箱通常需要 \(H D\) 个动作 Token。它不等于 FAST：FAST 对动作序列使用离散余弦变换和压缩编码，Token 数量及解码依赖具有不同含义。下面只实现均匀标量分箱，用来检查端点、词表范围与误差界，不模拟某个模型的完整 Tokenizer。



$$
\Delta=\frac{u-\ell}{N},\qquad k(a)=\min\!\left(N-1,\left\lfloor\frac{\operatorname{clip}(a,\ell,u)-\ell}{\Delta}\right\rfloor\right),\qquad \hat a=\ell+\left(k+\tfrac12\right)\Delta,\qquad |a-\hat a|\le\frac{\Delta}{2}\quad(a\in[\ell,u]).
$$

```python
import math

# 教学约定：N 个等宽区间、N 个中心；动作 Token 使用独立连续 ID 段。
def grid(n_bins=8, lo=-1.0, hi=1.0, token_start=1000):
    if type(n_bins) is not int or n_bins < 1:
        raise ValueError("n_bins must be a positive integer")
    if not (math.isfinite(lo) and math.isfinite(hi) and lo < hi):
        raise ValueError("bounds must be finite and ordered")
    if type(token_start) is not int or token_start < 0:
        raise ValueError("token_start must be a nonnegative integer")
    return (hi - lo) / n_bins


def encode_action(values, n_bins=8, lo=-1.0, hi=1.0, token_start=1000):
    width = grid(n_bins, lo, hi, token_start)
    ids = []
    for value in values:
        value = float(value)
        if not math.isfinite(value):
            raise ValueError("action must be finite")
        clipped = min(hi, max(lo, value))
        # 上端点 hi 的商为 N，必须截到最后一个有效区间。
        index = min(n_bins - 1, math.floor((clipped - lo) / width))
        ids.append(token_start + index)
    return ids


def decode_action(ids, n_bins=8, lo=-1.0, hi=1.0, token_start=1000):
    width = grid(n_bins, lo, hi, token_start)
    values = []
    for token_id in ids:
        if type(token_id) is not int or not token_start <= token_id < token_start + n_bins:
            raise ValueError("token ID is outside the action vocabulary")
        index = token_id - token_start
        values.append(lo + (index + 0.5) * width)
    return values


values = [-1.0, -0.73, -0.01, 0.0, 0.41, 1.0]
ids = encode_action(values)
reconstructed = decode_action(ids)
width = grid()
assert ids[0] == 1000 and ids[-1] == 1007
assert max(abs(a - b) for a, b in zip(values, reconstructed)) <= width / 2 + 1e-12
assert encode_action(reconstructed) == ids

# 饱和只保留边界区间，不能恢复原始的越界幅度。
saturated = decode_action(encode_action([3.0]))[0]
assert saturated == 0.875
assert abs(3.0 - saturated) > width / 2
try:
    decode_action([999])
    raise AssertionError("invalid token ID was accepted")
except ValueError:
    pass
print("quantization checks passed", ids, reconstructed)

```

encode_action 先裁剪，再计算区间索引，最后映射到词表 ID；decode_action 先检查 ID 范围，再恢复区间中心。断言分别覆盖两端点、区间内误差界、中心重编码、越界饱和以及无效 ID。实际接入模型时，还必须保持归一化统计量、展开顺序与特殊 Token 约定一致。



## 动作块的参考锚点决定恢复公式

参考锚点是相对动作恢复为目标时所依据的姿态。整块动作可以共享一个观测锚点，也可以逐步相对前一个目标。它们形成不同标签与恢复规则，尤其影响延迟后丢弃前缀的处理。



相对动作序列至少有两种常见含义：每一步都相对当前观测时刻的同一姿态，或每一步相对前一个目标姿态。前者恢复时一直使用同一个锚点，后者需要依次组合；二者不仅训练标签不同，遇到推理延迟和丢弃动作前缀时的处理也不同。必须在数据构造与执行器之间明确约定。



一维例子中，当前位置为 10，未来绝对位置为 11、13、16。固定锚点增量是 1、3、6，逐步增量是 1、2、3。若把前者累加，会得到 11、14、20；若把后者都加到原始位置，只得到 11、12、13。形状相同，结果却系统性错误；仅检查输出范围无法发现这种差异。



如果执行时使用最新实测状态替换原来锚点，要说明这是重新定义参考还是控制补偿。变化的锚点会改变整段计划的几何含义，不一定等价于“更闭环”。对旋转动作，同样的问题通过矩阵连乘体现，更需要保留每段动作的原始参考与时间来源。





## 用分层对照验证动作语义

动作接口包含形状、单位、坐标、归一化和时间参考，多项错误还可能在一次往返变换中相互抵消。因此需要让不同层次的测试使用独立的物理参照。验证的目的，是知道某个通过的检查排除了哪些错误，而不是用一个断言代替整个接口审查。



第一层检查形状、有限值、单位和有效位；第二层检查标准化往返；第三层使用已知非平凡位姿验证坐标变换与组合；第四层比较数据管线与部署管线对同一样本的结果。每层解决不同错误，不能因为一个 assert_close 通过就认为整个接口正确。



往返测试本身也有局限：编码与解码如果共享同一个错误单位或错误关节顺序，它们仍可互相抵消。需要额外的具有已知物理含义的样例，例如基座沿一个轴的小位移、某个关节的已知角度变化以及夹爪状态切换。先在受控条件验证命令含义，再将生成模型接入。



旋转矩阵与合成动作可以隔离验证坐标映射和损失。交换动作维、调换 R 与 \(R^\top\)、只把标签的米改为毫米，会分别破坏维度语义、变换方向与尺度一致性。碰撞、接触与跟踪稳定性没有进入这些计算，需要相应系统模型与实验。



动作向量的意义由对象、单位、坐标系、时间间隔和参考锚点共同定义，归一化或分箱只是在这套意义上再作编码。只有编码与解码沿同一约定对应，模型输出才具有可解释的控制含义。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| R | [3,3] 或 [B,3,3] | 工具坐标到基座坐标的旋转矩阵 |
| action | [B,H,D] | 明确了语义和单位的连续动作 |
| mean / std / valid_dim | [D] | 训练统计量和动作维度掩码 |

## 完整代码与精读

```python
import torch

torch.manual_seed(7)

# STEP 1: 将基座系位置变化表达为工具系变化
R = torch.tensor([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
p_now = torch.tensor([0.5, 0.2, 0.3])
p_next = torch.tensor([0.51, 0.2, 0.3])
delta_base = p_next - p_now
delta_tool = R.T @ delta_base
reconstructed_position = p_now + R @ delta_tool
torch.testing.assert_close(reconstructed_position, p_next)

# STEP 2: 第四维是统一动作空间中的填充维度，不是夹爪
train_actions = torch.tensor([[0.01, 0.03, -0.01, 0.],
                              [0.03, 0.01,  0.01, 0.],
                              [0.02, 0.02,  0.00, 0.]])
valid_dim = torch.tensor([True, True, True, False])
mean = train_actions.mean(dim=0)
std = train_actions.std(dim=0, unbiased=False).clamp_min(1e-6)

# STEP 3: 编码与解码使用同一统计量
normalized = (train_actions - mean) / std
normalized = torch.where(valid_dim, normalized, torch.zeros_like(normalized))
recovered = normalized * std + mean
torch.testing.assert_close(recovered[:, valid_dim], train_actions[:, valid_dim])

# STEP 4: 检查动作 mask 在损失中的分母
prediction = normalized + torch.tensor([0.1, 0.2, 0.3, float('nan')])
mask = valid_dim.expand_as(prediction)
loss = (prediction[mask] - normalized[mask]).square().mean()
print('base delta:', delta_base.tolist())
print('tool delta:', delta_tool.tolist())
print('round trip passed; masked loss:', round(loss.item(), 6))
torch.testing.assert_close(loss, torch.tensor((0.01 + 0.04 + 0.09) / 3))

```

- 第 5–13 行：R 的列是工具各坐标轴在基座系中的方向。转置把基座系向量转到工具系；矩阵相乘的方向不能仅凭习惯决定。
- 第 14–21 行：统计量只来自训练数据。最后一维是人为填充，必须单独标记；真实夹爪信号应按机器人接口编码。
- 第 22–27 行：先归一化、再使用同一份统计量反归一化。往返一致性是数据接口最有价值的检查之一。
- 第 28–35 行：有效维度掩码按样本广播，先选择有效值，再相减、平方并求 mean，分母因此是广播后的有效标量数。无效预测即使为 NaN，也不进入损失；先平方再乘零不能隔离 NaN。

预期观察：工具系增量约为 [0, -0.01, 0]，归一化往返检查通过，带维度 Mask 的损失约为 0.046667。

## 浏览器 Python 练习

实现 body_delta(p_now, p_next, R)。R 将工具系向量转换到基座系；函数应返回工具系中的相对位移。只使用 Python 列表和循环。

```python
def body_delta(p_now, p_next, R):
    # TODO: delta_body = R 的转置乘以位置差
    raise NotImplementedError

```

### 提示

- 先得到基座系中的 p_next − p_now。
- 输出的第 i 项取 R 的第 i 列，与位移做内积。

### 参考实现与解释

```python
def body_delta(p_now, p_next, R):
    if len(p_now) != 3 or len(p_next) != 3 or len(R) != 3 or any(len(row) != 3 for row in R):
        raise ValueError('expected 3D position and 3x3 matrix')
    delta = [p_next[i] - p_now[i] for i in range(3)]
    return [sum(R[j][i] * delta[j] for j in range(3)) for i in range(3)]

```

绕 z 轴九十度时，基座系 +x 对应工具系 −y。用这个可画图验证的小例子，比只看变量名更容易发现转置方向错误。

### 断言测试

```python
I = [[1,0,0],[0,1,0],[0,0,1]]
R = [[0,-1,0],[1,0,0],[0,0,1]]
assert body_delta([0,0,0], [1,2,3], I) == [1,2,3]
assert body_delta([0,0,0], [1,0,0], R) == [0,-1,0]
assert body_delta([1,2,3], [1,2,3], R) == [0,0,0]
try:
    body_delta([0], [1], [[1]])
    raise AssertionError('维度错误应报错')
except ValueError:
    pass
print('4 组坐标变换检查通过。')

```

## 本地 PyTorch 练习

实现 normalize_actions(a, mean, std, valid_dim)。a 为浮点 [B,H,D]，均值、标准差为同设备同类型 [D]，valid_dim 为同设备 bool [D]。只对有效维标准化，填充维输出零；无效动作与统计量允许为 NaN，有效值必须有限。用 1e-6 限制标准差下界，负标准差报错。实现应让无效维对输入与统计量的梯度均为零。

```python
import torch

def normalize_actions(a, mean, std, valid_dim):
    # TODO: 核对语义和维度；先选择有效坐标，再标准化并写回零张量。
    raise NotImplementedError

```

### 提示

- 先核对 [B,H,D]、[D]、bool 类型及设备，再用布尔索引选择动作末轴和相应统计量。
- 只在有效坐标上执行减法和除法，再写入 zeros_like(a)；无效 NaN 从未进入算术运算，反向梯度也应为零。

### 参考实现与解释

```python
import torch

def normalize_actions(a, mean, std, valid_dim):
    if (a.ndim != 3 or not a.is_floating_point()
            or any(v.shape != (a.shape[-1],) for v in (mean, std, valid_dim))
            or valid_dim.dtype != torch.bool
            or any(v.device != a.device for v in (mean, std, valid_dim))
            or mean.dtype != a.dtype or std.dtype != a.dtype):
        raise ValueError('expected floating [B,H,D], matching [D] statistics and bool mask')
    if bool((std < 0).any()):
        raise ValueError('negative standard deviation')
    values, mu, scale = a[..., valid_dim], mean[valid_dim], std[valid_dim]
    if not all(bool(torch.isfinite(v).all()) for v in (values, mu, scale)):
        raise ValueError('nonfinite value in a valid action dimension')
    result = torch.zeros_like(a)
    result[..., valid_dim] = (values-mu)/scale.clamp_min(1e-6)
    return result

```

归一化连接训练坐标与物理坐标。布尔索引选出相同有效维后，均值和尺度沿 [B,H] 广播；结果写回原形状的零张量，保留无效维的明确占位。测试同时对动作、均值和尺度求导，验证有效坐标的解析梯度以及无效坐标的零梯度。仅在除法完成后 where 掉 NaN，可能在统计量的反向传播中留下 NaN×0；先选择才真正移除这条无效计算路径。1e-6 只是明示的除零约定，不代表常数维具有学习价值。反归一化往返还需配合独立的单位、动作顺序与坐标检查。

### 断言测试

```python
a = torch.tensor([[[3., 5., float('nan')], [1., 9., float('nan')]]],
                 dtype=torch.float64, requires_grad=True)
m = torch.tensor([1., 1., float('nan')], dtype=torch.float64, requires_grad=True)
s = torch.tensor([2., 4., float('nan')], dtype=torch.float64, requires_grad=True)
v = torch.tensor([True, True, False])
z = normalize_actions(a, m, s, v)
torch.testing.assert_close(z, torch.tensor([[[1.,1.,0.],[0.,2.,0.]]], dtype=a.dtype))
torch.testing.assert_close(z[...,v]*s[v]+m[v], a[...,v])
ga, gm, gs = torch.autograd.grad(z.square().sum(), (a, m, s))
torch.testing.assert_close(ga, torch.tensor([[[1.,.5,0.],[0.,1.,0.]]], dtype=a.dtype))
torch.testing.assert_close(gm, torch.tensor([-1.,-1.5,0.], dtype=a.dtype))
torch.testing.assert_close(gs, torch.tensor([-1.,-2.5,0.], dtype=a.dtype))
assert all(torch.isfinite(g).all() for g in (ga, gm, gs))

# A zero scale is a declared finite convention, not an invalid value.
constant = normalize_actions(torch.zeros(1,1,1), torch.zeros(1), torch.zeros(1),
                             torch.ones(1, dtype=torch.bool))
torch.testing.assert_close(constant, torch.zeros_like(constant))
for bad_a, bad_m, bad_s, bad_v in [
        (a.detach(), m.detach(), torch.tensor([-1.,4.,0.], dtype=a.dtype), v),
        (a.detach(), m.detach(), s.detach(), torch.ones(3, dtype=torch.bool)),
        (a.detach(), m.detach(), s.detach(), v.float()),
        (a.detach()[0], m.detach(), s.detach(), v)]:
    try:
        normalize_actions(bad_a, bad_m, bad_s, bad_v)
    except ValueError:
        pass
    else:
        raise AssertionError('invalid shape, mask, scale or valid NaN accepted')
print('passed: valid-axis encoding, round trip, analytic gradients and NaN isolation')

```

## 练习：推导与分析

### R 表示工具系到基座系旋转，预测头输出工具系 Δp。为什么直接 p_next=p_now+Δp 可能错？

p_now 用基座坐标表达，而 Δp 的三个分量沿工具坐标轴定义。必须先用 R 将增量旋转到基座系，得到 p_next=p_now+R@Δp。反过来，已知两个基座位置时，工具系增量是 R.T@(p_next−p_now)。

构造绕 z 轴九十度的 R 作为可手算检查：基座 +x 对应工具 −y。再做正反变换往返。完整姿态的相对变换还要固定左乘或右乘约定，不能把逐维欧拉角差当作通用旋转差。

代码定位：code.source 中 delta_tool=R.T@delta_base 与 reconstructed_position。

- 明确每个向量和 R 的参考坐标系。
- 用九十度例子说明转置方向。

### 模型形状和归一化往返检查都正确，真机动作仍整体偏大十倍，还有哪些检查？

使用同一份错误统计量做编码和解码也可以通过往返检查。应检查训练与部署加载的统计量身份、米和厘米等单位、绝对目标与增量或速度定义、实际命令周期，以及动作通道顺序。用一个已知物理位移的样本跟踪整个处理链。

应比较原始标签、归一化标签、模型输出、反归一化命令和控制器收到的目标。不要在最终输出上随意乘 0.1 掩盖问题；缩放只有在属于动作接口设计且与训练约定一致时，才适合作为显式变换保存。

代码定位：normalize_actions、统计量加载位置与动作解码之后的命令日志。

- 指出往返一致不等于物理语义正确。
- 至少核对单位、参考定义和统计量身份。

### 把动作标准差加倍，为什么不能只理解为“网络输入更小了”？

同一物理误差的标准化平方损失变为原来的四分之一，对应物理坐标梯度也缩小。按数据方差缩放是一种度量选择，不自动等于任务容忍度。

若仍从标准化空间的 N(0,I) 生成，物理起始噪声标准差加倍、方差变成四倍，概率路径和速度尺度也改变。只有一致地变换整个模型与路径，才能把两套坐标解释为同一过程。

代码定位：标准化误差、速度反变换与初始噪声的协方差。

- 写出误差权重 \(\frac{1}{s^2}\)。
- 说明起始噪声与生成路径也受尺度影响。

## 练习：辨析与纠错

### 把位置增量直接当速度命令

检查 Δt 与控制模式，必要时按协议转换。改变执行频率后，应重新验证物理速度与动作语义。

### 在单位旋转上测试坐标变换

R=I 会掩盖方向错误。加入 90° 旋转和组合变换，用已知方向检查 R 与 \(R^\top\)。

### 逐项减 Euler 角来得到任意相对姿态

角度周期和有限旋转非交换会破坏这一解释。先构造相对旋转，再按明确参数化编码。

### 相对动作总是逐步累加

固定观测锚点与前一目标锚点是不同标签。对短序列写出绝对值，手算一次恢复过程。

### 归一化往返成功就证明单位正确

共同的错误也能自洽。使用独立已知物理样本，并核对动作顺序、统计来源和真实控制接口。

## 原始资料

- [OpenPI：归一化统计量](https://github.com/Physical-Intelligence/openpi/blob/main/docs/norm_stats.md)
- [旋转表示的连续性研究](https://arxiv.org/abs/1812.07035)
- [OpenPI 开源训练与动作变换入口](https://github.com/Physical-Intelligence/openpi)
- [Modern Robotics · 齐次变换与左右乘坐标约定](https://modernrobotics.northwestern.edu/nu-gm-book-resource/3-3-1-homogeneous-transformation-matrices/)
- [Lipman et al. · Flow Matching：路径、向量场与条件回归](https://arxiv.org/abs/2210.02747)
- [OpenVLA 官方 ActionTokenizer · 分箱、词表 ID 与解码端点](https://github.com/openvla/openvla/blob/main/prismatic/vla/action_tokenizer.py)
- [FAST 原论文 · 基于序列压缩的动作 Tokenization](https://arxiv.org/abs/2501.09747)
