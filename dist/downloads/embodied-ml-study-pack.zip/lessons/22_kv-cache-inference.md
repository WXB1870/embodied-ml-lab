# KV Cache 与增量计算

缓存成立条件、全局位置与非方形注意力 Mask。

自回归生成每次只增加少量新内容，却可能反复计算整个历史。缓存的价值在于复用确实不会变化的中间表示，而能否复用必须由计算依赖证明。本章承接因果注意力与位置编码，从完整前向和增量前向的等价性推导逐层 K/V 缓存，再分析位置偏移、批处理与条件变化。目标是理解缓存怎样节省计算，并能用数值对照辨认哪些表示已经失效。

前置知识：[注意力：匹配、聚合与梯度](https://wxb1870.github.io/embodied-ml-lab/learn/attention/) · [Transformer：注意力、残差与序列建模](https://wxb1870.github.io/embodied-ml-lab/learn/transformer/) · [Embedding 与位置编码](https://wxb1870.github.io/embodied-ml-lab/learn/embeddings/) · [分词、自回归与标签对齐](https://wxb1870.github.io/embodied-ml-lab/learn/tokenizer-autoregressive/)

## 历史表示不变的条件

重复计算能够被删除，前提是删除的部分与完整计算给出相同结果。因果注意力恰好提供了这样的依赖结构：新位置出现后，过去位置不需要读取它，因此可以逐层证明历史表示保持不变。



缓存成立的条件是函数依赖不变。因果 Transformer 的第 i 个位置只能读取不晚于 i 的位置，所以后来追加 token 时，旧位置在每一层的隐藏状态及其 K/V 都不会改变。可以对层数作归纳：旧输入和位置相同，第一层读取的集合相同，输出相同；因此下一层也相同。这是缓存正确性的依据，而不是“推理通常可以存中间结果”。



每一层都要保存自己的 K/V，因为它们来自不同层的输入和投影。只存第一层、把最后一层缓存复制给所有层，都不等价。旧 Q 通常不需要缓存：后续只需计算新位置的输出，新查询读取旧 K/V 即可。缓存也不等于保存 Attention 权重，因为权重还依赖当前新查询。



这段推理要求权重、位置规则和影响前向的状态保持一致。全序列双向注意力中，旧 token 可以读取新 token，追加内容后旧表示会改变，不能直接套用自回归缓存。训练态 Dropout 的随机性、跨序列统计的归一化或改变了前缀可见性的 Mask，也会破坏朴素复用的条件。





## Prefill 与 Decode

证明历史可复用后，推理自然分成处理已有上下文和处理新位置两个阶段。把两阶段的张量形状与工作量分开，才能看清缓存节省了哪些运算，以及哪些读取成本仍随历史增长。



Prefill 一次处理已知上下文，生成各层的前缀缓存；Decode 只投影新 token，并将它的 K/V 沿序列轴加入缓存。对于单个新查询，打分形状从完整序列的 [T,T] 变为 [1,T]。旧 token 的 QKV、FFN 和层间计算也无需再做，节省的不仅是一次矩阵乘法。



缓存没有消除新查询读取历史的成本。标准密集注意力每个新查询仍需访问全部历史 K/V，长度增加时带宽和计算都会增加。连续生成许多 token 的总注意力工作量仍会累积；“单步不再对所有旧 token 重算”和“整段生成变成常数复杂度”是不同命题。



实际瓶颈还受 Batch、缓存精度、显存布局和内核影响。FlashAttention 类内核减少中间注意力矩阵的存储与访存，但不是让历史信息不占空间；GQA 减少 KV 头数，也不是减少查询头数。测延迟应分别记录 Prefill、首 token 和稳定 Decode，而不只报告整个调用平均耗时。





## 非方形 Mask 与全局位置

新增位置在当前调用中从零编号，却不是整段序列的起点。缓存把局部查询索引和全局时间位置分离开来，因果条件必须在后者上定义，否则合法上下文会被无声屏蔽。



假设连续历史有 P 个 token，本轮增加 Q 个，则查询轴长 Q、键轴长 P+Q。新查询的局部行号 i 对应绝对位置 \(P+i\)，允许条件是 \(j\le P+i\)。把一个 [Q,P+Q] 矩阵直接取普通下三角，会把第一个新查询误当作序列起点；形状完全正确，读到的上下文却被大幅截断。



单 token Decode 中，当前 token 已加入 K/V 后，该查询通常可以读取所有有效历史和自身；此时长度为一的查询不代表只能读一个键。若使用滑动窗口、跨样本打包或有 padding，还须把因果条件与窗口、样本身份、有效键条件合并。不能拿历史长度推断所有键都有效。



PyTorch SDPA 的布尔 Mask 用 True 表示允许读取；其非方形 is_causal 行为不能凭“它会理解缓存”来假定。教学实现明确构造绝对位置比较，再传 attn_mask，并令 `is_causal=False`，避免把缓存偏移隐含在另一个标志中。



$$
M_{ij}=\mathbf{1}[j\le P+i],\quad M\in\{0,1\}^{Q\times(P+Q)}
$$



### 例：三个历史位置与两个新增位置

1. 缓存已有位置 \(0,1,2\)，本轮查询对应位置 \(3,4\)，键对应位置 \(0,1,2,3,4\)。

2. 第一个查询允许读取前四个键，第二个查询允许读取全部五个键，因此允许矩阵为 \(\begin{bmatrix}1&1&1&1&0\\1&1&1&1&1\end{bmatrix}\)。

3. 直接对 \(2\times5\) 的数组取普通下三角，会得到第一行只读键 0、第二行只读键 0 和 1，丢失了合法历史。

因果关系比较的是全局位置；矩阵局部行号只描述这一次调用。

### 把非方形 is_causal 当成带历史偏移的 Mask

因果内核需要遵循具体 API 的对齐定义；缓存长度不会自动成为所有接口的查询位置。错误遮罩仍能输出有限数值，很难从 loss 或 shape 单独发现。

打印 \(P=3\)、\(Q=2\) 的 allowed，逐行对照绝对位置；再用完整前向核对分块输出。

## 逻辑位置、存储位置与 Padding

连续、无填充的例子中，位置编号与缓存下标恰好一致，这种巧合容易被当成普遍规则。批内长度不同或位置编码参与计算后，需要分别维护语义位置、存储槽位和有效性。



位置编码必须与完整序列前向一致。可学习绝对位置表的新 token 应从历史对应的位置继续；RoPE 则要给新 Q/K 使用正确位置旋转。若缓存中已经保存旋转后的 K，下一轮不能把旧 K 重新按新位置旋转一次。旋转发生在哪一层、保存的是旋转前还是旋转后张量，都应成为接口约定。



缓存槽位是物理存储索引，position_ids 是模型位置语义，padding mask 是哪些键可读取。简单无 padding 的连续示例里它们都能用历史长度推导，真实批处理却可能不同。例如两个样本有效长度不同，即使缓存张量宽度相同，下一有效 token 的位置也未必相同；不能把整批宽度直接当成所有样本的语义位置。



示例代码有意限定从零开始、无 padding、无窗口的连续上下文，并检查 start 等于缓存长度。这是清晰的教学边界，不是通用推理引擎。扩展到左 padding、滑动窗口、beam 重排或多会话时，应分别维护有效位、样本归属和绝对位置，测试后再放宽这个断言。





## KV 头数与缓存容量

缓存通过保存激活换取较少的重复计算，因此也形成可预测的内存开销。先按层和头数统计需要保存的元素，再讨论预分配和复用，才能避免把逻辑长度、容量与实际峰值混为一谈。



普通未压缩缓存同时保存 K 与 V，元素数为 2×层数×Batch×KV 头数×长度×头宽度。查询头数 \(H_q\) 与 \(H_{\mathrm{kv}}\) 在 GQA 中可以不同，直接使用 \(H_q\) 会高估缓存；低比特缓存还需考虑尺度与元数据，不能只乘一个理想位宽就当作峰值显存。



动态实现反复 torch.cat 简单直观，但每次追加可能复制旧内容并产生临时分配。预分配缓存按位置写入可以减少复制，代价是管理容量、有效长度和重用生命周期。预分配到最大长度后，尚未写入的槽位必须不可见，缓存张量的容量不能直接作为逻辑历史长度。



多请求服务中的关键错误常是复用了另一请求的缓存，或 Batch 重排时只重排输入而没重排缓存。缓存应与请求身份、模型版本和条件摘要绑定；这些元数据的检查比单纯检查 shape 更能发现内容串用。



$$
\mathrm{bytes}=2LBH_{\rm kv}Td_{\rm head}\,b_{\rm elem}
$$



### 例：估算一个普通 BF16 KV Cache

1. 取 \(L=24\)、\(B=2\)、\(H_{\mathrm{kv}}=8\)、\(T=2048\)、每头 64 维，BF16 每元素 2 字节。

2. K 与 V 合计 \(2\times24\times2\times8\times2048\times64\times2=201326592\) 字节，即 192 MiB。

3. 若查询头为 32 而 KV 头仍为 8，不能把结果乘四；若 Batch 加倍，普通缓存主体则加倍。

这是缓存主体的精确元素预算，实际峰值还要加上模型、临时张量和分配器开销。

## 固定前缀与动态动作区

动作生成中也存在重复条件，但变化的对象往往是整块噪声动作，而非序列末尾的新符号。沿每一层追踪固定条件和动态状态的依赖，才能决定哪些前缀表示仍满足缓存的等价条件。



条件动作模型可能在一个动作块的多次去噪或流积分中重复使用同一组图像与语言。若前缀内部表示只依赖固定前缀，并且前缀不读取变化中的动作后缀，各层前缀 K/V 可以预先计算。动作查询每轮仍需重新计算，因为动作状态和生成时间改变了它们的输入。



这里的复用与文本逐 token 追加不同：固定前缀通常保持相同，动作后缀可能每轮整体替换，而不是无限追加到历史。把上一轮动作 K/V 也留在缓存里，会让新一轮读到不属于当前状态的旧动作，甚至不断增长序列。需要明确缓存返回值中哪一段是永久前缀、哪一段只是当前迭代。



新图像、新指令、预处理方式变化、权重更新、位置或 Mask 规则变化，都应重新判断缓存。尤其是时间调制如果也作用于前缀，即使图像没变，时间变了也可能使前缀表示变化。是否能缓存要沿真实计算图追踪依赖，不能仅按“视觉 token”这个名称决定。





### 画出固定条件与每轮变化量的依赖

复用前缀必须保证该前缀在所有层都不依赖变化的动作或时间。只有第一层输入相同并不足够，后续层仍可能通过注意力读取后缀。

保持图像和语言不变，单独改变动作/生成时间，比较各层待缓存 K/V；再改变图像，确认缓存会被重建。

## 分块与整段前向的等价性

缓存是一种等价改写，应先有一个完整前向作为参照。改变分块方式而保持输入、参数和可见性不变，可以把位置与拼接错误从模型能力问题中隔离出来。



建立一个关闭 Dropout 的完整因果前向作为参考，然后以 3+2+1、1+1+…和整段等不同分块方式计算，拼接输出并逐元素 assert_close。比较连续 logits 或隐藏状态更敏感；只比较 argmax token 可能让数值已经出错但排名暂时没变的问题漏过。



允许由不同内核和计算顺序引起的小误差，但应先用小模型、float32 或 float64 的教学实现定位逻辑。若第一块正确而第二块开始偏离，优先查位置偏移、非方形 Mask 和拼接轴；若每次调用都随机变，先查 eval、Dropout 与数据增强，而不是扩大容差。



负向测试同样必要：改变前缀内容后，用旧缓存得到的结果应与重新计算有差异；新会话应清空缓存；相同样本换 Batch 顺序后，缓存也要对应重排。一个通过“正常路径”测试的缓存系统，仍可能在请求生命周期变化时出错。



从单层 Mask 对照进一步到完整多层语言模型，可复用 [Transformer 的 tiny-causal-lm](#/learn/transformer?tab=code&anchor=demo-tiny-causal-lm)：同一参数下比较不同分块的 logits、逐层缓存和梯度。固定视觉语言前缀与变化动作块的区别，则在 [VLA 架构](#/learn/vla-architecture?tab=theory)沿真实两参数组计算链继续展开。





## 训练缓存与梯度寿命

前向数值相同并不足以保证训练等价，因为缓存还携带或切断了计算图。最后把推理复用与训练梯度分开，判断一个保存的表示在参数更新之后是否仍可作为当前计算的一部分。



推理缓存通常在 no_grad 或 inference_mode 中构造，适合不需要反向传播的场景。训练时直接拿上一次调用 detach 后的前缀缓存，会切断当前损失通向前缀编码器的梯度；使用未 detach 的历史计算图又可能延长图的生命周期，并在多次 backward 时遇到释放或版本问题。



冻结前缀编码器且输入完全固定时，可离线缓存特征，但还要考虑训练态统计、增强、位置编码和后续可训练投影的位置。若投影层需要更新，缓存它之前的固定特征与缓存它之后的过期 K/V 不等价。特征缓存应记录生成配置和模型版本。



缓存练习验证推理时的函数等价。阅读实际框架时，逐项确认 use_cache 的适用阶段、梯度检查点与缓存是否兼容，以及训练入口是否主动禁用缓存。优化前先证明复用的值在所需前向和反向意义上都没有改变。





### 推理正确的缓存不自动适用于微调

过期参数产生的 K/V 会改变当前模型函数，detach 又可能把需要的梯度截断；这两种错误不能靠输出 shape 判断。

分别列出被冻结和可训练模块，确认缓存位于哪一侧；用不缓存参考核对当前 loss 与可训练参数梯度。

## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 新 Q/K/V | [B,H,Q,d] | Q 可以大于一，代表本轮新 token 块。 |
| 旧缓存 | [B,H,P,d] | 每层分别保存；示例的 Q/K/V 头数相同。 |
| 合并 K/V | [B,H,P+Q,d] | 只追加本轮新键和值。 |
| allowed | [Q,P+Q] | 以绝对位置判断可见性，True 表示允许。 |

## 完整代码与精读

```python
# [1] 单层教学注意力，显式使用绝对位置
import math
import torch
from torch import nn
torch.manual_seed(38)

class CachedAttention(nn.Module):
    def __init__(self, dim=8, heads=2):
        super().__init__()
        self.dim, self.heads = dim, heads
        self.position = nn.Embedding(64, dim)
        self.qkv = nn.Linear(dim, 3*dim, bias=False)
        self.proj = nn.Linear(dim, dim, bias=False)

    def forward(self, x, past=None, start=0):
        batch, count, dim = x.shape
        past_len = 0 if past is None else past[0].shape[-2]
        if start != past_len:
            raise ValueError("本例位置起点必须等于历史缓存长度")
        positions = torch.arange(start, start+count)
        z = x + self.position(positions)[None]
        q, k, v = self.qkv(z).chunk(3, dim=-1)
        split = lambda a: a.reshape(batch,count,self.heads,dim//self.heads).transpose(1,2)
        q, k, v = map(split, (q,k,v))
        if past is not None:
            k, v = torch.cat((past[0],k),-2), torch.cat((past[1],v),-2)
        allowed = torch.arange(k.shape[-2])[None] <= positions[:,None]
        scores = (q @ k.transpose(-1,-2))/math.sqrt(q.shape[-1])
        values = scores.masked_fill(~allowed,float("-inf")).softmax(-1) @ v
        merged = values.transpose(1,2).reshape(batch,count,dim)
        return self.proj(merged), (k,v), allowed

# [2] 使用 3、2、1 的分块，检验非方形 Mask
model = CachedAttention().eval()
x = torch.randn(1,6,8)
with torch.no_grad():
    full, _, _ = model(x)
    a, prefix_cache, _ = model(x[:,:3])
    b, cache, mask = model(x[:,3:5], prefix_cache, start=3)
    c, _, _ = model(x[:,5:], cache, start=5)
    torch.testing.assert_close(torch.cat((a,b,c),1), full, atol=1e-6, rtol=1e-5)
    expected_mask = torch.tensor([[1,1,1,1,0],[1,1,1,1,1]],dtype=torch.bool)
    assert torch.equal(mask,expected_mask)

# [3] 修改前缀后复用旧缓存，会偏离重新计算的结果
    changed = x.clone()
    changed[:,0,0] += 4.0
    fresh, _, _ = model(changed)
    stale, _, _ = model(changed[:,3:],prefix_cache,start=3)
    assert not torch.allclose(stale, fresh[:,3:])
print("增量 Mask:", mask.tolist())
print("完整与分块一致；改变前缀后旧缓存失效")

```

- 第 1–32 行：缓存仅保存 K/V；start 显式控制位置，且与本例连续缓存长度一致。每轮只追加新位置。
- 第 33–44 行：第二块的查询位置是 3、4，键位置是 0…4。其允许矩阵不能用无偏移的普通下三角替代。
- 第 45–52 行：同样的后缀配上错误的旧前缀缓存会产生不同结果；这验证缓存依赖条件，而不只是依赖长度。

预期观察：非方形 Mask 为 [[True,True,True,True,False],[True,True,True,True,True]]；完整与分块输出一致，前缀改变后旧缓存被证明无效。

## 浏览器 Python 练习

实现 incremental_allowed(past_len,new_len)。返回 new_len 行、past_len+new_len 列的布尔矩阵，第 i 个查询位置为 `past_len+i`；负长度和 `new_len=0` 应抛出 ValueError。

```python
def incremental_allowed(past_len, new_len):
    # TODO: 使用绝对查询位置决定每行可读的键
    raise NotImplementedError("请完成增量 Mask")

```

### 提示

- 不要写 `key<=query`；query 是新块的局部索引，真实位置还要加 past_len。
- 当 `new_len=1` 时，新查询应该能读取全部历史以及自身。

### 参考实现与解释

```python
def incremental_allowed(past_len, new_len):
    if past_len < 0 or new_len <= 0:
        raise ValueError("历史长度需非负，新长度需为正")
    return [[key <= past_len+query for key in range(past_len+new_len)]
            for query in range(new_len)]

```

普通 tril 在 [Q,P+Q] 上沿左上角构造三角形，会忽略历史偏移。这个练习把局部索引与绝对位置明确分开。

### 断言测试

```python
assert incremental_allowed(3,2) == [[True,True,True,True,False],[True,True,True,True,True]]
assert incremental_allowed(0,3) == [[True,False,False],[True,True,False],[True,True,True]]
assert incremental_allowed(5,1) == [[True]*6]
try:
    incremental_allowed(2,0)
    raise AssertionError("空增量应被拒绝")
except ValueError:
    pass
print("通过：历史偏移、分块和单 token Decode")

```

## 本地 PyTorch 练习

实现 cached_attention。q/k_new/v_new 已经包含正确的上游位置处理；函数追加缓存并构造非方形因果 Mask。position_offset 必须等于本例历史长度。返回 (输出,(合并K,合并V))。

```python
import math
import torch

def cached_attention(q, k_new, v_new, past=None, position_offset=0):
    # TODO: 合并历史，使用绝对位置构造 Mask
    raise NotImplementedError("请实现缓存注意力")

```

### 提示

- 缓存沿倒数第二个序列轴拼接，不能沿头轴或通道轴拼接。
- 第二块输出使用 \(Q=2\)、\(K=5\) 的矩阵；先生成绝对位置，再比较 `key<=query`。

### 参考实现与解释

```python
import math
import torch

def cached_attention(q, k_new, v_new, past=None, position_offset=0):
    past_len = 0 if past is None else past[0].shape[-2]
    if position_offset != past_len:
        raise ValueError("位置偏移与历史长度不一致")
    k = k_new if past is None else torch.cat((past[0],k_new),dim=-2)
    v = v_new if past is None else torch.cat((past[1],v_new),dim=-2)
    query_positions = position_offset + torch.arange(q.shape[-2],device=q.device)
    key_positions = torch.arange(k.shape[-2],device=q.device)
    allowed = key_positions[None] <= query_positions[:,None]
    scores = (q @ k.transpose(-1,-2))/math.sqrt(q.shape[-1])
    weights = scores.masked_fill(~allowed,float("-inf")).softmax(-1)
    return weights @ v, (k,v)

```

测试把完整长度五的前向拆成三加二，并核对所有输出。仅测试单 token、无历史或输出 shape，容易漏掉非方形 Mask 和位置重置错误。

### 断言测试

```python
torch.manual_seed(38)
q, k, v = [torch.randn(1,2,5,4) for _ in range(3)]
expected = torch.nn.functional.scaled_dot_product_attention(q,k,v,is_causal=True)
first, cache = cached_attention(q[:,:,:3],k[:,:,:3],v[:,:,:3])
second, final_cache = cached_attention(q[:,:,3:],k[:,:,3:],v[:,:,3:],cache,3)
torch.testing.assert_close(torch.cat((first,second),-2),expected,atol=1e-6,rtol=1e-5)
assert final_cache[0].shape[-2] == 5
try:
    cached_attention(q[:,:,3:],k[:,:,3:],v[:,:,3:],cache,0)
    raise AssertionError("错误位置偏移应被拒绝")
except ValueError:
    pass
print("通过：缓存追加、非方形因果性、位置检查与完整前向一致性")

```

## 练习：推导与分析

### 历史缓存有 3 个 token，本轮处理 2 个新 token，为什么不能直接对一个 2×5 矩阵调用 tril？正确的两行是什么？

新查询的绝对位置是 3 和 4。第一行允许键 0、1、2、3，禁止键 4；第二行允许键 0…4。因此两行为 [真,真,真,真,假] 与 [真,真,真,真,真]。

无偏移 tril 把新查询当成位置 0、1，只开放左上角，错误屏蔽大部分历史。除了 Mask，新 token 的位置编码也必须与完整序列使用同样的绝对位置，不能只修 Mask 而重置位置。

代码定位：检查 allowed.shape==(2,5)，打印 query_positions，并与完整前向作分块对照。

- 写出两行正确可见性。
- 同时指出 Mask 偏移与位置编码都要处理。

### 一次动作去噪中可以复用图像/语言前缀缓存，为什么下一次收到新图像后通常不能继续使用它？变化的动作 token 能否一起固定缓存？

前缀缓存是由特定图像、指令、权重和可见性规则计算的中间结果。若一个动作块内部这些条件保持不变，且前缀不读取变化的动作后缀，复用可以保持相同函数；新图像改变了条件，旧结果通常就失效。

动作噪声状态和生成时间会逐步改变，对应后缀表示也需要更新，不能直接固定复用。缓存生命周期应以真实依赖是否改变为依据，而不是仅根据序列长度、机器人任务名称或张量形状。

代码定位：追踪 prefix_embs、past_key_values 与每轮 suffix_embs 的输入依赖；修改前缀后比较 fresh 与 stale。

- 说明固定前缀可复用的独立性条件。
- 列出观测或指令变化导致失效。
- 明确变化的动作/时间条件不能当固定前缀复用。

## 练习：辨析与纠错

### 只验证生成 token，不比较 logits

argmax 可以在错误数值下仍保持不变。先在 eval 下比较连续输出，再检查完整生成行为；误差从哪个分块开始能帮助定位。

### 把缓存容量当成有效历史长度

预分配的未写入槽位不能被注意力读取。维护逻辑长度和有效位，并用填满异常值的未写入区域做遮罩测试。

### 每轮重新旋转已缓存的 RoPE K

若 K 已按其绝对位置旋转，重复旋转会改变相似度。明确缓存保存的表示，并与完整前向比较每层 K。

### 动作去噪把旧动作不断追加

固定前缀复用不意味着变化后缀也永久保留。每轮重建动作 K/V，并检查缓存长度没有随积分步数无意增长。

### 微调更新权重后仍用旧缓存

缓存由具体参数和条件产生；更新相关权重后旧值不再代表当前模型。冻结特征缓存与训练态 KV 复用需分别设计。

## 原始资料

- [Hugging Face：How caching works](https://huggingface.co/docs/transformers/main/cache_explanation)
- [OpenPI：PyTorch sample_actions / denoise_step](https://github.com/Physical-Intelligence/openpi/blob/main/src/openpi/models_pytorch/pi0_pytorch.py)
- [PyTorch：scaled_dot_product_attention](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html)
