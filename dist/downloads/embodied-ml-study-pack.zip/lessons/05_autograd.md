# PyTorch 自动微分与计算图

准确回答：哪个参数在训练，梯度经过了哪里？

手推链式法则说明了正确梯度应该是什么，自动微分负责在真实程序中高效计算它。难点在于程序的求导关系、张量存储和优化器成员并不总是一致：一个参数可以允许求导，却没有参与当前目标或没有被更新。本章沿前向建图、反向累积和参数更新追踪这三种关系，解释冻结、断图、模式切换与高阶导数。代码实验将数学依赖转化为可检查的训练行为。

前置知识：[线性代数与矩阵求导](https://wxb1870.github.io/embodied-ml-lab/learn/matrix-grad/)

## 前向建图、反向求导、优化器更新是三个动作

一个训练步由程序依次完成，但数学上它包含建图、求导和更新三个不同动作。先分清它们各自读写什么状态，后面看到 loss 正常却参数不动时，才能判断应该检查哪一个环节。



在默认梯度模式下，输入中有需要梯度的张量时，可微运算会记录反向所需的信息，形成动态计算图。loss.backward() 从输出种子开始，按逆序应用局部导数，将叶子参数的贡献累积到 .grad。optimizer.step() 再读取这些梯度与内部状态执行更新。一个参数 requires_grad=True，只说明允许追踪它，不说明它已参与当前损失，也不说明优化器会更新它。



训练时通常每次重新前向产生一张新图，反向结束后不再需要的中间保存量可释放。Python 变量还引用着输出，不等于整张反向图中的所有缓存都可再次使用。重复对同一前向图 backward 需要明确理由；通常应重新前向，而不是把 retain_graph=True 添加到所有训练步。保留图会增加内存生命周期，也不能修复已经 detach 的依赖关系。





## 叶子、非叶子与梯度累积

反向传播会经过许多中间变量，却不需要为每个变量长期保留一份梯度。理解叶子与非叶子的区别，再结合默认的梯度累积行为，可以避免把未保存的中间梯度误判为断图。



用户直接创建且需要梯度的张量，或者 nn.Parameter，通常是求导图中的叶子；运算产生的中间张量是非叶子。默认情况下，非叶子的梯度会用于继续传播，但不会保存在它自己的 .grad 中。想检查某个激活可调用 retain_grad 或使用合适的 hook。看到中间 Tensor.grad 为 None，不能立即判断这条路径没有参与反向。



叶子的 .grad 默认累积而非覆盖，因此连续两次对独立图 backward 会把两个梯度相加。优化器的 zero_grad 只清理其管理的参数；若某些参数未进入优化器但仍求导，它们可能积累旧梯度。set_to_none=True 与写入零也有语义差异：未参与反向的参数可以保持 None，许多优化器会跳过它；有零梯度的参数仍可能受到已有动量或权重衰减影响。





### 把 grad=None 与全零梯度混为一谈

None 可能表示未参与图、被冻结或未保留中间梯度；零则是一个实际计算出的数值。

在 backward 后、zero_grad 前检查叶子参数，并标记 requires_grad、优化器成员和 grad 状态。

## 冻结参数不等于切断它对输入的导数

冻结权重经常用于后训练，但停止更新某组参数，并不意味着整个算子都可以退出求导。是否仍需要该模块的输入梯度，取决于它前面是否存在可训练变换，必须沿完整依赖链判断。



考虑 x→可训练 Adapter→冻结模块→损失。将冻结模块参数设为 requires_grad=False，只是不求这些参数的梯度；为了更新前面的 Adapter，仍需计算冻结模块输出对输入的导数。若把冻结模块前向包进 no_grad，或者把输出 detach，通向 Adapter 的路径会被截断。能否停止记录，取决于前面是否还有要训练的量。



如果冻结编码器直接接收固定数据，前面没有可训练处理，且后续只训练下游模块，那么在编码器内部使用 no_grad 可以是合理的效率选择。它的输出仍能作为常量输入参与后续可训练 Linear 的参数求导。两种结构都属于“冻结骨干”，但计算图的依赖关系不同；应从 loss 向前检查每一个需要更新的参数，不能仅按模块名称决定梯度上下文。





### 例：冻结乘数仍要把梯度传给输入

1. 设可训练 \(x=2\)、冻结常数 \(w=3\)，\(y=wx\)，\(L=\frac{y^2}{2}\)。

2. 前向 \(y=6\)；\(\frac{\partial L}{\partial x}=yw=18\)。w 不更新，但乘法仍参与对 x 的求导。

3. 如果在计算 y 时断图，则 L 无法通过这条路径给 x 传回 18。

冻结一个参数与删除整个算子的反向关系并不等价。

### 先画可训练参数的位置，再放 no_grad

冻结区内部的输入 Jacobian 可能仍是上游训练所必需的。

用最小标量或小 Linear 链复现结构，分别核对被冻结参数与前置 Adapter 的梯度。

## eval、no_grad 与 inference_mode 分别控制什么

模型的训练或评估行为，与程序是否记录梯度，是两个相互独立的状态。验证、冻结特征提取和输入敏感度分析需要不同组合，只有把各个开关的作用范围分开，才能选择正确模式。



model.eval() 改变具有训练/评估行为差异的模块，例如 Dropout 和 BatchNorm，但不会关闭自动微分。torch.no_grad() 不记录其中运算的反向图，但不会自动把 Dropout 切换成评估行为。做常规验证通常同时设置 eval 和 no_grad，二者解决不同问题；验证完成后恢复 train，避免后续训练一直使用评估行为。



inference_mode 进一步减少梯度跟踪开销，但其创建的张量在之后参与需记录的 autograd 运算时有更严格限制。不能因为名称叫“推理”就无条件套到“冻结编码器+可训练下游”的训练环节。先使用语义清楚的 no_grad，再根据实际边界验证更强模式是否适用。对需要输入梯度的可视化、敏感度分析或优化任务，eval 下仍应保留梯度模式。





### 例：四种模式组合

1. train + 默认梯度：Dropout 随机，通常用于训练。

2. eval + 默认梯度：Dropout 关闭，但仍能对输入或参数求导，适合某些敏感度分析。

3. train + no_grad：仍可能有随机 Dropout，且不记录反向。

4. eval + no_grad：普通确定性模块的评估配置，但算法中其他随机采样仍需另行固定。

模式开关控制不同维度，不应把其中一个当作另一个的别名。

## detach、clone、item 和重新构造 Tensor 的区别

记录日志、保存快照和组合可微输出都会创建新对象，但新对象与原张量之间可能保留不同关系。数据是否共享、数值是否复制以及求导路径是否存在，需要分别检查，不能根据函数名称推测。



detach 返回与原张量共享数据但不连接原求导图的张量；clone 通常复制数据并保留求导路径；detach().clone() 同时断图并获得独立副本。若对 detach 后的别名做原地修改，原张量的数值也可能改变。需要记录快照时应区分“我只想不反传”与“我也想避免后续修改影响这份数据”。



item 将单元素 Tensor 变成 Python 数值，适合日志，但把这个值重新包装为 Tensor 并不能恢复原图。类似地，用 torch.tensor(existing_tensor) 重新构造一般会切断原有求导联系，不能用 requires_grad=True 再接回旧路径。对于可微组合应使用 stack、cat 和张量运算；对于指标与日志则应主动 detach，避免长期保存带图对象。





### 重新 requires_grad 不能修复已经断开的历史

新叶子可以继续参与后续求导，但它不知道旧张量是怎样算出来的。

从 loss.grad_fn 向前审查 item、detach、NumPy 转换和重新构造 Tensor 的位置。

## 原地操作与无效计算为何会破坏反向

局部导数有时依赖前向时的原始数值，也要求被求值的运算处于合法定义域。改写保存值或先执行非法分支后再屏蔽，都可能破坏这些条件；正确修复应恢复计算依赖，而不是绕过错误检查。



autograd 可能保存前向值供 backward 使用。若之后原地改写这些值，反向需要的数据就与原计算不一致，框架通常借助版本检查报告错误。不能用 .data 绕过检查来“修复”，那可能让梯度悄悄错误。优先采用非原地表达式，只有在理解别名与保存需求之后再考虑原地优化。



对非法运算先计算再 Mask 也可能有问题。例如先除以零，再选择不包含该结果的输出，反向仍可能经过非法的局部导数并产生 NaN。应在运算前筛选有效输入，或构造只在合法定义域内执行的计算。torch.where 的两个分支往往都已先被求值，因此它不等于 Python 的惰性条件执行；安全分母与有效索引需要明确设计。





## 保留原图与对导数继续求导

多次使用同一次前向，与把导数本身作为新的可微函数，是两种不同需求。前者关心原图能否再次遍历，后者关心求导过程是否被记录；二阶信息和梯度惩罚正好揭示两者的区别。



autograd.grad 返回指定输入的导数，默认不把结果累积到参数 .grad。retain_graph=True 保留本次反向使用的原图，便于从同一前向再次求导；create_graph=True 则记录求导运算，建立“导数作为函数”的计算图。前者解决原图是否被释放，后者决定能否沿求导结果继续传播，两者不是更省内存与更费内存的同义开关。



例如 \(f(x)=x^3\)，第一次导数 \(g(x)=3x^2\)，第二次为 \(6x\)。若第一次只保留原图，返回的数值 \(3x^2\) 通常没有供继续求导的图；再次从原来的 f 求导仍然只会得到一阶导数。用 create_graph=True 得到 g 后，再对 g 求导，才是在计算二阶信息。普通训练只需要一阶梯度时，不必为此额外建图。



这个区别会直接影响梯度惩罚。若 \(g(\theta,x)=\frac{\partial f_\theta(x)}{\partial x}\)，并把 \(\lVert g\rVert_2^2\) 加入训练目标，它对 \(\theta\) 的导数经过 \(\frac{\partial^2 f}{\partial\theta\,\partial x}\)。必须让输入梯度的计算本身可微；把 g.detach() 后再平方，数值看似相同，却不再通过这一项训练 \(\theta\)。某些线性函数的高阶导为零，求导结果也未必依赖所有输入，应按数学依赖处理未使用项。



对共享同一前向图的多个任务，可以加权求和后一次 backward，也可按需多次求导并保留原图。分开记录梯度时，参数集合与展平顺序必须相同，未使用参数保留零占位。allow_unused 只允许表示没有依赖的输入，不证明它们得到了训练；非标量输出还必须给出与目标一致的 VJP 种子。



```python
import torch

x = torch.tensor(2., dtype=torch.float64, requires_grad=True)
(first,) = torch.autograd.grad(x**3, x, create_graph=True)
(second,) = torch.autograd.grad(first, x)
assert first.item() == 12. and second.item() == 12.

z = torch.tensor(2., dtype=torch.float64, requires_grad=True)
(value_only,) = torch.autograd.grad(z**3, z, retain_graph=True)
assert not value_only.requires_grad
print("first:", first.item(), "second:", second.item())
```

在 \(x=2\) 处，一阶和二阶导数碰巧都为 12，但来源不同。后半段只保留原图，返回的一阶导数没有继续求导所需的依赖；把 retain_graph 改成 create_graph 后再比较其 requires_grad。



## 从计算图到真实参数更新的验证

理解单个开关后，需要把它们放回一次完整训练步验证。依次检查图连接、叶子梯度和实际参数位移，才能证明预期模块确实受到监督，也能发现只查看 requires_grad 无法识别的问题。



用固定输入和参数快照做一次完整训练步：先清零，执行前向，确认 loss 有正确 grad_fn，再 backward，检查目标参数的 grad 是否有限，最后 step 并比较参数差。冻结参数应保持不变，需要更新的模块应实际出现在优化器中；合法的零梯度应有可解释原因，不能把所有未变化都视为程序故障。



演示冻结中间模块并训练其前面的 Adapter，专门区分“冻结权重”和“停止反传”。还应通过反例把冻结模块放进 no_grad，观察前置参数失去梯度的现象。这样的对照比查看一行 requires_grad 标记更有说服力，因为它验证的是完整计算依赖。



最后检查日志不会保留图：记录 loss.item()、detach 后的小统计量或独立 CPU 副本，不要不断把带图的 GPU 输出加入列表。重复几次后内存持续增长时，优先查对象引用、保留图和 hook，而不是立刻把问题归因于模型越来越大。



需要把本课 API 对应到完整计算图时，可回到 [MLP 的同一 17 参数案例](#/learn/mlp?tab=theory&anchor=section-backpropagation)：X、W₁、b₁、W₂、b₂ 五组导数由显式 VJP 与 autograd 逐项比较；真正的 SGD 只更新四组模型参数。中间量 retain_grad 与叶子 .grad 的区别，应以该计算图中的变量角色解释，而不是将所有 Tensor 都视作需要学习的参数。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| input | [B,4] | 不要求对原始数据求梯度 |
| adapter output | [B,4] | 来自可训练 Adapter，必须保留后续梯度路径 |
| frozen weight | [4,4] | 参数不更新，函数对输入的导数仍然可能需要 |
| head output | [B,1] | 产生用于训练的预测 |

## 完整代码与精读

```python
import torch
from torch import nn

torch.manual_seed(0)
# STEP 1: Adapter -> 冻结骨干 -> 预测头
adapter = nn.Linear(4, 4, bias=False)
backbone = nn.Linear(4, 4, bias=False)
head = nn.Linear(4, 1, bias=False)
with torch.no_grad():
    backbone.weight.copy_(torch.eye(4))
backbone.requires_grad_(False)
x = torch.randn(6, 4)
target = torch.randn(6, 1)

# STEP 2: 冻结权重，但保留对骨干输入的导数
prediction = head(backbone(adapter(x)))
loss = (prediction - target).square().mean()
loss.backward()
assert adapter.weight.grad is not None
assert backbone.weight.grad is None
assert head.weight.grad is not None
print("adapter grad norm:", adapter.weight.grad.norm().item())

# STEP 3: 故意 detach，观察前面的训练路径消失
for module in (adapter, backbone, head):
    module.zero_grad(set_to_none=True)
feature = backbone(adapter(x)).detach()
(head(feature) - target).square().mean().backward()
assert adapter.weight.grad is None
assert head.weight.grad is not None
print("after detach, adapter grad:", adapter.weight.grad)
adapter.eval()
assert adapter.weight.requires_grad
print("eval does not freeze parameters:", adapter.weight.requires_grad)

```

- 第 5–14 行：使用单位权重让梯度通路更直观；冻结只作用于骨干参数。
- 第 15–23 行：骨干参与前向计算，且它的输入依赖 Adapter，因此反向仍须经过该模块。
- 第 24–34 行：detach 断开特征与 Adapter 的关系；eval 只切换模块运行模式，不修改 requires_grad。

预期观察：第一轮 Adapter 有非零梯度、骨干梯度为 None；detach 后 Adapter 梯度为 None；eval 后参数仍然 requires_grad=True。

## 浏览器 Python 练习

模型预测 y=v*w*u*x，损失 0.5*(y-target)^2。w 冻结，u 和 v 可训练。返回 (du,dv)，不要把 w 冻结误解为对 u 的梯度也为零。

```python
def chain_grads(x, u, w, v, target):
    # TODO: 保留冻结因子 w 在链式法则中的乘法作用
    raise NotImplementedError("请实现 chain_grads")

```

### 提示

- 先算预测误差，再分别计算预测对 u 和 v 的导数。
- 不返回 dw，只表示不更新 w，不表示删除前向中的乘法。

### 参考实现与解释

```python
def chain_grads(x, u, w, v, target):
    error = v * w * u * x - target
    du = error * v * w * x
    dv = error * w * u * x
    return du, dv

```

在真实网络中，“冻结 w”与“detach 中间值”会产生不同的图结构；后者才会截断通往上游参数的路径。

### 断言测试

```python
assert chain_grads(2., 3., 4., 5., 1.) == (4760., 2856.)
assert chain_grads(2., 3., 4., 5., 120.) == (0., 0.)
assert chain_grads(2., 3., 0., 5., 1.) == (0., 0.)
print("通过：冻结参数的数值仍参与其他参数的梯度。")

```

## 本地 PyTorch 练习

冻结 backbone 参数，然后计算 head(backbone(adapter(x)))。必须使 Adapter 与 Head 都可获得梯度。禁止 detach 或把骨干前向放进 no_grad。

```python
import torch
from torch import nn

def forward_frozen(adapter, backbone, head, x):
    # TODO: 冻结参数，同时保留必要的计算图
    raise NotImplementedError("请实现 forward_frozen")

```

### 提示

- 只将 backbone 的参数 requires_grad 设为 False。
- 前向保持 adapter→backbone→head 的张量链，不使用 detach 或 no_grad 包围骨干。

### 参考实现与解释

```python
import torch
from torch import nn

def forward_frozen(adapter, backbone, head, x):
    backbone.requires_grad_(False)
    return head(backbone(adapter(x)))

```

冻结骨干参数只是不计算其参数梯度；当输入来自可训练 Adapter，仍需要骨干对输入的导数。测试让骨干成为单位映射，明确验证 Adapter 和 Head 均有非零梯度、骨干没有参数梯度。

### 断言测试

```python
torch.manual_seed(2)
adapter = nn.Linear(3, 3, bias=False)
backbone = nn.Linear(3, 3, bias=False)
head = nn.Linear(3, 1, bias=False)
with torch.no_grad():
    backbone.weight.copy_(torch.eye(3))
x = torch.randn(4, 3)
output = forward_frozen(adapter, backbone, head, x)
output.square().sum().backward()
assert all(not p.requires_grad for p in backbone.parameters())
assert all(p.grad is None for p in backbone.parameters())
assert adapter.weight.grad is not None and adapter.weight.grad.norm() > 0
assert head.weight.grad is not None and head.weight.grad.norm() > 0
print("PyTorch 测试通过：冻结与梯度路径均正确。")

```

## 练习：推导与分析

### 冻结骨干后为什么仍可能需要保存它的反向图？

如果骨干前面有可训练 Adapter，损失对 Adapter 的导数必须乘上骨干对输入的 Jacobian。骨干权重不更新，并不代表它对输入的函数关系可以从链式法则中删掉。

若原始输入不需要梯度，且只训练骨干后面的头，才可能不需要这段图。演示对比正常冻结与 detach：前者 Adapter 有梯度，后者断开这条路径。

代码定位：forward_frozen；演示 STEP 2 和 STEP 3 的 Adapter.grad 检查。

- 能画出需要梯度的实际路径。
- 能说明何时 no_grad 合理、何时会错误切断训练。

### requires_grad=True 且存在梯度，能否证明某个模块已经被更新？

不能。参数还必须在优化器参数组中，step 必须真正执行，学习率和有效梯度也不能让更新为零。旧梯度、优化器状态与实际训练分支也会影响结果。

检查应包括参数身份、requires_grad、grad 是否存在及有限、优化器成员关系，以及更新前后参数差。eval 只影响特定层的行为，不能替代上述验证。

代码定位：计算图与梯度检查；training-diagnostics 课程中的参数审计提供完整实现。

- 能列出梯度之外还需检查的条件。
- 能区分 eval、冻结和 optimizer.step 的职责。

## 练习：辨析与纠错

### 冻结中间模块就套 no_grad

若其前面有可训练 Adapter，仍需通过冻结模块反传。画出参数依赖并用最小例子核对前置参数梯度。

### 验证时只用 no_grad 而不 eval

Dropout 或 BatchNorm 仍可能保持训练行为。评估配置需同时考虑模块模式与求导模式，并在结束后正确恢复。

### 用 retain_graph=True 修复所有 backward 报错

它只保留当前图，不能恢复 detach，也可能导致内存增加。普通训练每步重新前向；多次求导才按需保留。

### 先非法计算，再用 Mask 掩盖

非法局部导数可能污染 backward，NaN×0 也不会消失。应在除法、对数等运算之前保证定义域合法。

## 原始资料

- [PyTorch：Autograd mechanics](https://docs.pytorch.org/docs/stable/notes/autograd.html)
- [PyTorch：Understanding leaf and non-leaf tensors](https://docs.pytorch.org/tutorials/beginner/understanding_leaf_vs_nonleaf_tutorial.html)
- [PyTorch：torch.autograd.grad 的 create_graph 与 retain_graph](https://docs.pytorch.org/docs/2.15/generated/torch.autograd.grad.html)
