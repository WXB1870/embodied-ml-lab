# 动作执行与延迟

动作年龄、队列、任务版本与重规划衔接。

模型生成的动作序列只有在正确时刻被执行，才对应训练时预测的行为。推理与控制以不同频率运行，观测传输、排队和计算又会使一部分预测在到达前已经过期。本章把动作块展开到统一时间轴，分析结果选择、队列覆盖和计划替换，再说明参考限幅能够约束什么。这样可以把模型计算、执行协议与闭环表现之间的差异定位到具体环节。

前置知识：[时间对齐与动作块](https://wxb1870.github.io/embodied-ml-lab/learn/action-chunk/) · [状态与动作表示](https://wxb1870.github.io/embodied-ml-lab/learn/action-representation/) · [部分观测与记忆](https://wxb1870.github.io/embodied-ml-lab/learn/partial-observability/)

## 把端到端延迟拆到可测量的时刻

控制器执行动作时，模型依据的观测已经经历了一段处理过程。将这段过程标记为可测量的时间点，才能区分计算慢、传输慢和结果过旧，并确定实际需要优化的环节。



至少区分观测源时间 \(t_{\mathrm{obs}}\)、请求发出时间、服务端排队与计算、结果可用时间 \(t_{\mathrm{ready}}\)，以及命令实际消费时间 \(t_{\mathrm{execute}}\)。只报告模型 forward 用时会遗漏图像处理、编码、传输、排队和后处理。执行时的信息年龄 \(\mathrm{age}=t_{\mathrm{execute}}-t_{\mathrm{obs}}\)，通常比 GPU 计时更直接反映策略依据的信息有多旧。



跨机器时间戳需要可比较的时钟基准或明确的映射误差；本机持续时间通常应使用单调时钟，避免系统校时引发负延迟。源传感器时钟、控制器时钟和服务端时钟不同步时，不能直接相减后把结果解释为真实信息年龄。应同时记录时钟来源和同步方式。



平均延迟不能概括队列风险：偶发长尾、并发请求和图像解码抖动可能导致动作耗尽。除平均值外，还应观察分位数、连续高延迟段与实际队列剩余时间。一个平均快于控制周期的模型，也可能因某次阻塞打断闭环；调度策略需要基于端到端实测，而不是标称算力。



$$
\operatorname{age}=t_{\rm execute}-t_{\rm obs},\qquad \operatorname{turnaround}=t_{\rm ready}-t_{\rm request}
$$



### 测量从观测到执行的信息年龄

模型计算只是延迟的一段，传输、排队、缓存和播放都会让条件变旧。

在请求和每条动作中保留源时间，记录 ready、消费时间与时钟来源，联看年龄分布和队列余量。

## 动作槽位如何与当前时间对齐

动作块中的数组下标只有与执行时间对应后才具有控制含义。先定义每个槽位负责的时间区间，再决定当前应读取哪个元素，可以避免把已经过期的前缀重新播放。



设动作块起始时间为 \(t_{\mathrm{start}}\)，间隔 \(\Delta t\)，第 k 个动作按零阶保持协议用于 \([t_{\mathrm{start}}+k\Delta t,\ t_{\mathrm{start}}+(k+1)\Delta t)\)。当前槽位可计算为 \(\left\lfloor(t_{\mathrm{now}}-t_{\mathrm{start}})/\Delta t\right\rfloor\)。这要求先确认结果已经完成、当前时间没有早于起始点，且索引仍在块内，以上区间采用左闭右开的约定。



动作块在返回前已经过去的前缀不能从头重新播放，否则策略将执行为旧状态预测的动作并引入额外延迟。对于“每个数组元素是未来瞬时目标点”的不同协议，可能需要选择下一个未过期时间点并做插值，不能机械套用同一个 floor。槽位公式必须跟随执行语义。



边界浮点误差也需要按时间协议处理。理论上 \(t_{\mathrm{now}}=0.3\) 与 \(\Delta t=0.1\) 对应整数槽位，二进制表示可能略偏一侧；实现可以在明确容差下处理，或使用整数 tick。不能为了消除负索引就随意 clamp 到第一步，那会把尚未开始或已经过期的结果伪装成合法动作。





### 例：返回时有多少前缀已经过去

1. 动作块 \(t_{\mathrm{start}}=1.0\) 秒，\(\Delta t=0.1\) 秒，结果在 1.23 秒可用。

2. 按零阶保持区间，索引 \(\lfloor0.23/0.1\rfloor=2\)：前两段区间已经过去，第 2 段当前仍有效。

3. 若协议只接收未来目标点，则要按该接口选择后续时刻并插值，不能从 1.0 秒重新播放。

先定义每个元素对应时间点还是保持区间，再计算前缀丢弃。

### 结果返回后从动作数组第零项执行

这把算法延迟转换成额外动作滞后，形状和数值检查都不会发现。

在合成时间线上注入延迟，确认选中槽位属于当前时间，过期块返回无可用动作。

## 异步队列需要覆盖下一次结果到达前的时间

异步执行把动作消费与下一块生成重叠起来，但已有动作必须覆盖等待新结果的时间。沿统一时间轴计算剩余可执行时长，可以判断平均延迟看似足够时，队列为何仍可能耗尽。



异步推理让执行端继续消费已有动作，同时后台生成下一块。队列应该在剩余有效播放时间低于某个阈值时发起请求，但阈值需覆盖端到端延迟及抖动，而不只是平均前向耗时。较早请求通常增加余量，也可能更频繁地用新块替换尚未执行的计划。



例如 \(H=20,\ \Delta t=0.05\) 秒的块名义长度是一秒，若结果到达时已经过去 0.3 秒，最多还剩约 0.7 秒。下一次生成若常需 0.6 秒，余量很小；若还有偶发 0.3 秒排队，就会耗尽。增加网络带宽未必能解决由 GPU 排队或条件预处理造成的缺口，应分段测量再调整。



耗尽时必须有明确行为：等待、保持已接纳参考、返回控制模式或结束当前策略执行，具体选择取决于控制系统。继续重复一个旧目标不表示机器人完全不动，因为底层仍可能向它运动；不能把“没有新命令”解释成物理上的立即停止。延迟处理与实际控制模式需要一起验证。





## 版本、来源年龄与乱序返回

结果到达得晚，并不意味着它使用了更新的信息。任务切换和并发请求使时间顺序与语义版本分离，需要同时检查来源、年龄与任务身份，才能决定一个候选是否仍有效。



每次任务指令变更应更新任务版本或 epoch，结果携带生成时的版本。旧请求晚到时，即使其源时间比队列某些动作新，也不能覆盖新任务计划。请求序号、模型版本和来源观测有助于区分乱序结果；仅靠网络到达顺序判断“最新”不可靠。



候选动作还需要满足来源年龄上限。当前槽位仍存在，不代表产生它的观测仍适用：很长的动作块可以在时间上有未来，但依据很久以前的场景。平滑或融合旧动作不会更新它的信息来源；如果混入旧预测，应按明确规则保留相关来源年龄，而不是把合并时间当作新的观测时间。



检查与队列修改需要原子性。若执行线程读取动作时，另一个线程只更新 values 却尚未更新对应 epoch 或时间戳，就可能把动作与错误元数据组合。数据结构应把值和来源作为一个单元发布；单线程选择逻辑的正确性不能推出并发发布的原子性，后者需要另外检查竞态和取消行为。





### 例：旧指令的慢结果不能覆盖新指令

1. 请求 A 使用 `epoch=3`，网络较慢；稍后指令改变，请求 B 使用 `epoch=4`。

2. B 先返回并开始执行，随后 A 才到达。

3. 若按到达顺序覆盖队列，会重新执行旧任务；检查 epoch 后应拒绝 A。

“最后收到”不等于“当前任务的最新有效预测”。

## 计划接缝与融合存在语义限制

新旧计划即使分别有效，替换时仍可能产生跳变。平滑必须先满足时间与动作语义对齐，再分析响应速度和可行性的取舍，否则连续的曲线可能掩盖错误的执行含义。



替换动作块时可能出现参考跳变，可以在同一执行时刻、同一坐标和参考语义下对连续目标做平滑。先对齐绝对时间，再判断哪些分量可以混合；把两个不同起点的相对增量直接平均，会混合两套参考。旋转、离散夹爪与接触模式也不适合无条件逐元素平均。



融合旧计划与新计划会在平滑和响应之间形成取舍。旧计划权重大时接缝小，但新观测的纠正也更慢；两个可行的绕行方案平均可能变成不可行中间路线。应通过任务表现与控制日志验证，不能仅以动作曲线更平滑当作提升依据。



不同异步生成方法还可能在生成过程中固定已经承诺执行的前缀，这与生成后简单平均不是同一机制。读取 RTC 或其他实时动作块实现时，要追踪哪些动作已经提交、哪些未来动作仍可更改、以及推理所用条件更新到何时。不要把所有“后台推理加队列”都视为同一个算法。





## 参考限幅与真实运动约束的边界

对参考命令做限幅能够限制送入控制接口的变化，却没有直接描述机器人的实际响应。先推导参考层的可接受区间，再对照实测状态，才能划清纯数值处理与运动约束的边界。



若上一接纳位置参考为 \(\bar q\)、允许参考变化率为 \(v_{\max}\)、周期为 \(\Delta t\)，可以把新参考限制到 \([\bar q-v_{\max}\Delta t,\ \bar q+v_{\max}\Delta t]\)，再与位置范围 \([q_{\min},q_{\max}]\) 取交集。目标超界时投影到该区间；交集为空时说明当前参考与约束不相容，应显式处理，而不是继续给出看似有限的数。



这个函数约束的是参考值及参考变化率，并不直接保证实测 \(\dot q\) 合规。实际运动取决于跟踪误差、内部插值、控制模式、负载与底层保护；用于限幅的 \(\Delta t\) 若和真实消费周期不同，参考层自己的解释也会变化。记录接纳参考与实测反馈，才能区分计划跳变和执行偏差。



非有限目标应在进入控制接口前拒绝。finite 与区间投影只限制数值及范围，计算中没有自碰撞、接触力、稳定性或动力学可达性的信息，因而不能推出这些物理性质。



$$
q_{\rm lo}=\max(q_{\min},\bar q-v_{\max}\Delta t),\quad q_{\rm hi}=\min(q_{\max},\bar q+v_{\max}\Delta t)
$$



### 命令每步变化有限就等于实测速度受限

参考与实际状态之间还有控制器和动力学，数值限幅只约束输入一侧。

同时记录 `q_ref`、`q_measured`、真实 dt 与控制模式；对不相容边界和非有限目标使用明确状态处理。

## 用故障注入检查时序行为

时序错误往往只在慢返回、取消或回合切换时出现，正常路径不能覆盖这些情况。将每一种时间关系构造成确定性输入，再检查完整队列行为，可以把偶发现象变成可复现的逻辑问题。



构造确定性计划列表，分别设置未来才 ready、已经过期、错 epoch、时间起点在未来与返回乱序，检查选择函数拒绝它们。再用边界时间测试槽位，确认已经过去的前缀不会重新出现。与真实网络延迟直接混合之前，这些纯逻辑检查更容易定位错误。



随后测试完整异步系统：慢请求、短暂卡顿、并发取消、指令切换和队列耗尽。记录每条实际执行命令的来源，重建当时队列与任务版本，确认等待结束后不会被旧请求重新激活。模型平均推理速度快，不能替代对这类状态转换的验证。



候选筛选、当前槽位与参考限幅分别对应来源有效性、时间有效性和数值边界。传感器与驱动器日志连接端到端观察；延迟分布、过期拒绝、等待次数、动作连续性和任务结果能揭示不同失效环节。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| action chunk | [H,D] | 带来源时间、起始时间和任务版本的一组命令 |
| position reference / bounds | [D] 或 [B,D] | 控制器接纳的参考及明确的参考约束 |
| ready / fresh / active | 每个预测块的布尔条件 | 时间、来源和版本一起决定是否可执行 |

## 完整代码与精读

```python
import math
import torch

torch.manual_seed(7)

# STEP 1: 三个返回时间不同的预测，第三个属于新指令
plans=[
 {'obs':0.0,'ready':0.15,'start':0.0,'epoch':0,'values':torch.arange(6).float()*0.1},
 {'obs':0.2,'ready':0.33,'start':0.2,'epoch':0,'values':torch.arange(6).float()*0.1+0.25},
 {'obs':0.4,'ready':0.53,'start':0.4,'epoch':1,'values':0.2-torch.arange(6).float()*0.1},
]
dt,max_age=0.1,0.35

# STEP 2: 按当前时间选槽位，不重新播放已经过去的前缀
def pick(now,epoch):
    candidates=[]
    for p in plans:
        if p['ready']>now or p['obs']>now or p['epoch']!=epoch or now-p['obs']>max_age:
            continue
        index=math.floor((now-p['start'])/dt+1e-9)
        if 0<=index<len(p['values']):
            candidates.append((p['obs'],index,p['values'][index]))
    return max(candidates,key=lambda x:x[0]) if candidates else None

# STEP 3: 位置与参考变化率区间取交集，不声称约束了实测动力学
def bounded_reference(previous,target):
    if not torch.isfinite(target).all():
        raise ValueError('non-finite target')
    lower=torch.maximum(torch.tensor(-0.5),previous-0.5*dt)
    upper=torch.minimum(torch.tensor(0.5),previous+0.5*dt)
    if (lower>upper).any():
        raise ValueError('incompatible reference constraints')
    return torch.maximum(lower,torch.minimum(upper,target))

# STEP 4: 新指令切换后拒绝旧结果；过期也不能靠平滑变新
previous=torch.tensor(0.0)
for tick in range(9):
    now=tick*dt
    epoch=1 if tick>=5 else 0
    selected=pick(now,epoch)
    if selected is None:
        print(round(now,1),'WAIT: no valid action')
        continue  # 真实系统的等待行为由执行状态机定义
    source,index,target=selected
    previous=bounded_reference(previous,target)
    print(round(now,1),'source',source,'slot',index,'reference',round(previous.item(),3))
assert pick(0.1,0) is None
assert pick(0.2,0)[1]==2
assert pick(0.5,1) is None
assert pick(0.8,1) is None

```

- 第 6–13 行：来源观测、动作起始时间和完成时间分别保存。epoch 表示指令或任务版本，不能仅比较到达顺序。
- 第 14–24 行：槽位由控制时刻与动作起始时刻计算。观测年龄超限、预测尚未返回或版本不符，都不进入候选。
- 第 25–34 行：位置边界和最大参考变化量一起限制命令。它是参考接口的数值检查，不是实测状态或碰撞的保证。
- 第 35–50 行：0.2 秒时第一块已到达，但第零步已过，应选槽位 2。指令切换和过期时返回 WAIT，由真实系统外层定义响应。

预期观察：0.2 秒选第一块槽位 2；0.5 秒旧指令结果不可使用，新结果尚未到达；0.8 秒最后一块已过期。参考每控制周期最多变化 0.05。

## 浏览器 Python 练习

实现 `choose_action(plans,now,dt,max_age,epoch)`。每块含 obs、ready、start、epoch、values；仅选择已完成、未过期、版本一致且覆盖当前槽位的块，优先来源 obs 最新者。返回 (value,index,obs)，无候选返回 None。

```python
import math

def choose_action(plans,now,dt,max_age,epoch):
    # TODO: 检查时间与版本，按当前槽位选择
    raise NotImplementedError

```

### 提示

- `ready<=now` 只表示结果已返回，还要检查来源年龄与任务版本。
- 从 (now−start)/dt 计算槽位，不能对每个新结果总是取 values[0]。

### 参考实现与解释

```python
import math

def choose_action(plans,now,dt,max_age,epoch):
    if dt<=0 or max_age<0:
        raise ValueError('invalid timing configuration')
    candidates=[]
    for p in plans:
        if p['ready']>now or p['obs']>now or p['epoch']!=epoch or now-p['obs']>max_age:
            continue
        index=math.floor((now-p['start'])/dt+1e-9)
        if 0<=index<len(p['values']):
            candidates.append((p['values'][index],index,p['obs']))
    return max(candidates,key=lambda x:x[2]) if candidates else None

```

选择当前槽位可避免延迟到达后重放已过去动作。obs 和 ready 分别描述信息来源及完成时间，作用不同。候选最新按来源排序，而非按列表末项或网络到达顺序。本练习假定同一时钟和分段常值动作。

### 断言测试

```python
p=[{'obs':0.,'ready':0.15,'start':0.,'epoch':0,'values':[0.,1.,2.,3.]}]
assert choose_action(p,0.21,0.1,0.3,0)==(2.,2,0.)
assert choose_action(p,0.11,0.1,0.3,0) is None
assert choose_action(p,0.41,0.1,0.3,0) is None
assert choose_action(p,0.21,0.1,0.3,1) is None
p.append({'obs':0.2,'ready':0.25,'start':0.2,'epoch':0,'values':[10.,11.,12.]})
assert choose_action(p,0.31,0.1,0.4,0)==(11.,1,0.2)
print('准备状态、过期、指令版本和动作槽位检查通过。')

```

## 本地 PyTorch 练习

实现 `limit_reference(previous,target,dt,max_rate,lower,upper)`。previous/target 为 `[B,D]`，其余边界为 [D]。返回位置与参考变化率区间交集内的目标；非有限、非法边界或交集为空时抛出 ValueError。

```python
import torch

def limit_reference(previous,target,dt,max_rate,lower,upper):
    # TODO: 先求可行区间，再投影目标
    raise NotImplementedError

```

### 提示

- 下界取 `max(位置下界,previous−rate*dt)`，上界取 `min(位置上界,previous+rate*dt)`。
- 若 `lower_effective>upper_effective`，应拒绝，不能再简单 clamp 到位置边界。

### 参考实现与解释

```python
import torch

def limit_reference(previous,target,dt,max_rate,lower,upper):
    if previous.ndim!=2 or target.shape!=previous.shape or dt<=0:
        raise ValueError('invalid shape or dt')
    if any(v.shape!=(previous.shape[-1],) for v in (max_rate,lower,upper)):
        raise ValueError('invalid bound shape')
    if not all(torch.isfinite(v).all() for v in (previous,target,max_rate,lower,upper)):
        raise ValueError('non-finite input')
    if (max_rate<0).any() or (lower>upper).any():
        raise ValueError('invalid bounds')
    lo=torch.maximum(lower,previous-max_rate*dt)
    hi=torch.minimum(upper,previous+max_rate*dt)
    if (lo>hi).any():
        raise ValueError('empty feasible reference interval')
    return torch.maximum(lo,torch.minimum(hi,target))

```

可行交集存在时投影目标同时满足两类参考约束。若 previous 已离边界过远，单个周期内可能无法同时满足位置和变化率，应交给上层处理。不把参考增量约束误称为实测速度、力或碰撞约束。

### 断言测试

```python
p=torch.tensor([[0.,0.9]])
t=torch.tensor([[2.,2.]])
rate=torch.tensor([0.5,2.])
lo=torch.tensor([-1.,-1.]); hi=torch.tensor([1.,1.])
out=limit_reference(p,t,0.1,rate,lo,hi)
torch.testing.assert_close(out,torch.tensor([[0.05,1.]]))
assert ((out-p).abs()<=rate*0.1+1e-6).all()
try:
    limit_reference(torch.tensor([[5.,0.]]),t,0.1,rate,lo,hi)
    raise AssertionError('位置与变化率边界不相容应报错')
except ValueError:
    pass
print('参考区间与空交集检查通过；这不等于实测动力学约束保证。')

```

## 练习：推导与分析

### 推理 150 ms，预测 50 步、每步 20 ms，为什么还不能只凭这些数字保证连续执行？

需要端到端延迟而不只是模型 forward 时间，还要知道队列何时补充、返回时已有多少槽位过去、执行多少步后重规划以及延迟抖动。名义一秒动作块不等于每次返回都还有一秒有效未来。

还要验证来源年龄、任务版本和实际消费频率。若裁掉旧前缀后剩余时间不足以覆盖下一次请求，提前请求或增大阈值不一定解决根本缺口。实验应报告耗尽、过期、停顿与任务效果，不能仅以平均耗时判断。

代码定位：pick 的 slot 计算与 obs/ready/start 三个时间字段。

- 区分名义时长与有效剩余时长。
- 包含延迟抖动、补队列节奏和来源年龄。

### 位置参考每步变化都被限制，为什么仍不能声称关节实测速度一定合规？

参考只是控制器接纳的目标，实际关节运动还取决于控制模式、跟踪误差、内部插值、负载和底层限幅。若实际控制周期与用于计算限幅的 dt 不一致，参考层本身的解释也会改变。

应分别记录接纳参考与实测状态，并在对应控制层落实所需反馈约束。空队列、非有限值或不相容边界要有明确状态机处理。这个数值函数不计算碰撞、接触力或整机稳定性，不能将其输出当作完整物理安全证明。

代码定位：`limit_reference` 的区间定义与调用方实际 dt、实测反馈日志。

- 明确参考与实测量的区别。
- 指出限幅函数未涵盖的实际约束。

## 练习：辨析与纠错

### 只测 GPU forward 当端到端延迟

编码、传输、排队、后处理和播放都会增加信息年龄。联看分段计时与源观测到执行时间。

### 用完整 H/fps 作为结果返回后的余量

已经过去的前缀不再可用。按当前槽位计算剩余有效时域，再评估下一次请求预算。

### 旧请求晚到就覆盖当前计划

任务 epoch、来源时间与请求序号必须共同筛选，动作及其元数据应原子发布。

### 平滑让旧动作变成新信息

融合改变数值连续性，不会更新观测来源。保留贡献来源年龄并检查任务与参考兼容性。

### 参考速度限幅等于物理安全保证

该计算只约束参考变化，不涵盖实测动态、碰撞、接触和稳定性。用反馈与控制层要求分别验证。

## 原始资料

- [LeRobot：异步远程推理、动作对齐与来源年龄](https://huggingface.co/docs/lerobot/remote_inference)
- [LeRobot：Real-Time Chunking](https://huggingface.co/docs/lerobot/rtc)
- [LeRobot：动作表示与处理顺序](https://huggingface.co/docs/lerobot/action_representations)
