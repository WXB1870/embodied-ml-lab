# 部分观测与记忆

状态、观测、历史信息与循环状态的边界。

一个策略可能面对相同图像却需要给出不同动作，例如位置相同但运动方向相反。此时困难来自观测中缺少决定动作的信息，不能仅靠增加网络容量解决。本章从 Markov 状态与观测的区别出发，用短历史的可辨认例子引入信念更新和循环记忆，再说明隐藏状态怎样随时间训练、传递与重置，把信息需求和记忆模块的工程实现连接起来。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [时间对齐与动作块](https://wxb1870.github.io/embodied-ml-lab/learn/action-chunk/)

## 状态、观测与 Markov 性的区别

策略需要依据当前信息预测动作后果，但相机和传感器未必暴露了决定后果的全部变量。先分清动力学状态与可获得观测，才能判断失败源于模型拟合不足，还是输入本来就无法区分正确行为。



在 MDP 中，给定当前状态 \(s_t\) 与动作 \(a_t\)，下一状态分布不再依赖更早历史。这里的状态是模型定义中足够描述动力学的变量，未必就是相机图片或传给神经网络的 Tensor。位置相同但速度不同、接触模式不同或任务阶段不同，都可能导致同一动作产生不同后果。



机器人通常只能得到观测 \(o_t\)，例如图像、编码器或力传感数据，它们由隐藏状态产生且可能带噪声、延迟和遮挡。若只把当前观测输入策略，两个需要不同动作的真实状态可能被映射成同一个输入，这称为观测混叠。模型再大，也无法从完全相同且没有额外信息的输入区分两种隐藏状态。



是否近似满足 Markov 性取决于任务与传感器，而不是数据字段叫 state 就成立。一个包含位置和速度的状态向量仍可能缺少摩擦、负载或接触历史；另一方面，某些慢速任务用当前观测就足够实用。应通过具有明确差异的动态场景验证信息需求，而非把使用记忆当成所有策略的默认答案。



$$
P(s_{t+1}\mid s_{0:t},a_{0:t})=P(s_{t+1}\mid s_t,a_t)
$$



### 把输入变量命名为 state 就认为它完整

Markov 性描述预测未来所需的信息，不由字段名、维度或模型大小决定。

构造当前输入相同、潜在速度或接触阶段不同的场景，检查最优动作是否真的相同。

## 用两帧构造一个可辨认的反例

判断是否需要历史，可以先构造当前观测完全相同、正确行为却不同的两个样本。位置与速度的简单关系足以暴露这种歧义，并说明增加哪一种信息才有可能解决它。



考虑一维位置控制，当前观测只有位置 \(x_t\)。两个样本都位于 \(x_t=0\)，一个从负方向快速接近，另一个从正方向快速接近；为了减速，它们需要相反的控制。只用当前位置的确定策略必须给出同一个动作，因此无法同时满足两个标签。加入前一位置与时间差，才有机会估计速度并区分状态。



差分速度应除以实际 \(\Delta t\)，而不是默认帧率。传感器丢帧后，相同位置差可能对应更低速度；时间重复或逆序时应拒绝计算。回合切换处也不能用上一回合末尾位置计算新回合速度，那是由记录拼接制造的虚假运动。



噪声会让短间隔差分放大误差，可以采用因果滤波或增加多帧信息，但滤波会引入滞后。离线平滑若使用未来样本，会得到部署时不存在的速度估计。比较当前观测与历史模型时，要保持这些处理规则一致，才能将收益解释为历史信息，而非未来数据泄漏。





### 例：相同位置，需要相反控制

1. \(\Delta t=0.1\) 秒，两段历史分别为 \(-0.1\to0\) 与 \(+0.1\to0\)。

2. 当前位置都为零，但估计速度分别为 +1 与 −1。

3. 若动作应抵消速度，标签分别是 −1 与 +1；只看当前位置的 MSE 最优常数为零。

历史的作用来自新增可辨认信息，不是单纯增加模型参数。

## 历史与信念状态在估计什么

两帧例子说明历史能够减少歧义，但带噪声和遮挡时往往不能唯一确定状态。信念状态用条件概率概括剩余不确定性，将已执行动作与新观测按明确的推断顺序联系起来。



POMDP 中可以用信念 \(b_t(s)=P(s_t=s\mid o_{0:t},a_{0:t-1})\) 概括对隐藏状态的不确定性。过去动作很重要：相同两帧变化可能来自不同已执行控制或外部扰动。只保存图像历史而不考虑动作与采样间隔，未必足够解释状态演化。



在已知转移与观测模型的标准设置下，先用动作把 \(b_t\) 传播到下一状态分布，再用新观测做贝叶斯更新并归一化。这说明记忆不仅是存储更多帧，也是结合先验动态和新证据估计当前状态。神经循环模块可以学习有用摘要，但它没有显式概率语义时，不能直接把 hidden 称为已校准的信念分布。



有限长度历史是计算与信息的折中。短窗口可提供局部速度和最近事件，长任务阶段可能需要更早信息；增加窗口又会增加显存、重复输入与噪声。如果某信息从未被任何传感器观察到，再长历史也无法确定它。应区分可估计的不确定性、不可观测变量和模型没有学会利用的证据。



$$
b_{t+1}(s^\prime)\propto P(o_{t+1}\mid s^\prime)\sum_s P(s^\prime\mid s,a_t)b_t(s)
$$



### 例：先传播，再用观测重新加权

1. 隐藏状态只有左、右两种。上一时刻信念为 \((0.6,0.4)\)，给定已执行动作后，状态保持的概率为 0.8、切换概率为 0.2。传播得到先验 \((0.56,0.44)\)。

2. 新观测在左状态下的似然为 0.9，在右状态下为 0.2。未归一化权重为 \((0.504,0.088)\)，总和为 0.592。

3. 后验为 \((0.504/0.592,0.088/0.592)\)。动作影响传播模型，观测影响似然，二者按时间顺序承担不同作用。

一个观测更支持某状态，会提高其后验权重；这与直接把最新观测当作真实状态不同。

## 因果历史按信息到达时刻构造

历史只有在决策时已经可用，才是合法的策略输入。传感器的采集时刻与数据到达时刻不同，因此因果性必须从数据处理开始检查，不能仅由模型内部的 Mask 保证。



策略在决策时只能读取此前已经到达的信息。源图像可能在时刻 t 拍摄，却在 \(t+\delta\) 才传到决策端；如果训练直接按采集时间将其放入 t 的输入，就低估了实际延迟。多模态历史应同时保留源时间和到达时间，并明确决策截止规则。



双向序列编码在离线表示学习中可以合法，但在线策略使用它处理整条轨迹时，早期位置会访问未来观测。因果 Mask、窗口截断或状态递推需要与部署一致。只在模型配置里写 `causal=True`，不能证明数据预处理没有先做未来平滑或把终局信息放入当前特征。



一种有辨别力的测试是固定 t 以前的数据，任意修改 t 之后的观测，检查当前策略输入及输出是否变化。这个测试应覆盖数据构造、特征提取和模型可见性，不能只检查 Transformer 最后一层的 Mask。对保留的传感器延迟，也应使用与在线系统相同的对齐规则。





### 用未来干预测试检查因果性

时间戳声明和注意力 Mask 只能约束各自局部，未来信息可能在预处理阶段进入。

修改未来帧、未来动作和回合结局，确认此前输入与输出不变；另测实际到达时间截止。

## GRU 的递推与张量轴

固定窗口显式保存过去样本，循环网络则把过去压缩进一个不断更新的向量。GRU 通过门控平衡旧状态与新候选信息，理解一次更新的计算之后，才有依据管理多层与批处理中的隐藏状态。



循环策略将上一隐藏状态 \(h_{t-1}\) 与当前输入 \(x_t\) 合成 \(h_t\)，再用于输出动作。GRU 的更新门与重置门控制旧信息保留和候选状态计算，提供可学习的递推摘要。门值可连续变化，不是由人写死“记住多少帧”；能否学到长期依赖仍受数据、优化和隐藏维数影响。



按 PyTorch 的单层约定，输入 \(x_t\in\mathbb R^D\)、历史 \(h_{t-1}\in\mathbb R^H\)，两门与候选 \(r_t,z_t,n_t\in\mathbb R^H\)。各输入矩阵为 \(H\times D\)，历史矩阵为 \(H\times H\)，偏置为 \(H\) 维。更新写为\[\begin{aligned}r_t&=\sigma(W_{ir}x_t+b_{ir}+W_{hr}h_{t-1}+b_{hr}),\\z_t&=\sigma(W_{iz}x_t+b_{iz}+W_{hz}h_{t-1}+b_{hz}),\\n_t&=\tanh(W_{in}x_t+b_{in}+r_t\odot(W_{hn}h_{t-1}+b_{hn})),\\h_t&=(1-z_t)\odot n_t+z_t\odot h_{t-1}.\end{aligned}\]这里 \(\sigma\) 是 Sigmoid。更新门靠近 1 时保留更多历史；重置门控制历史变换对候选的贡献。门值本身也依赖输入和历史，因此总 Jacobian 还包含门的导数，不能仅凭最后一行就保证长时梯度稳定。



候选中的门控位置要与实现一致：PyTorch 对历史仿射结果再乘 \(r_t\)，一般不等于先对 \(h_{t-1}\) 门控再乘历史矩阵。下方实验按照官方接口的权重分块顺序手写一次更新，并对输入、历史与全部参数的梯度作对照。



PyTorch 单向 GRU 在 `batch_first=True` 时输入和输出序列通常为 `[B,T,D]` 与 `[B,T,H]`，但 hidden 仍为 `[L,B,H]`，L 是层数。`batch_first` 不改变 hidden 的 Batch 所在轴；双向模型还会把方向数乘到相应维度，在线因果策略不能无意使用未来方向。



训练窗口可以一次处理多个时间步，在线则常逐步传入并保留 hidden。两种模式在相同参数、相同初始状态和确定性设置下应产生对应输出。用短序列比较整段运行与逐步运行，可以发现 hidden 轴错置、状态未传回或每步意外清零等错误。



```python
import torch
import torch.nn.functional as F

torch.manual_seed(7)
cell = torch.nn.GRUCell(3, 4).double()
x = torch.randn(2, 3, dtype=torch.float64, requires_grad=True)
h = torch.randn(2, 4, dtype=torch.float64, requires_grad=True)
ir, iz, inn = F.linear(x, cell.weight_ih, cell.bias_ih).chunk(3, -1)
hr, hz, hn = F.linear(h, cell.weight_hh, cell.bias_hh).chunk(3, -1)
r = torch.sigmoid(ir + hr)
z = torch.sigmoid(iz + hz)
n = torch.tanh(inn + r * hn)
manual = (1 - z) * n + z * h
official = cell(x, h)
torch.testing.assert_close(manual, official, rtol=1e-12, atol=1e-12)
probe = torch.randn_like(manual)
inputs = (x, h, *tuple(cell.parameters()))
gm = torch.autograd.grad((manual * probe).sum(), inputs)
go = torch.autograd.grad((official * probe).sum(), inputs)
for a, b in zip(gm, go):
    torch.testing.assert_close(a, b, rtol=1e-11, atol=1e-12)
print("通过：GRU 单步前向与输入、历史、参数梯度一致。")

```

权重沿输出轴依次打包 reset、update、new 三组。非零随机偏置可以检出候选分支中把门控放错位置的实现；非均匀 probe 避免只对输出求和掩盖部分梯度错误。这里只验证一个确定的单步算子，回合边界仍由后续 reset 协议处理。



## detach 与 reset 分别切断什么

循环训练同时维护隐藏数值和连接这些数值的计算图，这两者有不同生命周期。区分截断梯度与开始新回合，才能解释何时应保留记忆、何时必须清除旧信息。



截断反向传播使用 `detach` 保留 hidden 数值，但移除此前计算图的依赖，限制跨训练窗口的梯度长度。它减少图保留与内存，不会清除模型已经记住的数值信息。reset 则在新回合或指定环境上清零或设置初始 hidden，改变后续输出的起点。二者解决不同边界问题。



向量化环境中，不同 Batch 元素可能在不同时间结束，应该按 `reset_mask`:`[B]` 只重置相应环境的状态。整个 Batch 一起清零会让未结束环境丢失历史，完全不重置又会把上一回合信息泄漏到下一回合。即使不训练、只做 `no_grad` 推理，也仍需要正确 reset。



训练时若跨窗口保留 hidden，却在每个窗口随机抽取无关轨迹，会把记忆接到不连续数据上；若窗口来自连续轨迹，则要明确何时 `detach`、何时保留数值、何时真正 reset。当前代码的 `reset_hidden` 练习分别检查数值和梯度，避免用输出形状正确替代这两个行为的验证。





### 例：相同数值，梯度路径不同

1. 令 hidden 来自前一窗口计算。调用 hidden.`detach`() 后，其数值不变，后续前向仍使用这份记忆。

2. 对新回合位置乘零或写入初始状态，数值才改变，策略从新的记忆起点继续。

3. `truncate=True` 可以先 `detach` 全部历史，再按 `reset_mask` 清零特定环境；这同时表达两个独立动作。

截断训练图不等于清空记忆，清空某个环境也不要求清空整个 Batch。

### 用 detach 当作回合 reset

`detach` 只改变自动微分关系，旧回合的数值状态仍然进入新回合。

分别测试 hidden 的值、`requires_grad/grad_fn` 和新回合首步输出；用两个 Batch 环境检查部分重置。

## 如何评价记忆是否解决了信息问题

增加记忆模块只是提供了利用历史的可能，不能证明模型真正补齐了缺失信息。评价需要回到最初的混叠问题，同时核对训练窗口、部署状态与任务切换时的行为。



先用合成混叠任务验证历史输入能否区分应有不同动作的状态，再比较无历史、固定窗口与循环模型。保持参数预算、预处理与训练条件尽量可比，并加入帧率变化、短时遮挡或可控延迟，检查记忆是否利用了所需线索。只在普通验证集提高一点分数，难以说明长期记忆机制。



需要检查训练和 rollout 的 hidden 初始化与生命周期。训练每段从零开始，而部署持续运行很长时间，可能产生状态分布差异；反过来，训练利用真实连续历史、部署频繁 reset，也会丢掉模型依赖的信息。可以使用明确的预热历史与窗口采样协议，但必须记录它们对输入的实际影响。



更长记忆还可能积累错误或保留过时任务信息。任务切换、机器人复位和控制接管时应有清楚的状态边界。最终评价应同时观察相关动态场景的任务效果、状态泄漏反例与计算延迟；“加了 GRU/Transformer”只是结构描述，只有这些对照才能说明它补充了可用信息。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| observation sequence | [B,T,D_obs] | 当前决策之前已经可用的观测序列 |
| GRU hidden | [L,B,H] | 各层、各独立环境的循环状态 |
| episode reset mask | [B] | 哪些环境刚进入新回合，需要清除历史 |

## 完整代码与精读

```python
import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 相同当前位置，配上两种相反速度和相反制动标签
position = torch.linspace(-1,1,32,dtype=torch.float64).repeat_interleave(2)
velocity = torch.tensor([-1.,1.],dtype=torch.float64).repeat(32)
dt = 0.1
previous_position = position-dt*velocity
expert_action = -velocity
current_features = torch.stack([position,torch.ones_like(position)],dim=1)
history_features = torch.stack([position,(position-previous_position)/dt],dim=1)

# STEP 2: 最小二乘给出两个输入方案各自能拟合的结果
w_current = torch.linalg.lstsq(current_features,expert_action).solution
w_history = torch.linalg.lstsq(history_features,expert_action).solution
current_mse = (current_features@w_current-expert_action).square().mean()
history_mse = (history_features@w_history-expert_action).square().mean()
print('current-only/history MSE:', current_mse.item(),history_mse.item())
assert current_mse > 0.99 and history_mse < 1e-20

# STEP 3: GRU hidden 必须属于当前回合，不能继承无关轨迹
rnn = nn.GRU(input_size=1,hidden_size=4,batch_first=True)
first_episode = torch.tensor([[[1.],[2.],[3.]]])
next_episode = torch.tensor([[[9.],[8.],[7.]]])
_,h_old = rnn(first_episode)
fresh_output,h_fresh = rnn(next_episode)  # hidden 默认为零
contaminated_output,_ = rnn(next_episode,h_old.detach())
print('hidden shape:',tuple(h_fresh.shape))
print('cross-episode contamination:',(fresh_output-contaminated_output).abs().max().item())
assert not torch.allclose(fresh_output,contaminated_output)

# STEP 4: 截断 BPTT 只去掉图连接，按环境 reset 才清除数值
hidden = h_old.detach()
assert not hidden.requires_grad
assert torch.equal(hidden,h_old)
reset = torch.tensor([True])
hidden = torch.where(reset[None,:,None],torch.zeros_like(hidden),hidden)
assert torch.count_nonzero(hidden) == 0
print('detach retains values; reset clears episode memory')

```

- 第 7–15 行：每个当前位置都有两种速度；当前位置无法辨别需要的相反动作。历史差分在这个合成系统中提供了缺少的速度。
- 第 16–23 行：使用最小二乘避免训练未收敛的干扰。当前输入的最优平均预测仍有误差，带因果差分的输入可以精确表示标签。
- 第 24–34 行：新回合默认零 hidden 与错误继承旧 hidden 会产生不同结果。这里的 GRU 未训练，比较仅说明状态依赖真实存在。
- 第 35–42 行：detach 后数值不变，只断开过去的梯度图。reset_mask 沿层和隐藏维广播，单独清除指定环境。

预期观察：当前输入 MSE 约为 1，历史输入误差接近零；GRU hidden 形状为 (1,1,4)。新回合继承旧 hidden 的输出不同，detach 与 reset 检查通过。

## 浏览器 Python 练习

实现 `causal_velocity(positions,times,episodes)`。返回等长列表；第一项及回合切换处为 None，其余项使用当前与上一条记录的差分。相同回合内非递增时间要报错。

```python
def causal_velocity(positions, times, episodes):
    # TODO: 不读取未来，不跨 episode 做差分
    raise NotImplementedError

```

### 提示

- 第 t 项只能引用 t 与 t−1，不要做中心差分。
- 先检查 episode，回合切换的时间戳可以重新从零开始。

### 参考实现与解释

```python
def causal_velocity(positions, times, episodes):
    if not (len(positions)==len(times)==len(episodes)):
        raise ValueError('length mismatch')
    result=[]
    for t in range(len(positions)):
        if t==0 or episodes[t]!=episodes[t-1]:
            result.append(None)
        else:
            dt=times[t]-times[t-1]
            if dt<=0:
                raise ValueError('non-increasing time')
            result.append((positions[t]-positions[t-1])/dt)
    return result

```

因果差分不会因未来位置变化而改变此前结果。跨回合的两帧没有连续运动含义，即使时间戳相邻也应重置历史；同一回合则需用真实正时间差计算。

### 断言测试

```python
assert causal_velocity([0.,1.,3.,100.,102.],[0.,1.,2.,0.,1.],['a','a','a','b','b']) == [None,1.,2.,None,2.]
assert causal_velocity([],[],[]) == []
a=causal_velocity([0.,1.,3.],[0.,1.,2.],['a']*3)
b=causal_velocity([0.,1.,999.],[0.,1.,2.],['a']*3)
assert a[:2]==b[:2]
try:
    causal_velocity([0.,1.],[1.,1.],['a','a'])
    raise AssertionError('同回合时间重复应报错')
except ValueError:
    pass
print('因果性、回合边界和真实时间间隔检查通过。')

```

## 本地 PyTorch 练习

实现 `reset_hidden(hidden, reset_mask, truncate)`。hidden 为 `[L,B,H]`，`reset_mask` 为 `[B]` 布尔值。`truncate=True` 时先 `detach`，再将需重置的环境 hidden 清零；False 时保留其余环境的梯度路径。

```python
import torch

def reset_hidden(hidden, reset_mask, truncate):
    # TODO: 区分梯度边界和回合边界
    raise NotImplementedError

```

### 提示

- `reset_mask` 要变成 `[1,B,1]` 才能沿层与隐藏维广播。
- `detach` 保留数据；不要把它当成清零操作。

### 参考实现与解释

```python
import torch

def reset_hidden(hidden, reset_mask, truncate):
    if hidden.ndim!=3 or reset_mask.shape!=(hidden.shape[1],) or reset_mask.dtype!=torch.bool:
        raise ValueError('invalid hidden or reset mask')
    source=hidden.detach() if truncate else hidden
    return torch.where(reset_mask[None,:,None],torch.zeros_like(source),source)

```

torch.where 使重置环境的数值和输入梯度都为零，其余环境保留历史。truncate 决定是否允许损失继续向此前分段反传；reset 决定记忆是否属于当前回合。两者不能合成一个含糊的 done 操作。

### 断言测试

```python
h=torch.ones(2,3,4,requires_grad=True)
m=torch.tensor([False,True,False])
out=reset_hidden(h,m,False)
assert torch.count_nonzero(out[:,1])==0
out.sum().backward()
torch.testing.assert_close(h.grad[:,0],torch.ones(2,4))
torch.testing.assert_close(h.grad[:,1],torch.zeros(2,4))
detached=reset_hidden(h,m,True)
assert not detached.requires_grad
assert torch.equal(detached[:,0],h[:,0])
print('按环境 reset 与截断 BPTT 的梯度检查通过。')

```

## 练习：推导与分析

### 只增加历史长度就能保证策略输入满足 Markov 性吗？

不能。有限历史可能补充速度、事件顺序等信息，但隐藏变量未必可从这些观测推断，长时间遮挡或未观测接触状态也可能仍有歧义。Markov 性是给定输入后未来条件分布是否还依赖更早信息的性质。

可构造同一历史窗口对应不同隐藏状态和未来结果的反例，比较增加观测通道、动作历史或记忆模块后的效果。必须使用因果窗口，并保持训练与部署信息一致；不能用未来帧换取看似完整的状态。

代码定位：`history_features` 的因果差分与 observation/history 的构造。

- 说明有限历史不保证充分性。
- 提出一个缺失信息反例和可检验改进。

### 训练分段长度为 32，环境在第 20 步重置。`detach` 与 reset 分别该在哪里考虑？

在环境第 20 步进入新回合时，应清除对应环境 hidden，阻止前一回合影响新任务。分段末按截断 BPTT 方案 `detach`，用来限制梯度回传长度；这个操作通常保留该环境当时的数值记忆。

若多个环境不同步结束，需要 `[B]` `reset_mask`，而不是一次清空全部环境。训练与推理应使用一致的回合边界语义。每一步 `detach` 会阻止跨步信用分配，即使数值 hidden 仍在传递，也不能声称完整训练了长程依赖。

代码定位：`reset_hidden` 的 `reset_mask` 广播与 truncate 分支。

- 分别说明第20步重置与第32步截断。
- 指出异步向量环境必须按元素处理。

## 练习：辨析与纠错

### 相同图像一定对应相同正确动作

速度、接触模式和任务阶段可能不同。通过可控混叠例子检查是否需要历史或额外传感信息。

### batch_first 也改变 hidden 轴顺序

GRU hidden 的层/方向、Batch、隐藏维约定需单独核对。用 B、T、H 不同的短序列对照整段与逐步运行。

### detach 后认为上一回合已被遗忘

数值仍保留。新回合按环境 reset，截断图则按训练窗口另行处理。

### 随机窗口之间沿用同一 hidden

不连续轨迹的状态会被错误拼接。记录窗口连续关系，并按边界重置或预热。

### 离线速度平滑无意读取未来

双向插值或滤波可能在决策前使用尚未到达样本。做未来干预与时间截止测试。

## 原始资料

- [Spinning Up：状态、观测与 MDP](https://spinningup.openai.com/en/latest/spinningup/rl_intro.html)
- [Kaelbling 等：POMDP 原论文](https://people.csail.mit.edu/lpk/papers/aij98-pomdp.pdf)
- [Robomimic：循环策略与回合 reset](https://robomimic.github.io/docs/modules/algorithms.html)
- [PyTorch · GRU 输入、输出与 hidden 维度](https://docs.pytorch.org/docs/stable/generated/torch.nn.GRU.html)
