# 概率、统计与训练目标

理解 MSE、交叉熵和 KL 分别在要求模型做什么。

概率用 0 到 1 的数值描述随机事件发生的可能性，概率分布规定随机变量的取值怎样分配概率；统计则用有限观测估计这些规律。在机器学习中，条件分布区分“已知什么”与“要预测什么”，期望损失规定平均训练目标。本章先建立联合、边缘与条件分布，再解释似然怎样导出损失，最后连接条件均值、熵与采样权重。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [线性代数与矩阵求导](https://wxb1870.github.io/embodied-ml-lab/learn/matrix-grad/)

## 条件变量与学习目标

随机变量是随随机结果取值的量，条件变量是预测时已观察到的信息，目标变量是仍需预测的结果。条件分布描述在这些已知信息下目标怎样分布。先划定信息边界，才能判断哪些不确定性可被改进模型消除。



监督学习可以写成在数据分布上最小化期望损失 \(\mathbb E[\ell(f_\theta(x),y)]\)。这里的 x 包含部署时可获得的条件，y 是要预测的量；数据集只给出这个期望的有限样本估计。对具身策略，条件可能包含图像、语言、当前状态和历史，目标可能是下一动作或动作块。先定义采样单位和条件范围，才能解释某个概率或平均值代表什么。



把未来观测或目标本身混入 x，会改变问题：模型学到的是更容易的条件分布，部署却拿不到相同条件。反过来，如果关键信息没有进入条件，同一个 x 可以对应多个合理结果，这种不确定性无法仅靠增加训练步数消除。需要区分观测不足、示教多样性、测量噪声与模型拟合不足，否则会把全部不可预测性都误认为网络太小。



条件概率还要求明确条件固定的层次。观察多个不同场景下动作的总体方差，混合了条件变化与同条件不确定性；要讨论策略在同一观察下的多样性，应固定该条件再重复采样。否则模型只是随输入变化，却可能被误认为已覆盖同条件多个模式。





## 联合分布、边缘化与贝叶斯更新

联合分布描述多个变量同时取值的规律，边缘化是将暂不关心的变量求和或积分，条件化是使用已知信息缩小所讨论的分布。贝叶斯公式连接这些操作：用观测对原有分布重新加权，得到观测后的分布。



条件分布来自同一个联合分布的不同分解。对离散变量 X、Y，有 \(p(x,y)=p(y\mid x)p(x)=p(x\mid y)p(y)\)。在 \(p(x)>0\) 的位置，把两种分解相等并除以 \(p(x)\)，得到贝叶斯公式；其中分母由对所有可能的 y 求和得到。连续变量将求和换为积分，公式中的 p 是相对于相应坐标测度的密度。概率为零的条件事件需要更谨慎的条件分布定义，不能直接进行 0/0 运算。



先验 \(p(y)\) 表示观察当前 x 以前对 Y 的分布；似然 \(p(x\mid y)\) 衡量不同 y 对当前观测的解释；后验 \(p(y\mid x)\) 是更新后的分布。把似然看成 y 的函数时，它通常没有在 y 上归一化，所以不能把似然曲线直接称为后验。监督分类器可以直接参数化 \(p_\theta(y\mid x)\)，无需显式训练 \(p(x\mid y)\)，但其预测仍取决于训练样本隐含的类别比例。



例如接触事件 \(Y=1\) 的先验概率为 0.1，某传感器报警在有接触时的概率为 0.9、无接触时为 0.2。报警后的接触概率是 \(\frac{0.09}{0.09+0.18}=\frac13\)，而不是 0.9。若部署时接触先验变为 0.5，且两类的报警条件分布确实保持不变，后验变为 \(\frac{0.45}{0.45+0.10}=\frac9{11}\)。这个算例说明先验改变会改变后验；它不证明真实场景一定满足类别条件分布不变。



条件变量还可以是历史 h、任务 c 或潜变量 z。边缘化 \(p(a\mid c)=\int p(a\mid z,c)p(z\mid c)\,dz\) 保留潜变量的不确定性；将 z 直接替换为其均值通常得到另一个模型，因为非线性函数的期望不等于均值处的函数值。这一差别将在 [潜变量与变分推断](#/learn/latent-variable-models) 和 [部分观测](#/learn/partial-observability) 中再次出现。



$$
p(y\mid x)=\frac{p(x\mid y)p(y)}{\sum_{y^\prime}p(x\mid y^\prime)p(y^\prime)},\qquad p(x)=\sum_y p(x,y)
$$

```python
import math

def posterior(prior, positive_if_contact=0.9, positive_if_no_contact=0.2):
    evidence = prior * positive_if_contact + (1-prior) * positive_if_no_contact
    if evidence <= 0:
        raise ValueError("conditioning event must have positive probability")
    return prior * positive_if_contact / evidence

assert math.isclose(posterior(0.1), 1/3)
assert math.isclose(posterior(0.5), 9/11)
print("posterior under two priors:", posterior(0.1), posterior(0.5))
```

保持两种报警条件概率不变，只改变类别先验，检查贝叶斯分母如何改变后验。这里的数字是构造算例，不是传感器性能数据。



## 期望、协方差与全方差分解

期望是按概率加权的平均，方差描述围绕均值的波动，协方差描述不同坐标怎样共同变化。全方差分解进一步区分条件内部的波动与条件均值之间的差异，用来判断新增信息能解释哪部分变化。



期望是对分布的加权积分，不要求随机变量的某个样本真的等于期望。若 \(X\in\mathbb R^d\) 具有有限二阶矩，均值 \(\mu=\mathbb E[X]\in\mathbb R^d\)，协方差 \(\Sigma=\mathbb E[(X-\mu)(X-\mu)^\top]\in\mathbb R^{d\times d}\)。对任意方向 \(w\in\mathbb R^d\)，\(w^\top\Sigma w=\mathbb E[(w^\top(X-\mu))^2]\ge0\)，因此协方差是半正定矩阵。对仿射变换 \(Y=AX+b\)，先减去 \(\mathbb E[Y]=A\mu+b\)，再展开外积，得到 \(\operatorname{Cov}(Y)=A\Sigma A^\top\)；平移不影响协方差。



独立且二阶矩存在时，\(\mathbb E[XY]=\mathbb E[X]\mathbb E[Y]\)，所以协方差为零；反向一般不成立。令 X 在 −1、0、1 上等概率取值、\(Y=X^2\)，则 \(\mathbb E[X]=\mathbb E[XY]=0\)，\(\operatorname{Cov}(X,Y)=0\)，但知道 X 就完全确定了 Y。对联合高斯，零交叉协方差才足以推出独立；不能把这个特殊结论推广到任意动作分布。



全期望公式 \(\mathbb E[Y]=\mathbb E[\mathbb E[Y\mid X]]\) 可以从联合分布展开：先在固定 x 下对 y 求期望，再按 \(p(x)\) 平均。令 \(m(X)=\mathbb E[Y\mid X]\)，写 \(Y-\mathbb E[Y]=(Y-m(X))+(m(X)-\mathbb E[Y])\)。平方展开后，交叉项的条件期望为 \((m(X)-\mathbb E[Y])\mathbb E[Y-m(X)\mid X]=0\)，再对 X 取期望，就得到全方差分解。



因此总体动作方差可以来自同一条件下的动作多样性，也可以来自不同场景条件之间的均值变化。若只统计整个数据集的方差，不能判断模型是否表达了同条件多峰性。下面的有限分布检验将两项精确分开，不依赖蒙特卡洛误差。对于向量，使用外积代替平方即可得到全协方差公式；条件 MSE 的均值解是同一正交分解的另一种应用。



$$
\operatorname{Var}(Y)=\mathbb E[\operatorname{Var}(Y\mid X)]+\operatorname{Var}(\mathbb E[Y\mid X]),\qquad \operatorname{Cov}(AX+b)=A\Sigma A^T
$$

```python
import torch

torch.set_default_dtype(torch.float64)
# X=0 or 1 with equal mass; two equally likely Y values per condition.
y = torch.tensor([[0., 2.], [3., 7.]])
conditional_mean = y.mean(dim=1)
within = y.var(dim=1, correction=0).mean()
between = conditional_mean.var(correction=0)
total = y.flatten().var(correction=0)
torch.testing.assert_close(total, within + between)
x = torch.tensor([-1., 0., 1.])
dependent = x.square()
cov = ((x-x.mean()) * (dependent-dependent.mean())).mean()
assert cov == 0 and dependent[1] != dependent[0]
print("total, within-condition, between-condition:", total.item(), within.item(), between.item())
```

correction=0 对这个明确的有限概率分布计算总体方差；这与用 correction=1 估计未知总体的无偏样本方差是不同问题。最后的离散反例说明零协方差不保证独立。



## 最大似然如何变成常用训练损失

似然是把已经观测到的数据代入模型后、作为参数函数来看的概率或密度。最大似然选择使这些观测最受模型支持的参数；取负对数后，就得到常见的负对数似然损失。下面说明这个目标怎样产生回归与分类训练。



固定输入 \(x_1,\ldots,x_N\)，假设模型将对应标签视为条件独立观测，则数据似然为 \(\prod_{i=1}^N p_\theta(y_i\mid x_i)\)。因为对数严格递增，最大化这个乘积等价于最大化对数之和；乘以负号并除以与参数无关的 \(N\)，得到平均负对数似然 \(L(\theta)=-\frac1N\sum_i\log p_\theta(y_i\mid x_i)\)。加法结构由概率模型与条件独立假设导出，不是为了方便代码任意指定。相邻轨迹帧未必真的独立；若模型显式描述序列依赖，应按其条件分解计算似然。



以一维回归为例，规定 \(Y\mid x\sim\mathcal N(\mu_\theta(x),\sigma^2)\)，其中 \(\sigma>0\) 固定。高斯密度包含归一化因子 \((\sqrt{2\pi}\sigma)^{-1}\) 与指数项 \(\exp[-(y-\mu)^2/(2\sigma^2)]\)。取负对数后，前者给出 \(\log\sigma+\tfrac12\log(2\pi)\)，后者给出 \((y-\mu)^2/(2\sigma^2)\)。只有当方差固定、各样本采用同一尺度时，这个目标才与普通平方误差只差正比例及与均值参数无关的常数。



如果网络也预测尺度，令 \(s_\theta(x)=\log\sigma_\theta(x)\)，单个样本的负对数似然变为 \(\ell=\tfrac12(y-\mu)^2e^{-2s}+s+\tfrac12\log(2\pi)\)。对 \(s\) 求导得到 \(\partial\ell/\partial s=1-(y-\mu)^2/\sigma^2\)：误差项倾向于扩大尺度，而对数项提供相反贡献。删去对数项便不再是高斯似然。若某个样本可被精确插值且方差不受约束，尺度还可能趋近零，因而需要结合共享参数、尺度约束或正则化定义具体模型。



二分类则可令 \(Y\in\{0,1\}\)、\(P(Y=1\mid x)=p=\sigma(z_\theta(x))\)。Bernoulli 概率质量函数为 \(p^y(1-p)^{1-y}\)，取负对数得到 \(-y\log p-(1-y)\log(1-p)\)。代入 sigmoid 并合并对数，可写成 \(\operatorname{softplus}(z)-yz\)，对 logit 的导数为 \(\sigma(z)-y\)。这个推导说明 BCEWithLogitsLoss 为什么接收未经过 sigmoid 的分数；多类别的同类推导在后面的 Softmax 小节展开。



平均单位仍是模型定义的一部分。一个多维动作可以被建模为一个联合事件，再对样本平均，也可以先形成各坐标误差并采用任务权重。下一节区分事件维、分布批维和采样维，避免把概率求和与训练平均混成一次无说明的 mean。



$$
\begin{aligned}L(\theta)&=-\frac1N\sum_{i=1}^{N}\log p_\theta(y_i\mid x_i),\\ \ell_{\rm Gaussian}&=\frac{(y-\mu)^2}{2\sigma^2}+\log\sigma+\frac12\log(2\pi),\\ \ell_{\rm Bernoulli}&=\operatorname{softplus}(z)-yz,\qquad \frac{\partial\ell}{\partial z}=\sigma(z)-y.\end{aligned}
$$

```python
import math
import torch
import torch.nn.functional as F

# 固定输入，无随机估计；每行是一条一维观测。
y = torch.tensor([-1., 0.5, 2.], dtype=torch.float64)
mu = torch.tensor([-0.4, 0.2, 1.5], dtype=torch.float64,
                  requires_grad=True)
sigma = torch.tensor([0.5, 1., 2.], dtype=torch.float64)
manual = ((y - mu).square() / (2 * sigma.square())
          + sigma.log() + 0.5 * math.log(2 * math.pi)).mean()
official = F.gaussian_nll_loss(mu, y, sigma.square(), full=True)
torch.testing.assert_close(manual, official)
g = torch.autograd.grad(manual, mu)[0]
torch.testing.assert_close(g, (mu.detach() - y) / sigma.square() / y.numel())

logits = torch.tensor([-20., 0., 20.], dtype=torch.float64,
                      requires_grad=True)
labels = torch.tensor([1., 0., 1.], dtype=torch.float64)
bernoulli = (F.softplus(logits) - labels * logits).mean()
torch.testing.assert_close(bernoulli, F.binary_cross_entropy_with_logits(logits, labels))
gz = torch.autograd.grad(bernoulli, logits)[0]
torch.testing.assert_close(gz, (logits.detach().sigmoid() - labels) / labels.numel())
print("通过：两个观测模型的 NLL 与预测梯度均符合推导。")

```

高斯例子保留完整归一化项，并对三个样本平均，因而预测梯度包含 \(1/N\)。二分类使用有限但差异很大的 logits，核对稳定表达式及其解析导数。这里检查的是同一概率模型的实现等价，不是在比较两种损失的任务性能。



### 用概率假设解释为什么选某个 loss

MSE、分类交叉熵和不确定性建模并不是任意可替换的标量函数。

写出目标的支持集、网络预测的参数及对应负对数似然，检查是否漏掉依赖参数的项。

## 连续密度、对角高斯与概率张量的维度

概率密度是连续分布在单位体积中的概率集中程度，区域概率由密度积分得到。单点密度不等于单点概率，还会随计量单位变化。对角高斯用各坐标的均值与方差表示一种简化密度，因此输出轴与概率归约轴必须分清。



连续变量的概率由密度在区域上的积分得到；某点的密度 \(p(y)\) 不是该点发生的概率。因此密度可以超过 1，负对数密度也可以为负。以标准差 0.1 的一维高斯为例，均值处密度约为 3.99，而单点概率仍为零。单位改变也会改变密度数值：若 \(y^{\prime}=ay\) 且 \(a\ne0\)，同一事件的概率保持不变，但 \(p^{\prime}(y^{\prime})=\frac{p(y)}{|a|}\)，对应 NLL 增加 \(\log|a|\)。比较连续模型的 NLL，必须统一数据单位、坐标变换与密度定义。



若给定条件 x 后，D 个目标坐标被建模为相互独立的高斯，则联合密度是各坐标密度的乘积；取负对数后，对动作坐标求和，得到公式中的对角高斯 NLL。这里的独立是模型假设，不是张量有 D 列就能证明的事实。所有坐标共享固定方差时，平均联合 NLL 与 MSE 只差正比例和常数；固定但不同的方差则产生逐维误差权重。若预测方差，\(\log\sigma\) 项不能省略，且 scale 必须为正，例如用 softplus 后加一个明确的最小尺度；该下界同时限制了模型可表达的最小方差。



在 PyTorch 中，mu、sigma 都为 [B,D] 时，Normal(mu,sigma) 的 batch_shape 是 [B,D]，event_shape 是 []；它表示 \(BD\) 个标量分布，log_prob(y) 返回 [B,D]。Independent(base,1) 将最后一个 batch 维解释为一个联合事件：batch_shape 变为 [B]、event_shape 变为 [D]，log_prob 自动沿 D 求和并返回 [B]。Independent 只重解释分布维度，不改变底层采样规则，也不引入相关性；它明确“哪些坐标共同组成一次预测”。训练时再对 B 求平均，才得到每条样本的平均联合 NLL，直接对 [B,D] 全部取 mean 会额外除以 D。



额外的 sample_shape 是重复采样次数，而不是模型参数的 batch 维。例如 sample_shape=[S] 时，样本形状为 [S,B,D]，联合 log_prob 为 [S,B]。Normal 的 rsample 使用 y=mu+sigma*epsilon 保留通过采样值传回参数的路径；sample 不保留这条路径，两者产生相同类型的分布样本，但服务于不同梯度计算。该接口也不自动处理坐标相关性或有界动作：完整协方差需要相应的多元分布，经过 tanh 等非线性变换后计算密度还需变量变换项，不能继续直接使用原高斯的 log_prob。



$$
-\log p(y\mid x)=\sum_{d=1}^{D}\left[\frac{(y_d-\mu_d)^2}{2\sigma_d^2}+\log\sigma_d+\frac12\log(2\pi)\right]
$$

```python
import math
import torch
from torch.distributions import Independent, Normal

torch.manual_seed(0)
dtype = torch.float64
mu = torch.tensor([[0., 1.], [2., -1.]], dtype=dtype, requires_grad=True)
sigma = torch.tensor([[0.1, 0.5], [1., 2.]], dtype=dtype)
y = torch.tensor([[0.05, 0.8], [2.3, -0.5]], dtype=dtype)
base = Normal(mu, sigma)
joint = Independent(base, 1)
assert base.batch_shape == torch.Size([2, 2]) and base.event_shape == torch.Size([])
assert joint.batch_shape == torch.Size([2]) and joint.event_shape == torch.Size([2])
coordinate_nll = 0.5 * ((y - mu) / sigma).square() + sigma.log() + 0.5 * math.log(2 * math.pi)
manual_nll = coordinate_nll.sum(dim=-1)
torch.testing.assert_close(manual_nll, -joint.log_prob(y))
torch.testing.assert_close(base.log_prob(y).sum(dim=-1), joint.log_prob(y))
loss = -joint.log_prob(y).mean()  # 先合成联合事件，再平均 B 条样本。
torch.testing.assert_close(loss, -base.log_prob(y).mean() * mu.shape[-1])

samples = joint.rsample((3,))
assert samples.shape == (3, 2, 2) and joint.log_prob(samples).shape == (3, 2)
assert samples.requires_grad and not joint.sample((3,)).requires_grad
sample_grad = torch.autograd.grad(samples.sum(), mu)[0]
torch.testing.assert_close(sample_grad, torch.full_like(mu, 3.))
small = Normal(torch.tensor(0., dtype=dtype), torch.tensor(0.1, dtype=dtype))
assert small.log_prob(torch.tensor(0., dtype=dtype)).item() > 0
print("每条样本 NLL:", manual_nll.detach().tolist(), "平均联合 NLL:", loss.item())
print("采样形状:", tuple(samples.shape), "联合 log_prob 形状:", tuple(joint.log_prob(samples).shape))
```

手写公式、逐坐标 log_prob 求和与 Independent 的结果逐项相等，随后检查全元素 mean 恰好多除一个 D。这里 D=2，因此两种归约不能误当作同一标量目标。rsample 的三次采样对 mu 的导数累计为 3，验证采样路径确实保留；这只是重参数化的局部检查，并不声称任意强化学习目标都应沿该路径求导。最后的正 log_prob 展示了密度大于 1 的合法情形。



## 多元高斯、白化与条件分布

多元高斯是由均值向量和协方差矩阵确定的连续分布。协方差决定不同方向的尺度与相关性；白化把这些尺度和相关性变换成单位协方差。先理解这个几何结构，才能解释条件高斯和对应的损失。



非退化 d 维高斯用均值 \(\mu\in\mathbb R^d\) 和对称正定协方差 \(\Sigma\in\mathbb R^{d\times d}\) 参数化。其负对数密度包含三项：Mahalanobis 二次型、\(\log\det\Sigma\) 和维度常数。若只保留二次型并同时学习 \(\Sigma\)，模型可以通过扩大协方差降低该项；log det 项参与平衡，不能从可学习方差的目标中删除。协方差为奇异矩阵时，分布位于低维子空间，不能继续使用普通 d 维密度公式。



令 \(\Sigma=LL^\top\) 为 Cholesky 分解，求解 \(Lz=y-\mu\) 后，二次型等于 \(\lVert z\rVert_2^2\)，\(\log\det\Sigma=2\sum_i\log L_{ii}\)。这给出白化的几何解释：相关误差先变为无相关、单位尺度的坐标，再计算平方长度。实现中求解三角系统比显式构造 \(\Sigma^{-1}\) 更合适；仅按每个坐标的标准差缩放只消除边际尺度，不会一般性地消除相关性。



将联合高斯分成 \(X\in\mathbb R^{d_x}\) 与 \(Y\in\mathbb R^{d_y}\)，协方差按 XX、XY、YX、YY 分块。定义残差 \(R=Y-\mu_Y-\Sigma_{YX}\Sigma_{XX}^{-1}(X-\mu_X)\)。展开协方差可得 \(\operatorname{Cov}(R,X)=\Sigma_{YX}-\Sigma_{YX}\Sigma_{XX}^{-1}\Sigma_{XX}=0\)；由于 (R,X) 仍是联合高斯，R 与 X 独立。因此给定 \(X=x\) 后，Y 的均值由线性校正项给出，剩余协方差为 \(\Sigma_{YY}-\Sigma_{YX}\Sigma_{XX}^{-1}\Sigma_{XY}\)，即 Schur 补。此处要求 \(\Sigma_{XX}\) 可逆，且独立性这一步依赖联合高斯假设。



条件高斯解释了线性观测为什么能够减少不确定性，也为扩散模型的高斯后验提供代数工具。它并不意味着真实机器人动作一定服从单峰高斯：对角高斯、完整协方差高斯和潜变量混合分别限制了不同层面的表达能力。下面先对照手写 NLL 与 PyTorch 的多元高斯，再核验一个相关二维高斯的条件均值和方差。



$$
\begin{aligned}-\log p(y)&=\tfrac12[(y-\mu)^T\Sigma^{-1}(y-\mu)+\log\det\Sigma+d\log(2\pi)]\\\mathbb E[Y\mid X=x]&=\mu_Y+\Sigma_{YX}\Sigma_{XX}^{-1}(x-\mu_X)\\\operatorname{Cov}(Y\mid X)&=\Sigma_{YY}-\Sigma_{YX}\Sigma_{XX}^{-1}\Sigma_{XY}\end{aligned}
$$

```python
import math
import torch

torch.set_default_dtype(torch.float64)
mu = torch.tensor([0., 1.])
cov = torch.tensor([[1., .8], [.8, 4.]])
value = torch.tensor([[.5, 2.], [-1., 0.]])  # [B=2,D=2]
chol = torch.linalg.cholesky(cov)
white = torch.linalg.solve_triangular(chol, (value-mu).T, upper=False).T
manual = .5 * (white.square().sum(-1) + 2*chol.diag().log().sum() + 2*math.log(2*math.pi))
reference = -torch.distributions.MultivariateNormal(mu, cov).log_prob(value)
torch.testing.assert_close(manual, reference)
gain = torch.linalg.solve(cov[:1, :1], cov[:1, 1:]).T
conditional_mean = mu[1:] + gain @ (torch.tensor([2.])-mu[:1])
conditional_cov = cov[1:, 1:] - gain @ cov[:1, 1:]
torch.testing.assert_close(conditional_mean, torch.tensor([2.6]))
torch.testing.assert_close(conditional_cov, torch.tensor([[3.36]]))
print("NLL:", manual.tolist(), "conditional mean/cov:", conditional_mean.tolist(), conditional_cov.tolist())
```

批次轴 B 与事件轴 D 分开，三角求解后仅沿事件轴求和。条件高斯使用 solve 而非逆矩阵；1.6 的均值修正来自相关性，剩余方差 3.36 小于原方差 4。



## 平方误差为何学到条件均值

条件均值是固定输入信息以后，对所有可能目标取概率加权平均。平方误差的总体最优预测正是这个均值，而不一定是某个真实出现过的目标。下面通过风险分解说明为什么会平均，以及剩余误差意味着什么。



固定一个条件 x，令 \(\mu(x)=\mathbb E[Y\mid x]\)，并假设 Y 有有限二阶矩。把 \(Y-c\) 写成 \((Y-\mu)+(\mu-c)\)，平方展开后的交叉项为 \(2(\mu-c)\mathbb E[Y-\mu\mid x]=0\)。因此 \(\mathbb E[(Y-c)^2\mid x]=\operatorname{Var}(Y\mid x)+(\mu-c)^2\)；不可约的条件方差与预测偏离条件均值的误差被精确分开。结论来自平方损失，不要求网络是线性的。



对不受函数族限制的确定性预测，每个 x 的最优值都是 \(\mu(x)\)。真实网络共享有限参数，只能在可表达的函数中近似这个解，还受数据量和优化影响。“MSE 学到均值”不等于每个训练后的网络已经等于均值；也不等于换一个更大的网络就会改变该损失偏好的统计量。



若目标带非负数据权重 \(w(x,Y)\)，在 \(\mathbb E[w\mid x]>0\) 且相关矩有限时，对 c 求导可得最优值 \(c^*=\frac{\mathbb E[wY\mid x]}{\mathbb E[w\mid x]}\)。权重只依赖 x 且为正时，它在固定条件下抵消，条件均值不变；权重依赖标签、成功与否或动作模式时，一般会得到重新加权的条件均值。缺失标签的 Mask 也在选择条件分布，不能默认筛选前后是同一统计目标。



若同一条件下动作 −1 和 +1 等概率出现，确定性 MSE 偏好 0，而 0 未必可执行。若再给 +1 的样本三倍权重，最优预测变成 0.5，仍未必位于有效模式上。增加消歧条件可以改变条件分布；生成式模型可以表示多个模式。L1 在一维对应条件中位数，也不能仅靠换成 L1 就表达整个多峰分布。



$$
\mathbb E[(Y-c)^2\mid x]=\operatorname{Var}(Y\mid x)+(\mu(x)-c)^2,\qquad c_w^*(x)=\frac{\mathbb E[wY\mid x]}{\mathbb E[w\mid x]}
$$



### 例：同一条件下两个动作模式

1. 目标 Y 以 \(\frac12\) 概率为 -1，以 \(\frac12\) 概率为 +1。

2. 预测 0 的期望平方误差为 1；总预测 +1 的期望平方误差为 \(\frac{4+0}{2}=2\)。

3. 平方误差因此偏好 0，即使训练目标从来没有取过 0。

4. 若为 +1 设置权重 3、为 −1 设置权重 1，最优单点变为 \(\frac{3-1}{3+1}=0.5\)；数据频率没变，训练偏好已经改变。

平均误差最优与“预测是一个合理动作样本”是两个问题。

### 将低 MSE 当作多模态动作建模成功

一个确定性均值可以压低平方误差，却落在两个有效模式之间。

固定相同条件观察目标分布，分别检查均值误差、模式覆盖和闭环结果。

## logits、Softmax 和交叉熵的职责

Logit 是模型给出的未归一化类别分数，Softmax 将一组分数变成概率，交叉熵衡量这些概率对真实类别的支持程度。这是输出、概率解释和训练目标三个不同环节；先分清职责，再推导梯度。



logits 是未归一化的实数分数，不要求非负，也不要求和为 1。Softmax 把分数映射成类别概率：\(p_k=\frac{\exp(z_k)}{\sum_j\exp(z_j)}\)。给所有 logits 加同一常数不改变概率，说明可辨识的是类别间相对差异。对单个正确类别 y，交叉熵为 \(-\log p_y\)；框架的 CrossEntropyLoss 直接接收 logits，内部采用稳定的对数归一化。



把 \(-\log p_y\) 对 logits 求导时，log 的 \(\frac1{p_y}\) 与 Softmax 导数中的 \(p_y\) 抵消，得到 \(p-\operatorname{one\_hot}(y)\)。所以即使模型极度自信地预测错类，正确类的 logit 梯度仍可接近 −1；不能仅凭“Softmax 饱和”就断言交叉熵的 logit 梯度消失。二阶导为 \(\operatorname{diag}(p)-pp^\top\)，公共平移方向的曲率为零，呼应了所有 logits 同加常数不改变概率。这个结论针对 logits；传回早层的梯度还要乘模型 Jacobian，仍可能因其他环节变小。



先 Softmax 再传给 CrossEntropyLoss，会把概率再次当作 logits，改变目标与梯度。类别索引通常是 [B] 的 long，而模型输出为 [B,C]；对序列输出 [B,T,C]，要重排或展平到损失 API 所要求的类别轴。目标也可以是概率分布，但形状、dtype、权重与忽略标签的规则需要按对应输入形式核对，不能混用。



标签平滑把原本集中在正确类别上的目标质量分配一部分给其他类别，因此改变训练目标分布；它不是仅在推理时改变温度。两者都可能影响置信度，但作用阶段、梯度与实验解释不同。比较时应说明平滑强度及目标的构造方式，避免把所有概率变平都视为同一种校准。



$$
\ell(z,y)=\log\sum_j e^{z_j}-z_y,\qquad \frac{\partial\ell}{\partial z_k}=p_k-\mathbf1[k=y]
$$



### 例：从 logits 手算分类损失

1. 取两类 \(\mathrm{logits}=[0,\log3]\)，Softmax 为 \([\tfrac14,\tfrac34]\)。

2. 若正确类别是第二类，交叉熵为 \(-\log\frac34\approx0.28768\)。

3. 对两个 logits 的梯度分别为 0.25 和 -0.25：梯度下降会降低错误类分数、提高正确类分数。

损失的概率解释、数值和梯度方向应能相互核对。

## 稳定的 log-sum-exp 与温度缩放

log-sum-exp 是一组数取指数、求和再取对数的运算，常用作概率归一化项；温度则调节分数差对概率集中程度的影响。前者需要稳定计算，后者会改变所表示的分布，不能把二者都理解成数值技巧。



直接计算 \(\exp(1000)\) 会溢出，而 Softmax 对统一平移不变，所以可先减去最大 logit。log-sum-exp 写成 \(m+\log\sum_j\exp(z_j-m)\)，避免指数落在过大的范围；log_softmax 直接得到对数概率，避免先算一个极小概率再取对数。稳定实现保留原数学目标；直接截断分数则可能改变模型。



温度 \(\tau\) 通过 \(\frac z\tau\) 改变概率分布的尖锐程度。\(\tau\) 小时更集中，大时更平缓；正温度不改变最大 logit 的类别，但会改变置信度、采样分布和梯度尺度。将验证温度用于校准，与改变训练目标不是同一实验。判断分类器是否可靠时，准确率只检查最大类是否正确，校准还关心声称的概率与实际频率是否匹配。





### 把置信度变高当成表征变好

降低温度可以提高最大概率，却不增加模型输入的信息，也不一定提高准确率。

同时报告准确率、概率校准和任务指标，记录温度使用在训练还是推理阶段。

## 熵、交叉熵与 KL 的方向不能混淆

熵描述一个分布自身的不确定性，交叉熵描述用另一分布预测它时的平均对数代价，KL 散度衡量两者在指定方向上的差异。它们相关但用途不同；是否能省去某一项，取决于哪一个分布保持固定。



熵 \(H(p)\) 衡量分布自身的不确定程度；交叉熵 \(H(p,q)\) 衡量按 q 编码来自 p 的结果的平均代价。二者关系为 \(H(p,q)=H(p)+D_{\mathrm{KL}}(p\Vert q)\)。当 p 固定时，最小化交叉熵等价于最小化这个方向的 KL；若 p 也是可训练对象，则不能将 \(H(p)\) 作为常数省略。KL 不对称，也不是普通欧氏距离。



KL 非负可以由 Jensen 不等式解释。假设 p 的支持上 \(q>0\)，则 \(\mathbb E_p\!\left[\log\frac qp\right]\le\log\mathbb E_p\!\left[\frac qp\right]\le0\)；最后一个不等式来自 q 在 p 的支持上总质量至多为 1。取负号得到 \(D_{\mathrm{KL}}(p\Vert q)\ge0\)，等号在分布一致时成立。离散交叉熵展开为 \(-\sum p\log q=-\sum p\log p+\sum p\log\frac pq\)，于是得到熵与 KL 的分解，省略熵项的前提是目标 p 固定。



蒸馏常让教师分布作为固定目标，学生提供对数概率。PyTorch KLDivLoss 的 input 通常为 \(\log q\)，target 为 p，按这些参数计算的是 \(D_{\mathrm{KL}}(p\Vert q)\)，参数顺序与书上 p、q 的位置容易被读反。reduction="batchmean" 在按样本分布建模时对应每样本 KL；mean 会再平均类别元素。对于变长 token 还需有效位计数，不能只看到 API 名称就认为归约含义正确。



KL 还依赖支持集关系：若 p 在某类别上有正概率而 q 给零概率，\(D_{\mathrm{KL}}(p\Vert q)\) 会发散。使用对数空间能改善数值表示，却不改变这个数学事实。将 q 任意加 \(\varepsilon\) 后重新归一化，是修改分布而非精确实现原 KL，应该区分数值近似与目标定义。



连续变量可以在相关积分存在时得到相同的代数分解，但微分熵依赖坐标单位，也可能为负。有限连续样本组成的经验分布是点质量的集合，不能不加说明地把它与连续密度模型之间的 KL 当成一个有限数值；训练中实际计算的是样本上的平均负对数密度。总体负对数似然与 KL 的联系应在真实数据分布具有相应密度的假设下解释。



$$
D_{KL}(p\|q)=\sum_k p_k\log\frac{p_k}{q_k},\qquad H(p,q)=H(p)+D_{KL}(p\|q)
$$



## 经验平均、采样分布与权重共同定义训练任务

经验平均是用有限样本的平均近似分布期望，采样权重决定哪些样本更常进入这个平均。改变抽帧、抽轨迹或抽任务的概率，也就在改变实际训练的分布。下面把采样和损失权重放在同一个目标中解释。



训练数据来自采集和筛选流程，未必等于部署分布。均匀抽帧使长轨迹更常出现，均匀抽轨迹再抽帧则给短轨迹更大相对权重；任务混合比同样改变实际优化的期望。若为了覆盖少数任务而过采样，再加一次逆频率权重，可能重复补偿。讨论“数据量”时应同时说明采样单位与抽样概率。



重要性加权可在支持集覆盖等条件下把一个分布下的期望改写为另一个分布下的期望，但极大权重会增加估计方差，截断权重又引入偏差。这不是必须在所有项目采用的技巧，而是提醒：数据采样不是训练目标之外的中性操作。至少建立不加权基线，按任务分别报告误差，并审查权重分母与有效标签是否一致。





## 输出参数化与评估

输出参数化是用某一组数值描述预测对象的约定，例如类别分数、均值与方差、噪声或速度。相同张量形状可以承载不同对象，因此必须先定义输出是什么，再选择损失、解码与评估方式。



阅读模型代码时先问网络输出是什么：类别 logits、分布均值、方差、噪声、速度，还是其他参数。张量都可能是 [B,H,D]，但只有理解输出含义，才能决定目标、损失和推理解码。比如生成模型回归速度的平方误差，并不直接等于最终动作空间的负对数似然，也不能无推导地用它比较两种参数化的模型质量。



从 logits 手算交叉熵，可以核对输出、概率、损失与梯度是否一致。评估还需检查分组结果、置信度和输入分布变化：一个数据集上的低平均损失可能被大量容易样本主导。错误标签、未来信息泄漏和错误归约也能产生看似良好的曲线，需要配合样本审查与独立验证。



若想证明条件真的被利用，可以固定图像或状态，仅替换一个有语义差异的指令，检查预测是否作出合理变化。条件敏感只是必要证据，随机扰动引起的任意变化不等于正确理解；需要构造有明确预期的对照。这样才能从“概率公式正确”走向“模型优化的是预期问题”。



概率语言把条件、随机结果和平均目标连接起来：先说明可用信息，再选分布与损失，最后用与目标一致的采样和指标检验。条件均值、似然和生成速度分别描述不同对象，不能因输出形状相同而互换。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| logits | [B,C] | 每条样本对 C 个类别的未归一化分数 |
| target | [B] | long 类型的正确类别索引 |
| log_prob | [B,C] | 稳定计算的对数概率 |

## 完整代码与精读

```python
import torch
import torch.nn.functional as F

torch.manual_seed(0)
# STEP 1: 每条样本的 logits 对应一个类别分布
logits = torch.tensor([[2., 0., -1.], [0.5, 1., 3.]],
                      dtype=torch.float64, requires_grad=True)
target = torch.tensor([0, 2], dtype=torch.long)
log_prob = F.log_softmax(logits, dim=-1)
selected = log_prob.gather(1, target[:, None]).squeeze(1)
manual_ce = -selected.mean()
builtin_ce = F.cross_entropy(logits, target)
assert torch.allclose(manual_ce, builtin_ce)
print("cross entropy:", manual_ce.item())

# STEP 2: 共同平移 logits 不改变概率
shifted = F.log_softmax(logits + 10000, dim=-1)
assert torch.allclose(shifted, log_prob, atol=1e-10)
manual_ce.backward()
print("gradient:", logits.grad.tolist())

# STEP 3: 明确 KL 的方向与 API 的输入约定
p = torch.tensor([[0.8, 0.2]], dtype=torch.float64)
q = torch.tensor([[0.5, 0.5]], dtype=torch.float64)
manual_kl = (p * (p.log() - q.log())).sum(dim=-1).mean()
# kl_div 的第一个输入是 log(q)，第二个输入是 p
api_kl = F.kl_div(q.log(), p, reduction="batchmean")
assert torch.allclose(manual_kl, api_kl)
print("KL(p||q):", manual_kl.item())
choices = torch.tensor([-1.0, 1.0])
print("two-mode MSE optimal point:", choices.mean().item())

```

- 第 5–15 行：gather 为每条样本取出正确类别的对数概率；负号和 mean 就得到平均 NLL。
- 第 16–21 行：log_softmax 避免先指数化大数；反向梯度会提高真实类别相对其他类别的分数。
- 第 22–31 行：API 参数顺序应以接口定义为准。最后一个例子展示单点回归可能落在两个动作模式之间。

预期观察：手工交叉熵与内置结果一致；共同平移 logits 后概率不变；\(D_{\mathrm{KL}}(p\Vert q)\) 约为 0.192745；两个对称模式的 MSE 均值是 0。

## 浏览器 Python 练习

输入非空 logits 列表，输出概率列表。必须能处理 [1000,1001,999]，并且整体平移 logits 后结果不变。

```python
import math

def stable_softmax(logits):
    # TODO: 在取 exp 之前使用平移不变性
    raise NotImplementedError("请实现 stable_softmax")

```

### 提示

- 让最大的指数输入变为 0，其他输入非正。
- 每个指数值除以同一组指数值之和。

### 参考实现与解释

```python
import math

def stable_softmax(logits):
    if not logits:
        raise ValueError("logits 不能为空")
    maximum = max(logits)
    exps = [math.exp(z - maximum) for z in logits]
    total = sum(exps)
    return [value / total for value in exps]

```

减最大值没有改变概率比值，却避免了正方向指数溢出；非常小的概率仍可能下溢，这是有限精度的限制。

### 断言测试

```python
p = stable_softmax([1000., 1001., 999.])
q = stable_softmax([0., 1., -1.])
assert abs(sum(p) - 1.) < 1e-12
assert all(abs(a-b) < 1e-12 for a, b in zip(p, q))
assert abs(p[1] / p[0] - math.e) < 1e-12
assert stable_softmax([0., 0.]) == [0.5, 0.5]
try:
    stable_softmax([])
except ValueError:
    pass
else:
    raise AssertionError("空输入应显式拒绝")
print("通过：稳定性、归一化与平移不变性。")

```

## 本地 PyTorch 练习

只使用 logsumexp、gather 和基础运算实现平均分类 NLL。不要先 softmax，也不要调用 cross_entropy。

```python
import torch

def categorical_nll(logits, target):
    # TODO: 返回一个可反向传播的标量
    raise NotImplementedError("请实现 categorical_nll")

```

### 提示

- 每条样本的负对数似然等于 logsumexp(logits) 减正确类别的 logit。
- 用 target[:,None] 配合 gather，最后只对样本维求平均。

### 参考实现与解释

```python
import torch

def categorical_nll(logits, target):
    log_partition = torch.logsumexp(logits, dim=-1)
    correct_score = logits.gather(1, target[:, None]).squeeze(1)
    return (log_partition - correct_score).mean()

```

categorical_nll 直接在 log 空间计算，不先做可能下溢的概率再取 log。测试同时比较损失、梯度和整体平移不变性，防止仅得到近似数值却改变了训练方向。这里使用类别索引标签；软标签或序列 Mask 需要另行定义归约。

### 断言测试

```python
import torch.nn.functional as F
torch.manual_seed(3)
z = torch.randn(4, 5, dtype=torch.float64, requires_grad=True)
y = torch.tensor([0, 2, 1, 4])
a = categorical_nll(z, y)
b = F.cross_entropy(z, y)
assert a.ndim == 0 and torch.allclose(a, b)
ga = torch.autograd.grad(a, z, retain_graph=True)[0]
gb = torch.autograd.grad(b, z)[0]
assert torch.allclose(ga, gb, atol=1e-10)
assert torch.allclose(categorical_nll(z + 1000, y), b, atol=1e-10)
print("PyTorch 测试通过：损失和梯度均一致。")

```

## 练习：推导与分析

### CrossEntropyLoss、log_softmax 和 NLLLoss 的输入分别是什么？为什么不应先 softmax 再传 CrossEntropyLoss？

类别索引监督下，CrossEntropyLoss 接收未归一化 logits；log_softmax 把 logits 变成对数概率；NLLLoss 接收对数概率并选取正确类别。log_softmax 与 NLLLoss 的组合对应交叉熵。

先 softmax 再传 CrossEntropyLoss 会把概率误当作新的 logits，再归一化一次，损失与梯度都改变。代码用 logsumexp−正确分数独立还原目标，并检验共同平移 logits 后结果不变。

代码定位：categorical_nll 的 logsumexp/gather；演示 F.log_softmax 与 F.cross_entropy 对照。

- 能说明三个接口的输入空间。
- 能解释重复 softmax 改变了函数，而不只是多做一次计算。

### MSE 的条件均值结论在加权、标准化和缺失标签下还成立吗？

普通平方误差的最优值是 E[Y|x]。使用非负数据权重后，应重新求导得到 E[wY|x]/E[w|x]；若 w 只由 x 决定且非零，固定 x 时会抵消。若权重偏向某类标签或成功轨迹，通常会改变最优均值。

固定的逐维正尺度 \(s_d\) 对误差施加 \(\frac1{s_d^2}\) 权重。对不受限制的向量预测，每一维的最优条件均值仍不变；对共享参数、有限容量的模型，各维竞争以及优化轨迹却可能改变。必须区分统计最优解与受限制模型的训练结果。

只在标签有效处训练时，学到的首先是所观察标签分布下的目标。只有在给定 x 后有效性不再依赖 Y 等相应条件下，才可以把它解释成未筛选总体的条件均值。Mask 解决了参与计算的问题，不会自动修复选择偏差。

代码定位：平方误差展开与加权最优值；losses 课程中的有效分子、分母。

- 能推导加权条件均值，而不只背诵 MSE 的结论。
- 能区分权重依赖输入、标签和模型参数三种情况。

## 练习：辨析与纠错

### 把概率密度当成离散概率

连续变量在单点的概率为零，密度可以大于 1，负对数密度也可能为负。不要把回归分布的 NLL 数值直接套入分类概率的直觉。

### 向 CrossEntropyLoss 传 Softmax 结果

接口会再次对输入做对数归一化，得到另一目标。训练时传 logits；需要展示概率或采样时再显式转换。

### KL 参数位置和数学方向反了

先写目标 \(D_{\mathrm{KL}}(p\Vert q)\)，再确定教师 p 与学生 q 各由哪个参数提供。检查 target 是否概率、input 是否对数概率，以及 reduction 的分母。

### 同条件多种动作却只看平均误差

平均预测可能位于多个模式之间。检查条件信息是否充分，并用样本分布和真实任务指标判断是否需要分布式输出或生成式建模。

## 原始资料

- [PyTorch：CrossEntropyLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html)
- [PyTorch：KLDivLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.KLDivLoss.html)
- [Deep Learning：Probability and Information Theory](https://www.deeplearningbook.org/contents/prob.html)
- [PyTorch：数值准确性与稳定计算](https://docs.pytorch.org/docs/stable/notes/numerical_accuracy.html)
- [Goodfellow、Bengio、Courville：Deep Feedforward Networks，条件均值与输出损失](https://www.deeplearningbook.org/contents/mlp.html)
- [PyTorch：Probability distributions，Normal、Independent 与重参数化采样](https://docs.pytorch.org/docs/stable/distributions.html)
- [PyTorch：GaussianNLLLoss 的完整高斯目标](https://docs.pytorch.org/docs/stable/generated/torch.nn.GaussianNLLLoss.html)
- [PyTorch：BCEWithLogitsLoss 与 Bernoulli 负对数似然](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html)
