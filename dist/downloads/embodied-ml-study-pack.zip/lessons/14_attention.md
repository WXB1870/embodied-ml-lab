# 注意力：匹配、聚合与梯度

Q/K/V、Softmax 竞争、多头布局与可见性。

注意力（Attention）是一种按当前内容分配权重、再汇总候选信息的计算机制。它用 Query 与 Key 计算匹配程度，把分数归一化后读取对应的 Value，因此同一组候选可以对不同查询产生不同结果。它是可组合的算子，Transformer 则是包含它的完整网络架构。本章先完成一次读取，再解释缩放、梯度、多头与可见性，最后核对实现。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [MLP：表达、梯度与优化](https://wxb1870.github.io/embodied-ml-lab/learn/mlp/)

## Q/K/V 与加权读出

Query 是发起读取的查询表示，Key 是候选位置参与匹配的表示，Value 是候选位置提供的内容。一次注意力先匹配 Query 与各 Key，再按权重汇总对应 Value。先把这三个计算角色分清，后面的投影和矩阵形式才有明确含义。



注意力把一次信息读取拆成匹配和汇总。Query 描述当前位置要找什么，Key 描述每个候选位置怎样被检索，Value 是被读取的内容。对一个 Query，与所有 Key 点积得到一行分数，再归一化为权重，对 Value 加权求和。Key 和 Value 一一对应，但不必数值相同；Value 的通道宽度也可与 Query/Key 不同。输出的位置数量由 Query 决定，而不是由被读取的序列长度决定。

![Transformer 原论文 Figure 2：左为缩放点积注意力，Q 与 K 打分、缩放、可选掩码、Softmax 后汇总 V；右为多头注意力。](../assets/figures/attention-vaswani-figure2.png)

先自下而上读左图：Q 与 K 先打分，Scale 对应除以匹配维度的平方根，SoftMax 将分数变成权重，最后用权重汇总 V。Mask 是可选步骤。右图把这一过程并行执行多次，再合并各头。原图：[Vaswani et al., 2017, Figure 2](https://arxiv.org/abs/1706.03762)；依论文首页的学术图表复用许可使用，[出处与许可说明](/assets/figures/attention-figure2-LICENSE.txt)。

设查询端输入为 \(x_i\in\mathbb R^{d_x}\)，候选端输入为 \(z_j\in\mathbb R^{d_z}\)，为突出匹配结构先省略偏置。学习投影 \(q_i=W_Qx_i\)、\(k_j=W_Kz_j\)、\(v_j=W_Vz_j\)，其中 \(W_Q\in\mathbb R^{d_k\times d_x}\)、\(W_K\in\mathbb R^{d_k\times d_z}\)、\(W_V\in\mathbb R^{d_v\times d_z}\)。点积可展开为 \(q_i^\top k_j=x_i^\top W_Q^\top W_Kz_j\)，因此匹配规则本身由数据学习；它是一个双线性打分，并不预设某种物理相似度。分开的 \(W_V\) 允许网络用一组特征匹配、读取另一组内容。三种投影是常见设计，并不是所有注意力形式都必须采用的唯一结构。



Self-Attention 中 Q、K、V 通常来自同一组输入的三种线性投影，并不意味着它们相同；Cross-Attention 中 Query 可来自动作状态，Key/Value 来自视觉语言条件。学到的权重表示该次计算如何组合 Value，不等于可直接解释为物理接触概率或因果重要性。即使某个位置权重大，其 Value 也可能很小，且后续投影、残差和层间传播都会影响最终输出。



对一个固定查询，令 \(s_j=q^\top k_j/\sqrt{d_k}\)，再令 \(a_j=\exp(s_j)/\sum_r\exp(s_r)\)。权重非负且总和为一，于是 \(o=\sum_j a_jv_j\) 是当前 Value 集合的凸组合。它可看作在候选索引上的离散分布下读取 Value 的期望；概率分布描述这次读取，不代表候选的真实世界概率。Mask 会先限制这个候选集合，输出投影和残差则发生在这一读出之后。





## 点积方差与缩放因子

缩放点积注意力先用 Query 与 Key 的点积打分，再按每头匹配维度的平方根调整尺度。这个缩放用于避免维度增大时典型分数差异过大；它并不保证任意训练状态下分数方差恒定。下面说明推导需要哪些假设。



设 \(q,k\in\mathbb R^{d_k}\) 独立，且坐标对 \((q_r,k_r)\) 在不同 \(r\) 之间独立；每个分量均为零均值，方差分别为 \(\sigma_q^2\)、\(\sigma_k^2\)。因此 \(\mathbb E[q_rk_r]=0\)，\(\operatorname{Var}(q_rk_r)=\mathbb E[q_r^2]\mathbb E[k_r^2]=\sigma_q^2\sigma_k^2\)。点积是这些乘积的和，展开方差得到



\[\operatorname{Var}(q^\top k)=\sum_r\operatorname{Var}(q_rk_r)+2\sum_{r<s}\operatorname{Cov}(q_rk_r,q_sk_s)=d_k\sigma_q^2\sigma_k^2.\]最后一步使用了不同坐标对的独立性。除以 \(\sqrt{d_k}\) 后，方差变为 \(\sigma_q^2\sigma_k^2\)；只有这两个方差均为一时才得到单位方差。同一 token 生成的 Q/K 尤其不能无条件认为独立；相关坐标、非零均值或训练后的投影都会改变这个估计。缩放不是对任意输入分布成立的归一化恒等式。



Softmax 只取决于分数差。把一行分数整体放大，会使其更偏向较大者；如果存在唯一最大值，尺度趋大时就趋向单点分布。下一节的导数包含 \(a_j(1-a_j)\) 等项，因此过尖分布中的许多分数梯度会变小。平方根缩放用于控制典型初始化尺度，但不能替代对实际 logits、注意力熵和梯度的观察。



代码中应按每个头的 Query/Key 宽度缩放，而不是完整模型宽度 D、序列长度 T 或 Value 宽度。若还有温度、可学习尺度或 QK normalization，要把所有缩放合并理解，避免在调用已经内置缩放的 SDPA 前后再重复除一次。数值排查时观察 logits 的分布与每行熵，比只检查注意力输出是否有限更容易识别过尖或过平的权重。



$$
\operatorname{Var}\!\left(\frac{q^\top k}{\sqrt{d_k}}\right)=\sigma_q^2\sigma_k^2\quad\text{在所述独立、零均值和等方差假设下}. 
$$



### 缩放维度是每个头的 \(d_k\)

多头拆分后每个点积只累加 \(d_k\) 个乘积，使用完整 D 会改变权重温度。

手写实现与 SDPA 对照时只保留一处缩放，给 \(d_k\) 和序列长度选择不同数值。

## Softmax 的竞争与读出梯度

Softmax 将一组分数转换为非负、和为一的权重；一项分数变化会通过共同分母影响整组权重。注意力读出再用它们汇总 Value。下面先明确归一化集合，再追踪这种竞争怎样影响梯度。



分数张量通常为 [B,H,L,S]。每个 Query 要在 S 个 Key 中分配权重，因此 Softmax 沿最后一轴；沿 L 轴则是在让不同 Query 争夺同一个 Key，形状相同但问题变了。Softmax 对共同平移不敏感，稳定实现因此先减行最大值。无 Dropout 且存在有效 Key 时，一行权重和为 1；对权重施加 Dropout 后，单次前向的行和未必仍为 1。



把归一化分母记为 \(Z=\sum_r e^{s_r}\)，则 \(a_i=e^{s_i}/Z\)。商法则逐项给出 \[\frac{\partial a_i}{\partial s_j}=\frac{\delta_{ij}e^{s_i}Z-e^{s_i}e^{s_j}}{Z^2}=a_i(\delta_{ij}-a_j).\]这里 \(\delta_{ij}\) 是相等索引取一、否则取零的 Kronecker 符号。再对 \(o=\sum_i a_i v_i\) 求导：\(\partial o/\partial s_j=\sum_i v_i a_i(\delta_{ij}-a_j)=a_jv_j-a_j\sum_i a_iv_i=a_j(v_j-o)\)。



由此可见，Jacobian 的对角项是 \(a_i(1-a_i)\)，非对角项是 \(-a_i a_j\)：提高一个候选分数，会从其他候选处拿走概率质量。读出的变化方向为 \(v_j-o\)，即从当前均值朝该候选内容移动。若上游列梯度为 \(g=\nabla_oL\)，分数梯度就是 \(\partial L/\partial s_j=a_jg^\top(v_j-o)\)，而 Value 路径为 \(\nabla_{v_j}L=a_jg\)。两种梯度来自不同路径，不应只观察其中一种。



权重大不等于影响大。所有 Value 相同时，任意 logits 都读出同一个向量，Q/K 路径的梯度为零；V 路径仍能得到梯度。分布接近单点时，未选位置的 \(a_j\)很小，选中位置的 \(v_j-o\) 也很小，分数梯度因而容易变小。若直接把注意力热图当作解释，这两种反例都会被漏掉。



代码使用 \(\mathrm{logits}=[0,\ln3]\)、\(V=[0,2]\)，得到权重 [1/4,3/4]、输出 1.5，以及对两个 logits 的梯度 [−0.375,0.375]。梯度和为零对应共同平移不变性。然后把 Value 改成相同数，观察权重仍不均匀，但分数梯度消失。



$$
\frac{\partial a_i}{\partial s_j}=a_i(\delta_{ij}-a_j),\qquad \frac{\partial o}{\partial s_j}=a_j(v_j-o)
$$

```python
import math
import torch

s = torch.tensor([0., math.log(3.)], dtype=torch.float64, requires_grad=True)
v = torch.tensor([0., 2.], dtype=torch.float64)
a = s.softmax(-1)
out = a @ v
grad, = torch.autograd.grad(out, s, retain_graph=True)
manual = a * (v - out)
torch.testing.assert_close(grad, manual)
torch.testing.assert_close(grad, torch.tensor([-.375, .375], dtype=s.dtype))
same_values = torch.full_like(v, 2.)
zero_grad, = torch.autograd.grad(a @ same_values, s)
torch.testing.assert_close(zero_grad, torch.zeros_like(s))
print("读出 / 分数梯度:", out.item(), grad.tolist())
print("相同 Value 的分数梯度:", zero_grad.tolist())

```

autograd 求的是输出对 logits 的导数，manual 按 \(a_j(v_j-o)\) 独立计算。保留第一次图只是为了在同一 Softmax 上更换 Value；实际训练不会为了这个实验而反复 retain_graph。



### 例：从两项 logits 算出输出

1. 设一行 logits 为 [0, ln 3]，Softmax 权重就是 [1/4,3/4]。

2. Value 分别为 [2,0] 与 [0,4]，输出为 [0.5,3]。

3. 只交换 Value 而不交换 Key，权重不变但输出改变；若 Key 与 Value 一起交换，最终输出保持不变。

Q/K 决定权重，V 决定被组合的内容，二者职责可以用干预分开验证。

## 多头拆分与轴顺序

多头注意力是在多个投影子空间中分别计算注意力、再合并读出的机制。各头可以形成不同的候选权重，而不是把同一结果简单复制。拆头与合头是对通道的重排，需要保留每个 Token 的身份。



每个头 \(h\) 使用自己的 \(W_Q^{(h)},W_K^{(h)},W_V^{(h)}\)，得到 \(O^{(h)}=A^{(h)}V^{(h)}\)。不同头可以对同一组候选形成不同的权重矩阵，再将读出沿通道拼接并通过 \(W_O\) 混合。单头让所有 Value 通道共享同一行位置权重，多头允许不同内容子空间采用不同权重；这解释了结构增加的选择空间，但不保证训练后每个头都具有不同功能。



令模型宽度 \(D=H d_h\)，将 [B,T,D] 投影为 [B,T,H,dₕ] 后，需要 transpose 成 [B,H,T,dₕ] 才能逐头计算。直接 reshape 到 [B,H,T,dₕ] 会改变元素被分配到的位置与头，虽然总元素数相同，却不保留原来的轴语义。输出恢复时先从 [B,H,L,dᵥ] 换回 [B,L,H,dᵥ]，再合并最后两轴，最后执行输出投影。



不同头具有独立的投影子空间，但不预设“某个头专门负责位置、某个头专门负责语义”；这些是可能的训练结果，不是结构保证。参数是否打包为一个 QKV Linear、是否共享 K/V、是否使用不同头数，会改变权重布局和缓存大小。最小实现先明确标准 MHA 约定，再学习 MQA/GQA；不能把所有名称都套进一个要求 Q、K、V 头数相同的 reshape。





### 元素数量正确也可能把头和 token 交换

reshape 只重新分组连续元素，轴交换需要 transpose/permute。等长维度容易掩盖错误。

用 B=2、H=3、T=5 的哨兵张量追踪一个明确元素，检查拆分和恢复后位置。

## Mask 的布尔约定

注意力 Mask 是声明每个 Query 可以读取哪些 Key 的可见性约束。它改变参与 Softmax 归一化的集合，不是简单地把某个结果乘零。数学上的允许关系应先定义，再转换成具体库的布尔约定。



数学上可先定义 allowed[q,k] 表示某个 Query 是否允许读取某个 Key，再把禁止位置加上负无穷，使其 Softmax 权重为零。这一语义与接口布尔值不一定相同：PyTorch SDPA 的布尔 True 表示允许参与，而 nn.MultiheadAttention 的布尔 attn_mask 和 key_padding_mask 用 True 表示禁止或忽略。建议在业务代码中始终保留明确的 allowed，再在调用边界转换，避免多次取反后失去含义。



浮点 Mask 通常是加到分数上的偏置，不是将 0/1 数值直接乘在概率上。把 0/1 浮点张量传给加法 Mask，会只给允许位置加 1，而不会真正禁止另一些位置。SDPA 的 Mask 需可广播到权重形状；MHA 常用二维 [L,S] 或三维 [B×H,L,S]，另有 [B,S] 的 Key Padding Mask。不能假设两个接口接受完全相同的四维布局，迁移代码时应同时核对值语义、轴和 dtype。





## Padding、无效 Query 与空行

Padding 是为组成统一形状而加入的占位，既可能出现在被读取的 Key，也可能出现在发起读取的 Query。禁止读取占位 Key 不会自动规定占位 Query 的输出；全无可见 Key 的行还需要显式定义。



Key Padding Mask 只阻止其他位置读取无效 Key，不会自动把无效 Query 的输出归零。Padding Query 仍可能读到有效 Key，甚至通过输出层偏置产生非零结果；若后续池化或 Loss 会看到它，就需要明确排除。Loss Mask、Attention Mask 和输入填充值分别控制监督、信息传播与数值输入，三者不能互相替代。尤其在跨位置网络中，最终 Loss 为零的位置仍可能影响其他有效位置。



当一整行都被禁止，朴素写法 softmax([-inf,...,-inf]) 会遇到无效的减法。不同实现或内核对这种边界可能有不同处理，不能依靠偶然得到零作为设计约定。教学实现可显式规定空行输出为零，并在归一化前处理空行，确保反向也有限。无效输入若含 NaN，事后乘零仍然是 NaN；必须在参与点积或误差计算前处理不应进入运算的值。





### 例：Key Mask 不等于输出 Mask

1. 一个样本只有前两个有效 Key，第三个 Query 是 Padding。

2. 让三个 Query 都读取前两个 Key，第三个输出一般仍非零。

3. 若只把第三个 Query 的 Loss 权重置零，它仍可能在后续层作为 Key 被读取；应在每层保证需要的可见性规则。

有效位要沿整个信息链路传播，不能只在最终损失处补一行乘法。

### 全遮蔽行要有明确前向和反向约定

给 logits 填负无穷只能定义非空行的普通 Softmax；空行需要单独处理。

加入全部 Key 无效的样本，验证输出约定、输入梯度和参数梯度均有限；同时测试改变 Padding 内容是否污染有效输出。

## Cross-Attention 与因果可见性

Self-Attention 使用同一组位置产生 Q、K、V，Cross-Attention 则让一组位置的 Q 读取另一组位置的 K/V。因果性描述允许读取的时间范围，与这两种来源关系不同。先分清来源与可见性，再组合具体结构。



Cross-Attention 描述 Q 与 K/V 的来源；causal 描述可见性规则。一个 Cross-Attention 可以读取全部条件，也可以有时间或结构限制；一个 Self-Attention 可以是双向、因果或前缀式。不要因为模块名称含 decoder 就推断所有区域都只能向左读。在动作块的去噪或流匹配网络中，所有带噪动作位置可能同时可用，动作区双向交互也可以成立，但真实未来标签不能以其他路径泄漏。



对于自回归位置 i，允许读取不晚于自己的 Key，可写 \(j\le i\)。存在历史缓存 P、当前块长 L 时，当前第 i 个 Query 的全局位置是 P+i，因此应允许 \(j\le P+i\)。直接构造 \(L\times(P+L)\) 的普通左上角下三角矩阵，可能把历史缓存遮掉。信息规则应在全局位置上定义，再转换成当前矩阵；小尺寸手画比盲信 is_causal 标志更可靠。





## 高效实现与数值等价

融合注意力实现是将若干计算步骤合并或分块组织，以减少中间存储与数据搬运的实现方式。它可以计算同一个稠密注意力函数，却不因此自动消除成对匹配的工作量。比较时应先固定函数与 Mask 语义。



标准稠密注意力的分数矩阵大小随 \(L S\) 增长，多头和 Batch 进一步放大显存。融合实现可以避免保存完整中间矩阵或改进访存，却不代表注意力在数学上变成线性复杂度。是否返回权重、输入布局、精度、Mask 形状都会影响可用内核。先用小张量验证正确性，再用真实长度做性能剖析，不要把小例子的运行快慢外推到长序列。



对照时关闭 Dropout、对齐参数与 Mask，并分别比较输出和随机上游梯度。SDPA 函数按传入 dropout_p 执行，即使外层模块已 eval，也要显式传 0。然后做三类干预：改未来 token 检验因果性，改单个样本检验 Batch 隔离，改 Padding 检验有效位。等价断言通过只说明该约定下实现一致；注意力图、训练损失下降或低精度小数差异都不能单独证明模型是否学到了正确任务。



注意力的完整定义包含匹配表示、候选内容、归一化集合与读出方式。明确这四项以后，多头、Mask 和融合实现都可以被理解为对同一次内容读取的组织，而不再是互不相干的接口选项。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 输入 x | [B,T,D] | 演示使用同一个序列做 Self-Attention。 |
| 每头 Q/K/V | [B,H,T,d] | D=H×d，H 为头数。 |
| 注意力 logits / 权重 | [B,H,Tq,Tk] | 每一行对应一个查询，最后一维为键。 |
| 合并输出 | [B,Tq,D] | 先 transpose 回 token 在头之前，再合并。 |

## 完整代码与精读

```python
# [1] 先投影，再拆头；用小尺寸看清每个轴
import math
import torch
from torch import nn
from torch.nn import functional as F
torch.manual_seed(13)
B, T, D, H = 2, 4, 8, 2
d = D // H
x = torch.randn(B, T, D)
qkv = nn.Linear(D, 3 * D, bias=False)
q, k, v = qkv(x).chunk(3, dim=-1)

def split_heads(z):
    return z.reshape(B, T, H, d).transpose(1, 2)

q, k, v = map(split_heads, (q, k, v))

# [2] 这里 True 表示允许读取，构造下三角因果规则
allowed = torch.ones(T, T, dtype=torch.bool).tril()
assert allowed.any(dim=-1).all()
scores = (q @ k.transpose(-1, -2)) / math.sqrt(d)
scores = scores.masked_fill(~allowed, float("-inf"))
weights = scores.softmax(dim=-1)
head_output = weights @ v
torch.testing.assert_close(weights.sum(-1), torch.ones(B, H, T))
assert torch.equal(weights[..., ~allowed], torch.zeros_like(weights[..., ~allowed]))

# [3] 官方 SDPA 使用相同的 True=允许语义
reference = F.scaled_dot_product_attention(
    q, k, v, attn_mask=allowed, dropout_p=0.0
)
torch.testing.assert_close(head_output, reference, atol=1e-6, rtol=1e-5)
merged = head_output.transpose(1, 2).contiguous().reshape(B, T, D)
output_projection = nn.Linear(D, D, bias=False)
y = output_projection(merged)
print("Q / 权重 / 输出:", q.shape, weights.shape, y.shape)
print("手写注意力与 SDPA 一致")

```

- 第 1–17 行：reshape 与 transpose 分别拆出头维和移动头维；Q/K/V 的线性投影属于可训练参数。
- 第 18–27 行：Mask 在 Softmax 前生效，Softmax 沿键轴计算。检查行和与被屏蔽位置，不依赖肉眼观察。
- 第 28–37 行：先在每头结果上比较，再合并头并投影。真实模型可以用融合实现，但计算语义应一致。

预期观察：Q 的形状为 [2,2,4,4]，权重为 [2,2,4,4]，输出为 [2,4,8]；两个实现的结果在浮点容差内一致。

## 浏览器 Python 练习

输入 scores 和等长 allowed 列表。只对允许位置做 Softmax，禁止位置返回 0；所有位置都禁止时抛出 ValueError。需要避免 exp(1000) 溢出。

```python
def masked_softmax(scores, allowed):
    # TODO: 只在有效位置上求稳定 Softmax
    raise NotImplementedError("请完成 masked_softmax")

```

### 提示

- 先找允许位置中的最大值，再从这些位置的分数中减去它。
- 被屏蔽位置不要参与最大值与分母的计算。

### 参考实现与解释

```python
import math

def masked_softmax(scores, allowed):
    if len(scores) != len(allowed) or not any(allowed):
        raise ValueError("长度不匹配或没有有效键")
    maximum = max(s for s, ok in zip(scores, allowed) if ok)
    values = [math.exp(s-maximum) if ok else 0.0
              for s, ok in zip(scores, allowed)]
    total = sum(values)
    return [value / total for value in values]

```

如果先对所有位置做 Softmax，再把禁止位置置零，剩余权重的和通常不为 1；Mask 必须参与归一化。

### 断言测试

```python
a = masked_softmax([0.0, 0.0, 1000.0], [True, True, False])
assert a == [0.5, 0.5, 0.0]
b = masked_softmax([1000.0, 1001.0], [True, True])
assert abs(sum(b)-1.0) < 1e-12 and b[1] > b[0]
c = masked_softmax([-3.0, 9.0], [True, False])
assert c == [1.0, 0.0]
try:
    masked_softmax([1.0], [False])
    raise AssertionError("必须拒绝全屏蔽行")
except ValueError:
    pass
print("通过：Mask、数值稳定性和全屏蔽检测")

```

## 本地 PyTorch 练习

实现 attend(q,k,v,allowed)。q 为 [B,H,Tq,d]，k 为 [B,H,Tk,d]，v 为 [B,H,Tk,dv]；查询长度 Tq、键长度 Tk 与值维度 dv 可以不同。allowed 为布尔 Mask，可以广播到 [B,H,Tq,Tk]，True=允许。返回 [B,H,Tq,dv]。不使用 SDPA；拒绝全屏蔽行。

```python
import math
import torch

def attend(q, k, v, allowed):
    # TODO: 缩放点积、Mask、Softmax 和加权和
    raise NotImplementedError("请完成 Attention")

```

### 提示

- Q×K 转置后形状为 [B,H,Tq,Tk]，Softmax 沿 Tk，即最后一维。
- allowed=True 表示允许，应对 ~allowed 填负无穷；至少保留一个有效键。
- V 的最后一维可以不同于 Q/K 的每头维度，缩放因子来自 q.shape[-1]。

### 参考实现与解释

```python
import math
import torch

def attend(q, k, v, allowed):
    if not bool(allowed.any(dim=-1).all()):
        raise ValueError("每个查询至少需要一个有效键")
    scores = q @ k.transpose(-1, -2)
    scores = scores / math.sqrt(q.shape[-1])
    weights = scores.masked_fill(~allowed, float("-inf")).softmax(-1)
    return weights @ v

```

参考解分别完成缩放点积、可见性限制、按键归一化和 V 加权。测试故意使用 Tq=3、Tk=5、Q/K 宽度4而V宽度6，以检查代码是否把所有维度误认为相同；最后与官方 SDPA 对照并验证 Q 的梯度。

### 断言测试

```python
torch.manual_seed(13)
q = torch.randn(2, 2, 3, 4, requires_grad=True)
k, v = torch.randn(2, 2, 5, 4), torch.randn(2, 2, 5, 6)
allowed = torch.ones(3, 5, dtype=torch.bool)
allowed[:, -1] = False
out = attend(q, k, v, allowed)
ref = torch.nn.functional.scaled_dot_product_attention(
    q, k, v, attn_mask=allowed, dropout_p=0.0)
torch.testing.assert_close(out, ref, atol=1e-6, rtol=1e-5)
out.square().mean().backward()
assert q.grad is not None and torch.isfinite(q.grad).all()
print("通过：跨序列长度、值维度、Mask 与梯度")

```

## 练习：推导与分析

### Cross-Attention 中 Q 长度为 3、K/V 长度为 5，Q/K 每头宽度 4、V 宽度 6，权重与输出分别是什么形状？

忽略 Batch 和头轴时，\(QK^\top\) 产生 [3,5] 权重矩阵，每行对应一个查询、每列对应一个键。Softmax 应沿五个键的位置归一化，每个查询的有效权重和为一。

乘以 [5,6] 的 V 后得到 [3,6] 输出。Q/K 必须具有可做点积的匹配宽度，而 V 的内容宽度可以不同；缩放使用 Q/K 的宽度，不是 V 的宽度。

代码定位：逐步标出 scores、weights 和 weights@v 的形状，并核对 softmax(dim=-1)。

- 正确给出 [3,5] 与 [3,6]。
- 区分键位置轴、点积宽度和内容宽度。

### 将一份 SDPA 布尔 Mask 直接传给 MultiheadAttention，为什么可能反过来屏蔽信息？怎样设计一个最小检查？

两个接口的布尔语义不同：SDPA 的 attn_mask 中 True 表示允许；MultiheadAttention 的布尔 attn_mask 中 True 表示禁止。相同布尔矩阵直接迁移会改变可见性规则。

可以构造只有一个允许键的小例子，让输出必须等于该键的 V；再用因果规则修改未来输入，检查早期输出是否不变。还应检查全屏蔽行，避免朴素 Softmax 对全负无穷产生异常。

代码定位：明确命名 allowed 或 blocked，检查 masked_fill 的取反，并用单个可见键做行为测试。

- 准确陈述两个接口相反的布尔语义。
- 提出检查实际信息流的例子，不只检查 Mask 形状。

### 一个头始终把 99% 的权重分配给某个 Key，是否足以说明它决定了输出？如何构造权重不同、输出却完全相同的反例？

把所有 Value 设成同一个 v。无论注意力权重如何分配，只要行和为 1，输出都是 v，因此单看权重无法区分贡献。

由 \(\frac{\partial o}{\partial s_j}=a_j(v_j-o)\)，此时所有分数梯度为零。Q/K 在该读出路径上没有梯度，但 Value 的梯度按权重分配，整个层并非不能训练。

该结论针对无 Dropout 的注意力加权读出；输出投影、残差和后续非线性还会改变最终预测，热图更不能单独代替因果干预。

代码定位：分别固定 Q/K 改 V，以及固定 V 改 logits；同时比较输出和两条梯度路径。

- 给出相同 Value 的明确反例。
- 区分分数梯度、Value 梯度与最终模型输出。

## 练习：辨析与纠错

### Softmax 沿 Query 轴执行

[B,H,L,S] 应沿 S 归一化。用单行手算和非方形 L≠S 测试，避免把另一个合法操作误当注意力。

### 把 SDPA 的 True 原样传给 MHA

二者布尔语义相反。业务层先定义 allowed，在 API 边界转换，并测试一个只允许读取单个 Key 的案例。

### 全遮蔽行产生 NaN 后才乘零

NaN×0 仍然是 NaN，反向也可能污染。应在不合法的 Softmax 之前定义空行处理，并验证梯度。

### 认为 eval 自动关闭函数式 SDPA Dropout

SDPA 使用 dropout_p 参数。显式传入训练态概率或推理态 0，再进行完整序列与缓存的等价性比较。

### 只看注意力权重便解释最终决策

权重还要与 Value、输出投影、残差及后续层结合。用输入干预和任务评估验证解释，不把热图当作因果证明。

## 原始资料

- [Attention Is All You Need](https://arxiv.org/abs/1706.03762)
- [PyTorch：scaled_dot_product_attention](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html)
- [PyTorch：MultiheadAttention](https://docs.pytorch.org/docs/stable/generated/torch.nn.MultiheadAttention.html)
