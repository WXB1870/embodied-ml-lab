# 分词、自回归与标签对齐

序列概率、标签移位、Prompt 和有效损失位置。

分词器（Tokenizer）把文本转换为离散 Token ID；自回归模型则按顺序，用已有前缀预测下一个 Token 的条件分布。训练使用真实前缀并行计算各位置的损失，生成时把刚得到的 Token 接回前缀继续预测。二者共同定义从文本到序列概率的接口。本章先认识这个流程，再精确对齐输入、标签、可见性与有效监督。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [Transformer：注意力、残差与序列建模](https://wxb1870.github.io/embodied-ml-lab/learn/transformer/) · [Embedding 与位置编码](https://wxb1870.github.io/embodied-ml-lab/learn/embeddings/)

## 分词与离散接口

分词是将文本按词表与规则转换为 Token 序列的过程，Tokenizer 还负责特殊标记和反向解码。一个 Token 不必对应一个字或一个词。词表与切分规则共同构成模型的离散输入接口。



Tokenizer 将文本转换为词表中的整数序列，可能使用 BPE、WordPiece、Unigram 或字节级规则。一个汉字、单词或数字不一定只占一个 token；空格、标点、大小写和特殊模板也会影响切分。训练与推理必须使用匹配的词表和配置，不能因为输入最终都是整数就任意替换。示例中的人工词表仅用于展示标签对齐，不代表真实模型的分词方法。



特殊 token 定义序列起始、结束、填充或角色边界，聊天模板可能自动插入它们。手工再次添加 BOS/EOS 会造成重复，省略必要边界又可能改变生成任务。扩充词表时还要调整输入嵌入和输出词表维度，并处理新权重初始化。先打印 token 字符串、ID、有效位和标签，再进入神经网络，是定位监督问题最便宜的一步。





### 保存 tokenizer 与模板，别只保存模型权重

同一个 ID 的含义取决于词表，角色边界与特殊 token 又影响模型看到的条件。

对固定输入记录完整编码结果，包括特殊 token，验证训练/推理和重新加载后一致。

## 自回归概率分解

自回归模型把序列的联合概率分解为各位置在已有前缀下的条件概率乘积。它规定生成的依赖顺序，不等于某一种网络层。下面将这个分解连接到下一 Token 预测与逐位置交叉熵。



对序列 \(y_1,\ldots,y_T\)，链式法则写成 \(p(y_{1:T})=\prod_{i=1}^T p(y_i\mid y_{<i})\)。训练时最大化给定正确前缀后预测下一个 token 的概率，负对数似然就变成各位置交叉熵之和或适当平均。网络输出 [B,T,V] logits，最后一维 V 对应候选词表，而不是序列位置。Softmax 沿词表轴定义每个位置的预测分布，交叉熵使用目标 token 的整数索引。



Teacher Forcing 使用真实前缀进行并行训练，依靠因果 Mask 保证每个输出只读合法历史。推理时前缀包含模型自己生成的 token，因此训练分布与自由生成状态可能不同，这并不使训练公式无效，但提醒我们不能仅用 teacher-forced loss 代替生成评价。输出参数化也应区分：离散动作 token 可以采用类似目标，连续动作的回归或 Flow Matching 则使用不同损失。



$$
-\log p_\theta(y_{1:T})=-\sum_{i=1}^{T}\log p_\theta(y_i\mid y_{<i})
$$



## logits 位置与标签移位

标签移位是让一个输入位置的输出对应到它应预测的下一个 Token。它建立 Logit 行与目标 ID 的对应，不改变输入可见性规则。下面用短序列明确谁负责移位，避免漏移或重复移动。



若输入为 [BOS,A,B,EOS]，位置 0 的隐藏状态看到 BOS，监督目标应是 A；位置 1 看到 BOS,A，监督 B；位置 2 监督 EOS。常见自写 Loss 使用 `logits[:,:-1]` 对 `labels[:,1:]`。某些库的 CausalLM 在内部已经完成这一移位，通常传同长 labels；外部再移位会跳过一个 token。必须读取具体模型与损失接口，不能把某个仓库的调用方式当成所有模型的默认。



未移位时，当前位置可能直接看到被要求预测的 token，训练变成复制输入，损失很低却不会正确生成。移位两次时，模型可能被要求从不完整前缀预测隔一个位置的目标，任务同样改变。避免只检查 flatten 后的元素数：它可以完全对齐却在语义上错位。用几个可读 token 手工列出“输入前缀→目标”，再把这些行对应到 Tensor 索引。





### 例：BOS、A、B、EOS 的三条监督

1. 输入位置 0：BOS → 目标 A。

2. 输入位置 1：BOS,A → 目标 B；输入位置 2：BOS,A,B → 目标 EOS。

3. 最后位置的 logits 没有本序列内下一 token 标签，按本例约定不计入损失。

移位关系来自每个位置看到的前缀，不来自张量恰好能 reshape。

### 外部移位加内部移位会错两次

模型可能已经在 forward/loss 内切片。多移一次并不会更因果，而是改变预测目标。

查看具体 CausalLM 源码或文档，打印参与损失的 logits 位置与目标 token，逐项手算。

## Prompt、回答与 EOS

Prompt 是已给定的条件文本，回答是需要模型生成的目标部分，EOS 是标记序列结束的特殊 Token。它们决定输入、监督与停止规则。先确定每个目标属于哪个区域，再设置损失有效位。



条件生成经常只监督回答区，把 Prompt 标签设为 ignore_index，同时仍让回答位置读取 Prompt。关键是按目标 token 的所属区域决定是否监督，之后再应用移位。第一个回答 token 通常由最后一个 Prompt 位置的 logits 预测，如果按 logits 的当前位置直接屏蔽全部 Prompt，可能连这条重要监督也一起删掉。边界处尤其需要逐位置表格。



EOS 是模型学习何时停止的重要目标；如果一直被屏蔽，模型可能不会在正确时刻结束。PAD 与 EOS 在某些配置中可以共享 ID，这时不能仅靠 `input_ids==pad_id` 推断无效位置，否则真正的 EOS 也会被忽略。有效长度或 attention_mask 应来自样本结构，并与 labels 的屏蔽策略一起检查。文本截断若切掉回答或 EOS，也会改变有效目标数量。





### 例：第一个回答由哪个位置预测

1. 完整序列为 [BOS,提示,回答1,回答2,EOS]，只监督回答与 EOS。

2. 同长 labels 可写为 [忽略,忽略,回答1,回答2,EOS]；移位后 logits 的位置 1 监督 回答1。

3. 如果先把所有 Prompt 位置的 logits 删除，再移位，就可能漏掉第一个回答目标。

Loss Mask 以目标归属定义，再与预测位置正确错位配对。

## Attention Mask 与 Loss Mask

Attention Mask 选择某个预测能读取的输入，Loss Mask 选择哪些目标计入训练代价。忽略一个标签不等于移除其输入表示。二者应由信息边界与监督范围分别定义。



Attention Mask 控制输出能读取哪些输入，ignore_index 控制某个目标是否贡献损失。将某位置 label 设为 −100，并不阻止该 token 的隐藏状态影响其他位置；Prompt 不受直接监督，也可经回答 Loss 的反向路径收到梯度。另一方面，屏蔽 Padding Key 不会自动移除 Padding Query 的损失，需要对 targets 单独处理。两种 Mask 要沿信息与监督两条路径分别推导。



若把多条样本打包进一条长序列，还要处理样本间的边界：让后一条读取前一条是否属于设计、位置是否重置、EOS 后哪些目标有效，都需要明确。只在拼接处放一个 EOS 不会自动创建 block-diagonal Attention Mask。错误打包可能让模型利用另一条样本的内容，改变训练条件分布。高效训练技巧不能绕过每个预测目标实际看到了什么这一基本问题。





## 交叉熵的轴、归约与空监督

序列交叉熵对每个有效目标取预测类别的负对数概率，再按选定分母归约。类别轴是词表，位置轴是序列，两者承担不同角色。先对齐类别和目标，再明确空监督时的处理。



PyTorch 交叉熵的类别维度接口需要核对。对 [B,T,V] logits，可展平成 [B·T,V] 与 [B·T] targets，或按接口转置到相应布局；不要把 T 当作类别数。使用整数类别标签时，ignore_index 排除相应目标；reduction=none 便于显式统计有效 token，再按真正的有效数归约。若采用类权重等选项，默认 mean 的分母还有相应约定，不能套用无权重公式。



全批没有有效目标时，平均损失无定义，不应通过任意小 \(\varepsilon\) 静默得到零再继续优化；可以按训练协议拒绝或跳过，并记录原因。变长回答按所有 token 等权与先按样本平均再等权是不同目标，日志也应说明口径。perplexity 由所定义的平均负对数似然指数得到，跨不同 tokenizer、数据切分或监督区间直接比较通常没有同一单位。





### Padding 后的序列长度不是有效 token 数

Prompt、Padding、截断和忽略标签共同决定分母。错误平均会改变梯度和指标。

使用不同回答长度与全忽略边界，显式核对 `targets!=-100` 的数量，并手算少数 token 的平均损失。

## Teacher Forcing 与逐步生成

Teacher Forcing 在训练中提供真实前缀，逐步生成则使用模型此前输出构造后续前缀。采样规则决定怎样从预测分布选一个 Token，KV Cache 决定怎样复用历史计算。它们都不改变标签原本的对齐关系。



训练一次计算所有前缀的预测，推理则先处理已知 Prompt，再选择一个 token 接入前缀，继续预测。贪心、采样、温度和截断候选策略作用于 logits 到 token 的选择，不改变训练时标签应该如何移位。KV Cache 复用历史 K/V 以减少重复计算，但位置偏移、Attention Mask 和有效长度仍须与完整前向一致。缓存错误可能只在第二次或分块生成时显现。



自由生成评价应检查内容、格式、停止条件和长度，不只是 teacher-forced loss。多模态模型还要保证图像占位 token 与视觉特征注入位置对齐，结构化输出要核对分隔符和数值编码规则。若训练输出很流畅却不遵循条件，先检查 Prompt 是否被正确输入、回答监督是否包含边界、以及数据中条件与答案是否有足够变化，避免只靠更低学习率修补接口错误。





## 短序列中的逐项对齐

完整模型容易掩盖一个位置的偏移，短序列却可以逐项手算。将已知答案写成可控 logits，再覆盖回答边界、结束符号和 Padding，可以先验证监督问题本身，再判断网络是否学会它。



构造两条不同长度的短序列，明确 BOS、Prompt、回答和 EOS，画出每个 logits 所预测的目标，再运行自写 Loss 与官方损失的对照。人工令正确目标 logits 很大，损失应接近零；令高分给前一个或后一个 token，损失应显著增加。测试应覆盖第一个回答、最后 EOS 与 Padding，不能只用没有边界的长随机序列。



示例代码使用一个小型因果 Transformer，明确只移位一次，并断言五个有效目标；它验证的是监督构造与计算图。换成真实 tokenizer 后，应重新运行同样的可读探针，打印 decode 结果与有效目标区间。训练曲线异常低时尤其要检查目标泄漏与未移位，异常高时检查重复移位、词表/模板不匹配和空监督。先证明在学正确问题，再讨论模型容量。



自回归生成始于同一份离散接口与概率分解：文本被分成 Token，每个输出预测下一项，合法前缀定义条件，目标有效位定义监督。训练和生成访问的前缀不同，但每个位置预测谁应始终一致。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| input_ids / attention_mask | [B,T] | ID 与可读取的真实位置。 |
| 未移位 labels | [B,T] | 需要监督的位置保留 ID，其他位置为 −100。 |
| logits | [B,T,V] | 每个位置输出下一 token 的词表分数。 |
| 对齐后的预测 / 目标 | [B,T−1,V] / [B,T−1] | 只在明确没有内部移位时自行构造。 |

## 完整代码与精读

```python
# [1] 人工词表仅用于展示监督对齐，不替代真实模型 Tokenizer
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils.rnn import pad_sequence
torch.manual_seed(37)
vocab = {"<pad>":0, "<bos>":1, "任务":2, "抓取":3,
         "红":4, "杯":5, "<eos>":6, "蓝":7, "块":8}
texts = ["<bos> 任务 抓取 红 杯 <eos>", "<bos> 任务 蓝 块 <eos>"]
rows = [torch.tensor([vocab[t] for t in text.split()]) for text in texts]
input_ids = pad_sequence(rows, batch_first=True, padding_value=0)
valid = input_ids != vocab["<pad>"]
labels = input_ids.clone()
labels[:, :3] = -100  # 本例前 3 个 token 是 prompt
labels[~valid] = -100

# [2] 小型因果模型：保持原位置，先产生每个位置的 logits
B, T = input_ids.shape
embedding = nn.Embedding(len(vocab), 12, padding_idx=0)
position = nn.Embedding(T, 12)
block = nn.TransformerEncoderLayer(12, 3, 24, dropout=0.0, batch_first=True)
head = nn.Linear(12, len(vocab))
hidden = embedding(input_ids) + position(torch.arange(T))[None]
blocked = torch.ones(T, T, dtype=torch.bool).triu(1)
hidden = block(hidden, src_mask=blocked, src_key_padding_mask=~valid)
logits = head(hidden)

# [3] 自写的 loss 明确只移位一次
predictions = logits[:, :-1].contiguous()
targets = labels[:, 1:].contiguous()
token_losses = F.cross_entropy(
    predictions.reshape(-1, len(vocab)), targets.reshape(-1),
    ignore_index=-100, reduction="none")
count = (targets != -100).sum()
loss = token_losses.sum() / count
reference = F.cross_entropy(predictions.reshape(-1, len(vocab)),
                            targets.reshape(-1), ignore_index=-100)
torch.testing.assert_close(loss, reference)
assert count.item() == 5
loss.backward()
assert embedding.weight.grad is not None
print("移位后目标:", targets.tolist())
print("有效目标数:", count.item(), "loss:", round(loss.item(), 4))
print("prompt / EOS / Padding 与移位检查通过")

```

- 第 1–16 行：两条序列长度不同，真实 EOS 与 Padding 使用不同 ID；实际模型中也可能相同，此时必须依赖有效长度。
- 第 17–27 行：因果 Mask 限制信息访问；prompt 保留在输入中。这个自写模型不自动计算或移位标签。
- 第 28–44 行：有效目标分别为三个与两个：第一条红、杯、EOS；第二条块、EOS。按五个目标归约。

预期观察：targets 为 [[-100,-100,4,5,6],[-100,-100,8,6,-100]]，有效目标数为 5；两种归约方法一致。

## 浏览器 Python 练习

实现 next_token_example(ids,valid_length,prompt_length)。返回 `input_ids=ids[:-1]`、同长度 attention_mask 和 targets。targets 对应原位置 \(1,\ldots,T-1\)；原索引小于 prompt_length 或不在 valid_length 内时为 −100。允许真实 EOS 与 Padding 同为 0。

```python
def next_token_example(ids, valid_length, prompt_length):
    # TODO: 用原位置而不是 token 数值决定监督有效性
    raise NotImplementedError("请完成下一 token 对齐")

```

### 提示

- targets 的第 j 项来自 `ids[j+1]`，判断是否为 prompt 时也必须使用原索引 j+1。
- 不要写 `token!=0` 来判断有效性；测试中的第一个 0 是真实 EOS。

### 参考实现与解释

```python
def next_token_example(ids, valid_length, prompt_length):
    if not 1 <= valid_length <= len(ids):
        raise ValueError("有效长度无效")
    if not 0 <= prompt_length <= valid_length:
        raise ValueError("prompt 长度无效")
    inputs = list(ids[:-1])
    attention = [i < valid_length for i in range(len(inputs))]
    targets = [ids[i] if prompt_length <= i < valid_length else -100
               for i in range(1, len(ids))]
    return {"input_ids":inputs, "attention_mask":attention, "targets":targets}

```

真实 EOS 与补齐可以共享 ID，因此目标有效性必须来自长度或元数据。首个回答的监督落在前一个输入位置所产生的 logit 上。

### 断言测试

```python
a = next_token_example([1,2,3,9,0,0], 5, 3)
assert a["targets"] == [-100,-100,9,0,-100]
assert a["input_ids"] == [1,2,3,9,0]
assert a["attention_mask"] == [True]*5
b = next_token_example([1,2,8,6,0,0], 4, 2)
assert b["targets"] == [-100,8,6,-100,-100]
assert b["attention_mask"] == [True,True,True,True,False]
assert next_token_example([1],1,1)["targets"] == []
print("通过：首个回答、EOS/PAD 同 ID 与错位边界")

```

## 本地 PyTorch 练习

实现 shifted_causal_loss(logits,labels)。labels 已按原位置设好 −100，本函数负责唯一一次移位，并用有效目标总数归约；若没有有效目标则抛出 ValueError。

```python
import torch
from torch.nn import functional as F

def shifted_causal_loss(logits, labels):
    # TODO: 对齐预测与目标、有效目标计数、稳定 CE
    raise NotImplementedError("请实现自回归损失")

```

### 提示

- logits 去掉末尾位置，labels 去掉开头位置；不要同时再移动 input_ids。
- 用 reduction='sum' 的 CE 除以 `targets!=-100` 的数量；这里不是按 Batch 数归约。

### 参考实现与解释

```python
import torch
from torch.nn import functional as F

def shifted_causal_loss(logits, labels):
    predictions = logits[:, :-1].contiguous()
    targets = labels[:, 1:].contiguous()
    count = (targets != -100).sum()
    if int(count) == 0:
        raise ValueError("没有有效监督目标")
    total = F.cross_entropy(predictions.reshape(-1, logits.shape[-1]),
                            targets.reshape(-1), ignore_index=-100, reduction="sum")
    return total / count

```

手写的四项 log-prob 直接列出真实监督位置，能识别重复 shift 和取错时间轴。末位置与被忽略位置的梯度为零，说明没有意外监督这些 token。

### 断言测试

```python
torch.manual_seed(37)
logits = torch.randn(2,4,6,requires_grad=True)
labels = torch.tensor([[1,2,3,4],[1,5,-100,-100]])
loss = shifted_causal_loss(logits,labels)
lp = logits.log_softmax(-1)
expected = -(lp[0,0,2]+lp[0,1,3]+lp[0,2,4]+lp[1,0,5])/4
torch.testing.assert_close(loss, expected)
loss.backward()
assert torch.equal(logits.grad[:,-1],torch.zeros_like(logits.grad[:,-1]))
assert torch.equal(logits.grad[1,1:],torch.zeros_like(logits.grad[1,1:]))
try:
    shifted_causal_loss(logits,torch.full_like(labels,-100))
    raise AssertionError("必须拒绝空监督")
except ValueError:
    pass
print("通过：标签移位、有效分母与被忽略位置的梯度")

```

## 练习：推导与分析

### 输入为 [BOS,任务,抓取,红,杯,EOS,PAD]，前三个 token 是 prompt。哪些 logits 预测哪些目标？prompt 不计 loss 是否意味着不能被注意？

原索引 3、4、5 的红、杯、EOS 是有效目标，对应原索引 2、3、4 的 logits。PAD 不计监督，最后一个位置没有序列内的下一个目标。应先在原 labels 上标好有效性，再按照所用实现恰好移位一次。

prompt 仍然为回答提供条件。Loss Mask 仅决定哪些目标参与优化，Attention Mask 决定哪些输入可读取；不计算 prompt 的预测损失，不等于禁止回答位置读取 prompt。

代码定位：把 `labels[:,1:]` 与 `logits[:,:-1]` 并排打印，核对第一个回答和 EOS 边界。

- 正确指出红由原索引 2 的 logit 预测。
- 明确区分 Attention Mask 与 Loss Mask。
- 保留真实 EOS，排除 Padding。

### Teacher Forcing 为什么能并行训练，而推理通常逐 token 进行？它是否消除了错误累积？

训练已知整条真实序列，因此所有位置都可以获得各自的真实历史。因果 Mask 保证位置 i 的预测不读取其未来目标，从而可以在一次前向中同时计算多个位置。

推理时下一个真实 token 尚不可知，模型通常把自己的预测作为后续输入。若预测出错，后续历史会偏离训练中的真实历史，所以 Teacher Forcing 并未自动消除误差累积或训练与推理的分布差别。

代码定位：核对训练时输入的历史来源，以及生成循环何时把预测 ID 追加到上下文。

- 说明并行来自已知真实历史与因果 Mask。
- 说明推理历史由模型生成，不能把训练低 loss 等同于长序列可靠性。

## 练习：辨析与纠错

### 直接让 logits 监督当前位置 input_ids

当前位置已经看到同一个 token，可能学成复制任务。用 BOS,A,B,EOS 手工核对前缀与目标。

### 外部移位后交给内部再次移位的模型

目标被跳过一位。核对所用 CausalLM 的 loss 接口，保留一处明确的移位。

### 屏蔽 Prompt logits 时漏掉首个回答

应先按目标区域构造 labels，再执行错位配对。逐项检查最后 Prompt 位置预测什么。

### PAD 与 EOS 同 ID 时把所有 EOS 忽略

有效位不能只按 token 值推断。保留原长度或结构 Mask，明确 EOS 监督。

### 拿不同 tokenizer 的 perplexity 直接比较

分词单位、监督区间和数据切分不同会改变指标单位。只在统一约定下比较，并同时报告生成表现。

## 原始资料

- [Hugging Face：Tokenization algorithms](https://huggingface.co/docs/transformers/en/tokenizer_summary)
- [Hugging Face：GPT-2 labels 与内部 shift](https://huggingface.co/docs/transformers/main/model_doc/gpt2)
- [TensorFlow：Transformer 与 Teacher Forcing](https://www.tensorflow.org/text/tutorials/transformer)
- [PyTorch：CrossEntropyLoss 的 ignore_index 与 reduction](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html)
