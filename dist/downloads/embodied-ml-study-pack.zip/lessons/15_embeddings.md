# Embedding 与位置编码

离散索引、置换等变性、位置身份与 RoPE。

模型接收的是张量，但词表编号、空间位置和生成时间并不是同一种数值对象。编码的作用是在保留各自语义的前提下，把这些输入变成可学习模块能够使用的表示。本章从离散查表及其梯度开始，说明不带位置信息的序列模型有哪些对称性，再推导正弦编码与 RoPE 的位置关系。最后把这些结论用于缓存偏移和动作生成，避免形状正确却含义错位的输入。

前置知识：[注意力：匹配、聚合与梯度](https://wxb1870.github.io/embodied-ml-lab/learn/attention/) · [张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/)

## Embedding 查表与离散索引

离散类别没有天然的欧氏坐标，而神经网络需要能够相加、投影和求导的向量。Embedding 用一张可学习表为每个身份提供表示，学习的是表中的数值而不是整数编号之间的距离。先把索引与参数区分开，后面的梯度共享和词表兼容性才有明确含义。



Embedding 矩阵 E 的形状为 [V,D]，V 是词表或类别数量，输入 ID 的形状为 [B,T]，查表后得到 [B,T,D]。在数学上，取第 i 行等价于 one-hot 向量乘 E，但实现无需构造巨大的 one-hot。ID 只是词表索引：编号 100 与 101 相邻，并不意味着语义相近；把 ID 直接当浮点数送进回归网络，会额外引入词表并未定义的数值距离。



Embedding 权重可以由训练更新，也可以冻结；输出是否包含语义由训练目标和数据决定，随机查表本身没有理解能力。输入必须遵守整数类型与索引范围，新增 token 时还要调整相应矩阵大小。Tokenizer、特殊 token 与 Embedding 权重是一套接口：换了 tokenizer 后，即使词表大小一样，同一个 ID 也可能对应不同内容，形状检查无法发现这种语义错位。



$$
e_i=E[i,:]\equiv \operatorname{onehot}(i)^T E
$$



### ID 与语义由同一份词表绑定

Embedding 行号本身没有连续意义。权重、词表、特殊 token 和模板需要一起保存。

对固定文本打印 token 字符串和 ID，再检查加载的 tokenizer 是否与预训练权重匹配。

## 重复索引梯度与 Padding 行

多个位置可能引用同一条嵌入向量，这使查表同时成为参数共享的一个例子。反向传播必须把所有引用处的贡献送回同一行。Padding 行的特殊处理也应沿这条依赖解释，不能直接推广为整个模型忽略该位置。



若一个 ID 在多个位置出现，它们都引用同一行参数；反向时这些位置的梯度会累加到该行。没有被查到的行，在仅通过查表参与计算时通常没有来自这条路径的梯度。但若输出投影与输入 Embedding 共享权重，分类损失可能通过输出端影响更多行，不能只看输入里是否出现就判断更新。某些优化器的权重衰减和稀疏梯度配置也会改变实际更新细节。



更具体地，若第 \((b,t)\) 个位置的索引为 \(i_{bt}\)，输出为 \(Y_{bt,:}=E_{i_{bt},:}\)，其上游梯度为 \(g_{bt,:}\)，则第 \(v\) 行参数的梯度为 \[\nabla_{E_{v,:}}L=\sum_{b,t}\mathbf1\{i_{bt}=v\}\,g_{bt,:}.\]这一式子直接来自共享参数处的求和。索引选择是离散操作，普通查表不会对整数 ID 求连续导数；可学习的是被选中行的向量值。



padding_idx 可让查表的相应行不接收普通嵌入梯度，并通常以零初始化；它不等于整个网络自动忽略 Padding。加上位置向量、偏置或经过 Attention 后，Padding 位置仍可能非零，还需要有效位规则。max_norm 等选项会在前向处理权重，检查共享权重和可微用法时应阅读具体接口。理解“某行不收到这条路径的梯度”与“系统完全忽略该位置”的区别非常重要。





### 例：同一行被查两次

1. 令 ID 序列为 [2,2,5]，输出每个位置的上游梯度分别为 [1,0]、[0,3]、[4,4]。

2. Embedding 第 2 行累积得到 [1,3]，第 5 行得到 [4,4]。

3. 若第 2 行被设为 padding_idx，这条查表反向不更新它，但后续仍须屏蔽相应位置。

参数共享会汇总贡献，Padding 的查表规则不能替代网络信息屏蔽。

## 置换等变性与位置身份

查表给出了 token 的身份，却没有说明这些 token 以什么顺序出现。若只使用共享的逐位置变换与内容注意力，重排输入会带来确定的对称性。推导这种对称性，可以说明位置输入为何必要，以及它在后续汇聚中又可能怎样被丢掉。



不带位置输入且采用完整可见性的 Self-Attention 是置换等变的。记 P 为重排 token 的置换矩阵，输入变为 PX 后，Q/K/V 同时变为 PQ、PK、PV，分数矩阵变为 \(P(QK^\top)P^\top\)。逐行 Softmax 随同重排，最后得到 \(\operatorname{Attn}(PX)=P\operatorname{Attn}(X)\)。共享的逐位置 FFN 和 Norm 也保留这一性质。若有 Mask，需连同 Mask 一起重排；固定的因果 Mask 本身已经提供顺序结构，不能套用无 Mask 的结论。



再做全局均值会消去输出的重排，得到置换不变的向量。仅在均值前加位置向量仍不够：\(\operatorname{mean}_i(x_i+p_i)=\operatorname{mean}_i(x_i)+\operatorname{mean}_i(p_i)\)，内容与位置的配对关系被消掉。例如内容 [1,3] 与 [3,1]，固定位置 [0,10]，相加后均值都为 7。要保留“什么出现在什么位置”，需要在池化前让内容和位置发生交互，如带非线性的编码或位置相关的注意力；有位置输入只是必要信息来源，不是保留关系的自动保证。



位置可以是一维文本序号、二维 patch 坐标、动作块索引或历史时刻。多段输入还需要来源身份，离散身份并不自动等于物理坐标。Padding 会让存储下标与有效 token 的逻辑位置不同，左填充、右填充与增量缓存尤其需要统一 position_ids 的含义。



$$
\operatorname{Attn}(PX)=P\operatorname{Attn}(X),\qquad \frac1T\sum_i(x_i+p_i)=\bar x+\bar p
$$



## 多频正弦编码

位置和时间常是连续或有序的标量，直接用一张有限词表不能覆盖所有使用方式。多频正弦把标量映射为不同变化尺度的特征，提供可供网络组合的坐标。理解频率与输入单位的关系，才能解释端点、相邻位置和训练范围外的编码行为。



给定位置或时间 s，可以用多组 \(\sin(\omega_i s)\)、\(\cos(\omega_i s)\) 表示，再由 MLP 映射到模型宽度。低频成分随 s 缓慢变化，高频成分分辨较近的位置；频率范围、输入尺度与特征排列共同决定实际表示。把原本在 [0,1] 的时间改成 [0,1000] 却仍用同一频率，会显著改变输入分布。网络有时间嵌入并不能替代正确的时间定义。



对一组频率，令 \(e(s)=[\sin(\omega s),\cos(\omega s)]\)。由余弦差角公式，\(e(s)^\top e(t)=\cos(\omega(s-t))\)，所以两个位置的内积可以反映相对差；多频率拼接后，内积是这些余弦项之和。这说明特征为何具有可组合的位置关系，但并不表示任意远距离都可以被唯一、稳定地区分。



正弦特征能对未见过的标量计算数值，但这不保证模型在远超训练范围时仍有效。周期性也意味着单一频率存在别名，多频率只是提供更丰富的编码，不是自动解决所有外推问题。核对实现时应比较同一输入在两个端点、中间点和相邻点的编码，确认是否乘了额外尺度、是否交错 sin/cos，以及输出是否与后续权重布局一致。





## RoPE 与相对位置

绝对位置可以加到特征中，相对位置也可以直接进入匹配运算。RoPE 通过成对通道的旋转，让两个位置的差出现在 Q/K 点积里。它的核心是旋转复合关系，因此应从这个恒等式理解实现，而不是只记住奇偶维度的写法。



先看一个通道对。定义 \[R(\theta)=\begin{bmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{bmatrix}.\]对频率 \(\omega\)，位置 \(m\) 使用 \(R_m=R(\omega m)\)。矩阵转置把角度变为相反数，旋转相乘使角度相加，因此 \(R_m^\top R_n=R(\omega(n-m))\)。把它代入两个旋转向量的内积，就得到下面的相对位置关系；多个通道对分别使用各自频率。



RoPE 将 Query 和 Key 的通道两两组成二维向量，并用与位置相关的旋转矩阵变换。对同一频率，\((R_m q)^\top(R_n k)=q^\top R_{n-m}k\)，因此点积可以反映相对位置差。它不是把旋转矩阵直接作用到机器人姿态，也不是给 Value 做同样旋转的统一规定；应读取具体模型旋转的通道范围、怎样分组，以及是否只有一部分维度使用 RoPE。



实现里相邻配对和前后半区配对都可以形成合法约定，但与预训练权重的布局必须一致。单独旋转保持向量范数，这是很好的局部断言；同时平移 Q/K 的位置后，理想的相对点积关系也可作为测试。不能只验证 \(\sin^2\phi+\cos^2\phi=1\) 就宣布整个 RoPE 正确：频率、广播到头维的方式、绝对位置偏移和成对顺序仍可能错。



$$
(R_mq)^T(R_nk)=q^TR_{n-m}k
$$



### 例：用一个二维通道对理解相对位置

1. 设 q=k=[1,0]，两个位置的旋转角分别为 α 和 β。

2. 旋转后点积为 cos α cos β+sin α sin β=cos(β−α)。

3. 同时把两个角加 δ，点积不变；只改变一个角，点积随相对差变化。

相对位置关系来自 Q 与 K 旋转的配合，而非某个向量单独存有绝对坐标。

## 位置偏移与 KV Cache

位置关系在增量推理时必须与完整序列一致，但缓存把历史和当前 token 分开存放了。重新从零编号当前输入，会改变它与历史 Key 的相对关系。位置元数据因而和缓存内容一样，属于需要持续维护的模型状态。



自回归增量计算时，已经缓存 P 个 token，新 token 的逻辑位置通常从 P 开始，而不是每次从零重新编号。若历史 Key 已按原位置旋转，新 Query 又按零位置旋转，点积中的相对差就错误；形状仍然完全正常。分块解码也一样，当前块第 i 个位置对应 P+i，需要与非方形因果 Mask 和缓存写入位置一致。



不同缓存实现可能保存已旋转的 K、未旋转的 K，或维护单独位置元数据；不能在不知道约定时再次旋转已有缓存。滑动窗口、位置缩放、左 Padding 和批次中不同有效长度会进一步影响位置管理。最小检查是把同一序列用完整前向、逐 token 和不等长分块三种方式计算，对齐每个位置的输出，关闭随机性后定位第一处偏差。



这一节先规定后续增量推理的位置接口，不要求在学习位置编码前已经掌握完整 Transformer。缓存在哪一层保存、何时可复用以及完整前向与增量前向的对照，继续阅读[Transformer 的推理实现](#/learn/transformer?tab=code)。先掌握同一个相对位置关系，再进入多层状态管理。





### 增量解码不是每轮从位置 0 开始

缓存记录着历史位置；当前 Query、追加 Key、Mask 和缓存槽位必须使用一致的逻辑索引。

选择历史长度 3、当前块长 2，手写全局位置 [3,4]，与整段前向对照。

## 序列、观测、动作与生成时间

动作生成模型会同时处理多种“时间”，它们对应不同的问题和不同的张量轴。观测发生的时刻、计划中的动作步与生成过程的噪声阶段不能共享未经定义的含义。把这些量分别命名，才能判断条件是否按正确方式广播和注入。



历史观测时间描述传感器数据来自哪个物理时刻；动作块索引描述本次输出中的第几个未来控制步；语言或序列位置描述 token 的排列；扩散/流匹配生成时间描述当前噪声水平或生成进程。这些量可以通过各自编码进入同一个网络，却不能因为都记作 t 就互换。一次生成时间更新会同时改变整个动作块，并不表示机器人已经执行了一个动作位置。



例如形状 [B,H,D] 中 H 是未来动作长度，生成时间常是每个样本一个标量 [B]，广播到 [B,1,1]；动作位置编码则沿 H 不同。若把 t.expand(H) 当成动作位置，模型就失去了“当前噪声水平”和“第几个动作”的区分。物理控制周期改变时，还应判断动作标签是位置、增量还是速度以及相应时间尺度，不能只改一个 embedding 的长度就认为控制语义已适配。





### 同名 t 可能代表完全不同的量

生成时间、物理时间和序列索引服务于不同计算。广播只解决 shape，不解决语义。

给每个时间变量写单位、取值范围、shape 和更新时机，分别改变它们观察模型输入。

## 编码配置与输入干预

编码错误常常保留正确的形状，因此仅检查维度不足以识别语义错位。更有效的方法是固定其他输入，只改变身份、位置或时间，并预测输出应满足什么关系。这些干预把编码公式与真实模型的数据流连接起来。



先从数据到模型逐层跟踪：离散 ID 经哪张表，连续值经哪组频率，位置加到哪里，条件是否在每个所需位置可见。对形状广播使用 B、T、H 互不相同的测试尺寸，避免误把 Batch 轴当位置轴。检查特殊 ID、越界 ID、空序列和 Padding，再比较固定内容不同顺序时的输出。若模型没有顺序信号，无法期望它可靠地区分依赖顺序的目标。



对时间条件模型，固定状态与其他条件，只改变生成时间，确认输出存在可解释的变化；但输出变化仅证明网络依赖这个输入，不证明它学到了正确规律。还要对照训练路径和监督目标。保存模型时把 tokenizer、位置配置、时间尺度、频率约定一并记录。载入后用同一组探针逐元素比较编码与模型输出，比“权重加载没有报错”更能确认编码与模型配置一致。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 离散 ID | [B,T]，整数 | 用来索引词表参数矩阵。 |
| Embedding 输出 | [B,T,D] | 浮点可学习特征。 |
| RoPE 成对通道 | [B,T,D/2,2] | 要求示例的 D 为偶数。 |
| 生成时间条件 | [B] → [B,1,D] | 可以广播到该样本的多个动作 token，但含义不同于序列位置。 |

## 完整代码与精读

```python
# [1] 离散 ID 的查表与连续位置
import math
import torch
from torch import nn
torch.manual_seed(15)
ids = torch.tensor([[1, 2, 3, 4], [4, 3, 2, 1]], dtype=torch.long)
embedding = nn.Embedding(32, 8)
q = embedding(ids)
k = torch.randn_like(q)
positions = torch.arange(ids.shape[1], dtype=q.dtype)

# [2] 相邻两个通道组成一个旋转平面
def rope(x, position_ids, base=10000.0):
    dim = x.shape[-1]
    assert dim % 2 == 0
    frequency = base ** (-torch.arange(0, dim, 2, device=x.device, dtype=x.dtype) / dim)
    angle = position_ids.to(x)[:, None] * frequency[None, :]
    cos, sin = angle.cos()[None], angle.sin()[None]
    even, odd = x[..., 0::2], x[..., 1::2]
    paired = torch.stack((even*cos - odd*sin, even*sin + odd*cos), dim=-1)
    return paired.flatten(-2)

# [3] 旋转保持范数；整体平移位置不改变 Q/K 相对角度
qr, kr = rope(q, positions), rope(k, positions)
torch.testing.assert_close(qr.norm(dim=-1), q.norm(dim=-1))
score = qr @ kr.transpose(-1, -2)
shifted = rope(q, positions+7) @ rope(k, positions+7).transpose(-1, -2)
torch.testing.assert_close(score, shifted, atol=2e-6, rtol=1e-5)

# [4] 生成时间是另外一个条件，不是 token 序号
t = torch.tensor([0.2, 0.8])
time_features = torch.stack((t, torch.sin(math.pi*t), torch.cos(math.pi*t)), dim=-1)
time_mlp = nn.Sequential(nn.Linear(3, 16), nn.SiLU(), nn.Linear(16, 8))
time_condition = time_mlp(time_features)[:, None, :]
print("token / 时间条件:", q.shape, time_condition.shape)
print("RoPE 范数与相对位置检查通过")

```

- 第 1–11 行：Embedding 的输入必须是离散整数 ID；序列位置另外构造，不把 token ID 当作位置。
- 第 12–22 行：偶数和奇数通道配对，逐对应用正交旋转；代码使用与 x 一致的 dtype 和 device。
- 第 23–29 行：检查数学不变量，比仅打印形状更容易发现通道配对或位置偏移错误。
- 第 30–36 行：[B,1,D] 条件可以广播，但它表示生成状态而非预测动作的时间顺序。

预期观察：token 形状为 [2,4,8]，时间条件为 [2,1,8]；RoPE 两项不变量检查通过。

## 浏览器 Python 练习

实现 rotate_pair(pair, position, frequency)。pair 含两个数，角度为 position×frequency；返回旋转后的两个数。不使用第三方库。

```python
def rotate_pair(pair, position, frequency):
    # TODO: 用 cos 与 sin 实现二维旋转
    raise NotImplementedError("请完成成对旋转")

```

### 提示

- 旋转矩阵第一行是 [cosθ,-sinθ]，第二行是 [sinθ,cosθ]。
- 两个位置共同平移时，旋转后的点积保持不变。

### 参考实现与解释

```python
import math

def rotate_pair(pair, position, frequency):
    if len(pair) != 2:
        raise ValueError("每个旋转平面需要两个通道")
    a, b = pair
    angle = position * frequency
    c, s = math.cos(angle), math.sin(angle)
    return [a*c-b*s, a*s+b*c]

```

每个通道对执行相同形式的旋转；完整 RoPE 只是增加多个频率和批量维度。

### 断言测试

```python
import math
z = rotate_pair([1.0, 0.0], 1, math.pi/2)
assert abs(z[0]) < 1e-12 and abs(z[1]-1) < 1e-12
r = rotate_pair([3.0, 4.0], 7, 0.13)
assert abs(sum(v*v for v in r)-25.0) < 1e-10
dot = lambda a,b: sum(x*y for x,y in zip(a,b))
q, k = [1.0,2.0], [-0.5,3.0]
a = dot(rotate_pair(q, 2, .2), rotate_pair(k, 5, .2))
b = dot(rotate_pair(q, 12, .2), rotate_pair(k, 15, .2))
assert abs(a-b) < 1e-10
print("通过：旋转方向、范数与相对位置性质")

```

## 本地 PyTorch 练习

补全 rope_pairs(x, positions)。x 为 [B,T,D] 且 D 为偶数，positions 为长度 T 的向量，使用相邻通道配对。

```python
import torch

def rope_pairs(x, positions, base=10000.0):
    # TODO: 构造频率、角度和成对旋转
    raise NotImplementedError("请实现 RoPE")

```

### 提示

- 用偶数索引与奇数索引通道组成二维旋转平面，并使用相同的 cos/sin。
- 位置向量沿 T，频率沿 D/2；角度矩阵应为 [T,D/2]。
- 保持 x 的 dtype/device，最后 stack 后只合并最后两个轴。

### 参考实现与解释

```python
import torch

def rope_pairs(x, positions, base=10000.0):
    dim = x.shape[-1]
    if dim % 2:
        raise ValueError("D 必须为偶数")
    freq = base ** (-torch.arange(0, dim, 2, device=x.device, dtype=x.dtype) / dim)
    angle = positions.to(x)[:, None] * freq[None, :]
    c, s = angle.cos()[None], angle.sin()[None]
    a, b = x[..., 0::2], x[..., 1::2]
    return torch.stack((a*c-b*s, a*s+b*c), dim=-1).flatten(-2)

```

零位置对应零角度，因此输出应等于输入；正交旋转保持平方范数。测试进一步验证平方范数对输入的梯度仍为 2x，这能发现旋转方向、通道重排或梯度连接错误，而不只验证前向形状。

### 断言测试

```python
torch.manual_seed(15)
x = torch.randn(2, 4, 8, dtype=torch.float64, requires_grad=True)
pos = torch.arange(4)
y = rope_pairs(x, pos)
torch.testing.assert_close(y[:, 0], x[:, 0])
torch.testing.assert_close(y.square().sum(-1), x.square().sum(-1))
y.square().sum().backward()
torch.testing.assert_close(x.grad, 2*x.detach())
print("通过：零位置、范数、批量形状与反向传播")

```

## 练习：推导与分析

### token ID、position_id、动作未来步 h 与生成时间 t 分别代表什么？它们可以共用一个未经解释的 time 变量吗？

token ID 表示词表中的离散身份，position_id 表示模型序列中的位置；动作未来步 h 表示预测块中第几个动作。它们可能相关，但不是同一个量，例如一张图像可以展开成许多个视觉 token。

生成时间 t 表示扩散或流匹配路径上的状态，不是机器人已经经过多少秒，也不是动作索引。应分别命名并记录范围、单位、形状和注入位置，否则即使张量维度兼容，也可能输入了错误条件。

代码定位：追踪 Embedding 的整数索引、RoPE 位置与 time_mlp 输入三条不同路径。

- 至少正确区分离散身份、序列位置与生成状态。
- 说明维度相同不能证明语义相同。

### 为什么 RoPE 的旋转保持范数，同时还能让 Q/K 点积包含相对位置？共同平移两组位置时如何检查？

每个通道对乘以二维正交旋转矩阵，因此其欧氏范数不变。两个向量分别旋转后做点积，组合旋转由两个位置的角度差决定，所以点积可以包含相对位置关系。

固定原始 Q/K，分别在位置 m、n 计算点积，再同时将两个位置加上同一偏移，结果应在浮点容差内一致。这个检查还要求使用相同频率与通道配对约定，不能只验证每个向量的范数。

代码定位：比较 rope(q,pos)@rope(k,pos).transpose(-1,-2) 与共同加偏移后的矩阵。

- 解释正交性与相对角度。
- 提出同时平移位置的点积对照检查。

### 给每个 token 加上不同位置编码后立刻平均池化，是否已经保存了内容的顺序？

没有保证。若编码仅为 \(x_i+p_i\)，均值只剩内容均值与位置均值，交换内容但固定位置集合不会改变结果。对 [1,3]、[3,1] 和位置 [0,10]，两者的均值都为 7。

内容必须先与位置发生交互，配对关系才可能进入聚合结果。例如 \(\sum_i x_i p_i\) 在两例中分别为 30 和 10。这个乘积只是展示机制，实际可由合适的非线性或注意力形成，不保证任意编码器都学会保留所需信息。

如果进入池化前的骨干早已编码空间关系，池化仍可能保留任务所需信息。因此应分析整个计算路径，不能仅由最后一个 mean 判定模型完全丢失空间能力。

代码定位：固定位置编码，交换内容，比较交互前后两种聚合。

- 展开均值公式给出反例。
- 区分“注入位置”与“保留内容—位置关系”。

## 练习：辨析与纠错

### 换 tokenizer 后沿用原 Embedding 行号

相同词表大小不能证明 ID 意义相同。保存并核对词表、特殊 token 和文本模板，打印固定文本的编码结果。

### 将 padding_idx 当作完整 Padding 处理

位置向量、偏置和后续交互仍可能产生非零值。有效位需要沿注意力、池化和损失继续使用。

### 缓存解码把 position_ids 重置为零

历史 K 已有位置，新 Q 的偏移若错误，点积关系就变。用整段与不等长分块输出逐位置对照。

### 频率编码可计算就意味着可可靠外推

数学上能得到远处位置的向量不代表模型在该分布上训练过。长上下文或时间尺度改变都需要相应验证。

### 把生成时间当机器人执行步

一次 ODE/去噪步更新整个动作块，H 轴与生成时间轴并非同一个轴。写清单位和 shape，分别做输入干预。

## 原始资料

- [RoFormer：Rotary Position Embedding](https://arxiv.org/abs/2104.09864)
- [PyTorch：Embedding](https://docs.pytorch.org/docs/stable/generated/torch.nn.Embedding.html)
- [Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747)
- [Attention Is All You Need：正弦位置编码](https://arxiv.org/abs/1706.03762)
