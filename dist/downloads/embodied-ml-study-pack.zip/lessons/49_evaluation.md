# 闭环评估与统计

比较对象、重复试验、配对设计与不确定性。

训练目标衡量模型在给定样本上的预测，机器人评估衡量策略与执行系统在任务中的结果，两者之间需要独立的证据。一个成功率还取决于测试条件、试验数量与汇总权重，不能脱离实验设计解释。本章从要估计的行为问题出发，建立分组指标、二项比例区间与配对比较，再讨论消融和选模如何支持可靠结论，承接行为克隆中的闭环分布差异。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [泛化与验证](https://wxb1870.github.io/embodied-ml-lab/learn/generalization/) · [示教数据与采样](https://wxb1870.github.io/embodied-ml-lab/learn/data-quality/) · [行为克隆](https://wxb1870.github.io/embodied-ml-lab/learn/behavior-cloning/)

## 一个分数在估计哪个问题

离线动作 MSE 估计模型在给定数据分布上的预测误差；闭环成功率估计策略与执行系统在某组起始条件和任务上的结果。模型可能通过平均多峰标签得到更低 MSE，却产生不可执行动作；也可能在关键阶段更准确而总体 MSE 没有明显变化。评价指标首先应与实验要回答的行为问题一致。



成功率背后还隐含条件分布：物体、场景、初始姿态、任务指令和扰动的抽样方式。只在固定桌面重复一个动作，不能支持广泛新场景结论。应说明这些条件怎样产生、是否固定、是否被训练或调参见过，以及一次试验的时间上限与人工介入规则。



常用的辅助指标包括任务完成时间、关键阶段成功率、接触或碰撞事件、动作延迟和恢复次数。辅助指标帮助解释结果，但不能在看完结果后挑选最有利的一项当成原本目标。预先定义主指标与分组分析，能够减少对同一组数据作过度解释。





### 在运行前写下成功与失败的定义

未固定的判据会让同一段执行被不同评估者作不同解释，后续统计再精细也无法修复。

记录起始分布、成功判定、超时、人工介入、无效试验和重试计数规则，并保存原始结果。

## macro 与 micro 衡量不同权重

不同任务的结果汇成一个数时，必须决定每个任务还是每次试验拥有相同权重。这个选择对应不同的目标分布，不能由哪一个分数更高来决定。保留原始成功次数与分母，才能追踪总体变化来自行为改善还是试验组成。



若每个任务成功率为 \(\hat p_k\)，macro 是对任务成功率求平均，给每个任务相同总权重；micro 是总成功次数除以总试验次数，给每次试验相同权重。任务试验数不相同时，两者一般不同。选择哪一种取决于目标分布，不能因为某个结果更高就临时切换。



任务难度和试验分配不均衡时，总分尤其容易误导。一个方法可能在大多数小任务上退化，却因一个试验量特别大的任务改善而提高 micro；也可能专门优化大量罕见任务从而提高 macro，却不匹配真实部署频率。因此应保留各任务原始成功/试验数，再给出有明确定义的聚合指标。



失败回合不能在汇总前静默删除。若某些硬件故障按协议被标为无效试验，应区分故障原因、是否与策略有关以及剔除规则；与策略有关的超时或队列耗尽通常是系统表现的一部分。分母随方法变化而没有解释时，即使百分比相同，也可能不再是在比较同一个试验总体。



$$
\hat p_{\rm macro}=\frac1K\sum_{k=1}^{K}\frac{s_k}{n_k},\qquad \hat p_{\rm micro}=\frac{\sum_k s_k}{\sum_k n_k}
$$



### 例：同一组结果的两种总体成功率

1. 任务 A 成功 90/100，任务 B 成功 1/10。

2. macro=(0.9+0.1)/2=0.5；micro=91/110≈0.8273。

3. 两个数都计算正确，但一个按任务等权，一个按实际试验数加权。

报告分组成功次数与试验次数，并明确总体指标的权重。

## 独立试验单位比记录条数重要

成功次数越多通常提供更多信息，但前提是这些试验确实增加了相应的独立证据。训练种子、场景和重复 rollout 处在不同随机层次。先识别要评价哪一种变化，再选择区间与重采样单位，才能避免虚假的精确性。



标准二项成功率区间常假设试验独立、具有同一个成功概率，或在已定义随机条件抽样下可作相应解释。同一机器人不 reset 连续试十次、同一场景的高度相似初始状态、同一训练种子下的多次 rollout，都可能具有相关性。把它们当成完全独立，会使不确定性看起来过小。



需要区分训练随机性与评估随机性。多个训练种子代表从训练过程得到不同模型，多次测试一个模型主要反映环境或采样变化。一个模型跑很多回合，不能替代多个独立训练结果来支持“训练方法稳定”的主张。资源受限时可以报告当前范围，但要清楚说明区间涵盖哪种变化来源。



如果数据按场景或采集会话成组，重采样和区间计算也应尊重这些组。分层或组级 bootstrap 可以保留相应结构，但没有一个默认函数能自动推断正确的独立单位。先画出数据生成过程，再选择抽样层级，比把所有零一结果扔进统计库更有依据。





## Wilson 区间怎样表达有限试验的不确定性

给定合理的独立试验协议，仍需表达有限次数带来的统计不确定性。Wilson 方法从哪些成功概率与观测结果相容这一问题出发，而不是直接把点估计当真值。推导得分检验的接受区间，可以解释公式的中心为何会偏离样本比例。



给定 n 次独立伯努利试验、成功 s 次，点估计 \(\hat p=s/n\) 并不说明真实成功概率恰好等于这个比例。Wilson 区间通过反演得分检验得到，避免简单正态区间在小样本或边界附近出现负概率等问题。这里使用 \(z=1.96\) 构造常见的近似双侧 95% 区间，并明确它依赖试验假设。



对候选成功概率 \(p\in(0,1)\)，伯努利样本比例的标准差是 \(\sqrt{p(1-p)/n}\)。使用大样本正态近似的得分统计量 \(Z(p)=(\hat p-p)/\sqrt{p(1-p)/n}\)，保留满足 \(|Z(p)|\le z\) 的候选值。平方并乘正分母，得到 \(n(\hat p-p)^2\le z^2p(1-p)\)。



展开并整理为 \((n+z^2)p^2-(2n\hat p+z^2)p+n\hat p^2\le0\)。二次项系数为正，因此被接受的 p 位于两个根之间；使用求根公式并分别整理中点与半宽，就得到下方表达式。它在边界处可连续取极限。区间由近似检验反演而来，并不具有对每个 n、p 都恰好等于 95% 的有限样本覆盖率。



同为 90% 成功率，9/10 的 Wilson 区间约为 [59.6%,98.2%]，90/100 约为 [82.6%,94.5%]；样本量改变了证据的精度。即使 10/10 全成功，下界也只有约 72.2%，不能因此宣称系统绝不会失败。区间宽说明信息有限，不是算法或统计方法工作不正常。



频率学区间的覆盖率描述重复使用该构造方法的长期行为，不是“这一个固定真实参数有 95% 概率落在当前区间”这一贝叶斯陈述。区间也不会自动修复选择偏差、依赖性或更换测试分布。先满足数据协议，再解释数值；不要只报告一个漂亮的置信度标签。



$$
\mathrm{center}=\frac{\hat p+z^2/(2n)}{1+z^2/n},\qquad \mathrm{half}=\frac{z\sqrt{\hat p(1-\hat p)/n+z^2/(4n^2)}}{1+z^2/n}
$$

```python
from math import sqrt, isclose

def wilson(successes, trials, z=1.96):
    if trials <= 0 or not 0 <= successes <= trials:
        raise ValueError("require trials > 0 and 0 <= successes <= trials")
    phat = successes/trials
    denominator = 1 + z*z/trials
    center = (phat + z*z/(2*trials))/denominator
    half = z*sqrt(phat*(1-phat)/trials + z*z/(4*trials**2))/denominator
    low, high = center-half, center+half
    for endpoint in (low, high):
        quadratic = ((trials+z*z)*endpoint**2
                     -(2*trials*phat+z*z)*endpoint + trials*phat**2)
        assert isclose(quadratic, 0., abs_tol=1e-10)
    assert -1e-12 <= low <= high <= 1+1e-12
    return max(0., low), min(1., high)  # Guard only floating-point endpoint roundoff.

for successes, trials in [(9, 10), (90, 100), (10, 10), (0, 10)]:
    print(f"{successes}/{trials}:", wilson(successes, trials))

```

这里检验中心加减半宽确实是得分不等式的两个边界，兼顾零成功与全成功。它验证代数实现和文中的数值例子；没有通过这些断言就证明试验独立、分布恒定或区间具有精确覆盖率。 最后一步只消除浮点运算可能在边界产生的极小越界，不改变推导中的数学区间。



### 例：全成功也不等于已知成功概率为 1

1. n=10、s=10，点估计为 1。

2. Wilson 分母为 \(1+\frac{1.96^2}{10}\)；代入公式得到约 [0.7225,1]。

3. 继续增加独立试验会缩小不确定性，但不能靠复制同一次成功记录增加证据。

点估计、区间和试验条件需要一起报告。

### 把少量全成功写成确定性保证

有限观察没有排除低概率失败，更没有覆盖未采样的场景。

同时给出 s/n 和区间，明确独立性与条件范围，不用百分比掩盖试验数。

## 配对对照与 bootstrap 为什么要一起重采样

比较两个方法时，同一测试条件上的结果通常具有共同的难度因素。保留这种配对关系，能够直接评价每个条件上的差异。重采样必须带走完整结果对，否则计算的已经是另一个随机实验。



若两个方法在同一组起始条件上测试，每个条件形成一个配对结果 \((A_i,B_i)\)。比较差值 \(D_i=B_i-A_i\) 可以消除一部分条件难度差异。配对 bootstrap 应抽取条件索引，再同时带走该索引的 \(A_i\) 与 \(B_i\)；分别独立打乱两边，会破坏配对结构并改变所估计的差值分布。



配对不等于每次实际环境完全相同。真实机器人测试可能因磨损、物体复位误差或执行顺序变化产生额外差异，应随机化或交错方法次序，并记录影响因素。若有多个训练种子或场景组，需要在相应层级保持配对，而不是只按文件行号认定可配对。



两个成功率区间是否重叠，不是配对差异是否显著的等价判断。应直接估计差值及其不确定性，并同时说明效应是否具有实际意义。一个统计上可辨认的微小提升，可能不足以补偿明显更高的延迟或资源成本；反之，较宽区间也不能证明两方法等效。





## 消融设计隔离哪个变化

统计差异并不会自行说明哪项设计造成了差异。消融实验需要先提出可被干预的机制假设，再控制其他影响因素。训练预算、数据身份与执行协议共同决定比较是否能够支持所声称的原因。



一次消融应回答一个具体机制问题，例如去掉历史是否损失动态信息、固定采样预算时某个条件注入是否有效。尽量保持数据版本、模型初始化分布、训练预算、评估条件与控制接口可比。改变骨干、数据清洗和执行周期后再把提升归因于某个新模块，无法隔离它的贡献。



完全相同超参数未必是唯一公平比较方式：不同结构可能需要不同学习率，但应给出相同或明确的调参预算。除了最终最优值，还应记录训练成本、选模规则和重复实验范围。若某方法在更多测试条件上试错后挑到最佳版本，它拥有额外评价信息，应在结论中反映。



失败分析可按感知、条件理解、动作生成、接触控制、时序与恢复阶段记录，但阶段标签需要可复查规则。只展示成功视频容易忽略失效模式；应从完整试验清单出发抽样查看，保留能解释差异的典型失败。机制假设应由干预对照支撑，而不是用一个视频事后叙述。





### 先说明比较要隔离的变量

不同数据、预算或执行接口都可能改变结果，不能让它们与目标模块一起变化后仍归因于单一机制。

写出实验变量、固定项、调参预算和评估条件清单，按协议记录全部试验。

## 选模、重复测试与最终结论

评价流程本身也会影响最终证据，因为每次查看结果都可能改变下一次设计选择。开发阶段的探索有价值，但不能继续把反复使用的条件当成未见测试。将选模、停止规则与最终报告分开，才能解释区间和成功率所覆盖的范围。



开发集用于调参、排错和选择 checkpoint，最终测试集用于对选定方案作独立评估。若看完测试失败后补采相同条件或反复调整超参数，这些条件已成为开发信息。模型权重没有直接用其标签反传，也不代表没有发生评价反馈泄漏。



反复测试很多版本直到某一个“显著”，会增加偶然发现的机会。预先固定主要比较、预算和停止规则；探索性结果可以保留，但要与事先定义的检验区分。不要因为连续几次测试看起来稳定就随意停止并按固定样本协议解释区间，也不要在成功时停止、失败时继续采样。



Wilson 区间、配对 bootstrap 与 macro/micro 各回答不同问题。结果应同时给出模型、条件、成功判据、分母、配对关系、差值与区间，使读者能够重建比较过程。统计量的解释依赖实验设计，增加小数位不会增加证据。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| baseline / candidate outcomes | [N] | 同一情景顺序下的二值成功记录 |
| bootstrap indices | [R,N] | 每行是一组以试验对为单位的重采样索引 |
| per-task outcome matrix | [K,N_max] | 各任务试验结果，未评估位置需要 Mask |

## 完整代码与精读

```python
import math
import torch

torch.manual_seed(7)

# STEP 1: 明确每个元素是一条完整试验，两个方法使用同一情景索引
baseline = torch.tensor([1,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0],dtype=torch.float64)
candidate = baseline.clone()
candidate[torch.tensor([2,4,6])] = 1
candidate[0] = 0
assert ((baseline == 0) | (baseline == 1)).all()
assert baseline.shape == candidate.shape

# STEP 2: Wilson 区间假定这些试验可作为独立同分布伯努利样本
def wilson(successes, trials, z=1.96):
    p = successes/trials
    denominator = 1+z*z/trials
    center = (p+z*z/(2*trials))/denominator
    half = z*math.sqrt(p*(1-p)/trials+z*z/(4*trials*trials))/denominator
    return max(0.,center-half),min(1.,center+half)

n = len(candidate)
rate = candidate.mean().item()
interval = wilson(int(candidate.sum().item()),n)

# STEP 3: 以试验对为单位抽样，不打乱 baseline/candidate 的对应关系
generator = torch.Generator().manual_seed(7)
indices = torch.randint(n,(4000,n),generator=generator)
paired_difference = candidate-baseline
bootstrap_delta = paired_difference[indices].mean(dim=1)
ci = torch.quantile(bootstrap_delta,torch.tensor([0.025,0.975],dtype=torch.float64))

# STEP 4: 同时报告分子分母、效应大小与区间
print('candidate successes/trials:', int(candidate.sum()), '/', n)
print('candidate success rate:', round(rate,3), 'Wilson:', tuple(round(v,3) for v in interval))
print('paired improvement:', round(paired_difference.mean().item(),3))
print('paired percentile-bootstrap interval:', [round(v,3) for v in ci.tolist()])
print('Synthetic example: intervals do not establish real-world generalization.')

```

- 第 6–13 行：同一数组位置代表相同评估情景。candidate 有三次从失败变成功，也有一次从成功变失败，不能只展示改善样例。
- 第 14–25 行：Wilson 区间使用成功次数与总试验数。其独立性假设需要由实验设计支持，不能靠公式自动获得。
- 第 26–32 行：对 paired_difference 的索引抽样保留了配对。若同会话内试验相关，还需改为按会话等独立单元分组重采样。
- 第 33–38 行：同时报告点估计和区间。区间包含零意味着该估计仍容许零差值，不能只凭正点估计断言改动有效。

预期观察：候选方法为 12/20=60%，相对基线配对提升 10 个百分点。区间较宽，示例用于理解统计量，不是实际机器人性能报告。

## 浏览器 Python 练习

实现 wilson_interval(successes,trials,\(z=1.96\))，返回裁剪在 [0,1] 内的 (low,high)。成功次数必须是 0 到 trials 的整数，trials 为正整数，z 为正有限数。

```python
import math

def wilson_interval(successes, trials, z=1.96):
    # TODO: 先算分母、中心和半宽，再得到区间
    raise NotImplementedError

```

### 提示

- 不要使用简单的 p ± 常数；Wilson 的中心也会调整。
- n=0 没有可估计的成功率，应明确报错而不是返回 0%。

### 参考实现与解释

```python
import math

def wilson_interval(successes, trials, z=1.96):
    if not isinstance(successes,int) or not isinstance(trials,int) or trials <= 0 or not 0 <= successes <= trials:
        raise ValueError('invalid binomial counts')
    if not math.isfinite(z) or z <= 0:
        raise ValueError('invalid z')
    p = successes/trials
    d = 1+z*z/trials
    center = (p+z*z/(2*trials))/d
    half = z*math.sqrt(p*(1-p)/trials+z*z/(4*trials*trials))/d
    return max(0.0,center-half),min(1.0,center+half)

```

9/10 的 95% 近似 Wilson 区间约为 59.6%–98.2%，说明少量试验下 90% 的点估计仍有很大不确定性。该解释依赖独立伯努利试验假设。

### 断言测试

```python
lo,hi = wilson_interval(9,10)
assert abs(lo-0.59585) < 0.001 and abs(hi-0.98212) < 0.001
lo2,hi2 = wilson_interval(90,100)
assert hi2-lo2 < hi-lo
lo3,hi3 = wilson_interval(0,10)
assert lo3 < 1e-12 and 0.27 < hi3 < 0.29
try:
    wilson_interval(0,0)
    raise AssertionError('无试验应报错')
except ValueError:
    pass
print('Wilson 区间检查通过：相同成功率下，更多独立试验通常带来更窄区间。')

```

## 本地 PyTorch 练习

实现 macro_micro_success(scores, valid)。输入为 [任务数, 最大试验数]。valid 标记真实试验，每个任务至少一条，真实结果只能是 0/1。返回 macro 与 micro 两个标量。

```python
import torch

def macro_micro_success(scores, valid):
    # TODO: 先按任务汇总，再分别用任务数和试验数加权
    raise NotImplementedError

```

### 提示

- 先按任务累加有效成功次数和有效试验次数。
- macro 平均每任务比率；micro 先汇总分子分母。使用 where 排除无效 NaN。

### 参考实现与解释

```python
import torch

def macro_micro_success(scores, valid):
    if scores.ndim != 2 or scores.shape != valid.shape or valid.dtype != torch.bool:
        raise ValueError('invalid scores or mask')
    values = scores[valid]
    if not ((values == 0) | (values == 1)).all():
        raise ValueError('outcomes must be binary')
    counts = valid.sum(dim=1)
    if (counts == 0).any():
        raise ValueError('every task needs an evaluation')
    successes = torch.where(valid,scores,torch.zeros_like(scores)).sum(dim=1)
    return (successes/counts).mean(), successes.sum()/counts.sum()

```

macro 给每个任务相同权重，micro 给每次有效试验相同权重，所以不等次数评估时会不同。先验证有效条目是 0/1，并拒绝零试验任务，避免默默把未评估任务当作失败。torch.where 可在求和前排除无效位置的 NaN；直接 NaN*0 仍产生 NaN。两种指标都需公开分母与任务组成。

### 断言测试

```python
s = torch.tensor([[1.,1.,float('nan'),float('nan')],[0.,0.,0.,0.]])
v = torch.tensor([[True,True,False,False],[True,True,True,True]])
macro,micro = macro_micro_success(s,v)
torch.testing.assert_close(macro,torch.tensor(0.5))
torch.testing.assert_close(micro,torch.tensor(1/3))
assert torch.isfinite(macro) and torch.isfinite(micro)
print('Macro=0.5，Micro=1/3；不同分母回答不同问题。')

```

## 练习：推导与分析

### 方法 A 是 9/10，方法 B 是 90/100，可以说两者证据同样充分吗？

两者点估计都是 90%，但有限独立试验带来的不确定性不同。用相同方法计算区间时，一百次通常比十次更窄。应报告成功次数、总试验数和区间，而不是只显示百分比。

更多记录也不自动代表更多独立证据。连续同场景重试、同一物品或同一采集会话可能相关，应按适当独立单元分析。区间不能修复评估场景选择偏差，也不能替代在新场景上的测试。

代码定位：wilson_interval 的 n 与成功计数；评估日志中的 episode/session/object 元数据。

- 区分点估计与不确定性。
- 说明独立性及场景选择的限制。

### 两个模型都在相同 20 个场景上跑过，比较提升时为什么要保留配对？

同一个场景可能对两个模型都特别难或特别容易。逐场景相减保留了这种共有难度信息，能回答在相同条件下新模型改善了多少。如果把两个模型的结果各自独立重采样，会丢掉原有对应关系，改变估计方式。

配对 bootstrap 应一起抽取某个场景的两条结果，或等价地重采样逐场景差值。若场景还属于相关会话，则需要按组重采样。除了平均差，还应检查改善和退化的场景；不能只挑选新模型成功、旧模型失败的片段。

代码定位：paired_difference=candidate−baseline 与 paired_difference[indices]。

- 说明抽样单位是试验对。
- 同时关注改善、退化及可能的组相关性。

## 练习：辨析与纠错

### 只报告百分比不报告成功/试验数

9/10 与 90/100 的证据精度不同。保留原始计数、条件分组和区间。

### 把所有帧或高度相关 rollout 当独立样本

相关性会夸大有效样本量。按模型种子、场景或会话识别独立单位并据此重采样。

### 分别 bootstrap 两个配对方法

独立抽样破坏同一条件之间的关联。按配对索引同时抽取两边结果，直接计算差值分布。

### 只看区间是否重叠就判断方法差异

比较所需的是差值或等效性对应的统计问题。结合实际效应、试验设计及其区间，不从重叠图作绝对判断。

### 多次调参后仍称同一集合为盲测

这些条件已经反馈到开发过程。记录使用历史，并为最终方案保留未参与选择的评估条件。

## 原始资料

- [可靠评估与统计不确定性：rliable 原论文](https://arxiv.org/abs/2108.13264)
- [NIST：二项比例置信界与 Wilson 方法](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm)
- [PyTorch quantile 官方文档](https://docs.pytorch.org/docs/stable/generated/torch.quantile.html)
