# 生成建模、潜变量与 VAE

从边缘似然和后验推断推导 ELBO，明确重建、KL 与重参数化的含义。

生成模型用概率分布描述数据，并能从中产生新的样本；潜变量模型通过先采一个未直接观测的变量、再生成数据来实现这种分布。变分自编码器（VAE）在此基础上增加近似推断网络，用可计算的下界训练生成模型。本章先区分采样与密度，再认识先验、后验和解码器，随后推导 ELBO、重参数化与条件生成。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/)

## 生成模型学习的对象：分布、密度与采样

生成建模的目标是表示数据怎样分布，并据此产生样本；密度计算则回答模型给某个观测多大支持。能够采样与能够方便地计算密度是两种能力。先定义样本与条件，再选择要学习和评价哪一种对象。



生成建模首先需要指定随机变量和条件。设 \(A\in\mathbb R^D\) 为一个连续样本，\(c\) 为生成前可获得的条件；图像、潜空间向量和展开后的动作片段都可以作为 \(A\)，但它们使用的度量、支撑集和似然模型可能不同。模型希望表示 \(p_\theta(a\mid c)\)，并能够从这个条件分布采样。一个确定性回归输出只给出某种统计量；将相同输出重复多次不会自动得到条件不确定性。



若模型密度可计算，最大似然最小化训练样本的平均负对数密度。在真实数据分布具有相应密度、熵和交叉熵有限时，期望 NLL 等于数据熵加上 \(D_{\rm KL}(p_{\rm data}\Vert p_\theta)\)。数据熵不依赖 \(\theta\)，所以最大似然在这个假设下对应正向 KL 最小化。经验样本集合是有限观测，不能把对连续密度的这条总体恒等式直接套到“离散经验分布与连续模型的 KL”而忽略测度差异。



能够采样与能够求密度是两个不同接口。潜变量模型通常容易按先验采 \(z\) 再解码，却难以积分掉 \(z\)；Flow 可通过可逆变换或散度积分求密度，但训练 MSE 本身不是 `log_prob`；扩散的变分界又是另一类可计算量。因此，比较生成方法时应明确报告的是对数似然、变分下界、回归目标、样本分布指标，还是实际任务成功率。



本篇先省略条件 \(c\)，使用 \(a\) 表示观测值、\(z\) 表示潜变量。条件模型在最后一节恢复。前置的[概率与训练目标](#/learn/probability?tab=theory)给出密度、条件期望和 KL 的基础；这里关心无法直接计算边缘似然时，如何构造可优化的目标。



$$
\mathbb E_{A\sim p_{\mathrm{data}}}[-\log p_\theta(A)]=H(p_{\mathrm{data}})+D_{\mathrm{KL}}(p_{\mathrm{data}}\Vert p_\theta)
$$



## 潜变量如何产生复杂分布，后验为什么难算

潜变量是模型中未直接观测、用于组织生成过程的随机变量。先验规定生成前它怎样分布，解码器规定给定它如何产生数据，后验则反过来描述观测数据后它可能取什么值。下面用这条双向关系解释边缘积分的困难。



引入 \(Z\in\mathbb R^d\)，规定先验 \(p(z)\) 和条件观测模型 \(p_\theta(a\mid z)\)。生成时先采 \(z\)，再从解码器给出的观测分布中采 \(a\)；边缘密度要对所有可能 \(z\) 积分。即使每个 \(p_\theta(a\mid z)\) 很简单，积分后的 \(p_\theta(a)\) 仍可以复杂、多峰。神经网络通常输出条件分布的参数，不等于直接给出归一化后的边缘密度。

![VAE 训练从观测数据经编码器、近似后验和重参数化到解码器；生成从先验采样后直接使用同一个解码器。](../assets/figures/vae-definition.svg)

先区分两个方向：生成模型从潜变量走向数据；训练时的编码器从观测数据近似推断潜变量。上排采用对角高斯近似后验，重建项与 KL 项稍后展开；下排生成新样本时从先验出发。依据 [Kingma & Welling §2](https://arxiv.org/abs/1312.6114) 独立绘制。

贝叶斯公式给出 \(p_\theta(z\mid a)=\frac{p_\theta(a\mid z)p(z)}{p_\theta(a)}\)。这里分母就是难以计算的边缘积分。用另一张网络 \(q_\phi(z\mid a)\) 近似这个后验，意味着输入同一个 \(a\) 后输出一个潜变量分布的参数，例如均值与对角方差。\(q_\phi\) 是近似推断模型，\(p_\theta\) 是生成模型；二者参数、条件方向和可用信息都不同。



一个可解析的参照是 \(z\sim\mathcal N(0,1)\)，\(a\mid z\sim\mathcal N(z,\tau^2)\)，\(\tau>0\)。相加的独立 Gaussian 给出 \(a\sim\mathcal N(0,1+\tau^2)\)。固定观测 \(a\) 后，后验密度关于 \(z\) 的部分正比于 \(\exp[-\frac12(z^2+(a-z)^2/\tau^2)]\)，所以只需把指数中的二次式配成平方。



先展开得到 \((1+\tau^{-2})z^2-2a\tau^{-2}z+a^2\tau^{-2}\)，再将前两项配方：\[z^2+\frac{(a-z)^2}{\tau^2}=(1+\tau^{-2})\left(z-\frac{a}{1+\tau^2}\right)^2+\frac{a^2}{1+\tau^2}.\]最后一项不依赖 \(z\)，会进入归一化常数。因此后验精度为 \(1+\tau^{-2}\)，均值为 \(\frac{a}{1+\tau^2}\)，方差为 \(\frac{\tau^2}{1+\tau^2}\)。



当观测噪声变小，观测提供的精度 \(\tau^{-2}\) 变大，后验更集中于 \(a\)；噪声很大时，\(a\) 提供的信息变弱，后验趋近先验。这里先验、边缘分布与后验都来自同一个联合模型，不能将编码器的近似后验直接称为生成先验。



完整代码刻意使用这一可解析模型，使真实证据与后验都可检查。高维非线性 VAE 通常没有这些解析量，不能仅凭训练 loss 降低就宣布后验近似已经准确。



$$
\begin{aligned}p_\theta(a)&=\int p_\theta(a\mid z)p(z)\,dz,&p_\theta(z\mid a)&=\frac{p_\theta(a\mid z)p(z)}{p_\theta(a)}\\ z\mid a&\sim\mathcal N\!\left(\frac{a}{1+\tau^2},\,\frac{\tau^2}{1+\tau^2}\right)&&\text{for }a=z+\tau\epsilon\end{aligned}
$$



## ELBO 的推导：下界从哪里来，间隙是什么

证据下界（ELBO）是观测对数似然的一个可计算下界，由近似后验下的重建项与先验 KL 组成。它让难处理的边缘似然可以通过采样优化。下面推导下界和间隙，而非先把两个损失项当作经验配方。



固定观测 \(a\)，在适当支撑条件下，把边缘积分乘除同一个 \(q_\phi(z\mid a)\)，写为 \(q\) 下重要性比值的期望。要求 \(q\) 在所需积分区域具有支撑、涉及的对数和期望可积。对数是凹函数，Jensen 不等式使“期望的对数”不小于“对数的期望”，由此得到 evidence lower bound，记为 \(\mathcal L_{\rm ELBO}\)。



将联合密度分解为 \(p_\theta(a\mid z)p(z)\)，下界拆成两部分：重建对数似然的后验期望，以及负的 \(D_{\rm KL}(q_\phi(z\mid a)\Vert p(z))\)。最大化下界同时要求潜变量能够解释观测，并控制近似后验相对先验的代价。所谓“重建项减 KL”是从联合概率模型导出的表达式；任意重建误差再加任意正则项，不一定仍是这个模型的 ELBO。



还可以从后验 KL 反推同一结果。将 \(\log p_\theta(z\mid a)=\log p_\theta(a,z)-\log p_\theta(a)\) 代入 KL 的定义，\(\log p_\theta(a)\) 不依赖 \(z\)，可直接移出期望。整理后得到：



\[\log p_\theta(a)=\mathcal L_{\rm ELBO}+D_{\rm KL}(q_\phi(z\mid a)\Vert p_\theta(z\mid a))\]



这个等式说明下界的间隙由近似后验到真实后验的 KL 决定，而不是由 \(q\) 到先验的 KL 决定。



当 \(q\) 恰好等于真实后验时，间隙为零；固定为对角高斯的变分族不一定容纳真实后验。共享编码器还可能受到容量和优化误差限制，这通常称为摊销推断的限制。优化 \(\theta\)、\(\phi\) 时，生成模型的证据和后验近似质量都可能改变，因此较大的 ELBO 不能被解释成某一种误差单独减小。



实际通常最小化负 ELBO。代码中的符号应是 NLL 加 KL；若把 KL 减掉，会奖励远离先验。下面的解析模型同时计算真实 \(\log p(a)\)、ELBO 和后验 KL，以三方恒等式验证方向和常数，而不只检查一个 loss 是否有限。



$$
\begin{aligned}\log p_\theta(a)&=\log\mathbb E_{q_\phi(z\mid a)}\!\left[\frac{p_\theta(a,z)}{q_\phi(z\mid a)}\right]\\&\ge\mathbb E_q[\log p_\theta(a,z)-\log q_\phi(z\mid a)]\\&=\underbrace{\mathbb E_q[\log p_\theta(a\mid z)]-D_{\mathrm{KL}}(q_\phi(z\mid a)\Vert p(z))}_{\mathcal L_{\mathrm{ELBO}}}\\\log p_\theta(a)-\mathcal L_{\mathrm{ELBO}}&=D_{\mathrm{KL}}(q_\phi(z\mid a)\Vert p_\theta(z\mid a))\ge0.\end{aligned}
$$



## 对角高斯 KL：从对数密度逐项求期望

高斯 KL 衡量近似后验与先验在指定方向上的分布差异。对角高斯使用独立坐标的均值和方差，使这一项可解析计算。下面直接对两份对数密度求期望，解释均值、方差与常数项各从哪里来。



令 \(q=\mathcal N(\mu,\operatorname{diag}(s^2))\)，\(p=\mathcal N(0,I)\)，潜变量维度为 \(d\)，所有 \(s_i>0\)。\(q\) 的每维对数密度包含 \(-\log s_i\) 和 \(-\frac{(z_i-\mu_i)^2}{2s_i^2}\)；标准高斯先验对应 \(-z_i^2/2\)。相减后，在 \(q\) 下使用 \(\mathbb E[(Z_i-\mu_i)^2]=s_i^2\) 和 \(\mathbb E[Z_i^2]=\mu_i^2+s_i^2\)，归一化常数相消，得到每维 KL 后相加。



实现中常预测 \(\ell_i=\log s_i^2\)，即 log-variance。于是方差为 \(\exp(\ell_i)\)，标准差为 \(\exp(\ell_i/2)\)。将 \(\exp(\ell_i)\) 当标准差会在采样时把方差再平方一次；这类错误往往不改变张量形状。\(\mu=0\)、\(\ell=0\) 对应 \(q=p\)，KL 必须为零；\(\mu\ne0\) 或方差变化应增加相应代价。



\(\mu\) 和 \(\ell\) 通常形状为 \([B,d]\)。先对 \(d\) 求和得到每个样本的联合 KL，再对 \(B\) 取平均。若重建项对全部观测维求和、KL 却对潜变量维取平均，等效 KL 权重会随潜变量维度变化。无论选择何种归约，都要明确它对应哪个目标，不能以“mean 更方便”为理由改变两项的相对尺度。



固定先验不代表先验永远最合理。学习先验、结构化后验或条件先验会改变相应 KL 的表达式；本节公式只适用于指定的对角高斯与单位高斯。它不是对任意分布都成立的正则化公式。



$$
\begin{aligned}D_{\mathrm{KL}}(q\Vert p)&=\sum_{i=1}^d\mathbb E_q\!\left[-\log s_i-\frac{(Z_i-\mu_i)^2}{2s_i^2}+\frac{Z_i^2}{2}\right]\\&=\frac12\sum_{i=1}^d\left(\mu_i^2+s_i^2-1-\log s_i^2\right)\\&=\frac12\sum_{i=1}^d\left(\mu_i^2+e^{\ell_i}-1-\ell_i\right).\end{aligned}
$$



## 重建项选择的是观测模型，而不只是误差函数

观测模型是给定潜变量后数据的条件分布，解码器通常输出它的参数。重建损失来自这个分布的负对数似然，而不只是任选一种像素误差。先确定数据类型与噪声假设，再解释 MSE 等形式。



设解码器给出观测均值 \(f_\theta(z)\)，并明确规定 \(p_\theta(a\mid z)=\mathcal N(f_\theta(z),\tau^2I)\)。负对数似然等于平方误差除以 \(2\tau^2\)，再加 \(D\log\tau\) 与归一化常数。固定 \(\tau\) 时，优化重建均值等价于加权 MSE；但改变 \(\tau\) 会改变重建项相对 KL 的权重。若 \(\tau\) 也学习，\(\log\tau\) 项不能删除，否则模型可以只增大方差来降低误差项。



对于二值观测可以使用 Bernoulli 似然，其 NLL 是逐维二元交叉熵；任意实数动作并不满足二值观测假设。连续图像采用某种离散化似然、连续高斯近似或其他观测模型时，也需明确解释。概率模型应由变量语义决定，不能因为网络最后一层方便接 Sigmoid 就反过来赋予标签一个 Bernoulli 分布。



每个训练样本可从 \(q_\phi\) 采 \(S\) 个潜变量。重建分布的均值为 \([S,B,D]\)，观测 \(a\) 为 \([B,D]\)。观测维 \(D\) 是一个联合事件，需要按所选独立假设求和；\(S\) 是 Monte Carlo 轴，需要平均；\(B\) 是数据批次轴，也需要平均。把三个轴一次 mean 会额外除以 \(D\)，改变相对 KL 的量级。



动作归一化和有效位也会改变观测模型或误差度量。若动作各维具有不同固定尺度，等价的原单位高斯具有不同方差。Padding 不应作为真实观测进入重建似然；其处理应与[损失、掩码与归约](#/learn/losses?tab=theory)保持一致。



$$
-\log p_\theta(a\mid z)=\frac{\|a-f_\theta(z)\|^2}{2\tau^2}+D\log\tau+\frac D2\log(2\pi),\qquad \tau>0
$$



## 重参数化如何让梯度穿过随机采样

重参数化是把参数相关分布的采样改写为固定噪声经过可微变换的办法。这样参数变化仍能通过样本值影响目标，梯度便可沿变换回传。下面用高斯均值与尺度展示它解决的求导问题。



优化编码器 \(\phi\) 时，\(\mathbb E_{Z\sim q_\phi}[h_\theta(Z)]\) 的采样分布也依赖 \(\phi\)。把已经抽出的 \(z\) 当作与 \(\phi\) 无关的常数，会丢掉分布变化对目标的影响。重参数化把随机性放进一个分布固定的 \(\epsilon\sim\mathcal N(0,I)\)，令 \(z=\mu_\phi(a)+\exp(\ell_\phi(a)/2)\odot\epsilon\)。现在采样噪声不依赖 \(\phi\)，而 \(z\) 是参数的可微函数。



在允许交换求导与期望、路径函数可微且导数可积等条件下，可把编码器梯度写成：



\[\mathbb E\!\left[(\partial z/\partial\phi)^\top\nabla_z h_\theta(z)\right]\]



。对 \(\mu\) 有 \(\frac{\partial z_i}{\partial\mu_j}=\delta_{ij}\)；对 log-variance 有：



\[\frac{\partial z_i}{\partial\ell_j}=\frac12\exp(\ell_i/2)\epsilon_i\delta_{ij}\]



Autograd 追踪的正是这条计算路径，而不是对某次随机数发生器内部求导。



PyTorch 中具有可重参数化接口的分布可以使用 `rsample()`；普通 `sample()` 通常不保留这条路径。直接写 `μ+σ*torch.randn_like(μ)` 也可以，因为噪声本身不需要梯度，\(\mu\) 与 \(\sigma\) 的乘加仍在图中。对 \(z\) 调用 `detach`，或重新用 `torch.tensor(z)` 构造张量，会切断编码器从重建项获得的梯度。



这种路径导数与 score-function 估计是不同方法。离散潜变量不能直接套用连续高斯的可微变换；软松弛、枚举或其他估计器有各自目标和偏差。重参数化也不意味着一次随机梯度等于期望梯度，有限 Monte Carlo 样本仍有方差。



完整代码使用只含二次项的线性高斯模型，以 \(\epsilon\in\{-1,+1\}\) 两个等权点准确匹配零均值和单位二阶矩，核对 Autograd 与解析期望的梯度。这是该二次函数的确定性矩检验，不是宣称两个点能精确积分任意非线性 VAE。



$$
\begin{aligned}Z&=\mu_\phi(a)+\exp(\ell_\phi(a)/2)\odot\epsilon,\qquad\epsilon\sim\mathcal N(0,I)\\ \nabla_\phi\mathbb E[h_\theta(Z)]&=\mathbb E_\epsilon\!\left[\left(\frac{\partial Z}{\partial\phi}\right)^{\!\top}\nabla_Zh_\theta(Z)\right].\end{aligned}
$$



## 后验坍缩、聚合后验与 KL 权重的含义

后验坍缩指推断分布接近先验、潜变量对重建传递的信息不足的情况。聚合后验则是对所有数据的推断分布作平均后的总体分布。二者描述不同对象，下面从解码器依赖和 KL 权重解释它们。



先看一个明确的机制：若解码器实际满足 \(p_\theta(a\mid z)=p_\theta(a)\)，重建项就不随 \(z\) 变化，不能奖励编码器传递观测信息；先验 KL 则在 \(q_\phi(z\mid a)=p(z)\) 时达到零。这样的目标允许解码器忽略潜变量。这不是所有 VAE 都必然经历的过程，实际结果还取决于解码器、后验族、条件信息与优化动态。



定义 \(q(a,z)=p_{\rm data}(a)q_\phi(z\mid a)\)，以及聚合后验 \(q(z)=\int p_{\rm data}(a)q_\phi(z\mid a)\,da\)。将 \(\log\frac{q_\phi(z\mid a)}{p(z)}\) 拆成 \(\log\frac{q_\phi(z\mid a)}{q(z)}+\log\frac{q(z)}{p(z)}\)，再分别取联合期望，就得到平均先验 KL 等于互信息 \(I_q(A;Z)\) 加上聚合后验与先验的 KL。两项均非负。



因此平均 KL 接近零会限制潜变量携带的观测信息；严格等于零时，在相应几乎处处的意义下，\(q_\phi(z\mid a)=p(z)\)，潜变量不再随 \(a\) 改变。但平均 KL 大也不能证明表示很有用，因为代价可能来自聚合后验与先验不匹配。单看一个 KL 标量无法区分信息传递、先验失配以及不同潜维的活跃程度。



诊断时可以比较先验采样、后验采样、固定 \(z\) 与打乱 \(z\) 后的重建或任务结果，并检查每维后验均值变化与 KL。它们分别检查生成、推断和解码器对潜变量的依赖。仅凭 KL 下降不能判定模型改善，也不能把忽略潜变量归结为 KL 公式有错。



把负 ELBO 改为重建 \(\mathrm{NLL}+\beta\,D_{\rm KL}\)，或采用 KL warmup、free bits，会改变优化权衡；除 \(\beta=1\) 且其他项一致的标准情形外，不应继续把目标无条件称为原生成模型的同一个 ELBO。也不能仅因 \(\beta\) 较小、重建误差降低就推断先验采样更好。应把表示、重建和生成评估分开。



$$
\mathbb E_{A\sim p_{\mathrm{data}}}D_{\mathrm{KL}}(q_\phi(Z\mid A)\Vert p(Z))=I_q(A;Z)+D_{\mathrm{KL}}(q(Z)\Vert p(Z))
$$



## 条件 VAE、动作潜变量与生成模型之间的联系

条件 VAE 是让生成和推断同时依赖已知条件的潜变量模型。条件说明当前任务，潜变量表示在该条件下仍需表达的变化；生成时不能使用只在训练中可见的目标。下面将这一区分连接到动作潜变量。



加入条件 \(c\) 后，生成模型为 \(p_\theta(a,z\mid c)=p_\theta(a\mid z,c)p(z\mid c)\)，推断模型为 \(q_\phi(z\mid a,c)\)。条件 ELBO 在固定 \(c\) 下重复前面的推导。先验可以固定为 \(\mathcal N(0,I)\)，也可以依赖 \(c\)；只要先验改变，KL 的计算就要相应改变。条件编码器提供的是生成时可得到的信息，训练后验额外看到目标 \(a\) 是合法的推断设计。



部署时没有真实未来动作 \(a\)，因此不能调用依赖 \(a\) 的训练后验来生成。正确的生成路径是从 \(p(z\mid c)\) 采样，再通过 \(p_\theta(a\mid z,c)\) 产生动作。取 \(z=0\) 或后验/先验均值是某些实现采用的确定性选择，它既不是从先验采样，也不等于对所有 \(z\) 积分后的条件均值；非线性解码器通常使 \(f(\mathbb E[Z])\ne\mathbb E[f(Z)]\)。



在[生成式动作策略中的 ACT](#/learn/generative-policy?tab=theory&section=act-conditional-latent-model)中，潜变量可以概括同一观测下不同动作片段的变化，但具体架构、训练条件和测试时 \(z\) 的处理需查看相应实现。不能把条件 VAE 当作所有动作块模型或所有 VLA 的共同组成部分。



DDPM 同样可以从潜变量模型的变分目标理解，只是潜变量是一整条规定了前向加噪的轨迹；其常用 \(q\) 没有另一个学习型编码器。Flow Matching 则以固定概率路径的速度回归为核心训练机制。三者都在学习复杂条件分布，但训练下界、回归目标和采样接口不同。后续的[Diffusion](#/learn/diffusion?tab=theory)与[Score、SDE 和概率流](#/learn/score-sde?tab=theory)继续建立这些联系。



VAE 将生成、推断与学习连接成一套概率模型：先验提供潜变量，解码器定义数据分布，编码器近似后验，ELBO 提供训练依据。重建误差与 KL 都应回到这套定义解释，不能脱离观测模型判断好坏。



$$
\mathcal L(a,c)=\mathbb E_{q_\phi(z\mid a,c)}[\log p_\theta(a\mid z,c)]-D_{\mathrm{KL}}(q_\phi(z\mid a,c)\Vert p(z\mid c))
$$



## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| \(a\) / \(x\) | \([B,D]\) | \(B\) 个 \(D\) 维观测样本；\(D\) 是联合事件维 |
| \(\mu\) / \(\ell\) | \([B,d]\) | 近似后验的均值与 log-variance；\(d\) 是潜变量维 |
| \(\epsilon\) / \(z\) | \([S,B,d]\) | \(S\) 份基础噪声与重参数化潜变量样本 |
| \(f_\theta(z)\) | \([S,B,D]\) | 高斯解码器给出的观测均值 |
| KL / NLL | \([B]\) | 潜维/观测维求和且 Monte Carlo 轴平均后的每样本目标 |

## 完整代码与精读

```python
"""Check ELBO, its gap, pathwise gradients and amortized inference in one model."""
import math
import torch
from torch import nn

torch.manual_seed(19)
torch.set_num_threads(1)
torch.set_default_dtype(torch.float64)

# 1. z ~ N(0,1), x|z ~ N(z,tau^2); its exact posterior is available.
tau = 0.6
x = torch.tensor([-1.7, -0.8, 0.0, 0.5, 1.4])
posterior_variance = tau**2 / (1 + tau**2)
posterior_mean = x / (1 + tau**2)
mu = torch.tensor([-0.5, -0.3, 0.1, 0.3, 0.9], requires_grad=True)
logvar = torch.tensor([-0.4, -0.8, 0.0, -1.2, -0.6], requires_grad=True)
variance = logvar.exp()
expected_log_likelihood = -0.5 * (
    math.log(2 * math.pi * tau**2) + ((x - mu).square() + variance) / tau**2)
kl_prior = 0.5 * (mu.square() + variance - 1 - logvar)
elbo = expected_log_likelihood - kl_prior
log_evidence = -0.5 * (math.log(2 * math.pi * (1 + tau**2))
                      + x.square() / (1 + tau**2))
kl_posterior = 0.5 * (
    (variance + (mu - posterior_mean).square()) / posterior_variance - 1
    + math.log(posterior_variance) - logvar)
torch.testing.assert_close(log_evidence - elbo, kl_posterior)
assert (elbo <= log_evidence + 1e-12).all()
print("ELBO gaps:", kl_posterior.detach().tolist())

# 2. Two fixed points integrate these quadratic functions exactly.
# This is a moment check (E eps=0, E eps^2=1), not a generic Gaussian MC rule.
eps = torch.tensor([-1.0, 1.0])[:, None]
z = mu[None, :] + (0.5 * logvar).exp()[None, :] * eps
log_likelihood = -0.5 * (
    math.log(2 * math.pi * tau**2) + (x[None, :] - z).square() / tau**2)
pathwise_elbo = log_likelihood.mean(0) - kl_prior
torch.testing.assert_close(pathwise_elbo, elbo)
grad_mu, grad_logvar = torch.autograd.grad(pathwise_elbo.sum(), (mu, logvar))
manual_mu = (x - mu) / tau**2 - mu
manual_logvar = 0.5 * (1 - variance * (1 + 1 / tau**2))
torch.testing.assert_close(grad_mu, manual_mu)
torch.testing.assert_close(grad_logvar, manual_logvar)
print("pathwise gradients equal the analytic expectation gradients")

# 3. Fit an amortized encoder; the generative model above is deliberately fixed.
encoder = nn.Linear(1, 2)
optimizer = torch.optim.Adam(encoder.parameters(), lr=0.04)
for step in range(700):
    parameters = encoder(x[:, None])
    q_mu, q_logvar = parameters[:, 0], parameters[:, 1]
    expected_nll = 0.5 * (
        math.log(2 * math.pi * tau**2)
        + ((x - q_mu).square() + q_logvar.exp()) / tau**2)
    kl = 0.5 * (q_mu.square() + q_logvar.exp() - 1 - q_logvar)
    loss = (expected_nll + kl).mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

with torch.no_grad():
    fitted = encoder(x[:, None])
    mean_error = (fitted[:, 0] - posterior_mean).abs().max().item()
    logvar_error = (fitted[:, 1] - math.log(posterior_variance)).abs().max().item()
torch.testing.assert_close(fitted[:, 0], posterior_mean, rtol=0, atol=2e-3)
torch.testing.assert_close(fitted[:, 1], torch.full_like(x, math.log(posterior_variance)),
                           rtol=0, atol=2e-3)
print("encoder max mean/log-variance error:", mean_error, logvar_error)
print("passed: ELBO identity, pathwise gradients and exact-posterior recovery")

```

- 第 10–30 行：用线性高斯生成模型写出证据和真实后验；逐样本验证 log evidence−ELBO 等于后验 KL。先验 KL 与后验 KL 是不同对象。
- 第 31–45 行：固定两点的零均值和单位二阶矩，对这个二次函数准确积分；比较重参数化 Autograd 与对均值、log-variance 的解析梯度。
- 第 46–69 行：只训练共享线性编码器，固定已声明的生成模型；检查其均值与方差是否恢复解析后验。这个受控实验不代表高维 VAE 的生成效果。

预期观察：所有恒等式与梯度对照通过。编码器的后验均值与 log-variance 误差小于代码中的 2e-3 容差；具体浮点尾数取决于运行环境。

## 浏览器 Python 练习

仅用 Python 标准库实现 `diagonal_gaussian_kl(mu, logvar)`。输入是相同非零长度的均值和对数方差列表，返回联合分布的 KL，使用自然对数并对潜变量维求和。拒绝维度错误、非有限参数和方差溢出。

```python
def diagonal_gaussian_kl(mu, logvar):
    # TODO: 从 log-variance 恢复方差，逐维求和。
    raise NotImplementedError

```

### 提示

- 先用全零均值和 `logvar=0` 检查 \(q=p\) 时为零。
- `exp(logvar)` 是方差；不是标准差。
- 两个相同且独立的潜变量应使 KL 加倍，而不是保持不变。

### 参考实现与解释

```python
import math

def diagonal_gaussian_kl(mu, logvar):
    if len(mu) == 0 or len(mu) != len(logvar):
        raise ValueError("nonempty matching latent dimensions are required")
    if not all(math.isfinite(float(v)) for v in [*mu, *logvar]):
        raise ValueError("parameters must be finite")
    try:
        result = 0.5 * sum(float(m)**2 + math.exp(float(lv)) - 1 - float(lv)
                           for m, lv in zip(mu, logvar))
    except OverflowError as error:
        raise ValueError("variance overflow") from error
    if not math.isfinite(result):
        raise ValueError("nonfinite KL")
    return result

```

联合对角高斯的对数密度逐维相加，KL 也逐维相加。二阶矩 \(\mathbb E[Z_i^2]=\mu_i^2+\sigma_i^2\) 产生均值平方与方差项；`exp(logvar)` 还原方差，负的 `logvar` 项来自高斯归一化尺度。

### 断言测试

```python
import math
assert diagonal_gaussian_kl([0.0, 0.0], [0.0, 0.0]) == 0.0
assert math.isclose(diagonal_gaussian_kl([1.0, -2.0], [0.0, 0.0]), 2.5)
expected = 0.5 * (0.25 + 4.0 - 1.0 - math.log(4.0))
assert math.isclose(diagonal_gaussian_kl([0.5], [math.log(4.0)]), expected)
assert math.isclose(diagonal_gaussian_kl([0.5, 0.5], [math.log(4.0)]*2), 2*expected)
for mu, lv in [([], []), ([0.0], [0.0, 0.0]), ([math.nan], [0.0]),
               ([0.0], [math.inf]), ([0.0], [1000.0])]:
    try:
        diagonal_gaussian_kl(mu, lv)
        raise AssertionError("invalid input accepted")
    except ValueError:
        pass
print("passed: event-axis sum, log-variance convention and invalid inputs")

```

## 本地 PyTorch 练习

实现 `vae_negative_elbo(x,reconstruction_mean,posterior_mean,posterior_logvar,decoder_std)`。\(x\) 为 \([B,D]\)，\(S\) 次潜变量采样得到的重建均值为 \([S,B,D]\)，后验参数为 \([B,d]\)。解码器是固定正标量标准差的独立高斯，先验是单位高斯。返回包含高斯常数项的平均负 ELBO：先求和事件维，再平均 \(S\) 与 \(B\)；保留全部可学习输入的梯度，拒绝错误形状、空轴和非法尺度。

```python
def vae_negative_elbo(x, reconstruction_mean, posterior_mean, posterior_logvar, decoder_std):
    # TODO: 重建 NLL 按 D 求和、按 S 平均；KL 按 d 求和；最后按 B 平均。
    raise NotImplementedError

```

### 提示

- 可将 \(x\)[None] 广播到 \([S,B,D]\)；它不是增加一个新的事件维。
- 高斯 NLL 的常数项和 `log(decoder_std)` 必须按观测维数 \(D\) 累加。
- KL 返回 \([B]\) 后与每样本重建项相加，不能对潜维先 mean。

### 参考实现与解释

```python
import math
import torch

def vae_negative_elbo(x, reconstruction_mean, posterior_mean, posterior_logvar, decoder_std):
    values = (x, reconstruction_mean, posterior_mean, posterior_logvar)
    if any(not torch.is_tensor(v) or not v.is_floating_point() for v in values):
        raise ValueError("floating tensors required")
    if x.ndim != 2 or reconstruction_mean.ndim != 3 or posterior_mean.ndim != 2:
        raise ValueError("expected [B,D], [S,B,D], [B,Z], [B,Z]")
    if any(v.dtype != x.dtype or v.device != x.device for v in values):
        raise ValueError("dtype and device must match")
    if (x.shape[0] < 1 or x.shape[1] < 1 or reconstruction_mean.shape[0] < 1
            or reconstruction_mean.shape[1:] != x.shape
            or posterior_mean.shape[0] != x.shape[0] or posterior_mean.shape[1] < 1
            or posterior_logvar.shape != posterior_mean.shape):
        raise ValueError("incompatible or empty dimensions")
    std = float(decoder_std)
    if not math.isfinite(std) or std <= 0 or not all(torch.isfinite(v).all() for v in values):
        raise ValueError("finite inputs and positive decoder_std required")
    variance = posterior_logvar.exp()
    if not torch.isfinite(variance).all():
        raise ValueError("posterior variance overflow")
    # D is the event axis; S is the expectation axis; B is the dataset axis.
    nll = 0.5 * (((reconstruction_mean - x[None]) / std).square()
                 + 2 * math.log(std) + math.log(2 * math.pi)).sum(-1).mean(0)
    kl = 0.5 * (posterior_mean.square() + variance - 1 - posterior_logvar).sum(-1)
    return (nll + kl).mean()

```

测试将实现与 torch.distributions 的对数概率和 KL 对照，再用 gradcheck 验证路径梯度。额外给出错误事件平均的反例，防止一个可运行但目标权重错误的实现。

### 断言测试

```python
import math
import torch
torch.manual_seed(31)
torch.set_default_dtype(torch.float64)
x = torch.randn(3, 4)
reconstruction = torch.randn(2, 3, 4, requires_grad=True)
mu = torch.randn(3, 2, requires_grad=True)
logvar = (0.2 * torch.randn(3, 2)).requires_grad_()
std = 0.7
actual = vae_negative_elbo(x, reconstruction, mu, logvar, std)
normal = torch.distributions.Normal(reconstruction, std)
nll = -normal.log_prob(x[None]).sum(-1).mean(0)
q = torch.distributions.Normal(mu, (0.5*logvar).exp())
p = torch.distributions.Normal(torch.zeros_like(mu), torch.ones_like(mu))
expected = (nll + torch.distributions.kl_divergence(q, p).sum(-1)).mean()
torch.testing.assert_close(actual, expected)
assert torch.autograd.gradcheck(
    lambda r,m,l: vae_negative_elbo(x, r, m, l, std), (reconstruction, mu, logvar))
wrong_event_average = (
    -normal.log_prob(x[None]).mean(-1).mean(0)
    + torch.distributions.kl_divergence(q, p).sum(-1)).mean()
assert not torch.isclose(actual, wrong_event_average)
for bad_std in [0.0, -1.0, float("inf")]:
    try:
        vae_negative_elbo(x, reconstruction, mu, logvar, bad_std)
        raise AssertionError("invalid decoder scale accepted")
    except ValueError:
        pass
print("passed: distribution reference, axis counterexample and gradcheck")

```

## 练习：推导与分析

### 为什么较好的重建不必然意味着较好的先验生成？

重建使用 \(q_\phi(z\mid a)\)，生成使用 \(p(z)\)，二者可能访问不同潜空间区域。

减小 KL 权重可以改善某些重建，却可能增加聚合后验和先验之间的差异。评价应同时检查后验重建与先验采样。

代码定位：查看 `vae_negative_elbo` 中重建项与 KL 的各自归约。

- 区分后验与先验
- 解释潜空间分布差异
- 不把单一重建指标当作生成保证

### `logvar` 的梯度为什么包含 1/2，KL 里却使用 `exp(logvar)`？

`logvar` 定义为 \(\log\sigma^2\)，采样标准差为 `exp(logvar/2)`，因此路径导数包含 1/2。

KL 需要的是方差 \(\sigma^2\)，所以使用 `exp(logvar)`。两个位置分别对应标准差与方差，不是实现风格差异。

代码定位：完整代码的 \(z\) 构造与 `manual_logvar`。

- 写出标准差变换
- 区分两种指数
- 能复现梯度对照

## 练习：辨析与纠错

### 把到先验的 KL 当作下界间隙

ELBO 内部的 KL 是 \(q(z\mid a)\) 到 \(p(z)\)；证据与 ELBO 的间隙是 \(q(z\mid a)\) 到 \(p_\theta(z\mid a)\)。只有后者为零才能推出下界恰好等于该样本的对数证据。

### 用采样函数或 `detach` 切断编码器梯度

重建项需要通过重参数化 \(z\) 回传到 \(\mu\) 和尺度。一个不带路径的样本只能用于其他合适的梯度估计器，不能自动等价于这里的重参数化。

### 改变归约而没有意识到 KL 的相对权重改变

对观测维平均重建误差、对潜维求和 KL，会引入与维度相关的隐含权重；比较 \(\beta\) 或不同动作维度时应先统一目标。

### 训练后验在部署时不可用

\(q_\phi(z\mid a,c)\) 依赖真实未来动作 \(a\)。部署的条件生成必须按先验路径运行；将目标输入编码器的离线重建分数不等于可部署策略分数。

## 原始资料

- [Kingma & Welling · Auto-Encoding Variational Bayes（ELBO 与重参数化）](https://arxiv.org/abs/1312.6114)
- [Hoffman & Johnson · ELBO Surgery（互信息与聚合后验分解）](https://www.cs.columbia.edu/~blei/fogm/2020F/readings/HoffmanJohnson2016.pdf)
- [PyTorch · Distributions（Normal、Independent、rsample 与 KL）](https://docs.pytorch.org/docs/stable/distributions.html)
