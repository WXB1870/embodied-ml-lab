# Flow Matching

怎样训练一个网络，把容易采样的高斯噪声变成指定的二维双峰分布？本章先把这个生成任务写成一批可监督的中间状态与速度，再解释网络为什么学习条件平均速度，以及推理时如何沿它积分。贯穿案例沿用同一组分布、条件编号和变量；单高斯只用于解析计算。最后区分学习误差、积分误差与动作接口，并把 Flow Matching 与扩散路径联系起来。

## 符号约定

| 符号 | 形状 | 含义 |

|---|---|---|

| \(B\) / \(H\) / \(D\) | 标量维度 | 批量大小 / 动作块长度 / 每步动作维度 |

| \(X_0\) / \(\epsilon\) | \([B,H,D]\) | 从简单初始分布采样的噪声 |

| \(X_1\) / \(a\) | \([B,H,D]\) | 训练数据中的目标动作块 |

| \(t\) | \([B]\)；插值时 \([B,1,1]\) | 生成时间，噪声端为 0，数据端为 1 |

| \(c\) | 由条件编码器约定 | 与目标动作对应、部署可获得的观测条件 |

| \(X_t\) | \([B,H,D]\) | 由端点和时间构造的中间动作块 |

| \(U\) | \([B,H,D]\) | 条件路径对生成时间的导数 |

| \(u^*\) / \(v_\theta\) | \([B,H,D]\) | 真实边际条件速度 / 网络近似速度 |

| \(m\) | 可广播到 \([B,H,D]\) | 有效动作标量的布尔 Mask |

| \(h_k\) / \(\Delta t\) | 标量；与执行周期无关 | 积分网格相邻时间点之差 |

| \(\mu\) / \(\sigma\) | \([D]\) 或明确的可广播形状 | 固定动作归一化均值与正尺度 |

## 先确定要生成什么：从高斯噪声到二维双峰

我们能采到目标数据，却很难直接写出一个从随机数到目标样本的函数。先从标准高斯取得许多起点，再学习每个时间、每个位置应该朝哪里移动：这把生成问题变成了速度预测问题。

Flow Matching（FM）是一种训练连续生成模型的方法：给出连接噪声与数据的概率路径，让神经网络回归推动这条路径的速度。固定条件 \(c\)，从 \(X_0\sim\mathcal N(0,I_2)\) 出发，求解 \(dX_t/dt=v_\theta(X_t,t,c)\)，到 \(t=1\) 得到二维样本。一个起点产生一条轨迹，许多起点的终点共同定义生成分布；网络需要学的是随状态和时间变化的函数，而非一条固定方向。

全章主案例有两个条件 \(c\in\{0,1\}\)。条件 0 选择均值为 (−1.6,−0.6)、(1.6,0.6)，权重为 0.35、0.65 的双高斯混合；条件 1 选择均值为 (−0.6,1.6)、(0.6,−1.6)，权重为 0.65、0.35 的混合。各分量标准差都是 0.28。条件选择一整个分布，不指定它的某个分量。先看下图的噪声与目标两栏：我们需要移动整片概率质量；生成结果一栏将在后面的同一实验中解释。

![条件为 0 时的初始噪声、双峰目标数据与学习场生成样本](../../assets/experiments/fm-mixture-distributions.svg)

贯穿案例，固定条件 \(c=0\)：左为噪声、中为目标双峰、右为后文学习场的 64 步 Heun 生成结果。各栏是同一次已记录实验的 200 个样本；先比较左、中两栏确立问题，读完采样后再检查右栏。有限点云不证明分布已被精确恢复。

这里 \(t=0\) 是噪声、\(t=1\) 是数据。训练时可以抽到一个数据端点 \(X_1\)，推理时只有噪声、条件和网络。接下来先利用训练端点造出速度标签，再解决“缺少端点时究竟应该预测哪种速度”。示例中 noise、data、t、condition、target 与 \(X_0,X_1,t,c,U\) 分别对应。

FM 不限定网络架构；本章使用小型 MLP。Continuous Normalizing Flow（CNF）描述用连续 ODE 流变换分布的模型，FM 则给出训练这种流的一类目标。只有要计算密度时，才另需处理散度与密度演化。核心路径回归不以前向 SDE 或 Score 为先修；它们与本方法的联系在末尾的比较节展开。

进入动作策略时，可以把二维变量换成完整动作块 \(A\in\mathbb R^{H\times D}\)，同时保留动作时间轴。一次生成积分更新整块动作，生成时间 \(t\) 不等于执行时刻或动作索引 \(h\)。本章先把二维例子讲完整，再讨论有效位、单位与控制接口。

$$
X_0\sim p_0,\qquad \frac{dX_t}{dt}=v_\theta(X_t,t,c),\qquad X_1\sim p_\theta(\cdot\mid c)
$$



### 三种“时间”分别回答什么问题

| 量 | 含义 | 改变它会发生什么 |

|---|---|---|

| 生成时间 \(t\) | 噪声到数据路径的进度，这里取 0→1 | 同一个动作块的所有分量随速度场更新 |

| 动作位置 \(h\) | 动作块中第几个未来控制步，\(h=0,\ldots,H-1\) | 选择不同未来位置的动作，不是一次ODE迭代 |

| 物理时间与控制周期 | 真实观测、发送和执行的时刻 | 决定动作是否及时、是否已过期以及如何闭环重规划 |

## 用已知端点构造一条可监督的路径

要训练速度网络，需要先构造能够直接计算状态和速度的样本路径。线性端点插值提供了最简单的起点：已知两端即可得到中间状态与时间导数。它说明监督从何而来，同时留下一个待解问题——推理时不知道数据端点，网络应当预测哪一种速度。

最直接的构造是：从条件数据分布采样 \(x_1\)，从标准高斯采样 \(x_0\)，再采一个 \(t\in[0,1]\)。固定这一对端点时，定义 \(x_t=(1-t)x_0+t x_1\)。对 \(t\) 求导得到条件速度 \(U=x_1-x_0\)。这里的求导不涉及网络参数，也不需要自动微分；目标可以直接用两端点相减得到。训练时通常每次重新采噪声与时间，形成大量不同的回归样本。

从主案例取一对便于手算的端点：\(x_0=(-1,2)\)，\(x_1=(1.6,0.6)\)，后者取条件 0 的一个分量中心作为确定性探针。\(t=0.25\) 时，\(x_t=(-0.35,1.65)\)，目标速度为 \((2.6,-1.4)\)。这里的速度是这对已知端点的时间导数，暂时还不是网络应在该位置输出的边际速度。下面代码核对中间状态、两个端点及有限差分；完整训练会重新抽取端点，而非只记住这个探针。

噪声与数据如何配对称为耦合。以下采用独立配对，并非先在整个数据集上求出全局最优运输。采用线性路径或使用名为 CondOT 的调度器，不自动意味着获得全局最优耦合。若路径改成 \(\alpha(t)x_1+\sigma(t)x_0\)，目标必须同时改成 \(\alpha^\prime(t)x_1+\sigma^\prime(t)x_0\)；只改插值不改监督速度，会训练一个与目标概率路径不一致的模型。

$$
X_t=(1-t)X_0+tX_1,\qquad U=\frac{dX_t}{dt}=X_1-X_0
$$

```python
import torch

noise = torch.tensor([[-1.0, 2.0]], dtype=torch.float64)
data = torch.tensor([[1.6, 0.6]], dtype=torch.float64)
t = torch.tensor([[0.25]], dtype=torch.float64)  # [B,1] for [B,2]
x_t = (1 - t) * noise + t * data
target_velocity = data - noise
torch.testing.assert_close(x_t, torch.tensor([[-0.35, 1.65]], dtype=torch.float64))
torch.testing.assert_close(target_velocity, torch.tensor([[2.6, -1.4]], dtype=torch.float64))
for endpoint, expected in ((0.0, noise), (1.0, data)):
    torch.testing.assert_close((1-endpoint)*noise + endpoint*data, expected)
eps = 1e-5
plus = (1-t-eps)*noise + (t+eps)*data
minus = (1-t+eps)*noise + (t-eps)*data
torch.testing.assert_close((plus-minus)/(2*eps), target_velocity)
print("state / conditional target:", x_t.tolist(), target_velocity.tolist())

```

这段完整代码只验证固定配对的插值与导数，没有训练网络，也没有生成新的数据样本。二维批次用 t:[B,1]；换成动作块 [B,H,D] 时应显式改为 [B,1,1]。两者都让一个样本内的全部坐标共享生成时间。

## 从条件速度回归到边际速度

同一个中间状态可能由不同端点配对产生，而这些配对给出的速度未必相同。网络只能读取当前状态、时间和条件，因此无法逐一还原隐藏配对。平方误差的最优预测是条件期望；先推导这一回归结果，才能解释所学速度场的含义。

沿用线性路径，先抽 \((X_1,c)\sim p_{\rm data}\)，独立抽 \(X_0\sim p_0\) 与 \(t\sim\operatorname{Uniform}(0,1)\)，再构造 \(X_t=(1-t)X_0+tX_1\) 和 \(U=X_1-X_0\)。训练目标完整写为 \[\mathcal L_{\rm CFM}(\theta)=\mathbb E_{t,X_0,X_1,c}\!\left[\left\|v_\theta((1-t)X_0+tX_1,t,c)-(X_1-X_0)\right\|^2\right].\]网络读取中间状态、时间和条件，端点只用于训练时产生监督。

把可见信息合记为 \(Z=(X_t,t,c)\)。在固定 \(Z=z\) 时选择一个预测向量 \(v\)，条件风险为 \(r_z(v)=\|v\|^2-2v^\top\mathbb E[U\mid Z=z]+\mathbb E[\|U\|^2\mid Z=z]\)。在 U 平方可积的条件下，对 v 求导得到 \(2(v-\mathbb E[U\mid Z=z])\)，Hessian 为 \(2I\)，所以最优预测 \(m(z)=\mathbb E[U\mid Z=z]\)。这是隐藏配对在当前状态下的平均速度，不要求模型识别是哪一对端点产生了样本。

进一步把 \(v_\theta-U\) 写成 \((v_\theta-m)-(U-m)\)。交叉项的期望为 \(\mathbb E[(v_\theta-m)\cdot\mathbb E[U-m\mid Z]]=0\)，得到下面的正交分解：CFM 损失等于模型到边际场的平方误差，再加上输入无法解释的条件方差。等式按固定采样分布几乎处处理解。它不仅给出最优解，还解释了训练损失为什么可能在模型正确时仍非零。

“相同梯度”说的是总体损失的期望梯度。数据、噪声、端点耦合与时间采样分布在这个论证中都固定，不依赖正在优化的 \(\theta\)；条件方差项才是常数。网络内部可以训练条件编码器，但 \(Z\) 中的 \(c\) 应理解为固定原始条件，而不是把随 \(\theta\) 改变的中间特征当成固定随机变量。若联合采样机制也学习或重加权，需要重新检查求导项。

单个 \(U\) 的梯度依然有噪声，并不逐样本等于回归 \(m\) 的梯度。因此随机重采训练中存在非零最优 MSE，减少该值也不直接等同于减少采样误差。对给定位置的速度进行平均时，权重来自经过这里的配对后验，不能把所有端点配对的速度等权平均。

加权时也有边界。若非负权重 \(\lambda\) 只依赖 \(Z\) 且不依赖 \(\theta\)，同一个条件均值仍是每个正权重位置的最优解。若 \(\lambda\) 还依赖模型没看到的端点或目标，最优解改为 \(\frac{\mathbb E[\lambda U\mid Z]}{\mathbb E[\lambda\mid Z]}\)，分母须为正；这一般不是原来的边际速度。按困难样本或端点收益加权，会重新定义回归问题，不能不经推导就继承原来的运输结论。

条件直线可以相交，实际 ODE 流则在给定状态、时间与条件后只沿一个速度前进。条件平均场通常产生弯曲轨迹；在解唯一的条件下，不同初值的轨迹不能在同一时间相遇后任意分叉。训练配对里的指定终点不是推理输入，也不是每个噪声必须恢复的标签。 因而主案例下一步不是让网络拿到被隐藏的分量编号，而是保留 x、t、c 三类可用输入，用端点速度样本估计这个条件平均。下方离散两速度算例仅用于手算平方分解，不改变全章的二维数据分布。

$$
\begin{aligned}L_{\rm CFM}(\theta)&=\mathbb E\|v_\theta(Z)-m(Z)\|^2+\underbrace{\mathbb E\|U-m(Z)\|^2}_{\text{independent of }\theta}\\m(Z)&=\mathbb E[U\mid Z],\qquad m_\lambda(Z)=\frac{\mathbb E[\lambda U\mid Z]}{\mathbb E[\lambda\mid Z]}\end{aligned}
$$

```python
import torch

target = torch.tensor([-2.0, 4.0], dtype=torch.float64)
posterior = torch.tensor([0.75, 0.25], dtype=torch.float64)
mean = (posterior * target).sum()
variance = (posterior * (target - mean).square()).sum()
prediction = torch.tensor(0.8, dtype=torch.float64, requires_grad=True)
sample_loss = (posterior * (prediction - target).square()).sum()
marginal_loss = (prediction - mean).square()
(sample_grad,) = torch.autograd.grad(sample_loss, prediction)
(marginal_grad,) = torch.autograd.grad(marginal_loss, prediction)
assert torch.allclose(sample_loss, marginal_loss + variance)
assert torch.allclose(sample_grad, marginal_grad)

# A weight depending on the hidden target changes the conditional mean.
weights = torch.tensor([1.0, 3.0], dtype=torch.float64)
weighted_mean = (posterior * weights * target).sum() / (posterior * weights).sum()
assert torch.allclose(weighted_mean, torch.tensor(1.0, dtype=torch.float64))
print('mean / irreducible MSE:', mean.item(), variance.item())
print('equal expected gradients:', sample_grad.item(), marginal_grad.item())
print('target-weighted mean:', weighted_mean.item())
```

posterior 表示已经给定同一 \(x\)、\(t\)、\(c\) 后两种隐藏目标的概率。完整求和得到期望梯度，因此两个梯度精确相同，为 2.6；只抽其中一个目标则不会逐次相同。给正向目标三倍权重后，最优值从 −0.5 变为 1，说明端点相关加权会改掉原条件均值。



### 例：同一状态遇到两个速度，最优预测是什么

1. 假设在给定\((x,t,c)\)后，条件速度\(U\)以0.75概率为-2，以0.25概率为4。平方误差的最优预测是条件均值\(0.75(-2)+0.25(4)=-0.5\)。

2. 在\(v=-0.5\)处，平均平方误差为\(0.75(1.5)^2+0.25(-4.5)^2=6.75\)；在\(v=0\)处误差为\(0.75(2)^2+0.25(-4)^2=7\)。

3. 两者相差0.25，恰好等于\((0-(-0.5))^2\)。即使模型达到最优，6.75的条件方差也没有消失，因为输入没有揭示隐藏的端点配对。

持续重采样的训练损失不必趋近零；只凭它不为零，不能断言优化失败。

### 回归目标是样本速度，模型输出是条件平均的近似

每条训练配对的直线速度可以不同，网络却只看到当前状态、时间与可用条件。它无法同时记住所有隐藏配对，因此训练直线与生成ODE轨迹不是同一组线。

分别画端点插值和固定初始噪声的实际ODE轨迹，不要用前者冒充生成过程。

## 时间、状态与观测条件

理论速度依赖当前状态、生成时间与观测条件，网络接口必须保留这三类不同信息。时间决定当前路径位置，条件决定要生成哪类样本，动作轴决定联合建模范围。逐项对应输入语义，可以避免仅凭形状正确就接受错误广播或条件泄漏。

速度网络必须知道当前处于生成过程的哪一段。同一个 \(x\)，在接近噪声端和接近数据端时，合理的变化方向可能不同。最小实现可以直接拼接标量 \(t\)；常见实现先构造正弦或 Fourier 时间特征，再用 MLP 投影。时间嵌入是 \(t\) 的可学习或固定表示，不会替代正确的插值公式；\(t\) 的取值范围和端点含义仍需要在数据与采样器之间一致。

主案例将 \(x:[B,2]\)、时间特征 \([t,\sin(\pi t),\cos(\pi t)]:[B,3]\) 和条件 one-hot:[B,2] 拼成 [B,7]，经两个 64 宽 SiLU 隐藏层输出 [B,2]。代码中的 Velocity.forward 不接收 data 或混合分量编号；sample_pairs 只用它们构造 x_t 与 target。动作块模型也可使用 FiLM、AdaLN、Cross-Attention 或条件前缀，但需要重新声明轴与条件接口，不能仅把这组二维数据 reshape 成另一种任务。

训练条件必须与部署时可获得的信息一致。用未来观测、未来接触事件或目标动作本身作为输入，会形成标签泄漏，得到很低的 Loss 却无法实际推理。生成一次动作块时，通常固定该次调用的观测条件；下一轮机器人观测更新后再重新生成。是否复用条件编码或 KV Cache，取决于前缀是否独立于变化中的 \(x_t\) 和 \(t\)，不能仅因张量形状相同就缓存。

$$
v_\theta:\ (X_t\in\mathbb R^{B\times H\times D},\ t\in\mathbb R^B,\ c)\longmapsto\mathbb R^{B\times H\times D}
$$



### 条件必须来自推理时真实可用的信息

训练时使用真实目标动作构造\(x_t\)属于目标生成过程的一部分，但把目标动作另行作为条件\(c\)传入网络会形成另一种任务。未来观测、未来事件和结果标签也不能在部署不可得时充当输入。

列出每个网络输入的获取时刻、来源和推理路径。固定noise与\(t\)替换条件时，还应检查网络是否有合理的条件敏感性。

## 时间采样与加权目标

已经明确速度网络的输入和监督后，一次训练只需要抽样、插值与回归，无需先求解生成 ODE。真正影响优化目标的是时间如何抽取、误差如何加权以及哪些坐标有效。把这些选择写成期望，才能判断改动是在估计同一个目标，还是改变了学习问题。

对同一个双峰数据集，一次训练调用 sample_pairs 得到 x_t、t、condition、target；Velocity 预测 \(v_\theta\)，逐坐标平方误差取平均，再反向更新参数。二维批量的分母为 \(2B\)。这一轮只在一个抽中的时间做前向，不用先积分 ODE；“simulation-free training”指这件事，生成阶段仍需积分。若扩展为全有效 [B,H,D]，分母才变为 \(BHD\)。

梯度来自速度预测与目标的差异。把预测误写成 `actions.detach()` 等与参数无关的量，或者在模型输出上误用 `detach`，会让 Loss 看起来有数值却不能训练。目标动作通常来自固定数据，噪声与采样时间也不是优化参数；是否允许条件编码器更新，则由微调范围决定。只冻结编码器参数，与切断它后面可训练适配模块所需的计算图，是不同操作。

明确目标后才能讨论时间采样。设希望优化 \(L=\int_0^1\lambda(t)\mathbb E[\ell_t]\,dt\)，其中 \(\ell_t\) 是给定时间的平方误差。若实际从密度 \(q(t)\) 抽时间，且 \(q\) 在目标有权重处为正，则每个样本应乘 \(\lambda(t)/q(t)\)。这个重要性权重来自换测度，不是任意学习率技巧；漏掉 \(1/q\) 会得到另一个目标。

例如 \(q(t)=2t\)，可由 \(t=\sqrt U\)、\(U\sim\operatorname{Uniform}(0,1)\) 采样。若 \(\lambda=1\)，\(t=0.25\) 的权重为 2，\(t=0.75\) 的权重为 2/3。取一个纯数学误差函数 \(\ell_t=t^2\)，原目标是 1/3；直接平均 \(q\) 采到的 \(t^2\) 得到 1/2，乘 \(1/q\) 才恢复 1/3。端点 \(t=0\) 在该连续抽样中概率为零，但靠近它时一般损失的权重仍可能很大，造成高方差。

不补权重也可以是有意设计：它使有限模型更多拟合常被采到的时间区间。区别在于是否改变了原目标。时间分布、输出参数化、\(\lambda\)、有效位与归约一起决定优化问题，单个总 MSE 不能说明这些设定相同。固定少量完整三元组用于检查拟合，持续重采样用于估计随机目标，二者的误差下限也不同。

$$
L=\int_0^1\lambda(t)\mathbb E[\ell_t]dt=\mathbb E_{t\sim q}\!\left[\frac{\lambda(t)}{q(t)}\ell_t\right],\qquad q(t)>0\ \text{on the weighted support}
$$

```python
import math

# Midpoint quadrature in U; t=sqrt(U) follows q(t)=2t.
n = 20000
naive = corrected = 0.0
for i in range(n):
    u = (i + 0.5) / n  # avoids the endpoint t=0
    t = math.sqrt(u)
    loss_t = t * t
    naive += loss_t / n
    corrected += loss_t / (2 * t) / n
assert abs(naive - 0.5) < 1e-10
assert abs(corrected - 1 / 3) < 1e-6
print('unweighted / importance-corrected:', naive, corrected)
```

这里用确定性中点积分减少抽样噪声，验证的是换测度公式。循环在 \(U\) 坐标等距，但 \(t\) 坐标不等距；`loss_t/(2*t)` 补回 \(1/q(t)\)。它不模拟神经网络，只隔离“改时间分布是否改目标”这一件事。

## Euler、Heun 与有限步误差

训练得到的是瞬时速度，生成样本还需要把这些局部变化累积到终点。有限步求解器用若干速度评估近似时间积分，因此会引入独立于模型误差的离散化误差。从积分形式推导 Euler 与 Heun，可以解释第二次求值的作用以及步数的成本。

训练循环结束后，保留同一个 Velocity 和条件 \(c\)，但不再向它提供训练端点 data。integrate 从一批新噪声开始，在各时间反复读取当前 x，求解 \(dx/dt=v_\theta(x,t,c)\)。一段 \(h>0\) 内，精确更新为 \(x(t+h)=x(t)+\int_t^{t+h}v_\theta(x(s),s,c)\,ds\)。未知的是整段轨迹；数值方法用有限次速度评估近似它，不能继续沿某条已知训练直线走到答案。

Euler 把整段速度近似成当前速度 \(k_1=v_\theta(x,t,c)\)，相当于矩形求积，得到 \(x_E=x+hk_1\)。Heun 先用这一预测构造终点候选，再算 \(k_2=v_\theta(x_E,t+h,c)\)，用首尾平均近似积分：\(x_{\rm next}=x+\frac h2(k_1+k_2)\)。第二次场评估必须读取候选位置，而不是重复使用当前速度。非均匀网格中的 h 要取相邻时间点之差。

为何 Heun 能多匹配一阶？沿精确轨迹求导有 \(x^{\prime\prime}=\partial_t v+J_vv\)，其中 \(J_v=\partial v/\partial x\)。Taylor 展开给出 \(x(t+h)=x+hv+\frac{h^2}{2}(\partial_t v+J_vv)+O(h^3)\)。Euler 漏掉二阶项；对 Heun 的 \(k_2\) 作一阶展开，\(k_2=v+h(\partial_t v+J_vv)+O(h^2)\)，代回后恰好补上二阶项。

在场足够光滑、满足适当 Lipschitz 与稳定性条件的固定有限区间内，这对应 Euler 的单步局部误差 \(O(h^2)\)、全局误差 \(O(h)\)，以及 Heun 的局部误差 \(O(h^3)\)、全局误差 \(O(h^2)\)。以 \(dx/dt=x\)、\(x(0)=1\) 为例，终点精确值为 e；一步 Euler 得到 2，一步 Heun 得到 2.5。Heun 每步通常需要两次函数求值，因此还需按 NFE 与实际耗时比较计算成本。

误差阶数还不等于稳定性。取收缩场 \(\frac{dx}{dt}=-\kappa x\)，\(\kappa>0\)，精确一步乘 \(e^{-\kappa h}\)，总是正数且小于 1；Euler 一步乘 \(1-\kappa h\)，只有 \(0<\kappa h<2\) 才收缩幅值。\(\kappa h=1\) 时它把所有初值压到零，\(\kappa h=3\) 时反而放大两倍并翻转方向。Heun 的因子为 \(1-\kappa h+\frac{(\kappa h)^2}{2}\)，\(\kappa h=3\) 时是 2.5，同样发散。高阶方法的精度结论是在足够小步长与相应光滑条件下得到的，不是任意大步长都可靠。

这一反例还区分了连续流与离散更新：满足正则条件的精确 ODE 流可以可逆，粗 Euler 映射却可能坍缩信息。对生成模型，终点模式缺失既可能来自模型学错，也可能来自有限步更新破坏了流；固定同一场和噪声扫描步长，才能隔离后者。增加 NFE 能改善数值近似，却无法修复速度场本身的系统偏差。

学习速度场不精确时，减小积分误差并不保证最终任务效果一直改善，因为模型偏差、训练分布和执行接口仍然存在。采样时一般使用 eval 与 `no_grad`，固定噪声可得到可复查的对照。由于场依赖当前候选动作，可缓存的通常是满足独立性条件的观测部分；不能由条件固定推断整段去噪计算都可复用。对接动作执行时，积分预算还要与动作块的时效共同评估。

$$
k_1=v_\theta(x,t,c),\quad k_2=v_\theta(x+h k_1,t+h,c),\quad x_{\mathrm{next}}=x+\frac h2(k_1+k_2)
$$

```python
import math

for kh in (0.5, 1.0, 3.0):
    exact = math.exp(-kh)
    euler = 1 - kh
    heun = 1 - kh + 0.5 * kh * kh
    print(f'kappa*h={kh}: exact={exact:.6f}, Euler={euler:.3f}, Heun={heun:.3f}')

initial_states = [-2.0, -0.5, 1.0, 3.0]
collapsed = [x + 1.0 * (-x) for x in initial_states]
assert collapsed == [0.0] * len(initial_states)
assert len(set(math.exp(-1.0) * x for x in initial_states)) == len(initial_states)
```

三个因子直接来自把速度 −κ\(x\) 代入更新式。最后取 \(\kappa=h=1\)，所有 Euler 输出变成零，而精确解仍区分四个初值。这证明“确定性更新”“可逆 ODE”和“可逆的离散采样器”不是同一性质。



### 例：先在 \(\frac{dx}{dt}=x\) 上验证采样器

1. 初始\(x(0)=1\)，积分到\(t=1\)。一步Euler使用当前速度1，得到\(x=1+1\times1=2\)。

2. 一步Heun先预测候选2，再在终点候选处求速度2，最终为\(1+0.5(1+2)=2.5\)。精确值为\(e\approx2.71828\)。

3. 两步Heun每步\(h=0.5\)，每次乘\(1+h+\frac{h^2}{2}=1.625\)，终点为\(1.625^2=2.640625\)。它用了4次速度求值，不能与两次求值的两步Euler称为相同计算预算。

先验证方向、步长和第二阶段求值，再接神经网络；同时报告步数、NFE与实际延迟。

### 采样误差至少分成模型误差与积分误差

增加步数可以降低同一个速度场的数值积分误差，但不能保证修正学错的速度、错误条件或错误动作单位。模型输出本身有偏差时，更准确地积分这个错误场仍可能得到不合理动作。

用解析场测试积分器；再固定网络与初始噪声做步数扫描；最后独立检查条件与反归一化。

## 可解析的高斯边际场

现在可以训练和采样了，但怎样判断网络的速度与积分器分别有没有算对？先把主案例中的混合分布缩成一个高斯分量，使条件平均与精确轨迹都能手推；这是一项解析对照，之后仍回到原来的两个条件与双峰。

令标量噪声 \(X_0\sim\mathcal N(0,1)\)，目标 \(X_1\sim\mathcal N(\mu,\sigma^2)\)，并令两端点相互独立，其中 \(\sigma>0\)。线性插值的均值是 \(t\mu\)，方差 \(q(t)=(1-t)^2+t^2\sigma^2\)，因为独立变量的协方差为零。注意标准差不是 \((1-t)+t\sigma\)；那种结果对应使用同一个标准化随机变量构造两端点，属于另一个耦合。概率路径不仅依赖两个端点分布，也依赖它们如何配对。

由于 \(U=X_1-X_0\) 与 \(X_t\) 联合高斯，可以用高斯条件均值公式。\(\mathbb E[U]=\mu\)，\(\operatorname{Cov}(U,X_t)=t\sigma^2-(1-t)\)，所以边际场为 \(u_t(x)=\mu+\frac{t\sigma^2-(1-t)}{q(t)}(x-t\mu)\)。第一项移动中心，第二项缩放相对中心的偏差。早期该系数通常为负，样本向当前中心收缩；后期可以变正，样本重新展开。即使所有条件配对路径是直线，边际流也不需要以常量速度前进。

从初始值 \(z\) 出发，解析 ODE 解为 \(x(t)=t\mu+\sqrt{q(t)}z\)。对它求导，再将 \(x-t\mu=\sqrt q\,z\) 代回速度公式，就能逐项验证。终点是 \(\mu+\sigma z\)：同一个 \(z\) 决定同一个终点，这是一种由学得流形成的确定性耦合；训练抽到的那个独立 \(X_1\) 一般并不是这个终点。二维独立同方差的版本逐坐标成立，完整示例 A 正是使用这一性质。

可视化应分别画出均值 \(t\mu\)、分布宽度 \(\sqrt q\) 与一个初始 \(z\) 的积分轨迹，并将 Euler / Heun 轨迹和解析流对照。改变 \(\sigma\) 会同时改变路径收缩程度和速度场的时间变化。\(\sigma\) 必须保持正值，才能避免本公式在数据端出现 \(q=0\) 的退化；离散点或退化高斯的极限需要单独讨论。这里的解析结果只适用于已声明的独立高斯端点，不可直接套到任意多峰动作数据。 这个可解特例说明边际速度确实能推动所需分布。接下来用概率质量守恒证明一般路径为何也具有这一性质，再把分量合回主案例。

$$
\begin{aligned}q(t)&=(1-t)^2+t^2\sigma^2\\u_t(x)&=\mu+\frac{t\sigma^2-(1-t)}{q(t)}(x-t\mu)\\\phi_t(z)&=t\mu+\sqrt{q(t)}\,z\end{aligned}
$$



### 例：两端标准差都为1，中间为何仍会收缩

1. 设独立\(X_0\sim\mathcal N(0,1)\)、\(X_1\sim\mathcal N(2,1)\)。在\(t=0.5\)，均值是1，方差为\((1-0.5)^2+0.5^2=0.5\)，标准差约0.707。

2. 对初始噪声\(z=1\)，解析流中点为\(1+\sqrt{0.5}\approx1.707\)，终点为\(2+1=3\)。训练时随机配给\(z\)的那个\(X_1\)并不必须等于3。

3. 在中点，方差变化系数\(t\sigma^2-(1-t)=0\)，所有位置的瞬时速度都等于均值速度2；前半段收缩与后半段展开仍由其他时刻的系数体现。

同一端点分布可以对应不同的耦合和中间路径。独立插值不能用“标准差线性插值”替代。

## 从样本运动推导概率质量守恒

单高斯中可以直接验证终点分布；换回双峰后，训练配对的直线与实际生成轨迹不再逐条对应。要证明生成仍合理，需要验证条件平均速度保留了每个区域的概率质量变化。下面的推导回答这一问题，不要求实际训练时求解密度方程。

固定观测条件 \(c\)，考虑前面定义的线性路径，或更一般的可微随机路径 \(X_t\)，样本速度记为 \(U_t=dX_t/dt\)。由回归得到的条件均值为 \(u_t(x,c)=\mathbb E[U_t\mid X_t=x,t,c]\)。设 \(p_t\) 表示 \(X_t\) 在给定 c 下的密度；现在需要证明这个边际场与原随机路径具有相同的概率质量变化。

取任意光滑、紧支撑的测试函数 \(\varphi(x)\)。它可以理解为对空间某一小块区域的平滑计数；\(\mathbb E[\varphi(X_t)]\) 描述该区域的概率质量。在允许交换微分与期望的正则条件下，链式法则给出：

\[\frac d{dt}\mathbb E[\varphi(X_t)]=\mathbb E[\nabla\varphi(X_t)\cdot U_t]\] 对单个样本先用链式法则，再求平均；这一步尚未使用密度方程。

再按 \(X_t\) 条件化。因为 \(\nabla\varphi(X_t)\) 已由当前位置决定，\(U_t\) 可以替换为其条件均值 \(u_t\)；将期望写成密度积分后，对空间分部积分。\(\varphi\) 在边界外为零，边界通量项消失，于是得到下式。等式对所有这样的 \(\varphi\) 都成立，就是连续性方程的弱形式；密度足够光滑时可以写成熟悉的偏微分方程。

直观上，\(p_tu_t\) 是概率通量，散度为正代表净流出，所以密度的时间导数取负号。若速度场满足使 ODE 解存在且唯一、概率方程与流相容的条件，从 \(p_0\) 抽样后积分这个场，就会经过规定的 \(p_t\)。仅有一个形式上的 PDE，仍需满足存在性与边界条件，并处理可能的奇异端点。

$$
\begin{aligned}\frac{d}{dt}\mathbb E[\varphi(X_t)]&=\mathbb E[\nabla\varphi(X_t)\cdot U_t]\\&=\int\nabla\varphi(x)\cdot u_t(x)p_t(x)\,dx\\&=-\int\varphi(x)\nabla\!\cdot(p_tu_t)(x)\,dx\\\Longrightarrow\quad\partial_t p_t&+\nabla\!\cdot(p_tu_t)=0\end{aligned}
$$

## 回到同一双峰：分开核对学习场与积分器

前面已经完成路径、回归、训练和采样，并证明理想边际场的运输关系。现在回到开篇的两个条件、四个分量中心和标准差 0.28，检查实际学习场距理想场还有多远，以及有限步求解又增加了多少误差。

沿用开篇的数据分布，条件只选择一组双峰，仍不揭示当前样本属于哪个分量。单高斯对照已经给出每个分量的边际场；要组合成混合场，需要根据当前 x、t、c 计算分量后验责任权重，而非直接使用先验混合权重。

独立噪声与数据端点的线性插值使每个分量在 \(t\) 时仍是 Gaussian：均值为 \(t\mu_{c,j}\)，方差为 \(q(t)I\)，其中 \(q(t)=(1-t)^2+t^2\sigma_{\mathrm{data}}^2\)。由当前 \(x\) 对分量计算后验责任权重 \(r_j\)；各分量边际速度沿用[高斯边际场小节](#/learn/flow-matching?section=gaussian-marginal)的解析公式，再以 \(r_j\) 加权。由此得到可以单独求值的真实边际场，而不是把生成样本与某次随机配对的目标一一对齐。

完整实现使用固定种子 20261106、两层 64 宽隐藏层、Batch 256，在 CPU 上训练 1800 次。独立固定探针的目标速度 MSE 从 2.4931 降为 1.2641，同一探针上解析边际场对随机目标的 MSE 为 1.2174。后者仍非零，对应隐藏端点带来的条件方差；学习场与解析场之间的 MSE 为 0.0390。这些数值是随附代码在指定环境中的一次观测，不是模型或训练配置的一般保证。

固定同一批初始噪声后，先用学习场的 512 步 Heun 解作数值参考，再以 1024 步复核，两个结果的逐坐标 RMS 差约 4.99e−6。表中的 solver RMS 只度量同一个学习场的粗网格结果与这一细网格参考之差。另用解析场 1024 步 Heun 解作为目标流参考，并以 2048 步复核；它仍是有限精度参考，不称为精确解。

64 步 Heun 的 solver RMS 约 0.000396，但学习场与解析场的细网格终点差仍约 0.1469。继续增加积分步数会逼近学习场自己的流，不能自动消除这个场估计偏差。代码还输出两个条件上的有限样本 sliced-Wasserstein 比较与最近模式比例；这些指标有采样波动，也不等同于机器人任务成功率。

图中应区分训练配对的直线、某一时刻的速度场切片和实际随时间变化的 ODE 轨迹。推理只使用初始噪声、条件和网络，从不读取配对的真实终点。将二维样本替换为 \([B,H,D]\) 动作片段时，要改变网络接口、条件编码、有效 Mask 与动作反归一化，端点插值和条件回归原理保持相应形式。

$$
\begin{aligned}
q(t)&=(1-t)^2+t^2\sigma_{\mathrm{data}}^2,\qquad
r_j(x,t,c)=\frac{\pi_{c,j}\exp[-\|x-t\mu_{c,j}\|^2/(2q(t))]}
{\sum_k\pi_{c,k}\exp[-\|x-t\mu_{c,k}\|^2/(2q(t))]},\\
u_t(x,c)&=\sum_jr_j(x,t,c)\left[
\mu_{c,j}+\frac{t\sigma_{\mathrm{data}}^2-(1-t)}{q(t)}(x-t\mu_{c,j})
\right].
\end{aligned}
$$

![训练端点直线、\(t\)等于0.5的速度场、学习场的ODE轨迹及不同NFE的误差](../../assets/experiments/fm-mixture-dynamics.svg)

训练直线与实际积分轨迹分开绘制。速度箭头是 \(t=0.5\) 的瞬时场切片；误差图使用共同初始噪声，实线度量积分误差，虚线包含学习场与解析场的偏差。 速度箭头使用统一显示比例，不代表某个固定积分步长。

### 同一初始噪声与学习场的积分误差（一次固定种子实验）

| 方法 | 步数 | 网络求值次数 NFE | 相对学习场细网格的 RMS | 相对解析场参考的 RMS |

|---|---|---|---|---|

| Euler | 8 | 8 | 0.173109 | 0.217065 |

| Euler | 32 | 32 | 0.046530 | 0.151912 |

| Euler | 64 | 64 | 0.024432 | 0.148436 |

| Heun | 4 | 8 | 0.104013 | 0.178828 |

| Heun | 16 | 32 | 0.006411 | 0.147201 |

| Heun | 32 | 64 | 0.001611 | 0.146933 |

## 耦合决定中间分布与路径难度

解析例子已经显示，训练中的随机端点配对通常不会被生成轨迹逐一复刻。配对方式还会改变中间分布本身，即使起点与终点分布完全不变。把耦合写进协方差和路径定义，可以进一步理解独立配对、最优运输和重新配对各自改变什么。

端点边际分布只规定 \(X_0\) 与 \(X_1\) 各自怎么分布，耦合还规定二者如何一起出现。线性插值的协方差包含交叉项，因此即便两个端点边际完全相同，改变配对也会改变所有中间状态、训练目标和边际场。 对向量端点，记 \(\Sigma_i=\operatorname{Cov}(X_i)\)、\(C_{01}=\operatorname{Cov}(X_0,X_1)\)，交叉项应为 \(C_{01}+C_{01}^{\top}\)；只有标量或相应对称情形才可简写成两倍同一项。

一个直接反例是 \(X_0\)、\(X_1\) 都为标准高斯。独立配对的中间方差 \(q(t)=(1-t)^2+t^2\)，在中点为 1/2；边际场 \(\frac{(2t-1)x}{q(t)}\) 先收缩再展开。若令 \(X_1=X_0\)，则中间方差恒为 1，所有目标速度为零。两者最终都得到同一个标准高斯，但前者需要学习一段并非静止的过程。

前面 Gaussian 例子的解析流也揭示训练耦合和实际 ODE 耦合的差异：独立端点训练得到的流会把 \(z\) 映到 \(\mu+\sigma z\)，形成确定的初终点对应；它没有保留训练时为 \(z\) 随机抽到的 \(X_1\)。CFM 要匹配的是各时刻边际，不是复刻每次隐藏配对。

OT 类配对试图调整路径几何，使运输更容易学习和积分。不过“每对端点之间是直线”不表示配对本身是全局最优运输；小批次 OT 匹配也只针对该经验批次。更直的条件路径、较简单的边际场与有限步生成误差之间需要分别验证，不能从算法名称直接推出一步采样足够。

$$
\begin{aligned}\operatorname{Cov}((1-t)X_0+tX_1)&=(1-t)^2\Sigma_0+t^2\Sigma_1\\&\quad+t(1-t)(C_{01}+C_{01}^{\top}),\\\Sigma_i&=\operatorname{Cov}(X_i),\quad C_{01}=\operatorname{Cov}(X_0,X_1).\end{aligned}
$$

## 时间方向与重参数化

不同实现可能把噪声放在时间零点，也可能放在时间终点；这两种记号都可以描述同一生成过程。关键在于路径的导数也要随时钟变换。通过链式法则同时处理速度、时间输入与积分方向，才能可靠地比较训练和推理代码。

不同实现可以选择不同时间方向。这里的 \(t\) 从噪声端 0 递增至数据端 1；若改用 \(s=1-t\)，则同一插值变成 \(x_s=sx_0+(1-s)x_1\)，关于 \(s\) 的目标速度是 `noise - action`。采样从 \(s=1\) 走到 \(s=0\)，因此每步 \(\Delta s\) 为负。速度目标变号和时间网格下降共同保证样本仍从噪声走向数据。

这不是只把一个减号换掉的问题。链式法则给出 \(\frac{dx}{ds}=-\frac{dx}{dt}\)；网络输入时间也要换成 \(1-s\)。读一个仓库时，应同时查三处：构造训练中间状态的插值、监督速度 target、采样时间和更新式。OpenPI 的公开 `pi0.py` 是一个现成例子：所引用实现使用噪声端为 1 的约定，并配套 `noise - actions` 与负步长。这里是阅读约定的对照，不要求所有 VLA 都使用同一方向。

可用固定标量验证时间方向，例如取 `noise=2`、`action=5`。按上述时间方向，速度为 3，正的一整段时间得到 5；按反向参数化，速度为 −3，负的一整段时间仍得到 5。仅对目标变号而保持步长不变，结果会变为 −1；若在已经配套的约定上重复变号，同样会破坏积分方向。对于一般时间重参数化，除了正负号，还可能需要乘相应的时间导数。

一般地令原时间 \(t=g(s)\)，链式法则给出 \(w(x,s)=g^\prime(s)v(x,g(s))\)。例如 \(g(s)=s^2\)，同一条条件直线在 \(s\) 坐标的速度是 \(2s(X_1-X_0)\)，不再是常量。若目标仍想保留原来对 dt 均匀的速度 MSE，且所讨论区间内 \(g^\prime>0\)，那么以 \(w\) 为输出的误差要乘 \(1/g^\prime\) 再对 ds 积分；因为速度平方变换带来 \((g^\prime)^2\)，而 \(dt=g^\prime(s)\,ds\) 只带来一个 \(g\)′。只换时间输入而不换速度与权重，会改变路径或训练目标。

$$
t=g(s),\quad w(x,s)=g^\prime(s)v(x,g(s)),\qquad g(s)=1-s\ \Rightarrow\ w(x,s)=-v(x,1-s)
$$



### 例：时间反向，速度与步长要一起变号

1. 取`noise=2`、`data=5`。按\(t\)从0到1的约定，\(x(t)=2+3t\)，速度是3；\(t=0.25\)时状态为2.75。

2. 改用\(s=1-t\)，同一状态位于\(s=0.75\)，\(x(s)=5-3s\)，速度是-3。沿生成方向把\(s\)减少0.25，更新量为\((-0.25)(-3)=0.75\)。

3. 两种约定都从2.75移动到3.5。如果只翻转速度却继续使用正步长，就会向反方向移动。

读仓库时成组核对插值、target与采样网格；变量名称无法代替端点定义。

## 动作块与有效监督

把生成变量扩展为动作块后，并非每个坐标都具有有效监督。轨迹末尾、异构动作维和缺失标签需要形成明确的有效集合。损失分母和网络输入协议分别控制监督权重与信息流，不能用同一个 Mask 名称代替两项设计。

动作块常包含轨迹末尾的 Padding、不同机器人未使用的动作维度，或缺失监督。先定义有效位 \(m_{bhd}\)，再明确每个标量元素是否等权。若时间 Mask 是 \([B,H,1]\)，它广播到 \(D\) 维后，分母也必须计算展开后的有效元素数；只除以有效时间步数，会让 Loss 放大 \(D\) 倍。若不同样本的有效长度不同，简单平均各自的平均 Loss 与全体有效元素等权是两个不同目标。

使用梯度累积或多进程训练时，分子与分母的范围也必须一致。可以累计有效误差和与有效元素数，再形成目标；如果梯度已经按各微批次局部均值计算，事后只修改日志分母不能修复实际更新。空监督批次要显式拒绝或按训练协议跳过，不能依靠很小的 epsilon 静默产生“正常”的零 Loss，并继续更新优化器状态。

Loss Mask 只定义哪些输出受监督，不自动阻止无效输入通过 Attention 影响有效位置。Padding 的输入值、有效位如何传给网络、哪些维度在推理时被忽略，都应另行规定。无效标签若含 NaN，先乘零仍会产生 NaN；应在计算平方误差前安全选择有效值。下面的第二个演示同时验证正确分母、无效输出零梯度和微批次汇总一致性，但不会把单进程数值检查称为真实分布式训练。

$$
\mathcal L=\frac{\sum_{b,h,d}m_{bhd}\left(v_{bhd}-U_{bhd}\right)^2}{\sum_{b,h,d}m_{bhd}}
$$



### 时间 Mask 广播后，分母也必须计算动作维度

设两条动作块长度上限均为2，每步有2个有效动作维度，实际有效时间步总数为3。若每个有效标量的平方误差都是4，总误差为24，逐元素MSE应为\(24/6=4\)。只除以3会得到8。

把Mask显式扩展到损失形状，核对求和与分母；改变Padding数量不应改变有效元素等权的目标。

## 动作尺度、误差度量与初始噪声

速度回归发生在模型采用的动作坐标中，而机器人最终读取的是物理命令。标准化不仅改变误差权重，也改变对应的初始噪声和路径尺度。沿同一个坐标变换追踪状态与时间导数，可以解释哪些量必须一起转换，哪些不能直接下发执行。

设固定正对角尺度 \(S\)，标准化动作为 \(z=S^{-1}(a-\mu)\)。在 \(z\) 空间使用欧氏误差，相当于物理空间使用度量 \(S^{-\top}S^{-1}\)。沿同一轨迹，\(v_a=Sv_z\)；因此速度误差也按 \(1/s_d^2\) 加权。使用数据标准差，只保证按数据变化幅度衡量误差，并不保证每一维都获得与任务容忍度相符的权重。

尺度还定义起始分布。若 \(Z_0\sim\mathcal N(0,I)\)，物理坐标中的 \(A_0=\mu+SZ_0\sim\mathcal N(\mu,SS^\top)\)。将某维尺度加倍，物理噪声方差变成四倍，该维损失权重变成四分之一。若调整归一化后仍声称“只做了单位换算”，需要检查数据、统计量、噪声、场与后处理是否全部按同一个变换对应。

如果讨论同一条生成轨迹在物理动作坐标中的导数，固定仿射变换给出 \(\frac{da}{dt}=S\frac{dz}{dt}\)，平移 \(\mu\) 不参与导数。这里的 \(t\) 仍是生成时间，不能把 \(Sv_\theta\) 误认为机器人的物理执行速度。输出可表示关节位置、末端位姿、每控制周期的位移增量或速度命令；其定义必须在数据、后处理和执行器之间一致。

欧氏路径还不自动保持旋转或动作约束。线性插值四元数通常不保持单位范数，每一步再投影则改变了原 ODE；逐步裁剪关节限位也会改变传输分布。若约束是模型设计的一部分，需要为路径、目标和求解器一起定义几何，不能把后处理当成原推导中的无效操作。生成完成后，最终动作仍需按声明的相对/绝对坐标与控制语义还原。

$$
a=\mu+Sz,\quad v_a=Sv_z,\quad \|\hat v_z-v_z\|^2=(\hat v_a-v_a)^TS^{-T}S^{-1}(\hat v_a-v_a),\quad A_0\sim\mathcal N(\mu,SS^T)
$$

## Diffusion、Rectified Flow 与 Reflow

前面从路径与回归建立了 Flow Matching，现在可以用同一语言比较 Diffusion 和 Rectified Flow。比较的起点应是路径系数、条件均值与耦合，而不是算法输出是否随机。先推导 Score 到速度的转换，再讨论 Reflow 改变端点配对的作用。

Diffusion 与 FM 可以在概率路径层面相联系。对一般仿射路径 \(X_t=\alpha_tX_1+\sigma_tX_0\)，\(X_0\) 是与 \(X_1\) 独立的单位高斯噪声，固定端点的速度为 \(\dot\alpha_tX_1+\dot\sigma_tX_0\)。设 \(p_t\) 的状态 score 为 \(s_t(x)=\nabla_x\log p_t(x)\)，则 Gaussian 去噪恒等式给出 \(\mathbb E[X_0\mid X_t=x]=-\sigma_t s_t(x)\)。再对插值公式条件化，得到：

\[\mathbb E[X_1\mid X_t=x]=\frac{x+\sigma_t^2s_t(x)}{\alpha_t}\]

其中 \(\alpha_t\ne0\)。

将这些条件均值代入速度定义，得到下面的 score→velocity 公式。它依赖 \(\alpha\)、\(\sigma\) 及其导数，也依赖所用时间方向。对于与某个前向 SDE 相匹配的 Gaussian 路径，这个边际场可以与对应概率流 ODE 联系起来；一般 FM 路径并不需要先构造一个前向 SDE。完整推导见[Score、SDE 与概率流 ODE](#/learn/score-sde?tab=theory)。

因此差异不能归结为“Diffusion 随机、FM 确定”。同一个理想 score 可以驱动反向 SDE 或概率流 ODE，二者共享边际但不共享路径分布。相同路径下的 noise、score、velocity 有时可转换，但损失的时间权重也随转换改变；在 \(\alpha\) 或 \(\sigma\) 为零的端点附近，变换还可能奇异。

Rectified Flow 从一个端点耦合 \(\pi(X_0,X_1)\) 出发，对直线 \((1-t)X_0+tX_1\) 的端点差回归，得到边际速度。积分精确场形成新的确定性耦合 \((Z_0,Z_1)=(X_0,\Phi_1(X_0))\)。Reflow 使用这些新端点再次构造直线并重新训练。它不是把采样器由 Euler 换为 Heun，也不是把一次训练的所有实际轨迹强制画成直线。

在精确边际匹配、ODE 正则性和有限二阶矩等条件下，可以理解这种重新耦合的平方运输代价性质：终点位移是沿轨迹速度的时间积分，Jensen 给出其平方不大于速度平方的时间积分；条件期望的 Jensen 又使边际速度二阶矩不超过原端点差的二阶矩。于是新耦合的期望平方位移不增。这里需要实际流确实经过规定的 \(p_t\)，学习与离散化误差会破坏精确推理链。

代价不增不等于达到了全局最优运输，也不等于一个有限步 Euler 更新足够准确。一步精确要求实际流的相应运动足够简单，不能仅凭“训练条件路径是直线”推出。最优运输配对、Reflow、蒸馏和改变模型容量是不同操作，应各自做可控比较。

两种路径如何在相同数据上产生不同中间密度，可直接对照 [Score 课程的二维混合算例](#/learn/score-sde?tab=theory&section=shared-mixture)。本篇 conditional-mixture 沿用其中相同的数据均值、权重、标准差与条件编号，但只训练线性路径速度；Diffusion 课程则训练噪声预测器。数据对应是为了隔离方法定义，不应把不同目标的原始 MSE 当作统一性能指标。

$$
\begin{aligned}
u_t(x)&=\frac{\dot\alpha_t}{\alpha_t}x+
\left(\frac{\dot\alpha_t}{\alpha_t}\sigma_t^2-\sigma_t\dot\sigma_t\right)s_t(x),\\
\mathbb E\|Z_1-Z_0\|^2
&=\mathbb E\left\|\int_0^1u_t(Z_t)\,dt\right\|^2\\
&\le\int_0^1\mathbb E\|u_t(Z_t)\|^2dt
\le\mathbb E\|X_1-X_0\|^2 .
\end{aligned}
$$

## 多模态、可逆性与有限时间的边界

一个确定性 ODE 可以把不同噪声送向不同高密度区域，因此确定性并不排斥多峰生成。另一方面，光滑流的可逆性也限制了它在有限时间内能够精确表示哪些分布。将这些性质与有限步采样分开，才能合理解释模式覆盖和采样失败。

固定条件与初始噪声后，ODE 给出一个确定终点；不同噪声进入场的不同位置，可以被运输到不同高密度区域。速度是局部条件平均，不是对所有最终动作求一个全局平均。因此连续、非线性的流可以产生多峰密度，确定性动力学不等于单点输出。

可逆性说明的是另一个问题。对足够光滑、在整段时间中解存在且唯一的场，记流映射为 \(\phi_t\)，初值 Jacobian 为 \(J_t=\frac{\partial\phi_t}{\partial x_0}\)。它满足 \(\frac{dJ_t}{dt}=(\nabla_xu_t)J_t\)、\(J_0=I\)，所以：

\[\det J_t=\exp\!\left(\int_0^t\nabla\!\cdot u_s(\phi_s)\,ds\right)\]

只要这段积分有限，行列式不为零，局部体积可以压缩却不会精确变成零。

密度与似然计算还能从同一方程得到：沿 \(\frac{dx}{dt}=u_t\) 的轨迹，\(\frac d{dt}\log p_t(X_t)=-\nabla\!\cdot u_t(X_t)\)，要求密度为正且相应导数存在。以一维系统 \(\frac{dx}{dt}=-x\) 为例，样本随时间收缩，散度为 −1，轨迹上的 log 密度每单位时间增加 1。普通 CFM 训练无需计算散度；若要取得动作 `log_prob`，则需要这类密度计算，训练 MSE 本身不是似然。

这允许连续密度出现多个峰和很低密度的连接区域，却不能在这些正则假设下把连续高斯质量精确压成几个孤立点。若目标是离散原子、低维集合或完全断开的支持，需要考虑平滑近似、终点奇异极限或不同模型设计。实际网络与有限步求解器又会引入各自误差，不能把解析流的性质无条件归给采样代码。

前面的收缩场给出直接反例：精确解 \(x_1=e^{-1}x_0\) 可逆，一步 Euler 却将所有 \(x_0\) 映射为零。模式坍缩可能来自目标、学习或积分，要分别检查。第一个完整训练示例每个条件只有一个高斯簇，只能检验这些基本计算，不能作为已经学会条件多峰分布的证据。

评估分布时，固定观测条件、多次改变噪声，检查模式覆盖、可行性及实际执行结果。固定噪声比较步数用于隔离数值误差。若报告 \(K\) 次采样中的最好结果，应同时交代实际可用的选择机制；离线看过真实结果后挑最好的一条，不等于单次部署策略的成功率。

$$
\frac{dJ_t}{dt}=\nabla_xu_t(\phi_t)J_t,\qquad \det J_t=\exp\!\left(\int_0^t\nabla\!\cdot u_s(\phi_s)\,ds\right)
$$

## 定位训练与采样错误

Flow 系统包含路径、回归器、求解器和动作接口，多处错误都可能表现为训练损失或生成结果异常。诊断应先使用可手算端点和解析场，逐步恢复模型与数据随机性。每项对照都要回答一个具体假设，避免同时改变多个因素后无法解释结果。

第一步冻结所有随机性，直接打印一组 noise、action、\(t\)、\(x_t\) 和 target，核对端点、有限差分与张量轴。第二步用常量场或解析线性场代替神经网络，独立测试积分器：若方向、步长或第二阶段求值有误，应优先修正采样器。第三步固定少量完整三元组，检查参数确实收到有限梯度并发生更新；这个任务可以过拟合，但不能据此宣称在持续重采样的真实目标上达到零风险。

第四步恢复噪声与时间采样，并按时间区间、动作维度和轨迹长度分别报告误差。只有一个总 Loss 时，容易忽略某些区间严重失真，或者被大量低难度 Padding 掩盖。检查预测速度与目标速度的范数、有效分母、梯度范数和优化器参数集合。条件高维时，可在固定 noise 与 \(t\) 的情况下替换条件，确认目标网络确实对相关条件敏感，而不是只输出与观测无关的平均动作。

第五步固定网络和初始噪声，逐渐增加积分预算，区分数值误差、模型误差和条件错误；同时记录 NFE 和真实耗时。第六步用同一条样本贯通训练预处理、保存加载、推理后处理，逐维比对单位、归一化、相机顺序和 Action Chunk 对齐。若离线目标正常而部署异常，先完成这条一致性检查，再归因于模型容量或数据不足。每次只改变一个可解释因素，并保留反例与输出证据。

- 最小对照：固定数据、噪声、时间、模型权重和采样网格。

- 必要记录：目标参数化、时间方向、有效分母、NFE、动作反归一化。

- 验收证据：端点/导数测试、解析 ODE 对照、梯度检查、条件敏感性、训练推理一致性。

## 完整实现 A：条件高斯上的速度回归与 Euler 采样

从随机端点训练一个小 MLP，再从新噪声生成二维样本。给出同一合成分布的解析边际速度，展示为什么正确 MSE 也未必为零。全程 CPU，不依赖额外 Flow Matching 库。

```python
import math
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(41)
torch.set_num_threads(1)
MEANS = torch.tensor([[-1.5, -0.7], [1.5, 0.7]])
DATA_STD = 0.35

# 1. 条件数据、独立端点与随机生成时间。
def sample_pairs(batch, generator=None):
    c = torch.randint(0, 2, (batch,), generator=generator)
    x0 = torch.randn(batch, 2, generator=generator)
    x1 = MEANS[c] + DATA_STD * torch.randn(batch, 2, generator=generator)
    t = torch.rand(batch, 1, generator=generator)
    xt = (1 - t) * x0 + t * x1
    return xt, t, c, x1 - x0

# 2. x 为二维向量，时间三维特征，条件为二类 one-hot。
class Velocity(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, t, c):
        time_features = torch.cat([t, torch.sin(math.pi*t), torch.cos(math.pi*t)], -1)
        condition = F.one_hot(c, num_classes=2).to(x.dtype)
        return self.net(torch.cat([x, time_features, condition], -1))

# 3. 固定独立探针；它不参与参数更新。
model = Velocity()
optimizer = torch.optim.Adam(model.parameters(), lr=0.003)
probe = sample_pairs(2048, torch.Generator().manual_seed(202))
with torch.no_grad():
    before = F.mse_loss(model(*probe[:3]), probe[3]).item()

model.train()
for step in range(500):
    xt, t, c, target = sample_pairs(128)
    optimizer.zero_grad(set_to_none=True)
    loss = F.mse_loss(model(xt, t, c), target)
    assert torch.isfinite(loss)
    loss.backward()
    nn.utils.clip_grad_norm_(model.parameters(), 5.0)
    optimizer.step()

model.eval()
with torch.no_grad():
    after = F.mse_loss(model(*probe[:3]), probe[3]).item()
assert after < before  # 仅是这个固定合成问题的最小训练检查。
print(f"probe MSE: {before:.4f} -> {after:.4f}")

# 4. 本合成高斯例的精确边际速度；不是某个端点配对的专属速度。
def gaussian_velocity(x, t, c):
    mean = MEANS[c]
    variance = (1-t).square() + (t*DATA_STD).square()
    coefficient = (t*DATA_STD**2 - (1-t)) / variance
    return mean + coefficient * (x - t*mean)

with torch.no_grad():
    oracle_loss = F.mse_loss(gaussian_velocity(*probe[:3]), probe[3]).item()
print(f"analytic marginal-field MSE: {oracle_loss:.4f} (not generally zero)")

# 5. 采样只接收初始噪声、条件和网络，不接收真实目标动作。
@torch.no_grad()
def euler_sample(velocity, noise, condition, steps=64):
    if steps <= 0:
        raise ValueError("steps 必须为正")
    x = noise.clone()
    for k in range(steps):
        t = x.new_full((x.shape[0], 1), k / steps)
        x = x + velocity(x, t, condition) / steps
    return x

generator = torch.Generator().manual_seed(303)
noise = torch.randn(1024, 2, generator=generator)
c = torch.arange(1024) % 2
sampled = euler_sample(model, noise, c)
torch.testing.assert_close(sampled, euler_sample(model, noise, c))
assert torch.isfinite(sampled).all()
for label in (0, 1):
    points = sampled[c == label]
    print(f"condition={label}, mean={points.mean(0).tolist()}, std={points.std(0).tolist()}")

# 6. 解析场的流为 t*mean+sqrt(variance)*noise；用它单独检查积分误差。
oracle_samples = euler_sample(gaussian_velocity, noise, c, steps=256)
exact_terminal = MEANS[c] + DATA_STD * noise
error = (oracle_samples - exact_terminal).abs().max().item()
assert error < 0.04
print(f"analytic-field Euler max error: {error:.5f}")
print("通过：训练更新、确定性采样、条件分组和解析 ODE 对照")

```

- 第 1–19 行：端点独立采样。目标为 x1−x0；同一个 [\(B\),1] 的 \(t\) 用于二维中间状态。类别决定数据均值，不改变初始噪声分布。

- 第 20–31 行：输入共 7 维：\(x\) 的 2 维、时间的 3 维、条件 one-hot 的 2 维。输出保持 2 维，是速度而非最终样本。

- 第 32–54 行：固定探针使用独立随机生成器；训练每步重新采样。断言只检查这一合成问题确实发生了有效拟合，不将 Loss 下降当成通用正确性证明。

- 第 55–65 行：利用独立高斯端点推导条件期望速度。其对样本目标的误差包含隐藏端点的不确定性，所以无需接近零。

- 第 66–86 行：采样函数没有目标数据参数，每步使用当前 \(x\) 与当前时间重新预测。clone 保留原噪声，`no_grad` 避免记录整条积分图。

- 第 87–93 行：本高斯例的解析流可写成均值平移加标准差缩放；对照用于单独核验 Euler 数值误差，不依赖神经网络是否拟合得足够好。

预期输出：固定种子下，独立探针 MSE 应低于训练前；各条件的采样均值靠近各自高斯簇。解析边际场的样本级 MSE 仍非零。256 步 Euler 与解析终点的最大误差小于 0.04。该例只验证合成单高斯条件分布，不证明真实动作泛化或多峰覆盖。

## 完整实现 B：动作 Mask、有效分母与解析 ODE 对照

对不等有效长度和部分无效动作维度，检查 Loss、参数梯度及汇总方式；再用 \(\frac{dx}{dt}=x\) 验证 Euler 与 Heun。

```python
import math
import torch

torch.manual_seed(52)
torch.set_num_threads(1)

# 1. 对有效标量元素求均值；先安全选择，再相减与平方。
def masked_mse(prediction, target, valid):
    if prediction.shape != target.shape or valid.dtype != torch.bool:
        raise ValueError("prediction/target 同形，valid 必须为布尔张量")
    valid = torch.broadcast_to(valid, prediction.shape)
    count = valid.sum()
    if count.item() == 0:
        raise ValueError("没有有效监督")
    safe_pred = torch.where(valid, prediction, torch.zeros_like(prediction))
    safe_target = torch.where(valid, target, torch.zeros_like(target))
    if not torch.isfinite(safe_pred).all() or not torch.isfinite(safe_target).all():
        raise ValueError("有效元素必须有限")
    return (safe_pred-safe_target).square().sum() / count

# 2. 两条轨迹分别有 2 和 3 个有效动作标量。
noise = torch.randn(2, 3, 2, dtype=torch.float64)
actions = torch.randn(2, 3, 2, dtype=torch.float64)
t = torch.tensor([0.2, 0.8], dtype=torch.float64)[:, None, None]
xt = (1-t)*noise + t*actions
target = actions-noise
valid_time = torch.tensor([[True, False, False], [True, True, True]])[..., None]
valid_dim = torch.tensor([[True, True], [True, False]])[:, None, :]
valid = valid_time & valid_dim
prediction = torch.zeros_like(xt, requires_grad=True)
loss = masked_mse(prediction, target, valid)
loss.backward()
expected_grad = torch.where(valid, 2*(prediction.detach()-target)/5, 0.)
torch.testing.assert_close(prediction.grad, expected_grad)
assert valid.sum().item() == 5
assert (prediction.grad[~valid] == 0).all()

# 3. 局部均值需按有效元素数加权，才能得到全局均值。
counts = valid.sum((1, 2))
local = torch.stack([masked_mse(prediction[b], target[b], valid[b]) for b in range(2)])
weighted = (local*counts).sum()/counts.sum()
torch.testing.assert_close(weighted, loss)
assert not torch.isclose(local.mean(), loss)
poisoned = target.clone()
poisoned[~valid] = float("nan")
torch.testing.assert_close(masked_mse(prediction, poisoned, valid), loss)
print(f"effective counts={counts.tolist()}, global loss={loss.item():.5f}")

# 4. 解析场 dx/dt=x，用来隔离模型误差与数值积分误差。
@torch.no_grad()
def solve_linear(x0, steps, method):
    if steps <= 0 or method not in ("euler", "heun"):
        raise ValueError("需要正步数和已知方法")
    x = x0.clone()
    h = 1.0/steps
    for _ in range(steps):
        k1 = x
        if method == "euler":
            x = x+h*k1
        else:
            candidate = x+h*k1
            k2 = candidate  # 第二次求值必须在候选点上。
            x = x+0.5*h*(k1+k2)
    return x

initial = torch.tensor([1., -2.], dtype=torch.float64)
exact = initial*math.e
for steps in (4, 8, 16):
    euler_error = (solve_linear(initial, steps, "euler")-exact).abs().max().item()
    heun_error = (solve_linear(initial, steps, "heun")-exact).abs().max().item()
    assert heun_error < euler_error
    print(f"steps={steps}, Euler NFE={steps}, error={euler_error:.6f}; "
          f"Heun NFE={2*steps}, error={heun_error:.6f}")
assert torch.allclose(solve_linear(initial, 1, "euler"), initial*2)
assert torch.allclose(solve_linear(initial, 1, "heun"), initial*2.5)
print("通过：有效分母、Mask 梯度、NaN Padding 隔离和两种积分器")

```

- 第 1–20 行：安全选择有效元素后再求平方；分母统计广播后的标量数量。空监督和有效位置的非有限值会显式报错。

- 第 21–37 行：时间有效位与维度有效位组合成 \([B,H,D]\)。显式梯度 2(pred−target)/5 检查分母和 Mask，而不只检查输出形状。

- 第 38–48 行：两个局部平均的简单平均不等于全局平均；按有效计数加权才一致。此处是单进程数学对照，不是分布式通信测试。

- 第 49–76 行：解析场的第二阶段速度依赖候选状态，能暴露伪 Heun。结果同时显示 NFE，避免把相同步数错误当成相同计算预算。

预期输出：有效标量数为 [2,3]，总数为 5；无效预测梯度为零，局部均值按计数加权后等于全局 Loss，NaN Padding 被安全隔离。4/8/16 步上 Heun 的解析场误差小于同样步数 Euler，并同时报告各自 NFE。

## 二维条件多峰 Flow Matching：训练、速度场与误差分解

在每个条件下学习两个高斯模式。代码使用解析混合边际场作为 oracle，并分别度量学习场误差、数值积分误差与有限样本分布差异；默认在 CPU 训练并输出 `fm_mixture_results.json`。

```python
"""Train conditional 2D flow matching and export reproducible numerical evidence."""
import argparse
import json
import math
import time
from pathlib import Path

import torch
from torch import nn

SEED = 20261106
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


# 1. The same condition still has two modes; endpoints are independently paired.
def sample_data(condition, generator=None):
    first = torch.rand(len(condition), generator=generator) < WEIGHTS[condition, 0]
    component = (~first).long()
    return MEANS[condition, component] + DATA_STD * torch.randn(
        len(condition), 2, generator=generator)


def sample_pairs(batch, generator=None):
    condition = torch.randint(2, (batch,), generator=generator)
    noise = torch.randn(batch, 2, generator=generator)
    data = sample_data(condition, generator)
    t = torch.rand(batch, 1, generator=generator)
    return (1 - t) * noise + t * data, t, condition, data - noise


# 2. A learned field and an analytic marginal field, not the sampled pair target.
class Velocity(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, t, condition):
        clock = torch.cat([t, torch.sin(math.pi * t), torch.cos(math.pi * t)], -1)
        context = torch.nn.functional.one_hot(condition, 2).to(x.dtype)
        return self.net(torch.cat([x, clock, context], -1))


def oracle_velocity(x, t, condition):
    means = MEANS.to(x)[condition]                         # [B, K=2, D=2]
    q = (1 - t).square() + (t * DATA_STD).square()          # [B, 1]
    displacement = x[:, None, :] - t[:, :, None] * means
    log_weights = WEIGHTS.to(x)[condition].log()
    logits = log_weights - displacement.square().sum(-1) / (2 * q)
    posterior = logits.softmax(-1)                        # p(component | x,t,c)
    coefficient = (t * DATA_STD**2 - (1 - t)) / q
    component_field = means + coefficient[:, :, None] * displacement
    return (posterior[:, :, None] * component_field).sum(1)


# 3. Both solvers integrate the same field and use the same initial noise.
@torch.no_grad()
def integrate(field, noise, condition, steps, method, record=False):
    if steps < 1 or method not in ("euler", "heun"):
        raise ValueError("positive steps and euler/heun are required")
    x = noise.clone()
    path = [{"t": 0.0, "points": x[:24].tolist()}] if record else []
    h = 1.0 / steps
    for k in range(steps):
        t = x.new_full((len(x), 1), k * h)
        first = field(x, t, condition)
        if method == "heun":
            second = field(x + h * first, t + h, condition)
            x = x + h * (first + second) / 2
        else:
            x = x + h * first
        if record and (k + 1) % max(1, steps // 16) == 0:
            path.append({"t": (k + 1) * h, "points": x[:24].tolist()})
    return x, path


def rms(x, y):
    return (x - y).square().mean().sqrt().item()


# 4. Fixed projections give a finite-sample distribution comparison, not a proof.
def sliced_w2(x, y, directions):
    xp = (x @ directions.T).sort(dim=0).values
    yp = (y @ directions.T).sort(dim=0).values
    return rms(xp, yp)


def run(output, train_steps=1800):
    started = time.perf_counter()
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    model = Velocity()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.002)
    probe = sample_pairs(4096, torch.Generator().manual_seed(SEED + 1))
    with torch.no_grad():
        initial_mse = (model(*probe[:3]) - probe[3]).square().mean().item()
    curve = []
    model.train()
    for step in range(train_steps):
        xt, t, condition, target = sample_pairs(256)
        optimizer.zero_grad(set_to_none=True)
        loss = (model(xt, t, condition) - target).square().mean()
        assert torch.isfinite(loss)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        if (step + 1) % 100 == 0:
            curve.append({"step": step + 1, "batch_mse": loss.item()})
    model.eval()
    with torch.no_grad():
        predicted = model(*probe[:3])
        analytic = oracle_velocity(*probe[:3])
        final_mse = (predicted - probe[3]).square().mean().item()
        oracle_mse = (analytic - probe[3]).square().mean().item()
        field_mse = (predicted - analytic).square().mean().item()
    assert final_mse < initial_mse

    evaluation_rng = torch.Generator().manual_seed(SEED + 2)
    condition = torch.arange(1024) % 2
    noise = torch.randn(1024, 2, generator=evaluation_rng)
    target = sample_data(condition, evaluation_rng)
    directions = torch.randn(32, 2, generator=evaluation_rng)
    directions = directions / directions.norm(dim=-1, keepdim=True)
    # A finite reference also has integration error: check a finer grid.
    learned_reference, _ = integrate(model, noise, condition, 512, "heun")
    learned_finer, _ = integrate(model, noise, condition, 1024, "heun")
    oracle_reference, _ = integrate(oracle_velocity, noise, condition, 1024, "heun")
    oracle_finer, _ = integrate(oracle_velocity, noise, condition, 2048, "heun")
    reference_check = {"learned_512_to_1024_rms": rms(learned_reference, learned_finer),
                       "oracle_1024_to_2048_rms": rms(oracle_reference, oracle_finer)}
    metrics = []
    for method in ("euler", "heun"):
        for steps in (4, 8, 16, 32, 64):
            sampled, _ = integrate(model, noise, condition, steps, method)
            sw = [sliced_w2(sampled[condition == c], target[condition == c], directions)
                  for c in (0, 1)]
            metrics.append({"method": method, "steps": steps,
                            "nfe": steps * (1 if method == "euler" else 2),
                            "solver_rms": rms(sampled, learned_reference),
                            "oracle_rms": rms(sampled, oracle_reference),
                            "conditional_sliced_w2": sw})
    sampled, trajectories = integrate(model, noise, condition, 64, "heun", record=True)
    assert torch.isfinite(sampled).all()
    again, _ = integrate(model, noise, condition, 64, "heun")
    torch.testing.assert_close(sampled, again)
    # An independent scalar ODE checks the solver formulas without any learning.
    scalar = torch.ones(3, 1)
    field = lambda x, t, c: x
    euler, _ = integrate(field, scalar, torch.zeros(3).long(), 8, "euler")
    heun, _ = integrate(field, scalar, torch.zeros(3).long(), 8, "heun")
    exact = torch.full_like(scalar, math.e)
    assert rms(heun, exact) < rms(euler, exact)

    conditions = []
    for c in (0, 1):
        selected = condition == c
        generated = sampled[selected]
        nearest = (generated[:, None, :] - MEANS[c]).square().sum(-1).argmin(-1)
        conditions.append({"id": c, "means": MEANS[c].tolist(),
                           "target_weights": WEIGHTS[c].tolist(),
                           "nearest_mode_fractions": torch.bincount(
                               nearest, minlength=2).div(len(generated)).tolist(),
                           "noise": noise[selected][:200].tolist(),
                           "data": target[selected][:200].tolist(),
                           "generated": generated[:200].tolist()})
    grid = torch.cartesian_prod(torch.linspace(-2.7, 2.7, 11),
                                torch.linspace(-2.7, 2.7, 11))
    fields = []
    with torch.no_grad():
        for c in (0, 1):
            labels = torch.full((len(grid),), c)
            for t_value in (0.2, 0.5, 0.8):
                t = torch.full((len(grid), 1), t_value)
                fields.append({"condition": c, "t": t_value, "points": grid.tolist(),
                               "learned": model(grid, t, labels).tolist(),
                               "oracle": oracle_velocity(grid, t, labels).tolist()})
    # These straight paths are training pairs, distinct from the learned ODE paths.
    pair_rng = torch.Generator().manual_seed(SEED + 3)
    pair_condition = torch.arange(12) % 2
    pair_noise = torch.randn(12, 2, generator=pair_rng)
    pair_data = sample_data(pair_condition, pair_rng)
    result = {
        "seed": SEED, "torch": torch.__version__, "device": "cpu", "dtype": "float32",
        "train_steps": train_steps, "batch_size": 256, "hidden_width": 64,
        "data_std": DATA_STD, "training_curve": curve,
        "probe": {"before_mse": initial_mse, "after_mse": final_mse,
                  "oracle_target_mse": oracle_mse, "learned_to_oracle_field_mse": field_mse},
        "reference_check": reference_check, "metrics": metrics,
        "model_flow_rms": rms(learned_reference, oracle_reference),
        "conditions": conditions, "fields": fields,
        "trajectories": {"condition": condition[:24].tolist(), "states": trajectories},
        "training_pairs": {"condition": pair_condition.tolist(),
                           "noise": pair_noise.tolist(), "data": pair_data.tolist()},
        "seconds": time.perf_counter() - started,
        "limits": [
            "Single seeded CPU experiment; these values are observations, not guarantees.",
            "solver_rms compares to a finite fine-grid solution of the same learned field.",
            "model_flow_rms compares learned and analytic marginal fields with common noise.",
            "Sliced W2 uses 32 fixed directions and 512 samples per condition.",
            "Nearest-mode fractions are a diagnostic, not exact mixture component labels.",
        ],
    }
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"probe": result["probe"], "reference_check": reference_check,
                      "model_flow_rms": result["model_flow_rms"],
                      "metrics": metrics, "seconds": result["seconds"]}, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="fm_mixture_results.json")
    parser.add_argument("--train-steps", type=int, default=1800)
    args = parser.parse_args()
    run(args.output, args.train_steps)

```

- 第 1–33 行：定义两个观测条件下的双峰 Gaussian 数据；训练端点独立配对，条件没有泄漏混合分量或真实终点。

- 第 34–58 行：小 MLP 预测速度；解析场先计算分量后验责任，再对各分量速度加权，用于隔离学习误差。

- 第 59–83 行：Euler 与 Heun 使用相同接口、时间网格和初始噪声；可记录随时间变化的轨迹。

- 第 84–90 行：固定投影方向的 sliced-Wasserstein 只作为有限样本分布诊断，不能替代精确似然或任务指标。

- 第 91–120 行：固定种子训练，独立探针不参与梯度；同时报告随机目标误差和对解析边际场的误差。

- 第 121–156 行：分别细化学习场与解析场的参考解，比较相同步数与 NFE；用解析标量 ODE 和重复采样检查求解器。

- 第 157–219 行：导出同一次实验的样本、网格速度、轨迹、训练配对、指标和配置。默认写 JSON，绘图数据不由手工拟造。

预期输出：输出独立探针误差、细网格复核和 Euler/Heun 不同 NFE 的指标，并写出可绘图的 JSON。固定种子在本次 CPU 运行中目标 MSE 为 2.4931→1.2641；不同环境浮点结果可略有差异。检查只要求明确的公式、有限性、确定性及本合成训练改进，不把这些数值作为真实策略性能。

## 练习：手写条件路径与加权最优速度

仅用 Python 标准库实现 `linear_path(noise,data,t)`，返回线性插值和对 \(t\) 的速度；再实现 `conditional_mean_velocity(velocities,weights)`。weights 表示在给定 \(x\),\(t\),\(c\) 下各隐藏端点配对的相对后验权重，需返回平方误差下的最优速度。拒绝维度不一致、负权重、零总权重或越界时间。

运行环境：python

```python
import math

def linear_path(noise, data, t):
    # TODO: 插值与时间导数
    raise NotImplementedError("请实现线性条件路径")

def conditional_mean_velocity(velocities, weights):
    # TODO: 每个速度分量按条件权重求平均
    raise NotImplementedError("请实现条件平均速度")

```

### 提示

- 先把两个端点代入 \(t=0\) 与 \(t=1\)；速度不是 (data−xt)，而是固定端点路径的完整导数。

- 平方误差的最优预测是按后验概率加权的均值；相对权重须先除以总和。

### 参考答案

```python
import math

def linear_path(noise, data, t):
    if not noise or len(noise) != len(data) or not 0 <= t <= 1:
        raise ValueError("需要同长非空端点以及 [0,1] 时间")
    if not all(math.isfinite(x) for x in [*noise, *data, t]):
        raise ValueError("输入必须有限")
    xt = [(1-t)*a+t*b for a,b in zip(noise,data)]
    velocity = [b-a for a,b in zip(noise,data)]
    return xt, velocity

def conditional_mean_velocity(velocities, weights):
    if not velocities or len(velocities) != len(weights):
        raise ValueError("配对数量不一致")
    dim = len(velocities[0])
    if dim == 0 or any(len(v) != dim for v in velocities):
        raise ValueError("速度维度不一致")
    if any(w < 0 or not math.isfinite(w) for w in weights) or sum(weights) <= 0:
        raise ValueError("需要非负权重和正总权重")
    if not all(math.isfinite(x) for v in velocities for x in v):
        raise ValueError("速度必须有限")
    total = sum(weights)
    return [sum(w*v[d] for w,v in zip(weights,velocities))/total for d in range(dim)]

```

有限差分验证插值与速度一致；不等权重的例子使无权平均无法通过。这里直接给定后验权重用于理解条件期望，并不声称真实训练需要显式求出所有配对的后验。

### 断言测试

```python
noise, data = [-1.,2.], [3.,0.]
assert linear_path(noise,data,0)[0] == noise
assert linear_path(noise,data,1)[0] == data
xt, velocity = linear_path(noise,data,.25)
assert xt == [0.,1.5] and velocity == [4.,-2.]
eps = 1e-5
left, _ = linear_path(noise,data,.4-eps)
right, _ = linear_path(noise,data,.4+eps)
assert all(abs((r-l)/(2*eps)-v) < 1e-8 for l,r,v in zip(left,right,velocity))
# 给定同一 x,t,c 后，两个隐藏配对的后验权重为 1:3。
mean = conditional_mean_velocity([[2.,0.],[-4.,4.]],[1.,3.])
assert mean == [-2.5,3.]
assert conditional_mean_velocity([[2.,0.],[-4.,4.]],[2.,6.]) == mean
def risk(v):
    return sum(w*sum((p-u)**2 for p,u in zip(v,target))
               for w,target in zip([1.,3.],[[2.,0.],[-4.,4.]]))/4
assert risk(mean) < risk([-1.,2.])  # 无权平均并不是这个分布的最优解。
for call in [lambda:linear_path([0.],[1.],1.1),
             lambda:conditional_mean_velocity([[1.]],[0.]),
             lambda:conditional_mean_velocity([[1.],[2.]],[1.,-1.])]:
    try:
        call()
    except ValueError:
        pass
    else:
        raise AssertionError("无效输入未拒绝")
print("通过：端点、时间导数、条件加权平均与边界")

```

## 练习：手写条件 FM 训练一步：安全 Mask 与条件梯度

保留两个明确职责：实现 `cfm_loss(model, noise, actions, t, condition, valid)`，再实现 `cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid)`。形状约定：端点为同 dtype/device 的浮点 \([B,H,D]\)，时间为有限 \([B]\) 且 \(0\le t\le1\)，原始观测为 \([B,C_{\rm in}]\)，`encoder(observations)` 为有限 \([B,C]\)。`valid` 是同设备 bool，可广播为 \([B,H,D]\)，例如 \([B,H,1]\)；本题把它定义为调用方已知的结构有效位，网络接口为 `model(xt,t,condition,expanded_valid)`，输出有限 \([B,H,D]\)。若某个有效位仅在未来轨迹结束后才知道，它只应控制监督，不能直接当作部署可用的输入条件，本题不覆盖这种数据协议。

噪声端为 \(t=0\)，数据端为 \(t=1\)。无效端点允许含 NaN，必须在插值乘法、目标减法之前安全替换，不能靠最终乘零掩盖。只平均有效动作标量，拒绝全空监督、非法时间、有效 NaN、错误形状或非有限预测。普通精度的一步训练需要清理旧梯度、编码条件、构造目标、反向和一次更新；保留条件编码器的计算图，返回更新前 loss 的 Python float。优化器由调用者建立，并已包含两个模块中计划训练的全部参数；这里不实现 AMP、累积或自动采样噪声/时间。

运行环境：torch

```python
import torch


def cfm_loss(model, noise, actions, t, condition, valid):
    # TODO 1: 检查 [B,H,D]、[B]、条件与可广播 bool 有效位；拒绝空监督。
    # TODO 2: 先选择安全端点，再把时间扩为 [B,1,1] 构造路径和速度目标。
    # TODO 3: 网络仍接收 [B] 时间；把展开后的结构有效位传入网络。
    # TODO 4: 在减法/平方前选择有效输出，用真实有效标量数归约。
    raise NotImplementedError("请完成 CFM 路径与标量目标")


def cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid):
    # TODO 5: 训练模式、清零、可微条件编码、cfm_loss、反向与一次 optimizer 更新。
    # TODO 6: 检查梯度有限；返回更新前的数值，不把 loss 提前变成 Python 标量。
    raise NotImplementedError("请完成条件编码器与速度网络的联合训练一步")

```

### 提示

- 路径为 \(X_t=(1-t)X_0+tX_1\)，目标为 \(U=X_1-X_0\)；传给模型的 `t` 不应变成 \([B,1,1]\)。

- 先用 `torch.where` 选择有限端点，再运算。最终损失也先索引有效元素再相减；\(0\cdot\mathrm{NaN}\) 仍是 NaN。

- \([B,H,1]\) 广播后的有效分母含动作维 \(D\)。先手算少量有效标量，并检查条件编码器的参数是否收到梯度。

- 两个连续 SGD 更新比只看一次参数变化更有辨别力：第二步会暴露忘记清零；实际参数变化还可以发现未进入优化器的参数。

### 参考答案

```python
import torch


def cfm_loss(model, noise, actions, t, condition, valid):
    if (noise.ndim != 3 or noise.shape != actions.shape or noise.numel() == 0
            or not noise.is_floating_point() or noise.dtype != actions.dtype
            or noise.device != actions.device):
        raise ValueError("noise/actions 必须是同 dtype/device 的非空浮点 [B,H,D]")
    batch = noise.shape[0]
    if (t.shape != (batch,) or t.dtype != noise.dtype or t.device != noise.device
            or not torch.isfinite(t).all() or not ((0 <= t) & (t <= 1)).all()):
        raise ValueError("t 必须是同 dtype/device 的有限 [B]，且在 [0,1]")
    if valid.dtype != torch.bool or valid.device != noise.device:
        raise ValueError("valid 必须是同设备 bool 张量")
    try:
        mask = torch.broadcast_to(valid, noise.shape)
    except RuntimeError as error:
        raise ValueError("valid 不能广播到 [B,H,D]") from error
    count = mask.sum()
    if count.item() == 0:
        raise ValueError("整个更新没有有效监督")
    if (condition.ndim != 2 or condition.shape[0] != batch
            or not torch.isfinite(condition).all()):
        raise ValueError("condition 必须为有限 [B,C]")

    # 在乘法/减法之前选择：无效端点可为 NaN，进入网络的占位统一为 0。
    safe_noise = torch.where(mask, noise, torch.zeros_like(noise))
    safe_actions = torch.where(mask, actions, torch.zeros_like(actions))
    if not torch.isfinite(safe_noise).all() or not torch.isfinite(safe_actions).all():
        raise ValueError("有效端点必须有限")
    time = t[:, None, None]  # 只为路径运算扩维；网络仍接收原始 [B] 时间。
    xt = (1 - time) * safe_noise + time * safe_actions
    target = safe_actions - safe_noise
    prediction = model(xt, t, condition, mask)
    if prediction.shape != actions.shape or not torch.isfinite(prediction).all():
        raise ValueError("网络必须返回有限 [B,H,D]；Loss Mask 不能修复网络内部非法运算")
    # 同样先选元素，再相减/平方。分母统计广播后的有效标量。
    return (prediction[mask] - target[mask]).square().sum() / count


def cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid):
    model.train()
    encoder.train()
    optimizer.zero_grad(set_to_none=True)
    condition = encoder(observations)  # 不 detach：目标必须能训练条件编码器。
    loss = cfm_loss(model, noise, actions, t, condition, valid)
    loss.backward()
    for group in optimizer.param_groups:
        for parameter in group["params"]:
            if parameter.grad is not None and not torch.isfinite(parameter.grad).all():
                raise FloatingPointError("非有限参数梯度；不执行更新")
    optimizer.step()
    return float(loss.detach())  # 更新前目标的数值，不保留日志计算图。

```

逐标量参照独立推导残差对速度网络、条件编码器、端点和时间的梯度，并以无动量 SGD 的 \(\theta_{k+1}=\theta_k-\eta g_k\) 检查两次更新。测试特意让 \(B=D=2\)，错误地把时间沿最后一维广播可能仍能运行，但不会通过手算比较。无效端点含 NaN，额外开启数据和时间求导是为了暴露“先计算 NaN、后屏蔽”的反向污染；真实训练通常不优化这些随机变量。

追问：为什么还要检查条件编码器更新？仅看到速度头的 loss 下降，不能排除条件特征被 `detach` 或条件编码器不在优化器中。为什么传入 `valid` 后仍不能宣称 Transformer 的 Padding 已正确？本题验证的是接口和逐位置模型，跨位置网络必须另外验证 Attention/卷积的信息流。为什么正确损失不要求接近零？解析平移场是可达零风险的特例；一般随机端点的目标包含条件方差。方向反例使用同一场取负号，错误损失精确变为 \(\frac{4}{BD}\sum_{b,d}c_{bd}^2\)，能直接区分速度符号。

### 断言测试

```python
torch.manual_seed(20261106)
torch.set_num_threads(1)


class ToyVelocity(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.x_weight = torch.nn.Parameter(torch.tensor([.5, -.3], dtype=torch.float64))
        self.c_weight = torch.nn.Parameter(torch.tensor([.2, .4], dtype=torch.float64))
        self.t_weight = torch.nn.Parameter(torch.tensor([.1, -.2], dtype=torch.float64))

    def forward(self, x, t, c, valid):
        assert x.shape == (2, 3, 2) and t.shape == (2,) and c.shape == (2, 1)
        assert valid.shape == x.shape and valid.dtype == torch.bool
        assert torch.isfinite(x).all() and (x[~valid] == 0).all()
        self.last_x, self.last_time, self.last_condition = x, t, c
        return x * self.x_weight + c[:, None, :] * self.c_weight + t[:, None, None] * self.t_weight


encoder = torch.nn.Linear(2, 1, bias=False).double()
with torch.no_grad():
    encoder.weight.copy_(torch.tensor([[.4, -.2]], dtype=torch.float64))
model = ToyVelocity()
observations = torch.tensor([[1., .5], [-.5, 2.]], dtype=torch.float64)
noise = (torch.arange(12, dtype=torch.float64).reshape(2, 3, 2) / 5 - .6)
actions = torch.tensor([[[1., -.2], [.1, .5], [.4, -.7]],
                        [[2., .6], [-.5, 1.2], [-1., .4]]], dtype=torch.float64)
valid = torch.tensor([[[True], [False], [True]], [[False], [True], [False]]])
expanded = valid.expand_as(actions)
noise[~expanded] = float("nan")
actions[~expanded] = float("nan")
# 数据通常不求梯度；这里故意开启以揭示“算出 NaN 后再屏蔽”的隐蔽反向错误。
noise.requires_grad_()
actions.requires_grad_()
t = torch.tensor([.25, .8], dtype=torch.float64, requires_grad=True)
parameters = dict(model.named_parameters())
parameters["encoder.weight"] = encoder.weight
optimizer = torch.optim.SGD(list(parameters.values()), lr=.05)


def manual_reference():
    # 逐标量、用普通数值求导；不对同一向量化实现再调用 Autograd 冒充独立答案。
    n = int(expanded.sum())
    grads = {name: torch.zeros_like(p) for name, p in parameters.items()}
    gn, ga, gt = torch.zeros_like(noise), torch.zeros_like(actions), torch.zeros_like(t)
    total = 0.
    for b in range(2):
        cb = sum(encoder.weight[0, j].item() * observations[b, j].item() for j in range(2))
        tb = t[b].item()
        for h in range(3):
            for d in range(2):
                if not expanded[b, h, d]:
                    continue
                nb, ab = noise[b, h, d].item(), actions[b, h, d].item()
                xt = (1 - tb) * nb + tb * ab
                wx, wc, wt = (getattr(model, name)[d].item()
                              for name in ("x_weight", "c_weight", "t_weight"))
                residual = wx * xt + wc * cb + wt * tb - (ab - nb)
                total += residual * residual / n
                g = 2 * residual / n
                grads["x_weight"][d] += g * xt
                grads["c_weight"][d] += g * cb
                grads["t_weight"][d] += g * tb
                for j in range(2):
                    grads["encoder.weight"][0, j] += g * wc * observations[b, j].item()
                gn[b, h, d] = g * (wx * (1 - tb) + 1)
                ga[b, h, d] = g * (wx * tb - 1)
                gt[b] += g * (wx * (ab - nb) + wt)
    return total, grads, gn, ga, gt


model.eval()
encoder.eval()
for parameter in parameters.values():
    parameter.grad = torch.full_like(parameter, 123.)  # 必须清除旧梯度。
for step in range(2):
    expected_loss, grads, gn, ga, gt = manual_reference()
    before = {name: p.detach().clone() for name, p in parameters.items()}
    noise.grad = actions.grad = t.grad = None
    actual = cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid)
    assert isinstance(actual, float) and abs(actual - expected_loss) < 1e-12
    assert model.training and encoder.training
    assert model.last_time is t and model.last_condition.grad_fn is not None
    for name, parameter in parameters.items():
        torch.testing.assert_close(parameter.grad, grads[name], atol=1e-12, rtol=1e-12)
        torch.testing.assert_close(parameter, before[name] - .05 * grads[name], atol=1e-12, rtol=1e-12)
        assert not torch.equal(parameter, before[name])
    for actual_grad, expected_grad in [(noise.grad, gn), (actions.grad, ga), (t.grad, gt)]:
        assert torch.isfinite(actual_grad).all()
        torch.testing.assert_close(actual_grad, expected_grad, atol=1e-12, rtol=1e-12)
    assert (noise.grad[~expanded] == 0).all() and (actions.grad[~expanded] == 0).all()
    print("step", step + 1, "loss", round(actual, 9), "encoder_grad", encoder.weight.grad.tolist())


# 解析平移场：每个条件使数据等于噪声加 c，所以真实速度恒为 c。
class TranslationField(torch.nn.Module):
    def __init__(self, sign=1.):
        super().__init__()
        self.sign = sign
    def forward(self, x, t, c, valid):
        self.last_x = x
        return self.sign * c[:, None, :].expand_as(x)


z = torch.randn(2, 3, 2, dtype=torch.float64)
c = torch.tensor([[2., -1.], [-.5, 3.]], dtype=torch.float64)
a = z + c[:, None, :]
end_times = torch.tensor([0., 1.], dtype=torch.float64)
all_valid = torch.ones(2, 3, 1, dtype=torch.bool)
oracle = TranslationField()
assert cfm_loss(oracle, z, a, end_times, c, all_valid).item() < 1e-28
torch.testing.assert_close(oracle.last_x[0], z[0])
torch.testing.assert_close(oracle.last_x[1], a[1])
wrong = cfm_loss(TranslationField(-1.), z, a, end_times, c, all_valid)
torch.testing.assert_close(wrong, 4 * c.square().mean())

# 坐标有效位不能退化为“每个时间都算 D 个有效元素”。
coordinate_valid = all_valid.expand_as(z).clone()
coordinate_valid[0, 0, 1] = False
coordinate_valid[1, 1:, 0] = False
masked_noise = z.masked_fill(~coordinate_valid, float("nan"))
masked_actions = a.masked_fill(~coordinate_valid, float("nan"))
assert cfm_loss(oracle, masked_noise, masked_actions, end_times, c, coordinate_valid).item() < 1e-28

for bad_time, bad_valid, bad_actions in [
        (end_times, torch.zeros_like(all_valid), a),
        (torch.tensor([-.1, 1.], dtype=torch.float64), all_valid, a),
        (end_times, all_valid, a.clone().index_fill(0, torch.tensor([0]), float("nan"))),
        (end_times, torch.ones(2, 4, dtype=torch.bool), a)]:
    try:
        cfm_loss(oracle, z, bad_actions, bad_time, c, bad_valid)
    except ValueError:
        pass
    else:
        raise AssertionError("未拒绝空监督、非法时间、有效 NaN 或错误 Mask 形状")
print("通过：NaN 前选择、广播、手算梯度、条件编码器更新、两步清零、端点与方向反例")

```

## 练习：实现支持非均匀网格的条件 Heun 采样器

实现 `heun_sample(velocity,noise,times,condition)`。`velocity(x,t_batch,condition)` 返回与 \(x\) 同形的速度，`t_batch` 形状为 \([B]\)。times 是至少两个有限且严格单调的时间点，可递增或递减。每步在当前点和候选点各求一次速度；不修改初始输入，采样不记录梯度。用两个解析场分别检验时间与状态依赖。

运行环境：torch

```python
import torch

@torch.no_grad()
def heun_sample(velocity, noise, times, condition):
    # TODO: 相邻时间差、预测、第二次求值与平均校正
    raise NotImplementedError("请实现条件 Heun 采样")

```

### 提示

- \(h\) 必须从 right−left 计算；反向积分时 \(h\) 自然为负，不要再无条件额外翻转速度。

- Heun 的 `k2` 必须使用 `x+h*k1` 和下一时间。只用时间依赖的场不足以发现错误复用状态，需要再测 \(\frac{dx}{dt}=x\)。

### 参考答案

```python
import torch

@torch.no_grad()
def heun_sample(velocity, noise, times, condition):
    if noise.ndim < 2 or not noise.is_floating_point():
        raise ValueError("noise 必须含 Batch 轴且为浮点张量")
    grid = torch.as_tensor(times,dtype=noise.dtype,device=noise.device)
    if grid.ndim != 1 or grid.numel() < 2 or not torch.isfinite(grid).all():
        raise ValueError("需要至少两个有限时间点")
    deltas = grid[1:]-grid[:-1]
    if not ((deltas > 0).all() or (deltas < 0).all()):
        raise ValueError("时间网格必须严格单调")
    x = noise.clone()
    for left,right in zip(grid[:-1],grid[1:]):
        h = right-left
        t0 = x.new_full((x.shape[0],),left.item())
        t1 = x.new_full((x.shape[0],),right.item())
        k1 = velocity(x,t0,condition)
        if k1.shape != x.shape:
            raise ValueError("速度形状必须等于状态形状")
        candidate = x+h*k1
        k2 = velocity(candidate,t1,condition)
        if k2.shape != x.shape:
            raise ValueError("速度形状必须等于状态形状")
        x = x+0.5*h*(k1+k2)
    return x

```

非均匀网格与反向积分识别写死步长和错误符号；\(2t+c\) 的解析积分检查条件与时间，\(\frac{dx}{dt}=x\) 检查候选状态。反向积分使用同一向量场与下降时间，和改变量 \(s=1-t\) 后重新定义速度是两种需要分清的操作。

### 断言测试

```python
x0 = torch.tensor([[.5,-.2],[1.,2.],[.1,-.3]],dtype=torch.float64,requires_grad=True)
c = torch.tensor([[1.,2.],[0.,-1.],[.5,-.5]],dtype=torch.float64)
original = x0.detach().clone()
calls = []
def time_field(x,t,cond):
    calls.append(t.clone())
    assert cond is c
    return 2*t[:,None]+cond
# dx/dt=2t+c 的解析增量为 (t1²-t0²)+(t1-t0)c。
forward = heun_sample(time_field,x0,[0.,.05,.4,1.],c)
torch.testing.assert_close(forward,original+1+c)
assert len(calls) == 6 and not forward.requires_grad
reverse = heun_sample(time_field,forward,[1.,.8,.3,0.],c)
torch.testing.assert_close(reverse,original)
torch.testing.assert_close(x0,original)
# dx/dt=x：第二阶段必须使用候选状态，不能复用 k1。
steps = 8; h = 1/steps
result = heun_sample(lambda x,t,c:x,x0,torch.linspace(0,1,steps+1,dtype=torch.float64),c)
expected = original*(1+h+h*h/2)**steps
torch.testing.assert_close(result,expected)
for grid in [[0.],[0.,.5,.4,1.],[0.,0.,1.]]:
    try:
        heun_sample(time_field,x0,grid,c)
    except ValueError:
        pass
    else:
        raise AssertionError("非单调或不足的网格未拒绝")
print("通过：非均匀步长、时间依赖、状态依赖、条件、反向积分与 NFE")

```

## 练习：手写一般概率路径：系数导数与 Gaussian 边际场

实现 `affine_path(noise, data, t, schedule)` 和 `gaussian_marginal_velocity(x, t, mean, std, schedule)`。端点与状态为有限浮点 \([B,H,D]\)，时间为同 dtype/device 的 \([B]\) 且在 \([0,1]\)。`schedule(t)` 返回四个同形 \([B]\) 张量，依次表示 \(\alpha(t),\sigma(t),\dot\alpha(t),\dot\sigma(t)\)；导数已经给定，不允许把一般路径硬编码成 `data-noise`。第一函数返回 \(X_t=\alpha_tX_1+\sigma_tX_0\) 及其固定端点时间导数，保持 \([B,H,D]\)。

第二函数假设 \(X_0\sim\mathcal N(0,I)\)、\(X_1\sim\mathcal N(\mu,\operatorname{diag}(s^2))\)，端点相互独立；`mean/std` 均为 \([D]\)，标准差严格为正。请从联合高斯条件均值推导并实现边际速度，不能用当前采样端点的单条速度代替它。逐坐标路径方差 \(q_d(t)=\sigma_t^2+\alpha_t^2s_d^2\) 必须有限且为正。默认生成方向要求 \((\alpha_0,\sigma_0)=(0,1)\)、\((\alpha_1,\sigma_1)=(1,0)\)；函数本身根据传入系数计算，反向时钟测试会明确调换这一方向。形状不符或退化方差应拒绝。 本题将整个 \(H D\) 维动作块展平理解：每个端点内部的全部时间位置与坐标均相互独立，`mean/std` 在 \(H\) 轴共享，分别广播至 \([B,H,D]\)。不能将逐坐标公式直接用于带跨时刻协方差的联合动作分布。

运行环境：torch

```python
import torch


def affine_path(noise, data, t, schedule):
    # TODO: 验证四组 [B] 系数，扩展到 [B,1,1]。
    # TODO: 分别组合状态和固定端点的时间导数。
    raise NotImplementedError("请实现一般仿射条件路径")


def gaussian_marginal_velocity(x, t, mean, std, schedule):
    # TODO: 推导 E[X_t]、E[U_t]、Var(X_t) 和 Cov(U_t,X_t)。
    # TODO: 用联合高斯条件均值；不要除以 alpha 或 sigma 来制造端点奇异。
    raise NotImplementedError("请实现对应的 Gaussian 边际速度")

```

### 提示

- 固定端点后只有系数依赖时间：\(U_t=\dot\alpha_tX_1+\dot\sigma_tX_0\)。与线性路径相比，速度通常随时间变化。

- 独立端点给出 \(\mathbb E[U_t]=\dot\alpha_t\mu\)，逐坐标交叉协方差为 \(\operatorname{Cov}(U_{t,d},X_{t,d})=\dot\alpha_t\alpha_t s_d^2+\dot\sigma_t\sigma_t\)。

- 由联合高斯条件均值得到：\[u_{t,d}(x)=\dot\alpha_t\mu_d+\frac{\operatorname{Cov}(U_{t,d},X_{t,d})}{q_d(t)}(x_d-\alpha_t\mu_d).\]总路径方差非零才是这里的除法条件。

- 若令 \(t=g(s)\)，相同路径在新时钟中的速度还要乘 \(g^\prime(s)\)；\(g(s)=1-s\) 时为反号，生成步长也变为负。

### 参考答案

```python
import torch


def _coefficients(t, schedule, reference):
    if (t.shape != (reference.shape[0],) or t.dtype != reference.dtype
            or t.device != reference.device or not torch.isfinite(t).all()
            or not ((0 <= t) & (t <= 1)).all()):
        raise ValueError("t 必须为同 dtype/device 的有限 [B]，且在 [0,1]")
    values = schedule(t)
    if len(values) != 4:
        raise ValueError("schedule 必须返回 alpha, sigma, alpha_dot, sigma_dot")
    if any(v.shape != t.shape or v.dtype != t.dtype or v.device != t.device
           or not torch.isfinite(v).all() for v in values):
        raise ValueError("每个系数必须为有限 [B]，不能把标量或动作轴误当 Batch")
    return tuple(v[:, None, None] for v in values)


def affine_path(noise, data, t, schedule):
    if (noise.ndim != 3 or noise.shape != data.shape or noise.numel() == 0
            or not noise.is_floating_point() or noise.dtype != data.dtype
            or noise.device != data.device
            or not torch.isfinite(noise).all() or not torch.isfinite(data).all()):
        raise ValueError("端点必须为同 dtype/device 的有限非空 [B,H,D]")
    alpha, sigma, alpha_dot, sigma_dot = _coefficients(t, schedule, noise)
    return alpha * data + sigma * noise, alpha_dot * data + sigma_dot * noise


def gaussian_marginal_velocity(x, t, mean, std, schedule):
    if x.ndim != 3 or x.numel() == 0 or not x.is_floating_point() or not torch.isfinite(x).all():
        raise ValueError("x 必须是有限非空浮点 [B,H,D]")
    if (mean.shape != (x.shape[-1],) or std.shape != mean.shape
            or mean.dtype != x.dtype or std.dtype != x.dtype
            or mean.device != x.device or std.device != x.device
            or not torch.isfinite(mean).all() or not torch.isfinite(std).all()
            or not (std > 0).all()):
        raise ValueError("mean/std 必须为有限 [D]，std 严格为正")
    alpha, sigma, alpha_dot, sigma_dot = _coefficients(t, schedule, x)
    variance = sigma.square() + alpha.square() * std.square()
    if not torch.isfinite(variance).all() or not (variance > 0).all():
        raise ValueError("路径方差必须有限且为正；不在退化端点除零")
    cross_covariance = sigma_dot * sigma + alpha_dot * alpha * std.square()
    return alpha_dot * mean + cross_covariance / variance * (x - alpha * mean)

```

第一组测试用固定端点的有限差分核对一般路径导数；第二组用 \(t=s^2\) 暴露遗漏链式法则因子的问题；第三组显式构造反向时钟和错误步长反例。Gaussian 场的独立参照是解析轨迹 \(x_d(t)=\alpha_t\mu_d+\sqrt{q_d(t)}z_d\)，对它差分应等于边际速度，而不是逐样本条件速度。

追问：为什么 \(\alpha=0\) 或 \(\sigma=0\) 时这里仍可能直接求值？本解只除以总方差 \(q_d\)，没有使用需要除以单个系数的 score/noise 反解；当 \(q_d>0\) 且系数导数有限时，两个普通端点都可有效。若目标退化成点质量、或两个系数同时为零，可能出现 \(q_d=0\)，不能把 epsilon 填入分母后声称保留同一个数学模型。为什么独立噪声与数据很重要？非独立配对会增加交叉协方差，当前 Gaussian 公式不能原样使用。 若不同时间位置相关，对完整动作块条件化就必须使用相应的联合协方差；一般高斯条件均值包含矩阵 \(C_{UX}C_{XX}^{-1}\)，不再是每个坐标独立除以 \(q_d\)，且还需检查协方差的可逆性。

### 断言测试

```python
import math

torch.manual_seed(20261107)
torch.set_num_threads(1)
noise = torch.randn(2, 3, 4, dtype=torch.float64)
data = torch.randn_like(noise) + .7
t = torch.tensor([.2, .7], dtype=torch.float64)


def linear(t):
    return t, 1 - t, torch.ones_like(t), -torch.ones_like(t)


def cosine(t):
    angle = math.pi * t / 2
    return angle.sin(), angle.cos(), (math.pi / 2) * angle.cos(), -(math.pi / 2) * angle.sin()


# 路径导数来自固定端点求导；非线性系数不能继续返回 data-noise。
xt, velocity = affine_path(noise, data, t, cosine)
eps = 1e-6
left = affine_path(noise, data, t - eps, cosine)[0]
right = affine_path(noise, data, t + eps, cosine)[0]
torch.testing.assert_close(velocity, (right - left) / (2 * eps), atol=1e-8, rtol=1e-8)
assert not torch.allclose(velocity, data - noise)
for endpoint, expected in [(0., noise), (1., data)]:
    state, _ = affine_path(noise, data, torch.full_like(t, endpoint), cosine)
    torch.testing.assert_close(state, expected, atol=1e-14, rtol=1e-14)

# 时间重参数化 t=s²；速度需要链式法则因子 2s。
def quadratic(s):
    return s.square(), 1 - s.square(), 2 * s, -2 * s


state_s, speed_s = affine_path(noise, data, t, quadratic)
state_t, speed_t = affine_path(noise, data, t.square(), linear)
torch.testing.assert_close(state_s, state_t)
torch.testing.assert_close(speed_s, 2 * t[:, None, None] * speed_t)

# 反向时钟 s=1-t：端点与速度同时转换，负步长把样本送往数据。
def reversed_linear(s):
    return 1 - s, s, -torch.ones_like(s), torch.ones_like(s)


reverse_x, reverse_v = affine_path(noise, data, 1 - t, reversed_linear)
forward_x, forward_v = affine_path(noise, data, t, linear)
torch.testing.assert_close(reverse_x, forward_x)
torch.testing.assert_close(reverse_v, -forward_v)
torch.testing.assert_close(noise + (-1.) * reverse_v, data)
assert not torch.allclose(noise + reverse_v, data)

# 独立 Gaussian 端点的解析流，直接对轨迹做差分来核对边际场。
mean = torch.tensor([1., -.5, .3, 2.], dtype=torch.float64)
std = torch.tensor([.4, 1.2, .7, 1.5], dtype=torch.float64)
z = torch.randn_like(noise)

def exact_flow(time):
    alpha, sigma, _, _ = cosine(time)
    alpha, sigma = alpha[:, None, None], sigma[:, None, None]
    variance = sigma.square() + alpha.square() * std.square()
    return alpha * mean + variance.sqrt() * z


state = exact_flow(t)
field = gaussian_marginal_velocity(state, t, mean, std, cosine)
finite_difference = (exact_flow(t + eps) - exact_flow(t - eps)) / (2 * eps)
torch.testing.assert_close(field, finite_difference, atol=1e-8, rtol=1e-8)
# alpha=0 或 sigma=0 不自动导致此公式奇异；关键是总路径方差 q>0。
for endpoint in (0., 1.):
    time = torch.full_like(t, endpoint)
    assert torch.isfinite(gaussian_marginal_velocity(exact_flow(time), time, mean, std, cosine)).all()
# 相同单位方差端点的线性路径在 t=.5 处协方差斜率为零，速度恒为 mean。
mid = torch.full_like(t, .5)
mid_field = gaussian_marginal_velocity(state, mid, mean, torch.ones_like(std), linear)
torch.testing.assert_close(mid_field, mean.expand_as(state))

def degenerate(t):
    zero = torch.zeros_like(t)
    return zero, zero, zero, zero


for call in [lambda: gaussian_marginal_velocity(state, t, mean, std, degenerate),
             lambda: gaussian_marginal_velocity(state, t, mean, torch.zeros_like(std), cosine),
             lambda: affine_path(noise, data, t, lambda time: (time[:1],) * 4)]:
    try:
        call()
    except ValueError:
        pass
    else:
        raise AssertionError("未拒绝退化方差、零标准差或错误 Batch 系数")
print("通过：一般路径导数、端点、时间链式法则、方向反例和解析 Gaussian 边际场")

```

## 练习：推导与分析

### 目标是每对端点的 `action - noise`，为什么生成时没有那份 action 也能预测？

真实 action 仅用于构造训练目标。网络输入 \(x_t\)、\(t\)、条件 \(c\)，并学习给定这些量后目标速度的条件期望。推理时用模型替代未知的边际速度，从新噪声积分到终点。

网络不是恢复每次随机配对中的指定端点。固定输入后仍可能存在多个隐藏配对，所以正确模型的样本级 MSE 也可以有不可约的条件方差。

### 训练中 \(x_t\) 是直线插值，是否意味着生成只需一步 Euler？

不意味着。条件配对各自有一条直线，而网络学习这些配对在给定位置、时间、条件下的平均速度。沿学习场积分的轨迹通常会变化方向。

一步 Euler 只使用起点的局部速度。能否用极少步数采样，需要考察实际场的轨迹、数值误差、训练方式及可能的重配对或蒸馏，不能由线性插值公式直接推出。

### \(t=0\) 是噪声和 \(t=1\) 是噪声，哪一种正确？

两种参数化都可以正确。关键是训练中间状态、速度目标、模型时间输入及推理网格完全配套。

将 \(t\) 换成 \(s=1-t\) 后，插值为 \(sx_0+(1-s)x_1\)，目标为 `noise - action`，采样从 \(s=1\) 降到 0。给定一组标量端点手算一次更新，能迅速识别符号不一致。

### 如果 loss 降不下去，怎样判断是模型没学会，还是目标本来就有不可约误差？

先固定少量完整三元组做最小过拟合，确认代码路径、梯度和参数更新正常。再恢复噪声、时间的重采样，并与可得到的解析条件均值或有明确假设的基线比较。

对合成条件高斯分布，可以推导并计算精确边际速度的样本级 MSE；它通常仍不为零。真实数据上没有解析参考时，应按时间、维度、有效长度分解误差，并检查采样与闭环结果，不把任意非零 Loss 当作失败。

### \([B,H,1]\) 的有效时间 Mask，分母应该是 `mask.sum()` 还是 `mask.sum()×D`？

若损失要平均所有有效动作标量，且每个有效时间的 \(D\) 个维度均有效，展开前 `mask.sum()×D` 与展开到 \([B,H,D]\) 后求和等价。若还有维度 Mask，直接使用展开并合并后的有效位数更稳妥。

若希望每条轨迹或每个时间位置等权，可以定义另一种归约，但必须明确目标。不同长度的局部平均再平均，不等于全局有效元素平均。

### Heun 比 Euler 高阶，为什么不能只说它在同样 10 步下更高效？

Heun 每步通常评估两次速度网络，Euler 一次；相同步数并非相同 NFE。模型规模、条件缓存和并行实现还影响实际耗时。

应在同一模型、条件和初始噪声上，同时报告误差、NFE 与延迟。高阶误差结论依赖平滑性等条件；模型偏差较大时，积分误差更小也不保证机器人任务成功率更高。

### FM 产生多种动作时，为什么不一定是在不同有效模式之间插平均？

生成 ODE 从随机初始噪声出发。不同中间位置对应不同的条件后验速度，整个非线性运输可以形成多峰分布；局部条件均值并不等同于最终动作的全局均值。

是否学到了多种有效模式仍需要评估。固定条件下检查多次采样的覆盖、可行性与成功率；不能只展示挑选后的最佳样本。单高斯示例验证解析基本机制；二维多峰训练实验另行检验两个条件混合分布，但仍不外推到真实机器人策略。

### 为什么不能把 Flow Matching 的输出速度直接发给机器人速度控制器？

\(v_\theta\) 是对生成时间 \(t\) 的变化率，通常还位于归一化后的动作块坐标中。它的单位、时间轴和语义与机器人每秒的物理速度不是同一个对象。

应先沿 ODE 积分得到最终动作表示，再反归一化并遵守位置、增量或速度命令等已声明接口。若最终动作本身定义为速度命令，也是积分后的样本才具有该执行语义。

### 为什么条件速度取平均后，仍然能推动同一条概率路径？

对任意光滑紧支撑 \(\varphi\)，路径导数满足：

\[\frac d{dt}\mathbb E[\varphi(X_t)]=\mathbb E[\nabla\varphi(X_t)\cdot U_t]\]

按 \(X_t\) 条件化后，\(U_t\) 可替换为 \(\mathbb E[U_t\mid X_t,t,c]\)，所以每个测试函数的期望变化都保持不变。

将等式写成密度积分并分部积分，得到连续性方程。要进一步用 ODE 运输实现它，还需存在性、唯一性和边界等条件；均值回归本身没有保证有限网络与有限步采样已经达到理想场。

### 把高收益端点的回归权重加大，还能声称学到原来的边际速度吗？

若权重只由可见的 \(x\)、\(t\)、\(c\) 决定，在正权重位置仍得到原条件均值；若权重依赖隐藏端点或 \(U\)，最优输出变为：

\[\frac{\mathbb E[\lambda U\mid x,t,c]}{\mathbb E[\lambda\mid x,t,c]}\]

一般不同。

原目标 \(U\in\{-2,4\}\)、后验概率 \(\{0.75,0.25\}\) 的均值是 −0.5；给 \(U=4\) 三倍权重后，均值变为 1。可以重新定义目标分布与路径，但不能只改 loss 权重却不说明正在运输哪个分布。

### 时间采样更偏向数据端，只是在同一个目标上减少方差吗？

不一定。原目标按 dt 积分，改从 \(q(t)\) 抽样后，需要乘 \(1/q(t)\) 才估计同一目标。若没有校正，就有意提高 \(q\) 较大区域的权重。

以 \(q(t)=2t\)、\(\ell=t^2\) 为例，无权重期望为 1/2，原积分为 1/3。校正后的期望恢复，但权重可能增大方差；需要把目标是否相同与估计是否高效分别分析。

### 精确 ODE 可逆，为什么采样器仍可能把所有噪声压成同一点？

可逆性来自连续场的存在唯一性与正则条件，不自动属于离散更新。对 \(\frac{dx}{dt}=-x\)，精确一步是 \(e^{-1}x\)，Euler 用 \(h=1\) 却得到 \(x-x=0\)。

步长过大可能抹掉模式或产生不稳定更新。固定模型与噪声缩小步长、比较独立求解器，有助于隔离积分误差；如果误差来自场本身，增加步数不会自动修复。

## 练习：辨析与纠错

### 只把 target 的减法方向改了

插值、网络时间输入与采样网格仍沿用另一种时间约定。

固定标量端点检查 \(t=0\,/\,t=1\)、时间导数与一次完整积分；成套转换约定。

### 把生成时间当动作时间

将 ODE 更新步当作机器人已经执行的一帧，或把 \(t\) 嵌入误当动作位置编码。

分别标注 Batch、动作索引和生成时间；整个动作块在一次积分步中共同更新。

### 认为所有训练直线就是生成轨迹

忽略隐藏端点条件在网络输入中并不存在，误推断一步 Euler 一定足够。

区分条件路径与边际速度，记录模型真实积分轨迹和步数收敛情况。

### 只看一个 MSE 标量判定训练正确

错误目标也可能下降，持续重采样的正确目标也可能有非零下限。

增加端点、导数、Mask 分母、梯度、解析场及条件敏感性检查。

### 时间 Mask 广播了，分母没有广播

\([B,H,1]\) 的分子覆盖 \(D\) 个通道，分母仍只数时间位置。

将有效位展开到预测形状后求分母；加入不等长与部分动作维度缺失的测试。

### 用 \(0\cdot\mathrm{NaN}\) 掩盖无效标签

NaN 乘零仍是 NaN；更晚的 Mask 不能保证中间计算或梯度正常。

在减法和平方前安全选择有效元素；进入模型的占位输入必须有明确定义。

### Heun 第二阶段复用第一次速度

代码虽然有两行更新，却没有在候选状态与下一时间真正再求一次速度。

用 \(\frac{dx}{dt}=x\) 和 \(\frac{dx}{dt}=2t+c\) 两个解析场分别检查状态依赖与时间依赖。

### 反归一化后再额外乘控制周期

没有区分输出是每周期位移、物理速度还是绝对位置，重复改变动作尺度。

将动作语义、单位、坐标系、控制频率和后处理写成一致的输入输出约定。

### 把噪声预测直接当作 FM 速度

两个张量形状相同，但代表的目标和路径系数不同。

从 \(\alpha(t)\)、\(\sigma(t)\) 重新推导转换，核对中间时间与端点数值稳定性。

### 把线性路径称为全局最优运输

独立抽取噪声和数据并线性连接，不会自动求出全局最优耦合。

区分路径形状与端点配对机制，说明是否使用重配对、OT 求解或 Reflow。

## 参考资料

- [Lipman et al. · Flow Matching for Generative Modeling（条件路径、边际速度与等价目标）](https://arxiv.org/abs/2210.02747)

- [Lipman et al. · Flow Matching Guide and Code（数学基础与设计选择）](https://arxiv.org/abs/2412.06264)

- [官方 Flow Matching 文档 · AffineProbPath（路径系数、导数及目标转换）](https://facebookresearch.github.io/flow_matching/generated/flow_matching.path.AffineProbPath.html)

- [官方 Flow Matching 文档 · CondOTProbPath（\(\alpha=t\)、\(\sigma=1-t\)）](https://facebookresearch.github.io/flow_matching/generated/flow_matching.path.CondOTProbPath.html)

- [官方 Flow Matching 文档 · ODESolver（积分器、网格与求值接口）](https://facebookresearch.github.io/flow_matching/generated/flow_matching.solver.ODESolver.html)

- [Liu et al. · Flow Straight and Fast / Rectified Flow（直线路径与重新耦合）](https://arxiv.org/abs/2209.03003)

- [Song et al. · Score-Based Generative Modeling through SDEs（probability-flow ODE）](https://arxiv.org/abs/2011.13456)

- [PyTorch · MSELoss（mean 归约涵盖全部标量元素）](https://docs.pytorch.org/docs/stable/generated/torch.nn.MSELoss.html)

- [OpenPI · pi0.py（公开模型的反向时间约定与动作采样示例）](https://github.com/Physical-Intelligence/openpi/blob/main/src/openpi/models/pi0.py)

- [Physical Intelligence · π₀ 研究介绍（具身动作生成应用背景）](https://www.pi.website/blog/pi0)

- [Chen & Lipman · Flow Matching on General Geometries（非欧氏表示的进阶边界）](https://arxiv.org/abs/2302.03660)

- [Tong et al. · Conditional Flow Matching 与 minibatch OT 耦合](https://arxiv.org/abs/2302.00482)

- [Salimans & Ho · v 参数化与时间变量](https://arxiv.org/abs/2202.00512)

- [Chen et al. · Neural ODE：可逆流与瞬时密度变换](https://arxiv.org/abs/1806.07366)
