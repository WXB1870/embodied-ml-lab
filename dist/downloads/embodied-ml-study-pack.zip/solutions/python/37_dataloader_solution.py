# 数据采样与批处理
# 环境：Python 标准库
# 实现 pad_and_mask(sequences,pad_value=0)，返回补齐后的二维列表和同形状布尔 Mask。允许某条序列为空，但整个 Batch 不能为空；不修改输入。

def pad_and_mask(sequences, pad_value=0):
    if not sequences:
        raise ValueError("Batch 不能为空")
    longest = max(len(seq) for seq in sequences)
    padded = [list(seq) + [pad_value] * (longest-len(seq))
              for seq in sequences]
    valid = [[j < len(seq) for j in range(longest)] for seq in sequences]
    return padded, valid


# ===== 断言测试 =====
items = [[0, 2], [3], []]
padded, valid = pad_and_mask(items)
assert padded == [[0,2], [3,0], [0,0]]
assert valid == [[True,True], [True,False], [False,False]]
assert sum(sum(row) for row in valid) == 3
assert items == [[0,2], [3], []]
assert pad_and_mask([[], []]) == ([[], []], [[], []])
try:
    pad_and_mask([])
    raise AssertionError("空 Batch 应被拒绝")
except ValueError:
    pass
print("通过：真实零值、变长序列、空序列和不修改输入")

print("所有提供的测试通过。")
