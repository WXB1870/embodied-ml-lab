# VLA：从视觉语言骨干到动作专家
# 环境：Python 标准库
# 实现 block_attention_mask(valid, block_start)。valid 是 [B,N] 布尔列表，block_start 是长度 N 的布尔列表；其累积和为组号。返回 [B,N,N] 布尔矩阵，行 Query i 只能读有效、且组号不大于自身的 Key j；无效 Query 整行必须为 False。拒绝空输入、形状不符及非布尔值。先手算两个 prefix、一个 state、两个 action 的矩阵，再运行测试。

def block_attention_mask(valid, block_start):
    if not valid or not valid[0]:
        raise ValueError("nonempty batch and sequence required")
    n = len(valid[0])
    if len(block_start) != n or any(len(row) != n for row in valid):
        raise ValueError("inconsistent lengths")
    if any(type(value) is not bool for row in valid for value in row):
        raise ValueError("valid entries must be bool")
    if any(type(value) is not bool for value in block_start):
        raise ValueError("block_start entries must be bool")
    groups, total = [], 0
    for start in block_start:
        total += int(start)
        groups.append(total)
    return [[[bool(row[i] and row[j] and groups[j] <= groups[i])
              for j in range(n)] for i in range(n)] for row in valid]


# ===== 断言测试 =====
start = [False, False, True, True, False]
actual = block_attention_mask([[True] * 5], start)[0]
expected = [[True, True, False, False, False],
            [True, True, False, False, False],
            [True, True, True, False, False],
            [True, True, True, True, True],
            [True, True, True, True, True]]
assert actual == expected
mask = block_attention_mask([[True, False, True, True, False]], start)[0]
assert all(not row[1] and not row[4] for row in mask)
assert not any(mask[1]) and not any(mask[4])
# The first boundary flag may shift every group equally without changing visibility.
assert block_attention_mask([[True]*5], [True, False, True, True, False])[0] == expected
for valid, start in [([], []), ([[True]], []), ([[True], [True, False]], [False]),
                     ([[1]], [False]), ([[True]], [0])]:
    try:
        block_attention_mask(valid, start)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid input accepted")
print("block mask checks passed")

print("所有提供的测试通过。")
