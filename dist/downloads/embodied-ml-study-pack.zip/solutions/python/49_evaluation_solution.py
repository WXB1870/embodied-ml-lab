# 闭环评估与统计
# 环境：Python 标准库
# 实现 wilson_interval(successes,trials,\(z=1.96\))，返回裁剪在 [0,1] 内的 (low,high)。成功次数必须是 0 到 trials 的整数，trials 为正整数，z 为正有限数。

import math

def wilson_interval(successes, trials, z=1.96):
    if not isinstance(successes,int) or not isinstance(trials,int) or trials <= 0 or not 0 <= successes <= trials:
        raise ValueError('invalid binomial counts')
    if not math.isfinite(z) or z <= 0:
        raise ValueError('invalid z')
    p = successes/trials
    d = 1+z*z/trials
    center = (p+z*z/(2*trials))/d
    half = z*math.sqrt(p*(1-p)/trials+z*z/(4*trials*trials))/d
    return max(0.0,center-half),min(1.0,center+half)


# ===== 断言测试 =====
lo,hi = wilson_interval(9,10)
assert abs(lo-0.59585) < 0.001 and abs(hi-0.98212) < 0.001
lo2,hi2 = wilson_interval(90,100)
assert hi2-lo2 < hi-lo
lo3,hi3 = wilson_interval(0,10)
assert lo3 < 1e-12 and 0.27 < hi3 < 0.29
try:
    wilson_interval(0,0)
    raise AssertionError('无试验应报错')
except ValueError:
    pass
print('Wilson 区间检查通过：相同成功率下，更多独立试验通常带来更窄区间。')

print("所有提供的测试通过。")
