# 视觉预处理与坐标变换
# 环境：Python 标准库
# 实现 map_letterbox_point(point,original_hw,target_hw)。使用正数四舍五入 `int(value+0.5)` 确定缩放尺寸，居中补边，像素中心约定与 align_corners=False 对齐。返回 (u',v')。

def map_letterbox_point(point, original_hw, target_hw):
    h, w = original_hw
    oh, ow = target_hw
    if min(h,w,oh,ow) <= 0:
        raise ValueError("尺寸必须为正")
    ratio = min(oh/h, ow/w)
    nh, nw = max(1,int(h*ratio+0.5)), max(1,int(w*ratio+0.5))
    top, left = (oh-nh)//2, (ow-nw)//2
    u, v = point
    return ((u+0.5)*(nw/w)-0.5+left,
            (v+0.5)*(nh/h)-0.5+top)


# ===== 断言测试 =====
assert map_letterbox_point((2,1),(4,8),(8,8)) == (2.0,3.0)
assert map_letterbox_point((0,0),(4,4),(8,8)) == (0.5,0.5)
assert map_letterbox_point((3,2),(5,9),(5,9)) == (3.0,2.0)
u,v = map_letterbox_point((4,2),(5,9),(12,12))
assert abs(u-5.5) < 1e-12
assert abs(v-5.0) < 1e-12
print("通过：补边、半像素、恒等变换和整数尺寸")

print("所有提供的测试通过。")
