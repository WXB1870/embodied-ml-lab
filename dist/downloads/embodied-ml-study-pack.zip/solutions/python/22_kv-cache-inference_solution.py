# KV Cache 与增量计算
# 环境：Python 标准库
# 实现 incremental_allowed(past_len,new_len)。返回 new_len 行、past_len+new_len 列的布尔矩阵，第 i 个查询位置为 `past_len+i`；负长度和 `new_len=0` 应抛出 ValueError。

def incremental_allowed(past_len, new_len):
    if past_len < 0 or new_len <= 0:
        raise ValueError("历史长度需非负，新长度需为正")
    return [[key <= past_len+query for key in range(past_len+new_len)]
            for query in range(new_len)]


# ===== 断言测试 =====
assert incremental_allowed(3,2) == [[True,True,True,True,False],[True,True,True,True,True]]
assert incremental_allowed(0,3) == [[True,False,False],[True,True,False],[True,True,True]]
assert incremental_allowed(5,1) == [[True]*6]
try:
    incremental_allowed(2,0)
    raise AssertionError("空增量应被拒绝")
except ValueError:
    pass
print("通过：历史偏移、分块和单 token Decode")

print("所有提供的测试通过。")
