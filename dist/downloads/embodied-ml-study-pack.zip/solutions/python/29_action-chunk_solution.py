# 时间对齐与动作块
# 环境：Python 标准库
# 实现 window_indices(length,t,history,horizon)，返回 (obs_indices, action_indices)。不存在的历史或未来记录使用 None，t 必须位于轨迹内，三个长度参数都必须为正。

def window_indices(length, t, history, horizon):
    if min(length, history, horizon) <= 0 or not 0 <= t < length:
        raise ValueError('invalid window configuration')
    obs = [i if 0 <= i < length else None for i in range(t-history+1, t+1)]
    act = [i if 0 <= i < length else None for i in range(t, t+horizon)]
    return obs, act


# ===== 断言测试 =====
assert window_indices(5,0,3,3) == ([None,None,0], [0,1,2])
assert window_indices(5,4,3,3) == ([2,3,4], [4,None,None])
assert window_indices(5,2,2,2) == ([1,2], [2,3])
try:
    window_indices(5,5,2,2)
    raise AssertionError('t 越界应报错')
except ValueError:
    pass
print('窗口边界与当前动作对齐检查通过。')

print("所有提供的测试通过。")
