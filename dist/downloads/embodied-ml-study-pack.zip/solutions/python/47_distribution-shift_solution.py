# 分布偏移与 DAgger
# 环境：Python 标准库
# 实现 `aggregate_pairs(old_pairs, visited_states, expert)`。返回旧样本加上每个访问状态的新专家标签，不修改 `old_pairs`，不去重访问状态。`expert(state)` 返回正确监督动作。

def aggregate_pairs(old_pairs, visited_states, expert):
    result=list(old_pairs)
    for state in visited_states:
        result.append((state,expert(state)))
    return result


# ===== 断言测试 =====
old=[(0.0,0.0)]
calls=[]
def teacher(s):
    calls.append(s)
    return -0.5*s
out=aggregate_pairs(old,[1.,2.,1.],teacher)
assert out==[(0.,0.),(1.,-0.5),(2.,-1.),(1.,-0.5)]
assert old==[(0.,0.)] and calls==[1.,2.,1.]
assert aggregate_pairs(old,[],teacher)==old
print('专家查询、保留旧数据和访问频率检查通过。')

print("所有提供的测试通过。")
