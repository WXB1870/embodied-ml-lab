# 多任务梯度
# 环境：Python 标准库
# 实现 gradient_relation(g_a, g_b, weight)，返回 (combined, cosine)。两个输入为等长非空有限数列表，weight 为有限非负数；combined = g_a + weight*g_b。cosine 比较两个原始梯度，任一个范数为零时返回 None。非法输入抛 ValueError。 合成梯度溢出时抛 ValueError；余弦应避免直接相乘大数范数造成的中间溢出。

import math

def gradient_relation(g_a, g_b, weight):
    if not g_a or len(g_a) != len(g_b):
        raise ValueError('向量形状不同')
    if not math.isfinite(weight) or weight < 0 or any(not math.isfinite(v) for v in g_a + g_b):
        raise ValueError('必须是有限数且权重非负')
    combined = [a + weight * b for a, b in zip(g_a, g_b)]
    if any(not math.isfinite(v) for v in combined):
        raise ValueError('合成梯度超出浮点有限范围')
    sa, sb = max(map(abs, g_a)), max(map(abs, g_b))
    if sa == 0 or sb == 0:
        return combined, None
    # 两个正尺度分别约掉，不直接计算可能溢出的 dot 或 norm 乘积。
    a, b = [v / sa for v in g_a], [v / sb for v in g_b]
    na, nb = math.hypot(*a), math.hypot(*b)
    cosine = math.fsum((u / na) * (v / nb) for u, v in zip(a, b))
    return combined, max(-1.0, min(1.0, cosine))


# ===== 断言测试 =====
combined, cosine = gradient_relation([1, 0], [-2, 0], 0.5)
assert combined == [0, 0] and cosine == -1
assert gradient_relation([1, 0], [0, 2], 2) == ([1, 4], 0.0)
assert gradient_relation([0, 0], [1, 2], 3) == ([3, 6], None)
assert gradient_relation([1, 2], [1, 2], 0)[0] == [1, 2]
for args in [([], [], 1), ([1], [1, 2], 1), ([1], [float('nan')], 1)]:
    try:
        gradient_relation(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法向量')
assert gradient_relation([1e200, 0], [-1e200, 0], 1) == ([0, 0], -1.0)
assert abs(gradient_relation([1.7e308, 1.7e308], [1.7e308, 1.7e308], 0)[1] - 1) < 1e-12
try:
    gradient_relation([1e308], [1e308], 1)
except ValueError:
    pass
else:
    raise AssertionError('应拒绝合成梯度溢出')
print('通过：抵消、正交、零范数、大数余弦与输入边界')

print("所有提供的测试通过。")
