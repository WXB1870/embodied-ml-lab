# Flow Matching
# 环境：Python 标准库
# 实现 euler_integrate(x0, velocity, steps)，将标量初值从 t=0 积分到 t=1。velocity(x,t) 返回速度；steps 必须是正整数。每次用更新前的 x 与当前 t 计算速度。

def euler_integrate(x0, velocity, steps):
    if not isinstance(steps,int) or steps <= 0:
        raise ValueError('steps must be positive integer')
    x = float(x0)
    dt = 1.0/steps
    for k in range(steps):
        x = x + dt*velocity(x,k*dt)
    return x


# ===== 断言测试 =====
assert abs(euler_integrate(2.,lambda x,t:3.,10)-5.) < 1e-12
assert abs(euler_integrate(1.,lambda x,t:x,10)-1.1**10) < 1e-12
assert abs(euler_integrate(0.,lambda x,t:t,4)-0.375) < 1e-12
try:
    euler_integrate(0.,lambda x,t:1.,0)
    raise AssertionError('步数为零应报错')
except ValueError:
    pass
print('常速度、状态相关速度和时间相关速度检查通过。')

print("所有提供的测试通过。")
