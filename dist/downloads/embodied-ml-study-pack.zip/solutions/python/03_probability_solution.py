# 概率、统计与训练目标
# 环境：Python 标准库
# 输入非空 logits 列表，输出概率列表。必须能处理 [1000,1001,999]，并且整体平移 logits 后结果不变。

import math

def stable_softmax(logits):
    if not logits:
        raise ValueError("logits 不能为空")
    maximum = max(logits)
    exps = [math.exp(z - maximum) for z in logits]
    total = sum(exps)
    return [value / total for value in exps]


# ===== 断言测试 =====
p = stable_softmax([1000., 1001., 999.])
q = stable_softmax([0., 1., -1.])
assert abs(sum(p) - 1.) < 1e-12
assert all(abs(a-b) < 1e-12 for a, b in zip(p, q))
assert abs(p[1] / p[0] - math.e) < 1e-12
assert stable_softmax([0., 0.]) == [0.5, 0.5]
try:
    stable_softmax([])
except ValueError:
    pass
else:
    raise AssertionError("空输入应显式拒绝")
print("通过：稳定性、归一化与平移不变性。")

print("所有提供的测试通过。")
