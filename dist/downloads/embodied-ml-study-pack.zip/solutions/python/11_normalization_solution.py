# 归一化：统计轴、梯度与不变性
# 环境：Python 标准库
# 实现 layer_norm_rows(rows, eps)。每行独立计算均值与总体方差，不使用 NumPy。输入行不能为空；不加可学习仿射参数。返回新的二维列表。

import math

def layer_norm_rows(rows, eps=1e-5):
    result = []
    for row in rows:
        if not row:
            raise ValueError("不能归一化空行")
        mean = sum(row) / len(row)
        var = sum((value - mean) ** 2 for value in row) / len(row)
        scale = math.sqrt(var + eps)
        result.append([(value - mean) / scale for value in row])
    return result


# ===== 断言测试 =====
a = layer_norm_rows([[1.0, 2.0, 3.0], [8.0, 8.0, 8.0]])
assert abs(sum(a[0])) < 1e-10
assert a[1] == [0.0, 0.0, 0.0]
b = layer_norm_rows([[11.0, 12.0, 13.0]])[0]
assert all(abs(x-y) < 1e-10 for x, y in zip(a[0], b))
assert abs(a[0][0] + (1.0 / (2.0/3.0 + 1e-5) ** 0.5)) < 1e-10
try:
    layer_norm_rows([[]])
    raise AssertionError("空行应被拒绝")
except ValueError:
    pass
print("通过：统计维度、平移不变性、常量行和空行检查")

print("所有提供的测试通过。")
