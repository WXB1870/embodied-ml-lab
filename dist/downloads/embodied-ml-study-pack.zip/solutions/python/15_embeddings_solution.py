# Embedding 与位置编码
# 环境：Python 标准库
# 实现 rotate_pair(pair, position, frequency)。pair 含两个数，角度为 position×frequency；返回旋转后的两个数。不使用第三方库。

import math

def rotate_pair(pair, position, frequency):
    if len(pair) != 2:
        raise ValueError("每个旋转平面需要两个通道")
    a, b = pair
    angle = position * frequency
    c, s = math.cos(angle), math.sin(angle)
    return [a*c-b*s, a*s+b*c]


# ===== 断言测试 =====
import math
z = rotate_pair([1.0, 0.0], 1, math.pi/2)
assert abs(z[0]) < 1e-12 and abs(z[1]-1) < 1e-12
r = rotate_pair([3.0, 4.0], 7, 0.13)
assert abs(sum(v*v for v in r)-25.0) < 1e-10
dot = lambda a,b: sum(x*y for x,y in zip(a,b))
q, k = [1.0,2.0], [-0.5,3.0]
a = dot(rotate_pair(q, 2, .2), rotate_pair(k, 5, .2))
b = dot(rotate_pair(q, 12, .2), rotate_pair(k, 15, .2))
assert abs(a-b) < 1e-10
print("通过：旋转方向、范数与相对位置性质")

print("所有提供的测试通过。")
