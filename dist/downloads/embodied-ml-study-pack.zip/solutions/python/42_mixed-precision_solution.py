# 混合精度训练
# 环境：Python 标准库
# 实现 unscale_and_clip(scaled_grad, scale, max_norm)，输入为非空的有限数列表，返回 (真实裁剪前范数, 裁剪后梯度列表)。scale 必须为有限正数，max_norm 为有限非负数；输入非法时抛 ValueError。零梯度应保持为零。只用标准库。反缩放结果或其范数超出浮点有限范围时，也应抛 ValueError。

import math

def unscale_and_clip(scaled_grad, scale, max_norm):
    if not scaled_grad or not math.isfinite(scale) or scale <= 0:
        raise ValueError('缩放尺度必须为正数')
    if not math.isfinite(max_norm) or max_norm < 0:
        raise ValueError('阈值必须为非负数')
    if any(not math.isfinite(x) for x in scaled_grad):
        raise ValueError('梯度必须有限')
    grad = [x / scale for x in scaled_grad]
    if any(not math.isfinite(x) for x in grad):
        raise ValueError('反缩放结果超出浮点有限范围')
    norm = math.hypot(*grad)
    if not math.isfinite(norm):
        raise ValueError('梯度范数超出浮点有限范围')
    factor = min(1.0, max_norm / norm) if norm else 1.0
    return norm, [x * factor for x in grad]


# ===== 断言测试 =====
norm, grad = unscale_and_clip([24, 32], 8, 2.5)
assert abs(norm - 5) < 1e-12 and grad == [1.5, 2.0]
assert unscale_and_clip([3, 4], 1, 10) == (5.0, [3.0, 4.0])
assert unscale_and_clip([0, 0], 16, 0) == (0.0, [0.0, 0.0])
for args in [([1], 0, 1), ([1], 1, -1), ([float('inf')], 1, 1), ([1e308], 1e-308, 1.0), ([1.7e308, 1.7e308], 1, 1)]:
    try:
        unscale_and_clip(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法输入')
print('通过：反缩放顺序、阈值和零梯度')

print("所有提供的测试通过。")
