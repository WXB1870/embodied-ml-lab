# MLP：表达、梯度与优化
# 环境：Python 标准库
# w1 为 [H,D]，w2 为 [O,H]，隐藏层使用 ReLU，输出层不加激活。输入 x 是一条 D 维特征，返回 O 维输出列表。

def mlp_forward(x, w1, b1, w2, b2):
    hidden = [max(0., sum(w * xi for w, xi in zip(row, x)) + bias)
              for row, bias in zip(w1, b1)]
    return [sum(w * hi for w, hi in zip(row, hidden)) + bias
            for row, bias in zip(w2, b2)]


# ===== 断言测试 =====
w1, b1 = [[1., 1.], [-1., 2.]], [0., 6.]
w2, b2 = [[2., 3.], [-1., 4.]], [1., -2.]
assert mlp_forward([1., -2.], w1, b1, w2, b2) == [4., 2.]
assert mlp_forward([2., 1.], w1, b1, w2, b2) == [25., 19.]
assert mlp_forward([0.], [[0.]], [0.], [[1.]], [-3.]) == [-3.]
print("通过：隐藏非线性正确，输出允许负值。")

print("所有提供的测试通过。")
