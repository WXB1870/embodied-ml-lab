# 生成式动作策略：ACT、Diffusion 与 Flow
# 环境：Python 标准库
# 实现 `diagonal_gaussian_kl(mu, logvar)`。输入等长、非空的数值列表，分别表示均值 \(\mu\) 和对数方差 \(\ell\)；返回 \(\mathcal N(\mu,\operatorname{diag}(e^\ell))\) 到 \(\mathcal N(0,I)\) 的 KL 总和。输入长度不符或包含非有限值时抛出 `ValueError`。注意 `logvar` 是对数方差，不是对数标准差。

import math

def diagonal_gaussian_kl(mu, logvar):
    if not mu or len(mu) != len(logvar):
        raise ValueError('expected equal, nonempty vectors')
    if not all(math.isfinite(x) for x in list(mu)+list(logvar)):
        raise ValueError('nonfinite distribution parameter')
    return 0.5 * sum(m*m + math.exp(v) - 1.0 - v for m,v in zip(mu,logvar))


# ===== 断言测试 =====
assert diagonal_gaussian_kl([0.,0.], [0.,0.]) == 0.
# In one dimension, mean=1 and standard deviation=2.
expected = 0.5 * (4.0-math.log(4.0))
assert math.isclose(diagonal_gaussian_kl([1.], [math.log(4.)]), expected)
assert math.isclose(diagonal_gaussian_kl([-1.], [math.log(4.)]), expected)
# Independent dimensions contribute additively.
assert math.isclose(diagonal_gaussian_kl([1.,-1.], [0.,0.]), 1.)
for mu, lv in [([],[]), ([0.],[0.,0.]), ([float('nan')],[0.])]:
    try:
        diagonal_gaussian_kl(mu,lv)
        raise AssertionError('invalid parameters must be rejected')
    except ValueError:
        pass
print('passed: prior equality, variance convention and independent-coordinate KL')

print("所有提供的测试通过。")
