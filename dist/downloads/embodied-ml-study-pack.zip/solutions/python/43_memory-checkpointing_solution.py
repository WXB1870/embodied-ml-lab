# 训练显存与重计算
# 环境：Python 标准库
# 实现 adam_state_bytes(total_params, trainable_params)。两个输入都是非负整数，且训练参数量不大于总量。按 FP32 权重、FP32 梯度、两个 FP32 Adam 矩估计，返回 weights、gradients、moments、total 四个字节数。状态已初始化，不计激活、缓存或临时工作区。非法输入抛 ValueError。

def adam_state_bytes(total_params, trainable_params):
    if (not isinstance(total_params, int) or not isinstance(trainable_params, int)
            or total_params < 0 or trainable_params < 0 or trainable_params > total_params):
        raise ValueError('参数数量不合法')
    weights = 4 * total_params
    gradients = 4 * trainable_params
    moments = 8 * trainable_params
    return dict(weights=weights, gradients=gradients, moments=moments,
                total=weights + gradients + moments)


# ===== 断言测试 =====
assert adam_state_bytes(1000, 100) == dict(weights=4000, gradients=400, moments=800, total=5200)
assert adam_state_bytes(1000, 1000)['total'] == 16000
assert adam_state_bytes(1000, 0)['total'] == 4000
for args in [(1, 2), (-1, 0), (2.5, 1)]:
    try:
        adam_state_bytes(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法参数数量')
print('通过：全量训练、冻结与数量边界')

print("所有提供的测试通过。")
