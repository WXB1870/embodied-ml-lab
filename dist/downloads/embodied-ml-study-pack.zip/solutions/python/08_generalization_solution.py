# 泛化与验证
# 环境：Python 标准库
# records 是含 episode 字段的字典列表。val_episodes 指定验证轨迹，返回 (train,val)，保持各集合中原始记录的顺序，不修改输入记录。

def split_by_episode(records, val_episodes):
    selected = set(val_episodes)
    train = [row for row in records if row['episode'] not in selected]
    validation = [row for row in records if row['episode'] in selected]
    return train, validation


# ===== 断言测试 =====
records = [{'episode': 1, 'frame': 0}, {'episode': 2, 'frame': 0},
           {'episode': 1, 'frame': 1}, {'episode': 3, 'frame': 0},
           {'episode': 2, 'frame': 1}]
train, val = split_by_episode(records, [2])
assert [r['episode'] for r in train] == [1, 1, 3]
assert [r['frame'] for r in val] == [0, 1]
assert {r['episode'] for r in train}.isdisjoint({r['episode'] for r in val})
assert len(train) + len(val) == len(records)
assert records[1] == {'episode': 2, 'frame': 0}
assert split_by_episode([], [2]) == ([], [])
print("通过：轨迹互斥、顺序保持和输入完整性。")

print("所有提供的测试通过。")
