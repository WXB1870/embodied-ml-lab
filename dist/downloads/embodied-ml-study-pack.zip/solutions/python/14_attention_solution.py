# 注意力：匹配、聚合与梯度
# 环境：Python 标准库
# 输入 scores 和等长 allowed 列表。只对允许位置做 Softmax，禁止位置返回 0；所有位置都禁止时抛出 ValueError。需要避免 exp(1000) 溢出。

import math

def masked_softmax(scores, allowed):
    if len(scores) != len(allowed) or not any(allowed):
        raise ValueError("长度不匹配或没有有效键")
    maximum = max(s for s, ok in zip(scores, allowed) if ok)
    values = [math.exp(s-maximum) if ok else 0.0
              for s, ok in zip(scores, allowed)]
    total = sum(values)
    return [value / total for value in values]


# ===== 断言测试 =====
a = masked_softmax([0.0, 0.0, 1000.0], [True, True, False])
assert a == [0.5, 0.5, 0.0]
b = masked_softmax([1000.0, 1001.0], [True, True])
assert abs(sum(b)-1.0) < 1e-12 and b[1] > b[0]
c = masked_softmax([-3.0, 9.0], [True, False])
assert c == [1.0, 0.0]
try:
    masked_softmax([1.0], [False])
    raise AssertionError("必须拒绝全屏蔽行")
except ValueError:
    pass
print("通过：Mask、数值稳定性和全屏蔽检测")

print("所有提供的测试通过。")
