# 训练诊断
# 环境：Python 标准库
# 实现 classify_records(records)，返回字典，键为 missing_optimizer、no_gradient、nonfinite_gradient、zero_gradient，对应按字母排序的参数名列表。每条记录含 name、trainable、in_optimizer 和 grad（None 或非空数列表）。只诊断 trainable=True 的记录；类别允许重叠，但非有限梯度不归入 zero_gradient。

import math

def classify_records(records):
    report = {key: [] for key in ['missing_optimizer', 'no_gradient', 'nonfinite_gradient', 'zero_gradient']}
    for item in records:
        if not item['trainable']:
            continue
        name, grad = item['name'], item['grad']
        if not item['in_optimizer']:
            report['missing_optimizer'].append(name)
        if grad is None:
            report['no_gradient'].append(name)
        elif any(not math.isfinite(v) for v in grad):
            report['nonfinite_gradient'].append(name)
        elif all(v == 0 for v in grad):
            report['zero_gradient'].append(name)
    return {key: sorted(names) for key, names in report.items()}


# ===== 断言测试 =====
records = [
    dict(name='good', trainable=True, in_optimizer=True, grad=[1, -2]),
    dict(name='missing', trainable=True, in_optimizer=False, grad=None),
    dict(name='zero', trainable=True, in_optimizer=True, grad=[0, 0]),
    dict(name='nan', trainable=True, in_optimizer=True, grad=[float('nan'), 1]),
    dict(name='frozen', trainable=False, in_optimizer=False, grad=None)]
assert classify_records(records) == {'missing_optimizer':['missing'], 'no_gradient':['missing'],
                                    'nonfinite_gradient':['nan'], 'zero_gradient':['zero']}
assert classify_records([]) == {k: [] for k in classify_records(records)}
print('通过：状态区分、重叠分类和冻结参数排除')

print("所有提供的测试通过。")
