# 线性代数与矩阵求导
# 环境：Python 标准库
# 预测是 w*x+b，损失是误差平方平均值的 \(\frac12\)。返回 (dw, db)。输入 x 与 y 是等长非空列表。

def mse_gradient(x, y, w, b):
    n = len(x)
    errors = [w * xi + b - yi for xi, yi in zip(x, y)]
    dw = sum(e * xi for e, xi in zip(errors, x)) / n
    db = sum(errors) / n
    return dw, db


# ===== 断言测试 =====
assert mse_gradient([1., 2.], [3., 5.], 0., 0.) == (-6.5, -4.0)
assert mse_gradient([1., 2.], [3., 5.], 2., 1.) == (0., 0.)
x, y, w, b = [-1., 0., 2.], [2., 1., -1.], 0.4, 0.2
def loss(w_value):
    return sum((w_value * xi + b - yi) ** 2 for xi, yi in zip(x, y)) / (2 * len(x))
eps = 1e-6
numerical = (loss(w + eps) - loss(w - eps)) / (2 * eps)
assert abs(mse_gradient(x, y, w, b)[0] - numerical) < 1e-6
print("通过：解析梯度与有限差分一致。")

print("所有提供的测试通过。")
