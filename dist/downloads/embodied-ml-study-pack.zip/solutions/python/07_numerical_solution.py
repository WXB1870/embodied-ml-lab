# 数值精度与标准化
# 环境：Python 标准库
# 实现 fit_normalizer(rows,eps) 返回逐维 (mean,scale)，scale 使用总体标准差并至少为 eps；normalize 只使用已有统计量，不重新拟合。

import math

def fit_normalizer(rows, eps=1e-6):
    n, d = len(rows), len(rows[0])
    mean = [sum(row[j] for row in rows) / n for j in range(d)]
    scale = [max(eps, math.sqrt(sum((row[j] - mean[j]) ** 2
                                   for row in rows) / n)) for j in range(d)]
    return mean, scale

def normalize(rows, mean, scale):
    return [[(x - m) / s for x, m, s in zip(row, mean, scale)] for row in rows]


# ===== 断言测试 =====
train = [[1., 10.], [3., 10.]]
mean, scale = fit_normalizer(train)
assert mean == [2., 10.]
assert scale == [1., 1e-6]
assert normalize(train, mean, scale) == [[-1., 0.], [1., 0.]]
assert normalize([[5., 10.]], mean, scale) == [[3., 0.]]
assert mean == [2., 10.], "应用验证数据不应修改统计量"
one_mean, one_scale = fit_normalizer([[3., 4.]])
assert normalize([[3., 4.]], one_mean, one_scale) == [[0., 0.]]
print("通过：总体标准差、常数维度与评估隔离。")

print("所有提供的测试通过。")
