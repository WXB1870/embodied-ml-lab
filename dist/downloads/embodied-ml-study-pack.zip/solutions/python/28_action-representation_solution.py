# 状态与动作表示
# 环境：Python 标准库
# 实现 body_delta(p_now, p_next, R)。R 将工具系向量转换到基座系；函数应返回工具系中的相对位移。只使用 Python 列表和循环。

def body_delta(p_now, p_next, R):
    if len(p_now) != 3 or len(p_next) != 3 or len(R) != 3 or any(len(row) != 3 for row in R):
        raise ValueError('expected 3D position and 3x3 matrix')
    delta = [p_next[i] - p_now[i] for i in range(3)]
    return [sum(R[j][i] * delta[j] for j in range(3)) for i in range(3)]


# ===== 断言测试 =====
I = [[1,0,0],[0,1,0],[0,0,1]]
R = [[0,-1,0],[1,0,0],[0,0,1]]
assert body_delta([0,0,0], [1,2,3], I) == [1,2,3]
assert body_delta([0,0,0], [1,0,0], R) == [0,-1,0]
assert body_delta([1,2,3], [1,2,3], R) == [0,0,0]
try:
    body_delta([0], [1], [[1]])
    raise AssertionError('维度错误应报错')
except ValueError:
    pass
print('4 组坐标变换检查通过。')

print("所有提供的测试通过。")
