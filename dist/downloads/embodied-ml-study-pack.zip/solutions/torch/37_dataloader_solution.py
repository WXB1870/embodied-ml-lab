# 数据采样与批处理
# 环境：Python + PyTorch CPU
# 实现 collate_actions。输入为非空列表，每个 Tensor 是非空 [Ti,A]，且 A 相同；返回补齐动作和 bool 有效位。使用 pad_sequence。

import torch
from torch.nn.utils.rnn import pad_sequence

def collate_actions(sequences):
    if not sequences or any(x.ndim != 2 or len(x) == 0 for x in sequences):
        raise ValueError("需要非空二维动作序列")
    if len({x.shape[1] for x in sequences}) != 1:
        raise ValueError("动作维度必须一致")
    padded = pad_sequence(sequences, batch_first=True)
    lengths = torch.tensor([len(x) for x in sequences], device=padded.device)
    valid = torch.arange(padded.shape[1], device=padded.device)[None] < lengths[:, None]
    return padded, valid


# ===== 断言测试 =====
seqs = [torch.zeros(2, 3), torch.ones(1, 3), torch.full((4, 3), 2.)]
actions, valid = collate_actions(seqs)
assert actions.shape == (3, 4, 3) and valid.dtype == torch.bool
assert valid.sum().item() == 7
assert valid[0, 0] and torch.equal(actions[0, 0], torch.zeros(3))
assert not valid[1, 1]
assert (actions[~valid] == 0).all()
print("通过：形状、长度、真实零动作与 Padding")

print("所有提供的测试通过。")
