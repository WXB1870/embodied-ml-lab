# 激活与初始化
# 环境：Python + PyTorch CPU
# 为本题中每个后接 ReLU 的 Linear 使用 Kaiming normal，并将存在的 bias 清零。不要创建新参数或改变 requires_grad。

import torch
from torch import nn

def init_relu_mlp(model):
    for layer in model.modules():
        if isinstance(layer, nn.Linear):
            nn.init.kaiming_normal_(layer.weight, nonlinearity="relu")
            if layer.bias is not None:
                nn.init.zeros_(layer.bias)
    return model


# ===== 断言测试 =====
torch.manual_seed(11)
model = nn.Sequential(nn.Linear(1000, 200), nn.ReLU(),
                      nn.Linear(200, 40, bias=False), nn.ReLU())
original_ids = [id(p) for p in model.parameters()]
init_relu_mlp(model)
assert [id(p) for p in model.parameters()] == original_ids
assert torch.equal(model[0].bias, torch.zeros_like(model[0].bias))
variance = model[0].weight.var(unbiased=False).item()
assert abs(variance - 2 / 1000) < 0.0002
assert all(p.requires_grad for p in model.parameters())
assert torch.isfinite(model(torch.randn(2, 1000))).all()
print("PyTorch 测试通过：尺度、偏置及参数身份正确。")

print("所有提供的测试通过。")
