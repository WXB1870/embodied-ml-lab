# 行为克隆
# 环境：Python + PyTorch CPU
# 实现带时间掩码的 BC MSE。pred 和 target 为浮点张量 [B,H,D]，valid 为布尔张量 [B,H]。仅对有效标量动作元素取平均；无效位置允许含 NaN，不能污染输出与梯度。没有有效监督或有效位置非有限时抛出 ValueError。

import torch

def masked_bc_loss(pred, target, valid):
    if (pred.ndim != 3 or pred.shape != target.shape
            or valid.shape != pred.shape[:2] or valid.dtype != torch.bool):
        raise ValueError('expected [B,H,D] and boolean [B,H]')
    mask = valid.unsqueeze(-1).expand_as(pred)
    if not bool(mask.any()):
        raise ValueError('no valid action')
    p, y = pred[mask], target[mask]
    if not bool(torch.isfinite(p).all() & torch.isfinite(y).all()):
        raise ValueError('nonfinite value at a valid action')
    return (p-y).square().mean()


# ===== 断言测试 =====
p = torch.tensor([[[1., 3.], [float('nan'), float('nan')]]], requires_grad=True)
y = torch.tensor([[[0., 0.], [float('nan'), float('nan')]]])
v = torch.tensor([[True, False]])
loss = masked_bc_loss(p, y, v)
torch.testing.assert_close(loss, torch.tensor(5.))
loss.backward()
# Analytic derivative: 2 * error / M, with M=2 valid scalar coordinates.
torch.testing.assert_close(p.grad, torch.tensor([[[1., 3.], [0., 0.]]]))
for bad_y, bad_v in [(y, torch.zeros_like(v)),
                     (torch.full_like(y, float('nan')), v),
                     (y, v.float())]:
    try:
        masked_bc_loss(p, bad_y, bad_v)
        raise AssertionError('invalid supervision must be rejected')
    except ValueError:
        pass
print('passed: valid-scalar denominator, analytic gradient, ignored NaNs and invalid supervision')

print("所有提供的测试通过。")
