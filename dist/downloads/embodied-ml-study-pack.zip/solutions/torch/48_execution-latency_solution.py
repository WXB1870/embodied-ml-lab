# 动作执行与延迟
# 环境：Python + PyTorch CPU
# 实现 `limit_reference(previous,target,dt,max_rate,lower,upper)`。previous/target 为 `[B,D]`，其余边界为 [D]。返回位置与参考变化率区间交集内的目标；非有限、非法边界或交集为空时抛出 ValueError。

import torch

def limit_reference(previous,target,dt,max_rate,lower,upper):
    if previous.ndim!=2 or target.shape!=previous.shape or dt<=0:
        raise ValueError('invalid shape or dt')
    if any(v.shape!=(previous.shape[-1],) for v in (max_rate,lower,upper)):
        raise ValueError('invalid bound shape')
    if not all(torch.isfinite(v).all() for v in (previous,target,max_rate,lower,upper)):
        raise ValueError('non-finite input')
    if (max_rate<0).any() or (lower>upper).any():
        raise ValueError('invalid bounds')
    lo=torch.maximum(lower,previous-max_rate*dt)
    hi=torch.minimum(upper,previous+max_rate*dt)
    if (lo>hi).any():
        raise ValueError('empty feasible reference interval')
    return torch.maximum(lo,torch.minimum(hi,target))


# ===== 断言测试 =====
p=torch.tensor([[0.,0.9]])
t=torch.tensor([[2.,2.]])
rate=torch.tensor([0.5,2.])
lo=torch.tensor([-1.,-1.]); hi=torch.tensor([1.,1.])
out=limit_reference(p,t,0.1,rate,lo,hi)
torch.testing.assert_close(out,torch.tensor([[0.05,1.]]))
assert ((out-p).abs()<=rate*0.1+1e-6).all()
try:
    limit_reference(torch.tensor([[5.,0.]]),t,0.1,rate,lo,hi)
    raise AssertionError('位置与变化率边界不相容应报错')
except ValueError:
    pass
print('参考区间与空交集检查通过；这不等于实测动力学约束保证。')

print("所有提供的测试通过。")
