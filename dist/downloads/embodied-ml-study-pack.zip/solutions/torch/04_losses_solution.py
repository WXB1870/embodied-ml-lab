# 损失、掩码与归约
# 环境：Python + PyTorch CPU
# 实现 prediction/target 为 [B,T,D] 的加权 Mask MSE。valid 为布尔 [B,T]，dim_weight 为有限非负 [D]；输入位于同一设备，预测、标签和权重使用同一浮点类型。有效集合同时要求 valid=True 且维度权重大于零：只有集合外的位置允许 NaN。先安全选择再计算误差，分母为有效权重之和；形状不符、非法权重、有效位置非有限或没有正权重监督时抛出 ValueError。权重是数据给定常量，目标不是学习如何挑选样本。

import torch

def masked_weighted_mse(prediction, target, valid, dim_weight):
    if (prediction.ndim != 3 or prediction.shape != target.shape
            or valid.shape != prediction.shape[:2]
            or dim_weight.shape != prediction.shape[2:]
            or valid.dtype != torch.bool):
        raise ValueError("形状或 Mask 类型不符合约定")
    if not torch.isfinite(dim_weight).all() or (dim_weight < 0).any():
        raise ValueError("维度权重应有限且非负")
    weight = valid.to(prediction.dtype).unsqueeze(-1) * dim_weight
    active = weight > 0
    denominator = weight.sum()
    if denominator <= 0:
        raise ValueError("没有有效权重")
    if (not torch.isfinite(prediction[active]).all()
            or not torch.isfinite(target[active]).all()):
        raise ValueError("有效监督中含有非有限值")
    safe_prediction = torch.where(active, prediction, torch.zeros_like(prediction))
    safe_target = torch.where(active, target, torch.zeros_like(target))
    return ((safe_prediction - safe_target).square() * weight).sum() / denominator


# ===== 断言测试 =====
torch.manual_seed(3)
p = torch.randn(2, 3, 2, dtype=torch.float64, requires_grad=True)
y = torch.zeros_like(p)
m = torch.tensor([[True, True, False], [True, False, False]])
w = torch.tensor([1., 2.], dtype=p.dtype)
loss = masked_weighted_mse(p, y, m, w)
# 独立标量索引参照：只读取真正有效的值，不复用被测的广播实现。
expected = sum((p[b,t,d] - y[b,t,d]) ** 2 * w[d]
               for b in range(2) for t in range(3) if m[b,t]
               for d in range(2)) / 9
torch.testing.assert_close(loss, expected)
actual_grad = torch.autograd.grad(loss, p)[0]
reference_grad = torch.autograd.grad(expected, p)[0]
torch.testing.assert_close(actual_grad, reference_grad)
assert torch.equal(actual_grad[~m], torch.zeros_like(actual_grad[~m]))

# 无效位置含 NaN，也应保持相同损失和有限的零梯度。
pn = p.detach().clone()
yn = y.detach().clone()
pn[~m] = float("nan")
yn[~m] = float("nan")
pn.requires_grad_()
safe = masked_weighted_mse(pn, yn, m, w)
torch.testing.assert_close(safe, loss.detach())
safe.backward()
torch.testing.assert_close(pn.grad, reference_grad)
torch.testing.assert_close(masked_weighted_mse(pn, yn, m, 7 * w), safe.detach())

# 零权重维也在有效集合外；有效零标签仍必须参与。
one_dim = torch.tensor([1., 0.], dtype=p.dtype)
pd = p.detach().clone()
yd = y.detach().clone()
pd[..., 1] = float("nan")
yd[..., 1] = float("nan")
pd.requires_grad_()
dim_loss = masked_weighted_mse(pd, yd, m, one_dim)
torch.testing.assert_close(dim_loss, p.detach()[..., 0][m].square().mean())
dim_loss.backward()
assert torch.equal(pd.grad[..., 1], torch.zeros_like(pd.grad[..., 1]))
assert torch.isfinite(pd.grad).all()

def expect_value_error(pred, target, valid, weights):
    try:
        masked_weighted_mse(pred, target, valid, weights)
    except ValueError:
        return
    raise AssertionError("应拒绝不符合约定的输入")

expect_value_error(p, y, torch.zeros_like(m), w)
expect_value_error(p, y, m, torch.zeros_like(w))
expect_value_error(p, y, m, torch.tensor([-1., 2.], dtype=p.dtype))
expect_value_error(p, y, m, torch.tensor([float("inf"), 2.], dtype=p.dtype))
expect_value_error(p, y, m.float(), w)
expect_value_error(p, y[:, :1], m, w)
bad = p.detach().clone()
bad[0, 0, 0] = float("nan")
expect_value_error(bad, y, m, w)
print("PyTorch 测试通过：有效集合、值域、分母和全部预测梯度正确。")

print("所有提供的测试通过。")
