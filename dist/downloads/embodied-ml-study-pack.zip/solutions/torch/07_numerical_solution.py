# 数值精度与标准化
# 环境：Python + PyTorch CPU
# 实现逐维 fit_stats、normalize_tensor 与 denormalize_tensor。统计量只在 fit_stats 中计算，总体标准差的最小值为 eps。

import torch

def fit_stats(train, eps=1e-6):
    return train.mean(dim=0), train.std(dim=0, unbiased=False).clamp_min(eps)

def normalize_tensor(x, mean, scale):
    return (x - mean) / scale

def denormalize_tensor(z, mean, scale):
    return z * scale + mean


# ===== 断言测试 =====
torch.manual_seed(1)
x = torch.randn(12, 3, dtype=torch.float64)
x[:, 2] = 7.
mean, scale = fit_stats(x)
z = normalize_tensor(x, mean, scale)
assert mean.shape == scale.shape == (3,)
assert torch.isfinite(z).all()
assert torch.allclose(z[:, 2], torch.zeros(12, dtype=x.dtype))
assert torch.allclose(denormalize_tensor(z, mean, scale), x, atol=1e-12)
old_mean = mean.clone()
_ = normalize_tensor(x + 100, mean, scale)
assert torch.equal(mean, old_mean)
single_mean, single_scale = fit_stats(torch.tensor([[1., 2.]]))
assert torch.isfinite(single_scale).all() and (single_scale > 0).all()
print("PyTorch 测试通过：统计量、反变换和单样本边界正确。")

print("所有提供的测试通过。")
