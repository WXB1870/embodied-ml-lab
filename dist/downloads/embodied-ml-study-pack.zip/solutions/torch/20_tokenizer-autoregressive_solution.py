# 分词、自回归与标签对齐
# 环境：Python + PyTorch CPU
# 实现 shifted_causal_loss(logits,labels)。labels 已按原位置设好 −100，本函数负责唯一一次移位，并用有效目标总数归约；若没有有效目标则抛出 ValueError。

import torch
from torch.nn import functional as F

def shifted_causal_loss(logits, labels):
    predictions = logits[:, :-1].contiguous()
    targets = labels[:, 1:].contiguous()
    count = (targets != -100).sum()
    if int(count) == 0:
        raise ValueError("没有有效监督目标")
    total = F.cross_entropy(predictions.reshape(-1, logits.shape[-1]),
                            targets.reshape(-1), ignore_index=-100, reduction="sum")
    return total / count


# ===== 断言测试 =====
torch.manual_seed(37)
logits = torch.randn(2,4,6,requires_grad=True)
labels = torch.tensor([[1,2,3,4],[1,5,-100,-100]])
loss = shifted_causal_loss(logits,labels)
lp = logits.log_softmax(-1)
expected = -(lp[0,0,2]+lp[0,1,3]+lp[0,2,4]+lp[1,0,5])/4
torch.testing.assert_close(loss, expected)
loss.backward()
assert torch.equal(logits.grad[:,-1],torch.zeros_like(logits.grad[:,-1]))
assert torch.equal(logits.grad[1,1:],torch.zeros_like(logits.grad[1,1:]))
try:
    shifted_causal_loss(logits,torch.full_like(labels,-100))
    raise AssertionError("必须拒绝空监督")
except ValueError:
    pass
print("通过：标签移位、有效分母与被忽略位置的梯度")

print("所有提供的测试通过。")
