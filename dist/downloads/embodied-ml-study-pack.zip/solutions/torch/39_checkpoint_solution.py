# 保存与恢复训练状态
# 环境：Python + PyTorch CPU
# 实现 restore_training。model、optimizer、scheduler 已按原结构构造；checkpoint 含 model、optimizer、scheduler、torch_rng、global_step。恢复后返回步数，最后设置 PyTorch CPU RNG。

import torch

def restore_training(model, optimizer, scheduler, checkpoint):
    model.load_state_dict(checkpoint["model"])
    optimizer.load_state_dict(checkpoint["optimizer"])
    scheduler.load_state_dict(checkpoint["scheduler"])
    torch.set_rng_state(checkpoint["torch_rng"])
    return checkpoint["global_step"]


# ===== 断言测试 =====
import copy
torch.manual_seed(20)
m = torch.nn.Linear(2, 1)
opt = torch.optim.AdamW(m.parameters(), lr=0.03)
sched = torch.optim.lr_scheduler.StepLR(opt, step_size=1, gamma=0.5)
opt.zero_grad()
m(torch.ones(1, 2)).square().mean().backward()
opt.step()
sched.step()
ckpt = {"model": copy.deepcopy(m.state_dict()), "optimizer": copy.deepcopy(opt.state_dict()),
        "scheduler": copy.deepcopy(sched.state_dict()), "torch_rng": torch.get_rng_state(),
        "global_step": 1}
expected_random = torch.rand(3)
m2 = torch.nn.Linear(2, 1)
o2 = torch.optim.AdamW(m2.parameters(), lr=0.9)
s2 = torch.optim.lr_scheduler.StepLR(o2, step_size=1, gamma=0.5)
assert restore_training(m2, o2, s2, ckpt) == 1
torch.testing.assert_close(torch.rand(3), expected_random, atol=0, rtol=0)
torch.testing.assert_close(m2.weight, m.weight)
assert abs(o2.param_groups[0]["lr"]-0.015) < 1e-12
assert len(o2.state) == len(opt.state) and s2.last_epoch == sched.last_epoch
print("通过：权重、优化器、调度器、步数与 RNG")

print("所有提供的测试通过。")
