# 生成建模、潜变量与 VAE
# 环境：Python + PyTorch CPU
# 实现 `vae_negative_elbo(x,reconstruction_mean,posterior_mean,posterior_logvar,decoder_std)`。\(x\) 为 \([B,D]\)，\(S\) 次潜变量采样得到的重建均值为 \([S,B,D]\)，后验参数为 \([B,d]\)。解码器是固定正标量标准差的独立高斯，先验是单位高斯。返回包含高斯常数项的平均负 ELBO：先求和事件维，再平均 \(S\) 与 \(B\)；保留全部可学习输入的梯度，拒绝错误形状、空轴和非法尺度。

import math
import torch

def vae_negative_elbo(x, reconstruction_mean, posterior_mean, posterior_logvar, decoder_std):
    values = (x, reconstruction_mean, posterior_mean, posterior_logvar)
    if any(not torch.is_tensor(v) or not v.is_floating_point() for v in values):
        raise ValueError("floating tensors required")
    if x.ndim != 2 or reconstruction_mean.ndim != 3 or posterior_mean.ndim != 2:
        raise ValueError("expected [B,D], [S,B,D], [B,Z], [B,Z]")
    if any(v.dtype != x.dtype or v.device != x.device for v in values):
        raise ValueError("dtype and device must match")
    if (x.shape[0] < 1 or x.shape[1] < 1 or reconstruction_mean.shape[0] < 1
            or reconstruction_mean.shape[1:] != x.shape
            or posterior_mean.shape[0] != x.shape[0] or posterior_mean.shape[1] < 1
            or posterior_logvar.shape != posterior_mean.shape):
        raise ValueError("incompatible or empty dimensions")
    std = float(decoder_std)
    if not math.isfinite(std) or std <= 0 or not all(torch.isfinite(v).all() for v in values):
        raise ValueError("finite inputs and positive decoder_std required")
    variance = posterior_logvar.exp()
    if not torch.isfinite(variance).all():
        raise ValueError("posterior variance overflow")
    # D is the event axis; S is the expectation axis; B is the dataset axis.
    nll = 0.5 * (((reconstruction_mean - x[None]) / std).square()
                 + 2 * math.log(std) + math.log(2 * math.pi)).sum(-1).mean(0)
    kl = 0.5 * (posterior_mean.square() + variance - 1 - posterior_logvar).sum(-1)
    return (nll + kl).mean()


# ===== 断言测试 =====
import math
import torch
torch.manual_seed(31)
torch.set_default_dtype(torch.float64)
x = torch.randn(3, 4)
reconstruction = torch.randn(2, 3, 4, requires_grad=True)
mu = torch.randn(3, 2, requires_grad=True)
logvar = (0.2 * torch.randn(3, 2)).requires_grad_()
std = 0.7
actual = vae_negative_elbo(x, reconstruction, mu, logvar, std)
normal = torch.distributions.Normal(reconstruction, std)
nll = -normal.log_prob(x[None]).sum(-1).mean(0)
q = torch.distributions.Normal(mu, (0.5*logvar).exp())
p = torch.distributions.Normal(torch.zeros_like(mu), torch.ones_like(mu))
expected = (nll + torch.distributions.kl_divergence(q, p).sum(-1)).mean()
torch.testing.assert_close(actual, expected)
assert torch.autograd.gradcheck(
    lambda r,m,l: vae_negative_elbo(x, r, m, l, std), (reconstruction, mu, logvar))
wrong_event_average = (
    -normal.log_prob(x[None]).mean(-1).mean(0)
    + torch.distributions.kl_divergence(q, p).sum(-1)).mean()
assert not torch.isclose(actual, wrong_event_average)
for bad_std in [0.0, -1.0, float("inf")]:
    try:
        vae_negative_elbo(x, reconstruction, mu, logvar, bad_std)
        raise AssertionError("invalid decoder scale accepted")
    except ValueError:
        pass
print("passed: distribution reference, axis counterexample and gradcheck")

print("所有提供的测试通过。")
