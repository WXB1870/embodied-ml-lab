# 归一化：统计轴、梯度与不变性
# 环境：Python + PyTorch CPU
# 完成 last_dim_norm(x,gamma,beta,eps)：只沿最后一维做 LayerNorm，再应用形状为 [D] 的 gamma 和 beta。输入为有限浮点张量且 D>0、eps>0；不能调用 nn.LayerNorm 或 F.layer_norm，也不能 detach 均值、方差或输入。测试同时核对前向和 x、gamma、beta 的导数。

import torch

def last_dim_norm(x, gamma, beta, eps=1e-5):
    mean = x.mean(dim=-1, keepdim=True)
    var = x.var(dim=-1, keepdim=True, unbiased=False)
    normalized = (x - mean) * torch.rsqrt(var + eps)
    return normalized * gamma + beta


# ===== 断言测试 =====
torch.manual_seed(1)
dtype = torch.float64
for scale, offset in ((1., 0.), (1e-6, 4.), (0., 3.)):
    x = (scale * torch.randn(2, 3, 4, dtype=dtype) + offset).requires_grad_()
    gamma = torch.randn(4, dtype=dtype, requires_grad=True)
    beta = torch.randn(4, dtype=dtype, requires_grad=True)
    upstream = torch.randn_like(x)
    y = last_dim_norm(x, gamma, beta, 1e-4)
    ref = torch.nn.functional.layer_norm(x, (4,), gamma, beta, 1e-4)
    torch.testing.assert_close(y, ref, rtol=1e-8, atol=1e-10)
    actual = torch.autograd.grad((y * upstream).sum(), (x, gamma, beta))
    expected = torch.autograd.grad((ref * upstream).sum(), (x, gamma, beta))
    for a, b in zip(actual, expected):
        torch.testing.assert_close(a, b, rtol=1e-7, atol=1e-8)
    torch.testing.assert_close(actual[0].sum(-1), torch.zeros(2, 3, dtype=dtype), rtol=0, atol=1e-8)
    changed = x.detach().clone()
    changed[1] += 7.
    torch.testing.assert_close(last_dim_norm(changed, gamma, beta, 1e-4)[0], y[0])
print("通过：普通/小方差/常量行、三组梯度、平移方向与批次独立性")

print("所有提供的测试通过。")
