# Diffusion：DDPM、目标参数化与 DDIM
# 环境：Python + PyTorch CPU
# 实现 ddpm_reverse_step(x, eps_hat, k, betas, noise)。采用后验方差 beta_tilde，\(k=0\) 返回均值且忽略 noise。x、eps_hat、noise 形状相同，k 是 Python 整数。

import torch

def ddpm_reverse_step(x, eps_hat, k, betas, noise):
    if not 0 <= k < len(betas) or not ((betas > 0) & (betas < 1)).all():
        raise ValueError('invalid step or schedule')
    alphas = 1-betas
    abar = torch.cumprod(alphas, dim=0)
    mean = (x-betas[k]/(1-abar[k]).sqrt()*eps_hat) / alphas[k].sqrt()
    if k == 0:
        return mean
    variance = betas[k]*(1-abar[k-1])/(1-abar[k])
    return mean + variance.sqrt()*noise


# ===== 断言测试 =====
betas = torch.tensor([0.1,0.2])
x = torch.tensor([[1.,2.]])
eps = torch.zeros_like(x)
one = torch.ones_like(x)
a = ddpm_reverse_step(x,eps,0,betas,one)
b = ddpm_reverse_step(x,eps,0,betas,-one)
torch.testing.assert_close(a,b)
torch.testing.assert_close(a,x/torch.tensor(0.9).sqrt())
c = ddpm_reverse_step(x,eps,1,betas,one)
expected = x/torch.tensor(0.8).sqrt() + torch.tensor(0.2*0.1/0.28).sqrt()
torch.testing.assert_close(c,expected)

# 非零 eps_hat：最后一步应精确反演已知的单步加噪
clean = torch.tensor([[0.4, -0.6]])
known_eps = torch.tensor([[0.7, -1.2]])
alpha0 = 1 - betas[0]
noisy0 = alpha0.sqrt() * clean + (1 - alpha0).sqrt() * known_eps
recovered = ddpm_reverse_step(noisy0, known_eps, 0, betas, one)
torch.testing.assert_close(recovered, clean, atol=1e-6, rtol=1e-5)
# k=1 也必须使用噪声预测，系数中的累计 alpha 是 0.9*0.8=0.72
nonzero_eps = torch.tensor([[0.5, -0.25]])
expected_nonzero = (x - (0.2 / (0.28 ** 0.5)) * nonzero_eps) / (0.8 ** 0.5)
expected_nonzero = expected_nonzero + (0.2 * 0.1 / 0.28) ** 0.5 * one
actual_nonzero = ddpm_reverse_step(x, nonzero_eps, 1, betas, one)
torch.testing.assert_close(actual_nonzero, expected_nonzero, atol=1e-6, rtol=1e-5)

print('DDPM 后验方差和最后一步检查通过。')

print("所有提供的测试通过。")
