# Embedding 与位置编码
# 环境：Python + PyTorch CPU
# 补全 rope_pairs(x, positions)。x 为 [B,T,D] 且 D 为偶数，positions 为长度 T 的向量，使用相邻通道配对。

import torch

def rope_pairs(x, positions, base=10000.0):
    dim = x.shape[-1]
    if dim % 2:
        raise ValueError("D 必须为偶数")
    freq = base ** (-torch.arange(0, dim, 2, device=x.device, dtype=x.dtype) / dim)
    angle = positions.to(x)[:, None] * freq[None, :]
    c, s = angle.cos()[None], angle.sin()[None]
    a, b = x[..., 0::2], x[..., 1::2]
    return torch.stack((a*c-b*s, a*s+b*c), dim=-1).flatten(-2)


# ===== 断言测试 =====
torch.manual_seed(15)
x = torch.randn(2, 4, 8, dtype=torch.float64, requires_grad=True)
pos = torch.arange(4)
y = rope_pairs(x, pos)
torch.testing.assert_close(y[:, 0], x[:, 0])
torch.testing.assert_close(y.square().sum(-1), x.square().sum(-1))
y.square().sum().backward()
torch.testing.assert_close(x.grad, 2*x.detach())
print("通过：零位置、范数、批量形状与反向传播")

print("所有提供的测试通过。")
