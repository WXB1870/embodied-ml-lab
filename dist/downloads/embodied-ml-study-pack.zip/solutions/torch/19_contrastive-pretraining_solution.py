# 图文预训练：CLIP 与 SigLIP
# 环境：Python + PyTorch CPU
# 实现 clip_pair_loss(image_raw,text_raw,logit_scale)。沿最后一维单位化，使用 `exp(logit_scale)` 缩放，并返回两个方向平均 CE。保持所有输入的梯度连接。

import torch
from torch.nn import functional as F

def clip_pair_loss(image_raw, text_raw, logit_scale):
    image = F.normalize(image_raw, dim=-1)
    text = F.normalize(text_raw, dim=-1)
    scores = logit_scale.exp() * (image @ text.transpose(-1, -2))
    labels = torch.arange(scores.shape[0], device=scores.device)
    return (F.cross_entropy(scores, labels)
            + F.cross_entropy(scores.T, labels)) / 2


# ===== 断言测试 =====
torch.manual_seed(36)
a = torch.randn(3, 5, requires_grad=True)
b = (a.detach()+0.02*torch.randn(3, 5)).requires_grad_()
scale = torch.tensor(1.0, requires_grad=True)
loss = clip_pair_loss(a, b, scale)
torch.testing.assert_close(loss, clip_pair_loss(7*a, 2*b, scale))
order = torch.tensor([2, 0, 1])
torch.testing.assert_close(loss, clip_pair_loss(a[order], b[order], scale))
assert clip_pair_loss(a, b.roll(1,0), scale) > loss
loss.backward()
assert all(x.grad is not None and torch.isfinite(x.grad).all() for x in (a,b,scale))
# 非对称配对：两个检索方向的 CE 确实不同。
a_fixed = torch.tensor([[1., 0.], [0., 1.]])
b_fixed = torch.tensor([[1., 0.], [1., 1.]])
fixed_scale = torch.tensor(1.)
scores = fixed_scale.exp() * (F.normalize(a_fixed, dim=-1) @ F.normalize(b_fixed, dim=-1).T)
labels = torch.arange(2)
expected = (F.cross_entropy(scores, labels) + F.cross_entropy(scores.T, labels)) / 2
torch.testing.assert_close(clip_pair_loss(a_fixed, b_fixed, fixed_scale), expected)
assert not torch.isclose(expected, F.cross_entropy(scores, labels))
print("通过：单位化、配对顺序、非对称双向目标和梯度")

print("所有提供的测试通过。")
