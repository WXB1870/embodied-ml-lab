# 闭环评估与统计
# 环境：Python + PyTorch CPU
# 实现 macro_micro_success(scores, valid)。输入为 [任务数, 最大试验数]。valid 标记真实试验，每个任务至少一条，真实结果只能是 0/1。返回 macro 与 micro 两个标量。

import torch

def macro_micro_success(scores, valid):
    if scores.ndim != 2 or scores.shape != valid.shape or valid.dtype != torch.bool:
        raise ValueError('invalid scores or mask')
    values = scores[valid]
    if not ((values == 0) | (values == 1)).all():
        raise ValueError('outcomes must be binary')
    counts = valid.sum(dim=1)
    if (counts == 0).any():
        raise ValueError('every task needs an evaluation')
    successes = torch.where(valid,scores,torch.zeros_like(scores)).sum(dim=1)
    return (successes/counts).mean(), successes.sum()/counts.sum()


# ===== 断言测试 =====
s = torch.tensor([[1.,1.,float('nan'),float('nan')],[0.,0.,0.,0.]])
v = torch.tensor([[True,True,False,False],[True,True,True,True]])
macro,micro = macro_micro_success(s,v)
torch.testing.assert_close(macro,torch.tensor(0.5))
torch.testing.assert_close(micro,torch.tensor(1/3))
assert torch.isfinite(macro) and torch.isfinite(micro)
print('Macro=0.5，Micro=1/3；不同分母回答不同问题。')

print("所有提供的测试通过。")
