# Score、SDE 与概率流 ODE
# 环境：Python + PyTorch CPU
# 实现 `gaussian_path_quantities(noisy,eps_hat,alpha,sigma,alpha_dot,sigma_dot)`。`noisy` 和 `eps_hat` 为 \([B,D]\)，四个系数均为 \([B]\) 且采用同一个时间变量；仅处理 \(\alpha>0\)、\(\sigma>0\) 的内部时间区间。返回干净样本估计、score 估计和速度估计，保留梯度并正确广播；拒绝错误形状、非有限值和奇异端点。

import torch

def gaussian_path_quantities(noisy, eps_hat, alpha, sigma, alpha_dot, sigma_dot):
    if (not torch.is_tensor(noisy) or noisy.ndim != 2 or noisy.numel() == 0
            or not noisy.is_floating_point() or not torch.is_tensor(eps_hat)
            or eps_hat.shape != noisy.shape):
        raise ValueError("noisy and eps_hat must be nonempty [B,D] tensors")
    values = (eps_hat, alpha, sigma, alpha_dot, sigma_dot)
    if any(not torch.is_tensor(v) or v.dtype != noisy.dtype or v.device != noisy.device
           for v in values):
        raise ValueError("dtype and device must match")
    if any(v.shape != (noisy.shape[0],) for v in (alpha,sigma,alpha_dot,sigma_dot)):
        raise ValueError("path coefficients must have shape [B]")
    if not all(torch.isfinite(v).all() for v in (noisy,*values)):
        raise ValueError("inputs must be finite")
    if (alpha <= 0).any() or (sigma <= 0).any():
        raise ValueError("this conversion is restricted to alpha>0, sigma>0")
    a, s, ad, sd = (v[:,None] for v in (alpha,sigma,alpha_dot,sigma_dot))
    clean_hat = (noisy - s * eps_hat) / a
    score_hat = -eps_hat / s
    velocity_hat = ad * clean_hat + sd * eps_hat
    return clean_hat, score_hat, velocity_hat


# ===== 断言测试 =====
import torch
torch.manual_seed(37)
torch.set_default_dtype(torch.float64)
B, D = 3, 2
clean, noise = torch.randn(B,D), torch.randn(B,D)
t = torch.tensor([0.2,0.4,0.7])
alpha, sigma = t, 1-t
alpha_dot, sigma_dot = torch.ones_like(t), -torch.ones_like(t)
noisy = alpha[:,None]*clean + sigma[:,None]*noise
a_hat,s_hat,v_hat = gaussian_path_quantities(noisy,noise,alpha,sigma,alpha_dot,sigma_dot)
torch.testing.assert_close(a_hat,clean)
torch.testing.assert_close(s_hat,-noise/sigma[:,None])
torch.testing.assert_close(v_hat,clean-noise)
noisy = noisy.requires_grad_()
estimate = (noise + 0.15*torch.randn_like(noise)).requires_grad_()
assert torch.autograd.gradcheck(
    lambda x,e: gaussian_path_quantities(x,e,alpha,sigma,alpha_dot,sigma_dot),
    (noisy,estimate))
_,score_hat,_ = gaussian_path_quantities(noisy,estimate,alpha,sigma,alpha_dot,sigma_dot)
noise_loss = (estimate-noise).square().sum()
weighted_score_loss = (sigma[:,None].square()*(score_hat+noise/sigma[:,None]).square()).sum()
torch.testing.assert_close(noise_loss,weighted_score_loss)
g1 = torch.autograd.grad(noise_loss,estimate,retain_graph=True)[0]
g2 = torch.autograd.grad(weighted_score_loss,estimate)[0]
torch.testing.assert_close(g1,g2)
try:
    gaussian_path_quantities(noisy,estimate,alpha,torch.zeros_like(sigma),alpha_dot,sigma_dot)
    raise AssertionError("singular endpoint accepted")
except ValueError:
    pass
print("passed: non-square dimensions, parameter conversion, loss weights and gradients")

try:
    gaussian_path_quantities(noisy,[[0.0]],alpha,sigma,alpha_dot,sigma_dot)
    raise AssertionError("non-tensor estimate accepted")
except ValueError:
    pass

print("所有提供的测试通过。")
