# 泛化与验证
# 环境：Python + PyTorch CPU
# 实现评估函数：临时切换 eval 与 no_grad，累积全部输出元素的平方误差/元素数，返回 Python float，并恢复调用前的模型整体 training 状态。空 loader 抛出 ValueError。

import torch

def evaluate_mse(model, loader):
    was_training = model.training
    model.eval()
    total, count = 0., 0
    try:
        with torch.no_grad():
            for x, y in loader:
                error = model(x) - y
                total += error.square().sum().item()
                count += error.numel()
        if count == 0:
            raise ValueError("评估数据为空")
        return total / count
    finally:
        model.train(was_training)


# ===== 断言测试 =====
from torch import nn
class Probe(nn.Module):
    def __init__(self):
        super().__init__()
        self.drop = nn.Dropout(0.9)
        self.flags = []
    def forward(self, x):
        self.flags.append((self.training, torch.is_grad_enabled()))
        return self.drop(x)
model = Probe().train()
loader = [(torch.tensor([[1.], [2.]]), torch.zeros(2, 1)),
          (torch.tensor([[3.]]), torch.zeros(1, 1))]
score = evaluate_mse(model, loader)
assert isinstance(score, float) and abs(score - 14/3) < 1e-12
assert model.training and model.flags == [(False, False), (False, False)]
model.eval()
_ = evaluate_mse(model, loader)
assert not model.training
try:
    evaluate_mse(model, [])
except ValueError:
    pass
else:
    raise AssertionError("应拒绝空评估集")
assert not model.training
print("PyTorch 测试通过：指标加权、无梯度评估与模式恢复。")

print("所有提供的测试通过。")
