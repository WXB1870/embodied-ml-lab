# 注意力：匹配、聚合与梯度
# 环境：Python + PyTorch CPU
# 实现 attend(q,k,v,allowed)。q 为 [B,H,Tq,d]，k 为 [B,H,Tk,d]，v 为 [B,H,Tk,dv]；查询长度 Tq、键长度 Tk 与值维度 dv 可以不同。allowed 为布尔 Mask，可以广播到 [B,H,Tq,Tk]，True=允许。返回 [B,H,Tq,dv]。不使用 SDPA；拒绝全屏蔽行。

import math
import torch

def attend(q, k, v, allowed):
    if not bool(allowed.any(dim=-1).all()):
        raise ValueError("每个查询至少需要一个有效键")
    scores = q @ k.transpose(-1, -2)
    scores = scores / math.sqrt(q.shape[-1])
    weights = scores.masked_fill(~allowed, float("-inf")).softmax(-1)
    return weights @ v


# ===== 断言测试 =====
torch.manual_seed(13)
q = torch.randn(2, 2, 3, 4, requires_grad=True)
k, v = torch.randn(2, 2, 5, 4), torch.randn(2, 2, 5, 6)
allowed = torch.ones(3, 5, dtype=torch.bool)
allowed[:, -1] = False
out = attend(q, k, v, allowed)
ref = torch.nn.functional.scaled_dot_product_attention(
    q, k, v, attn_mask=allowed, dropout_p=0.0)
torch.testing.assert_close(out, ref, atol=1e-6, rtol=1e-5)
out.square().mean().backward()
assert q.grad is not None and torch.isfinite(q.grad).all()
print("通过：跨序列长度、值维度、Mask 与梯度")

print("所有提供的测试通过。")
