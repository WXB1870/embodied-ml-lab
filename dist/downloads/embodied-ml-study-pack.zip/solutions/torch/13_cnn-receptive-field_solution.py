# CNN：卷积、采样与空间表示
# 环境：Python + PyTorch CPU
# 使用 F.unfold 实现 unfold_conv2d，与普通 groups=1、dilation=1 的 F.conv2d 对齐。支持非方形核、整数 stride/padding 和可选 bias。不得直接调用 conv2d。

import torch
from torch.nn import functional as F

def unfold_conv2d(x, weight, bias=None, stride=1, padding=0):
    batch, channels, height, width = x.shape
    out_channels, weight_channels, kh, kw = weight.shape
    if channels != weight_channels:
        raise ValueError("输入通道数不一致")
    patches = F.unfold(x, (kh, kw), padding=padding, stride=stride)
    flat_weight = weight.reshape(out_channels, -1)
    output = torch.einsum("oc,bcl->bol", flat_weight, patches)
    if bias is not None:
        output = output + bias[None, :, None]
    oh = (height + 2*padding - kh)//stride + 1
    ow = (width + 2*padding - kw)//stride + 1
    return output.reshape(batch, out_channels, oh, ow)


# ===== 断言测试 =====
torch.manual_seed(35)
x = torch.randn(2, 2, 6, 7, requires_grad=True)
weight, bias = torch.randn(3, 2, 2, 3), torch.randn(3)
actual = unfold_conv2d(x, weight, bias, stride=2, padding=1)
expected = F.conv2d(x, weight, bias, stride=2, padding=1)
torch.testing.assert_close(actual, expected, atol=1e-6, rtol=1e-5)
torch.testing.assert_close(unfold_conv2d(x, weight), F.conv2d(x, weight))
actual.square().mean().backward()
assert x.grad is not None and torch.isfinite(x.grad).all()
print("通过：多通道、非方形核、偏置、步长与梯度")

print("所有提供的测试通过。")
