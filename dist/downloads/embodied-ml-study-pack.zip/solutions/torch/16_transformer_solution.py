# Transformer：注意力、残差与序列建模
# 环境：Python + PyTorch CPU
# 补全 PracticeBlock.forward。使用 Pre-Norm 与两次残差；blocked 是 MultiheadAttention 的禁止矩阵。不要在 forward 中临时创建新层。

import torch
from torch import nn

class PracticeBlock(nn.Module):
    def __init__(self, dim=8):
        super().__init__()
        self.n1, self.n2 = nn.LayerNorm(dim), nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, 2, dropout=0, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(dim, 16), nn.GELU(), nn.Linear(16, dim))

    def forward(self, x, blocked):
        z = self.n1(x)
        update, _ = self.attn(z, z, z, attn_mask=blocked, need_weights=False)
        h = x + update
        return h + self.ffn(self.n2(h))


# ===== 断言测试 =====
torch.manual_seed(14)
model = PracticeBlock()
x = torch.randn(2, 4, 8)
mask = torch.ones(4, 4, dtype=torch.bool).triu(1)
a = model(x, mask)
changed = x.clone()
changed[:, -1, 0] += 4
b = model(changed, mask)
torch.testing.assert_close(a[:, :-1], b[:, :-1])
assert a.shape == x.shape
a.square().mean().backward()
assert all(p.grad is not None for p in model.parameters())
print("通过：形状、因果隔离、所有模块的梯度连接")

print("所有提供的测试通过。")
