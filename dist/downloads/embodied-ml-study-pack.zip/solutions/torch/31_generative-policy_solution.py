# 生成式动作策略：ACT、Diffusion 与 Flow
# 环境：Python + PyTorch CPU
# 实现 `training_pair(actions, noise, time, family)` 与 `masked_policy_mse(pred, target, valid)`。actions/noise 为相同形状的有限浮点 \([B,H,D]\)，time 为 \([B]\) 且在 [0,1]；family 为 flow 或 diffusion。Flow 使用噪声→数据直线，Diffusion 使用 \(\alpha=\cos(\pi\tau/2)\)、\(\sigma=\sin(\pi\tau/2)\) 并预测噪声。Loss 的 valid 为布尔 \([B,H,D]\)，先选有效位再计算 MSE；空监督、非有限有效值和非法形状应报错。

import math
import torch

def training_pair(actions, noise, time, family):
    if (actions.ndim != 3 or actions.shape != noise.shape
            or time.shape != actions.shape[:1]):
        raise ValueError('shape mismatch')
    if not all(bool(torch.isfinite(x).all()) for x in (actions, noise, time)):
        raise ValueError('nonfinite training input')
    if bool(((time < 0) | (time > 1)).any()):
        raise ValueError('time outside [0,1]')
    t = time[:, None, None]
    if family == 'flow':
        return (1-t)*noise+t*actions, actions-noise
    if family == 'diffusion':
        return (math.pi*t/2).cos()*actions+(math.pi*t/2).sin()*noise, noise
    raise ValueError('unknown family')

def masked_policy_mse(pred, target, valid):
    if (pred.ndim != 3 or pred.shape != target.shape
            or valid.shape != pred.shape or valid.dtype != torch.bool):
        raise ValueError('shape or mask type mismatch')
    if not bool(valid.any()):
        raise ValueError('no supervised coordinates')
    p, y = pred[valid], target[valid]
    if not bool(torch.isfinite(p).all() & torch.isfinite(y).all()):
        raise ValueError('nonfinite supervised coordinate')
    return (p-y).square().mean()


# ===== 断言测试 =====
torch.manual_seed(59)
a = torch.randn(2,3,2,dtype=torch.float64)
z = torch.randn_like(a)
t = torch.tensor([0.,1.],dtype=torch.float64)
xf, uf = training_pair(a,z,t,'flow')
xd, eps = training_pair(a,z,t,'diffusion')
torch.testing.assert_close(xf[0],z[0])
torch.testing.assert_close(xf[1],a[1])
torch.testing.assert_close(xd[0],a[0])
torch.testing.assert_close(xd[1],z[1])
torch.testing.assert_close(uf,a-z)
torch.testing.assert_close(eps,z)
# Interior scalar example: a=2,z=-2,t=1/4 gives flow x=-1,target=4.
one = torch.tensor([[[2.]]],dtype=torch.float64)
state, target = training_pair(one,-one,torch.tensor([.25]),'flow')
torch.testing.assert_close(state,-one/2)
torch.testing.assert_close(target,2*one)
p = torch.tensor([[[1.,3.],[float('nan'),float('nan')]]],requires_grad=True)
y = torch.tensor([[[0.,1.],[float('nan'),float('nan')]]])
valid = torch.tensor([[[True,True],[False,False]]])
loss = masked_policy_mse(p,y,valid)
torch.testing.assert_close(loss,torch.tensor((1.**2+2.**2)/2))
loss.backward()
torch.testing.assert_close(p.grad,torch.tensor([[[1.,2.],[0.,0.]]]))
bad_calls = [lambda: training_pair(a,z,torch.tensor([-1.,.5]),'flow'),
             lambda: training_pair(a,z,t,'unknown'),
             lambda: training_pair(a,z,t[:,None],'flow'),
             lambda: masked_policy_mse(p,y,torch.zeros_like(valid)),
             lambda: masked_policy_mse(p,torch.full_like(y,float('nan')),valid),
             lambda: masked_policy_mse(p,y,valid.float())]
for fn in bad_calls:
    try:
        fn()
        raise AssertionError('invalid input must be rejected')
    except ValueError:
        pass
print('passed: endpoint direction, interior target, analytic gradient and invalid supervision')

print("所有提供的测试通过。")
