# 动作执行与延迟
# 环境：Python 标准库
# 实现 `choose_action(plans,now,dt,max_age,epoch)`。每块含 obs、ready、start、epoch、values；仅选择已完成、未过期、版本一致且覆盖当前槽位的块，优先来源 obs 最新者。返回 (value,index,obs)，无候选返回 None。 所有时间戳使用同一时钟，dt>0，max_age>=0；非法 dt/max_age 抛 ValueError。obs 是观测时刻，ready 是计算完成时刻，start 是 values[0] 的执行起点，相邻动作间隔 dt。用 floor((now-start)/dt) 计算槽位；未来观测和未来起点不可用，年龄恰好为 max_age 仍有效。相同 obs 的候选取输入中最先出现者。

import math

def choose_action(plans,now,dt,max_age,epoch):
    # TODO: 检查时间与版本，按当前槽位选择
    raise NotImplementedError


# ===== 断言测试 =====
p=[{'obs':0.,'ready':0.15,'start':0.,'epoch':0,'values':[0.,1.,2.,3.]}]
assert choose_action(p,0.21,0.1,0.3,0)==(2.,2,0.)
assert choose_action(p,0.11,0.1,0.3,0) is None
assert choose_action(p,0.41,0.1,0.3,0) is None
assert choose_action(p,0.21,0.1,0.3,1) is None
p.append({'obs':0.2,'ready':0.25,'start':0.2,'epoch':0,'values':[10.,11.,12.]})
assert choose_action(p,0.31,0.1,0.4,0)==(11.,1,0.2)

base = {'obs': 0., 'ready': 1., 'start': 0., 'epoch': 0, 'values': [10.,20.,30.]}
assert choose_action([base], 1., 1., 1., 0) == (20.,1,0.), 'ready 和年龄的等号边界应有效'
assert choose_action([base], 3., 1., 4., 0) is None, '不能越过动作块末尾'
assert choose_action([dict(base, obs=2.)], 1., 1., 3., 0) is None, '不能使用未来观测'
assert choose_action([dict(base, start=2.)], 1., 1., 3., 0) is None, '不能提前执行尚未开始的块'
newer = dict(base, obs=0.5, ready=0.8, values=[40.,50.,60.])
assert choose_action([base, newer], 1., 1., 2., 0) == (50.,1,0.5), '按观测来源排序，而非 ready'
for dt, age in [(0.,1.),(-1.,1.),(1.,-1.)]:
    try:
        choose_action([], 1., dt, age, 0)
    except ValueError:
        pass
    else:
        raise AssertionError('非法时间配置必须拒绝')
print('准备状态、过期、指令版本和动作槽位检查通过。')

print("所有提供的测试通过。")
