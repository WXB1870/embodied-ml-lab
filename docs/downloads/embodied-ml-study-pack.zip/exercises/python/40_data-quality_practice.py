# 示教数据与采样
# 环境：Python 标准库
# 实现 sample_weights(tasks, desired)。tasks 是记录的任务标签列表，desired 是总和为 1 的非负目标概率。返回每条记录的权重；缺失但有正目标概率的任务、未知标签或空数据要报错。 每条记录的权重为 desired[任务]/该任务记录数，所以同一任务的权重总和等于目标概率，全部权重总和为 1。目标概率为零的任务可以没有记录。

import math
from collections import Counter

def sample_weights(tasks, desired):
    # TODO: 每条记录应获得其任务概率除以该任务样本数
    raise NotImplementedError


# ===== 断言测试 =====
tasks = ['reach','reach','reach','grasp']
w = sample_weights(tasks,{'reach':0.5,'grasp':0.5})
assert abs(sum(w[:3])-0.5) < 1e-12
assert abs(w[3]-0.5) < 1e-12
assert abs(sum(w)-1.0) < 1e-12
assert sample_weights(['a','a'],{'a':1.0}) == [0.5,0.5]
try:
    sample_weights(['reach'],{'reach':0.5,'grasp':0.5})
    raise AssertionError('缺失目标任务应报错')
except ValueError:
    pass

assert sample_weights(['a'], {'a': 1., 'b': 0.}) == [1.]
assert sample_weights(['a','b'], {'a': 1., 'b': 0.}) == [1., 0.]
for tasks, desired in [([], {'a': 1.}), (['x'], {'a': 1.}), (['a'], {'a': 0.5}), (['a'], {'a': -1., 'b': 2.}), (['a'], {'a': float('nan')})]:
    try:
        sample_weights(tasks, desired)
    except ValueError:
        pass
    else:
        raise AssertionError('必须拒绝空数据、未知任务或非法概率分布')
print('逐样本权重与任务总概率检查通过。')

print("所有提供的测试通过。")
