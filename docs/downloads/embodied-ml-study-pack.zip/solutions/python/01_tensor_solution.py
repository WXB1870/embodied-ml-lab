# 张量与广播
# 环境：Python 标准库
# rows 是 [T, D] 的列表，valid 标记哪些时刻有效。只平均有效行；若没有有效行，抛出 ValueError。不要把 Padding 的数值平均进去。 输入保证为等宽、非空行，valid 是长度 T 的布尔列表；无效行可含 NaN。返回长度 D 的平均值列表。例如 [[1,2],[3,4],[999,999]] 配合 [True,True,False]，应得到 [2,3]。

def masked_mean(rows, valid):
    chosen = [row for row, keep in zip(rows, valid) if keep]
    if not chosen:
        raise ValueError("没有有效时刻")
    width = len(chosen[0])
    return [sum(row[d] for row in chosen) / len(chosen) for d in range(width)]


# ===== 断言测试 =====
assert masked_mean([[1, 2], [3, 4], [999, 999]], [True, True, False]) == [2, 3]
assert masked_mean([[2, 4, 6]], [True]) == [2, 4, 6]
assert masked_mean([[float('nan'), float('nan')], [4, 8]], [False, True]) == [4, 8], "必须先排除无效行，不能用 NaN 乘零"
rows = [[1, 2], [5, 8]]
assert masked_mean(rows, [True, True]) == [3, 5], "按特征维平均"
assert rows == [[1, 2], [5, 8]], "不能修改输入"
try:
    masked_mean([[1, 2]], [False])
except ValueError:
    pass
else:
    raise AssertionError("全无效输入必须显式处理")
print("通过：有效时刻平均、Padding 排除、空有效集处理。")

print("所有提供的测试通过。")
