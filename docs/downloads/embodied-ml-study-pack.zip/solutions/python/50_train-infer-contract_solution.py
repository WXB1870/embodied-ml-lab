# 训练与推理一致性
# 环境：Python 标准库
# 实现 `contract_errors(saved,runtime,train_groups,eval_groups)`。按起始代码 REQUIRED 的顺序检查 action_order、unit、action_mode、normalizer_id、prediction_type、control_dt、causal_history；缺失报 `missing:key`，不同报 `mismatch:key`。两边 `causal_history` 都应为 True，否则报 `noncausal_history`；组交叉时报 `group_overlap`。返回错误字符串列表。 缺失检查优先于同字段的值比较；两边都缺失仍报告一次 missing。先返回字段错误，再依次追加 noncausal_history 和 group_overlap；无错误返回 []。

REQUIRED=('action_order','unit','action_mode','normalizer_id','prediction_type','control_dt','causal_history')

def contract_errors(saved,runtime,train_groups,eval_groups):
    errors=[]
    for key in REQUIRED:
        if key not in saved or key not in runtime:
            errors.append('missing:'+key)
        elif saved[key]!=runtime[key]:
            errors.append('mismatch:'+key)
    if saved.get('causal_history') is not True or runtime.get('causal_history') is not True:
        errors.append('noncausal_history')
    if set(train_groups)&set(eval_groups):
        errors.append('group_overlap')
    return errors


# ===== 断言测试 =====
s={'action_order':['x','y'],'unit':'m','action_mode':'delta','normalizer_id':'abc','prediction_type':'epsilon','control_dt':0.1,'causal_history':True}
assert contract_errors(s,dict(s),['a'],['b'])==[]
r=dict(s,unit='cm',prediction_type='sample')
e=contract_errors(s,r,['a'],['a'])
assert set(e)=={'mismatch:unit','mismatch:prediction_type','group_overlap'}
r=dict(s); del r['normalizer_id']
assert 'missing:normalizer_id' in contract_errors(s,r,[],[])
r=dict(s,causal_history=False)
assert 'noncausal_history' in contract_errors(s,r,[],[])

assert contract_errors({}, {}, [], []) == ['missing:'+key for key in REQUIRED] + ['noncausal_history']
r = dict(s, causal_history=False)
assert contract_errors(s,r,['a'],['a']) == ['mismatch:causal_history','noncausal_history','group_overlap']
print('单位、参数化、缺失配置、因果声明与组泄漏检查通过。')

print("所有提供的测试通过。")
