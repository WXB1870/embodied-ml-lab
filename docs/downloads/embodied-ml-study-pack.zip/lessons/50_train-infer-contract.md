# 训练与推理一致性

用可复现输入追踪预处理、模型、采样与动作还原。

训练—推理一致性是指训练、验证与部署沿同一输入输出约定实现模型所学习的策略，包括预处理、条件编码、输出参数化、采样和动作解码。相同权重与形状只覆盖其中一部分。本章先把策略写成完整函数组合，再定义各接口的不变量，最后沿同一合成任务寻找训练和部署的首处分歧并检验恢复。

## 学习目标

- 把模型、预处理、动作表示和采样配置作为同一可复查版本
- 用已知输入检查 epsilon 解码、反归一化与动作维度的顺序
- 注入形状不变的配置错误，并检查数据组隔离和因果输入

前置知识：[保存与恢复训练状态](https://wxb1870.github.io/embodied-ml-lab/learn/checkpoint/) · [状态与动作表示](https://wxb1870.github.io/embodied-ml-lab/learn/action-representation/) · [Diffusion：DDPM、目标参数化与 DDIM](https://wxb1870.github.io/embodied-ml-lab/learn/diffusion/) · [Flow Matching](https://wxb1870.github.io/embodied-ml-lab/learn/flow-matching/) · [示教数据与采样](https://wxb1870.github.io/embodied-ml-lab/learn/data-quality/) · [闭环评估与统计](https://wxb1870.github.io/embodied-ml-lab/learn/evaluation/)

## 把策略写成一条完整的函数组合

策略函数组合是从原始观测到最终命令的一连串有序变换。每个阶段既改变数值，也可能改变单位和变量含义。先看整条输入输出链，再判断网络权重在其中负责哪一部分。





部署策略可理解为：原始传感信息经过预处理与条件编码，生成模型和采样器得到生成空间中的动作，再经反归一化、坐标/参考转换与执行规则变成命令。网络权重只决定其中一部分。相机顺序、图像范围、文本模板、动作顺序或时间日程任意改变，都可能让相同权重产生另一种行为。





训练也有对应组合：原始标签先转换为动作表示，再归一化、加噪或构造速度目标。推理必须恢复与训练目标匹配的变量，不能直接将网络最后一层输出作为驱动器命令。固定随机性后，完整映射才能成为可复查对象；只存一个 checkpoint 文件名不足以确定这一映射。





因此版本至少绑定基础模型与适配器、预处理配置、观测键、动作语义、统计量、采样器与执行频率。每个字段应能追到真实代码路径，而不是只存在于 README。配置完全相等说明声明一致，仍需确认加载代码确实使用了它们，没有隐式默认值或写死常数覆盖。





$$
a_{\rm cmd}=E\circ D\circ S_\theta\circ P(o,\ell,s;\varepsilon)
$$





### 把模型版本扩展到完整输入输出映射

预处理与动作解码改变后，相同权重不再代表相同策略。

保存影响语义的配置与内容身份，并在加载时检查真实运行值和缺失字段。

## 形状检查之外还需要语义检查

语义接口规定某个张量的每个位置、单位、来源与有效性含义，形状接口只规定它能否参与数组运算。两者共同定义输入输出。下面用保持 shape 的变化说明为何单看尺寸不够。





图像从 RGB 换成 BGR、像素从 [0,1] 变成 [0,255]、两台相机交换顺序，都可能保持 Tensor 尺寸完全不变。状态或动作的关节顺序改变也具有同样问题。dtype、shape 和 finite 检查是必要起点，但无法证明每个数值都对应正确的语义位置。





为每个观测键保留单位、来源、布局和时间含义，为每个动作维保留名称、坐标系、参考与控制模式。用具有辨别力的样例检查，例如为每个通道/关节填不同已知值，验证经过批处理和部署转换后仍对应同一身份。全零或各通道相同的测试输入会掩盖顺序错误。





内容哈希可以检查统计量或配置是否被更换，但需要使用规范化序列化方式，明确字段顺序与数值精度。哈希一致只证明内容相同，不证明内容最初正确；两个系统都使用厘米却把它声明成米，仍可能具有相同指纹。身份检查必须结合独立已知物理样本。









## 预处理与条件编码是第一处分歧点

训练预处理与部署预处理是对同一类原始信息生成模型条件的两条实现路径。它们应在声明容差和随机性约定下对应相同输入。先比较最早的模型边界，再判断后续差异来自哪里。





同一条原始记录分别通过训练预处理和部署预处理，应先比较进入模型前的图像、语言 token、状态、Mask 与位置/相机标识。图像裁剪、resize、归一化和文本特殊 token 的细微差异，都可能让后面的差异看起来像模型不稳定。先找到第一个不同的中间量，再检查最终动作。





对带随机增强的训练处理，不能直接要求与推理逐值相同；应区分训练时的数据增强策略与用于确定性验证的共同处理部分。评估对照时关闭不必要随机增强，并明确模型 eval 状态。只使用 `no_grad` 不会自动关闭 Dropout 或更改归一化层模式。





条件缓存也需要内容与依赖检查。固定图像不意味着所有前缀结果都可复用；如果前缀隐藏状态依赖生成时间、当前动作 token、模型权重或位置编号，变化后缓存应失效。测试可分别修改这些因素，对比缓存与重算输出，而不是仅以缓存张量形状匹配作为正确依据。









## 动作变换必须按相反顺序恢复

动作解码是训练标签编码过程的逆向恢复，将模型坐标还原为控制语义。复合变换通常要按相反顺序求逆，归一化值不能直接与物理状态混加。下面用相对动作与标准化的组合说明。





假设标签先从绝对动作 a 变成相对当前状态 q 的增量 \(d=a-q\)，再标准化 \(z=(d-\mu)/\sigma\)。推理应先得到 z，计算 \(d=\sigma z+\mu\)，再恢复 \(a=q+d\)。把 q 加到 z 上后再反归一化，会把物理状态与无单位标准化量混加，数值仍然有限，含义却已经改变。





固定锚点与逐步增量的恢复也不能互换；丢弃动作块前缀或使用新观测锚点，会影响原动作表示的解释。旋转参数化还可能要求投影到合法旋转、规范化或群组合。每一层都应注明输入和输出空间，再按真正逆变换连接，不要靠“看起来更平滑”的补偿修正错误。





往返测试是有用的局部检查，但编码与解码共享错误时也会通过。应同时使用独立已知样本，例如具有明确单位与关节身份的动作，并对训练、离线推理与在线解码分别比较。不可逆的裁剪或量化不能要求精确还原，需要声明误差范围与边界行为。





$$
d=a-q,\quad z=(d-\mu)/\sigma\quad\Longrightarrow\quad a=q+\sigma z+\mu
$$



### 例：反变换顺序影响最终位置

1. 当前位置 \(q=10\)，绝对目标 \(a=18\)，则增量 \(d=8\)。

2. 使用 \(\mu=2,\ \sigma=4\)，标准化 \(z=(8-2)/4=1.5\)。

3. 正确恢复为 \(10+4\times1.5+2=18\)；先算 \(z+q\) 再反归一化会得到 48。

每一步都标明数值空间，逆序恢复比仅检查最终维度更重要。

### 一份错误统计量也能通过往返测试

共同错误在正反变换中会抵消，不能证明物理含义正确。

加入独立物理样例和已知单位，故意交换统计量或关节顺序，确认检查能发现差异。

## 生成参数化、日程与 oracle 测试

生成协议定义网络输出的随机变量、时间日程及采样更新规则。Oracle 测试使用已知正确目标或生成场暂时代替网络，从而隔离协议计算。先固定这套定义，再解释相同形状为什么不能直接互换。





扩散 epsilon 输出表示噪声，干净样本预测表示动作空间中的估计，特定 v 参数化又有自己的转换；FM 输出是所选路径上的速度。它们可能具有完全相同形状，但采样方程不同。保存并检查 `prediction_type`、噪声日程、时间方向、边界系数和 solver，才能确定输出怎样成为动作。





使用已知干净动作和噪声构造中间状态，再用已知噪声作为 oracle 解码，能检验恢复公式、广播和反归一化。这个过程使用已知噪声代替网络预测，因此检验接口一致性，无法据此判断模型的去噪能力。对 FM 则可用常量场、指数场或解析高斯场检查积分方向与步长，再将学习网络接入。





推理减少采样步数可以是合法配置变化，但必须使用相容的算法与等级系数。固定模型、条件和全部随机噪声作对照，先验证数值误差，再评估生成质量与延迟。随机 DDPM 还包含中间噪声，固定初始种子之外应确认随机状态消费顺序；否则两次差异不一定来自代码改动。





```python
import hashlib
import json
import torch

torch.manual_seed(7)

# STEP 1: 统计量和变换模式也有内容身份
mean=torch.tensor([1.,-2.])
std=torch.tensor([0.5,2.])
def normalizer_id(mean,std):
    payload={'mode':'mean_std','mean':mean.tolist(),'std':std.tolist()}
    return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()

saved={'actions':('x','y'),'unit':'m','mode':'delta_base',
       'normalizer':normalizer_id(mean,std),'prediction':'epsilon','dt':0.1}
runtime=dict(saved)

# STEP 2: 对真正影响语义的字段逐项检查，不能仅比较维度
def check_contract(expected,actual):
    mismatches=[key for key in expected if key not in actual or actual[key]!=expected[key]]
    if mismatches:
        raise ValueError('contract mismatch: '+','.join(mismatches))

check_contract(saved,runtime)
broken=dict(runtime,unit='cm')
try:
    check_contract(saved,broken)
    raise AssertionError('单位错误未被发现')
except ValueError as error:
    print('detected:',error)

# STEP 3: 用已知噪声作测试夹具，核对 epsilon 到原始动作的恢复
raw_action=torch.tensor([[[1.1,-1.8]]])
clean=(raw_action-mean)/std
noise=torch.tensor([[[0.4,-0.2]]])
alpha_bar=torch.tensor(0.6)
noisy=alpha_bar.sqrt()*clean+(1-alpha_bar).sqrt()*noise
recovered_clean=(noisy-(1-alpha_bar).sqrt()*noise)/alpha_bar.sqrt()
recovered_action=recovered_clean*std+mean
torch.testing.assert_close(recovered_action,raw_action)
wrong_action=noise*std+mean  # 误把 epsilon 当干净动作；形状仍然正确
assert wrong_action.shape==raw_action.shape
assert not torch.allclose(wrong_action,raw_action)

# STEP 4: 配置与数据边界一起保存，且由真实代码检查支持
train_groups={'train-a','train-b'}
evaluation_groups={'heldout-c'}
assert train_groups.isdisjoint(evaluation_groups)
assert normalizer_id(mean,std)!=normalizer_id(mean,std*10)
print('round trip:',recovered_action.tolist())
print('same-shape wrong decoding:',wrong_action.tolist())
print('contract, normalization fingerprint and group-isolation checks passed')

```

这段单元级对照用已知噪声验证生成参数化和解码顺序，另对单位及统计量身份注入故障。下方综合实验进一步执行真实训练、序列窗口、保存恢复和闭环预测。



### 例：已知噪声验证 epsilon 解码

1. 设 \(\bar\alpha=0.64\)、标准化干净动作 \(z=2\)、噪声 \(\epsilon=-1\)，中间值 \(x=1\)。

2. 将 oracle \(\epsilon\) 代入 \(\frac{x-\sqrt{1-\bar\alpha}\,\epsilon}{\sqrt{\bar\alpha}}\)，可恢复 \(z=2\)，再按保存统计量解码。

3. 故意把 \(\epsilon\) 直接当 z，形状仍然正确，却会得到另一个原始动作。

oracle 检查证明变换链自洽；网络是否能给出可靠估计仍需真实预测测试。

## 数据组隔离与因果性也属于版本

实验版本还应记录训练和评估的组身份、统计量来源、输入截止规则与选模过程。这些对象共同规定可用信息和结论范围。数据文件不重名并不足以证明两套实验条件独立。





训练和评估的组身份、统计量拟合来源、选模记录与输入截止时刻，应与实验版本一起保存。训练集与测试集文件名不重合，仅能排除最直接的重复，不能排除同一轨迹的重导出、同一对象/会话共享或反复查看测试失败后的反馈。边界应按要测的泛化轴定义。





`causal_history=True` 是一个声明，实际索引可能仍读取未来图像，预处理也可能使用双向插值。应固定过去，修改未来观测、动作或结局，验证当前输入和输出不变；另外检查多传感器记录在决策时是否已经到达。只有声明与干预都一致，才能支撑因果输入这一解释。





恢复 checkpoint 时也要区分继续训练与只做推理。继续训练需要优化器、调度器、随机状态和数据位置等信息；推理主要需要确定完整前向映射。恢复某一个固定样例输出一致是必要检查，但不能证明训练随机序列或后续参数更新完全一致，应按所声称的恢复范围验证。









### 字段相等就认为契约完整

两边都缺失字段可能在 get 比较时得到相同 None，两边都声称因果也可能共同实现错误。

先检查必需字段存在，再比较内容；对组隔离、因果性和实际变换增加行为测试。

## 按首处分歧定位静默故障

首处分歧检查是在固定输入、参数与随机性后，沿两条实现依次比较中间结果，寻找最早偏离的边界。它将最终动作差异拆回具体变换，而不是在末端用经验系数补偿未知原因。





先冻结模型版本、模型模式、原始输入与随机性，分别保存训练验证路径和部署路径的关键中间量：模型输入、条件表示、原始预测、采样终态、反归一化动作与实际接纳命令。逐层对比，找到第一个分歧点；不要直接在最后动作上乘一个经验系数来掩盖前面的错误。





故障注入应覆盖单位变化、动作/相机顺序交换、统计量替换、错误参数化、未来输入泄漏与旧任务结果混入。一个有价值的检查不仅让正常样例通过，还要能拒绝对应的错误版本。对允许的硬件或精度差异设置有依据的容差，避免用过宽容差使真正接口错误也通过。





最后将局部证据与闭环评价连接：配置身份正确、变换往返正确、真实模型输出合理、执行时间与控制语义正确，分别回答不同问题。合成代码只能覆盖其中声明的最小计算。完整策略的有效性仍来自目标条件下的独立闭环试验，而不是“所有 JSON 字段一致”或“loss 看起来正常”。









## 综合实验：从 Episode 切分到新进程恢复与闭环执行

局部算子测试证明的是某一步计算，而完整交付还要求这些步骤在独立进程中正确衔接。下面使用可实现的合成策略贯通数据切分、训练、保存和闭环执行，使每一项观察都有明确的变量和验证范围。





完整代码使用二维合成状态 s 和目标 g，专家动作定义为 \(a=0.25(g-s)\)，环境按 \(s_{\mathrm{next}}=s+a\) 更新。模型观察上一状态、当前状态和目标共六个数，预测 \(H=3\) 个二维增量。专家是观测的线性函数，因此选择线性策略来隔离数据与训练流程，避免将模型表达能力不足混入协议检验。这个系统没有图像、接触或真实动力学，不能据此报告机器人任务成功率。





首先按完整 Episode 将 60 个回合固定分为 40/10/10，再在各自回合内部构建历史和未来动作窗口。最后不足 H 个动作的槽位填 NaN，并提供独立有效位。输入统计只由训练输入估计；动作统计只使用训练窗口中的有效帧。窗口采样会使一条原始动作被多个窗口重复使用，因此这里拟合的是训练窗口所定义的经验分布；若需要每条原始动作等权，应先在未窗口化记录上估计。





网络预测归一化动作，损失仅在有效坐标上归约。Adam 执行固定 600 次更新，验证集只用于观察这个预先指定实验的误差，没有用测试集选择学习率或步数。代码中的小误差阈值是针对可实现的线性教学问题的回归测试，不是所有训练任务必须达到的门槛。线上推理沿相反方向执行：归一化观测、网络前向、动作反归一化、按已声明单位和增量语义执行。





保存包包含模型权重、统计量、观测顺序、动作含义、时间步长和数据划分身份。代码真正启动一个新 Python 进程读取保存文件，使用相同原始观测核验输出，而不是只在同一进程复制 `state_dict`。随后每次预测三步、只执行第一步并重新观测，计算留出回合上的终点距离。另将单位字段改为不兼容值，要求加载器在相同 Tensor 形状下仍拒绝错误配置。





固定种子的一次 CPU 执行中，归一化训练损失由约 1.131 降至 0.000430，验证动作 MSE 约 3.26×10⁻⁶，留出测试动作 MSE 约 2.17×10⁻⁶，24 次闭环更新后的平均终点距离约 0.00265。数值是本节构造系统的实际观测，可能随库和硬件轻微变化。离线动作误差、归一化训练损失和物理状态终点距离具有不同单位与统计对象，应分别解释。





训练与推理一致性要对整条函数链负责：相同的原始信息应经过匹配的编码、模型计算、采样和动作恢复。保存这套约定，并从首个分歧定位问题，才能把权重文件变成可解释、可复查的策略计算。







### 实验阶段与可排除的问题

| 阶段 | 实际检查 | 仍不能推出 |

|---|---|---|

| Episode 切分与窗口 | 组隔离、末尾有效位、训练统计量 | 真实采集数据没有遗漏或语义错误 |

| 训练与留出预测 | 损失有限、参数发生更新、简单目标可拟合 | 大模型一定收敛或具备分布外泛化 |

| 新进程恢复 | 序列化后相同原始输入得到相同预测 | 传感器、相机及真实执行接口已经一致 |

| 合成闭环 | 重新观测后的反馈与终点误差 | 真实动力学、接触或时延下的机器人效果 |



## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| action keys / mean / std | [D] | 顺序、单位与统计量共同定义动作语义 |
| normalized noisy action | [B,H,D] | 采样器使用的空间，不直接等于原始控制命令 |
| contract / group IDs | 结构化配置 / 集合 | 约束版本身份、处理规则和评估信息边界 |

## 完整代码与精读

```python
"""Synthetic two-dimensional policy: split -> fit -> restore -> closed loop.

CPU-only teaching experiment. The dynamics are s_next = s + action.
The experiment checks software contracts, not performance on a robot.
"""
import copy
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import torch
from torch import nn

torch.set_num_threads(1)
torch.manual_seed(83)
HORIZON, ACTION_DIM = 3, 2
CONFIG = {"horizon": HORIZON, "action_dim": ACTION_DIM,
          "observation": "previous_state,current_state,goal",
          "action": "world_delta", "unit": "synthetic_length", "dt": 1.0}


def model_factory(config):
    # This expert is linear in the observation; a linear model isolates the pipeline.
    return nn.Linear(6, config["horizon"] * config["action_dim"])


def make_episodes():
    generator = torch.Generator().manual_seed(83)
    episodes = []
    for episode_id in range(60):
        state = 2 * torch.rand(2, generator=generator) - 1
        goal = 2 * torch.rand(2, generator=generator) - 1
        previous = state.clone()
        observations, actions = [], []
        for _ in range(12):
            action = 0.25 * (goal-state)
            observations.append(torch.cat([previous, state, goal]))
            actions.append(action)
            previous, state = state, state+action
        episodes.append({"id": episode_id, "obs": torch.stack(observations),
                         "actions": torch.stack(actions), "goal": goal})
    return episodes


def windows(episodes):
    obs, actions, masks = [], [], []
    for episode in episodes:
        length = len(episode["obs"])
        for t in range(length):
            count = min(HORIZON, length-t)
            chunk = torch.full((HORIZON, ACTION_DIM), float("nan"))
            valid = torch.zeros(HORIZON, 1, dtype=torch.bool)
            chunk[:count] = episode["actions"][t:t+count]
            valid[:count] = True
            obs.append(episode["obs"][t]); actions.append(chunk); masks.append(valid)
    return torch.stack(obs), torch.stack(actions), torch.stack(masks)


def fit_statistics(train):
    obs, actions, valid = train
    selected_actions = actions[valid[..., 0]]  # [valid frames,D]
    return {"obs_mean": obs.mean(0), "obs_std": obs.std(0, correction=0).clamp_min(1e-4),
            "action_mean": selected_actions.mean(0),
            "action_std": selected_actions.std(0, correction=0).clamp_min(1e-4)}


def prepare_data(episode_splits):
    # The complete preparation entry point receives every split, but fits only train.
    prepared = {name: windows(items) for name, items in episode_splits.items()}
    return prepared, fit_statistics(prepared["train"])


def predict(model, stats, obs):
    normalized = (obs-stats["obs_mean"]) / stats["obs_std"]
    q = model(normalized).reshape(-1, HORIZON, ACTION_DIM)
    return q * stats["action_std"] + stats["action_mean"]


def masked_error(prediction, target, valid):
    mask = valid.expand_as(prediction)
    if not mask.any():
        raise ValueError("empty supervision")
    p, y = prediction[mask], target[mask]
    if not (torch.isfinite(p).all() and torch.isfinite(y).all()):
        raise ValueError("nonfinite valid supervision")
    return (p-y).square().mean()


def restore(path):
    artifact = torch.load(path, map_location="cpu", weights_only=True)
    if artifact["config"] != CONFIG:
        raise ValueError("incompatible observation/action contract")
    model = model_factory(artifact["config"])
    model.load_state_dict(artifact["model"])
    model.eval()
    return model, artifact


def restore_check(path):
    model, artifact = restore(path)
    with torch.no_grad():
        actual = predict(model, artifact["statistics"], artifact["probe"])
    torch.testing.assert_close(actual, artifact["expected"], atol=1e-6, rtol=1e-6)
    print("fresh-process prediction matches saved probe")


def run():
    episodes = make_episodes()
    train_episodes, validation_episodes, test_episodes = episodes[:40], episodes[40:50], episodes[50:]
    split = {"train": [e["id"] for e in train_episodes],
             "validation": [e["id"] for e in validation_episodes],
             "test": [e["id"] for e in test_episodes]}
    assert not (set(split["train"]) & set(split["validation"]) | set(split["train"]) & set(split["test"]))
    episode_splits = {"train": train_episodes, "validation": validation_episodes, "test": test_episodes}
    prepared, stats = prepare_data(episode_splits)
    train, validation, test = (prepared[name] for name in ("train", "validation", "test"))
    # Re-run the actual preparation entry point with altered held-out inputs.
    altered_splits = copy.deepcopy(episode_splits)
    for name in ("validation", "test"):
        for episode in altered_splits[name]:
            episode["obs"].add_(1000)
            episode["actions"].add_(1000)
    _, altered_stats = prepare_data(altered_splits)
    for key, value in altered_stats.items():
        torch.testing.assert_close(value, stats[key])

    model = model_factory(CONFIG)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.03)
    x, y, valid = train
    # Only selected targets are transformed; invalid NaN values never enter a loss.
    normalized_x = (x-stats["obs_mean"]) / stats["obs_std"]
    mask = valid.expand_as(y)
    safe_y = torch.where(mask, y, stats["action_mean"])
    normalized_y = (safe_y-stats["action_mean"]) / stats["action_std"]
    losses = []
    for step in range(600):
        optimizer.zero_grad(set_to_none=True)
        q = model(normalized_x).reshape_as(y)
        loss = masked_error(q, normalized_y, valid)
        loss.backward(); optimizer.step()
        if step in (0, 599): losses.append(float(loss.detach()))
    model.eval()
    with torch.no_grad():
        validation_mse = float(masked_error(predict(model, stats, validation[0]), validation[1], validation[2]))
        test_mse = float(masked_error(predict(model, stats, test[0]), test[1], test[2]))
        probe = test[0][:8].clone()
        expected = predict(model, stats, probe)
    assert losses[-1] < losses[0]
    assert validation_mse < 1e-4  # A contract test for this deliberately realizable toy problem.
    artifact = {"model": {k: v.detach().clone() for k, v in model.state_dict().items()},
                "statistics": stats, "config": CONFIG, "split": split,
                "probe": probe, "expected": expected}
    with tempfile.TemporaryDirectory() as directory:
        checkpoint = Path(directory)/"policy.pt"
        torch.save(artifact, checkpoint)
        # Exercise actual serialization and a new Python process, not just a state_dict alias.
        subprocess.run([sys.executable, __file__, "--restore-check", str(checkpoint)], check=True)
        restored, saved = restore(checkpoint)
        final_errors = []
        with torch.no_grad():
            for episode in test_episodes:
                previous = episode["obs"][0, :2].clone()
                state = episode["obs"][0, 2:4].clone()
                goal = episode["goal"]
                for _ in range(24):
                    obs = torch.cat([previous, state, goal])[None]
                    action = predict(restored, saved["statistics"], obs)[0, 0]
                    previous, state = state, state+action  # Execute one slot, then re-observe.
                final_errors.append(float((state-goal).norm()))
        # Fault injection: identical shapes do not establish compatible units.
        broken = copy.deepcopy(artifact); broken["config"]["unit"] = "other_unit"
        torch.save(broken, checkpoint)
        try: restore(checkpoint)
        except ValueError: pass
        else: raise AssertionError("unit mismatch must be rejected")
    print(json.dumps({"train_loss_first_last": losses, "validation_action_mse": validation_mse,
                      "test_action_mse": test_mse, "closed_loop_mean_final_distance": sum(final_errors)/len(final_errors),
                      "episodes": {key: len(value) for key, value in split.items()}}, indent=2))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--restore-check": restore_check(sys.argv[2])
    else: run()

```

- 第 24 行：线性教师使目标可实现，模型容量不成为本实验的主要混杂；这不代表真实机器人只需线性策略。
- 第 29 行：先建立完整 Episode，再按 Episode 分割，避免重叠窗口跨集合。
- 第 47 行：[N,H,D] 的未来动作与 [N,H,1] 有效位一起构造，末尾使用 NaN 暴露掩码错误。
- 第 61 行：只从训练窗口的有效动作拟合统计；重叠窗口的频率权重在正文中另作说明。
- 第 69 行：同一准备入口接收全部集合；干预验证/测试输入后重新调用入口，训练统计应保持不变。
- 第 75 行：先按训练统计处理观测，再将网络的归一化动作显式反变换。
- 第 81 行：选择有效输出与标签后才做减法、平方；不能靠 NaN 乘零消除无效监督。
- 第 91 行：恢复同时校验配置和模型权重；相同形状不保证动作单位一致。
- 第 101 行：在新进程中重建模型，对持久化的探针检查输出一致性。
- 第 109 行：贯通训练、留出集误差、保存加载与执行第一步后重观测，并注入单位不匹配故障。

预期观察：新进程恢复后的预测与保存探针一致，不兼容的单位配置被拒绝。固定种子教学运行的验证动作 MSE 约 3.26e-6，闭环平均终点距离约 0.00265；这些数值只描述本文的线性合成系统。

## 浏览器 Python 练习

实现 `contract_errors(saved,runtime,train_groups,eval_groups)`。检查题目列出的必需字段；缺失报 `missing:key`，不同报 `mismatch:key`。两边 `causal_history` 都应为 True，否则报 `noncausal_history`；组交叉时报 `group_overlap`。返回错误字符串列表。

```python
REQUIRED=('action_order','unit','action_mode','normalizer_id','prediction_type','control_dt','causal_history')

def contract_errors(saved,runtime,train_groups,eval_groups):
    # TODO: 不用隐式默认值掩盖缺失字段
    raise NotImplementedError

```

### 提示

- 检查字段是否存在，要先于值是否相等；两边都缺失不表示一致。
- 因果历史必须真的为 True，不能让两边都为 False 通过相等检查。

### 参考实现与解释

```python
REQUIRED=('action_order','unit','action_mode','normalizer_id','prediction_type','control_dt','causal_history')

def contract_errors(saved,runtime,train_groups,eval_groups):
    errors=[]
    for key in REQUIRED:
        if key not in saved or key not in runtime:
            errors.append('missing:'+key)
        elif saved[key]!=runtime[key]:
            errors.append('mismatch:'+key)
    if saved.get('causal_history') is not True or runtime.get('causal_history') is not True:
        errors.append('noncausal_history')
    if set(train_groups)&set(eval_groups):
        errors.append('group_overlap')
    return errors

```

这份检查能揭示已声明的冲突，但不能证明配置忠实反映实际代码。还需要计算统计量指纹、检查真实索引和动作变换，并用已知物理样本核对接口。组隔离粒度由要测量的泛化目标决定。

### 断言测试

```python
s={'action_order':['x','y'],'unit':'m','action_mode':'delta','normalizer_id':'abc','prediction_type':'epsilon','control_dt':0.1,'causal_history':True}
assert contract_errors(s,dict(s),['a'],['b'])==[]
r=dict(s,unit='cm',prediction_type='sample')
e=contract_errors(s,r,['a'],['a'])
assert set(e)=={'mismatch:unit','mismatch:prediction_type','group_overlap'}
r=dict(s); del r['normalizer_id']
assert 'missing:normalizer_id' in contract_errors(s,r,[],[])
r=dict(s,causal_history=False)
assert 'noncausal_history' in contract_errors(s,r,[],[])
print('单位、参数化、缺失配置、因果声明与组泄漏检查通过。')

```

## 本地 PyTorch 练习

实现 `decode_epsilon(noisy,eps_hat,alpha_bar,mean,std,valid_dim)`。`noisy` 与 `eps_hat` 为 `[B,H,D]`，`alpha_bar` 为 `[B]` 且在 \((0,1]\)，其余为 `[D]`。先恢复归一化干净动作，再反归一化，填充维返回零；`std` 必须为正。

```python
import torch

def decode_epsilon(noisy,eps_hat,alpha_bar,mean,std,valid_dim):
    # TODO: 参数化换算 → 反归一化 → 有效动作维
    raise NotImplementedError

```

### 提示

- 先把 `alpha_bar` 转为 `[B,1,1]`，不能把它广播到动作轴。
- epsilon 输出不是干净动作，须先完成公式换算再乘 std 加 mean。

### 参考实现与解释

```python
import torch

def decode_epsilon(noisy,eps_hat,alpha_bar,mean,std,valid_dim):
    if noisy.ndim!=3 or noisy.shape!=eps_hat.shape or alpha_bar.shape!=(len(noisy),):
        raise ValueError('invalid action or coefficient shape')
    if any(v.shape!=(noisy.shape[-1],) for v in (mean,std,valid_dim)) or valid_dim.dtype!=torch.bool:
        raise ValueError('invalid normalization shape')
    if not all(torch.isfinite(v).all() for v in (noisy,eps_hat,alpha_bar,mean,std)):
        raise ValueError('non-finite values')
    if ((alpha_bar<=0)|(alpha_bar>1)).any() or (std<=0).any():
        raise ValueError('invalid coefficient or scale')
    ab=alpha_bar[:,None,None]
    clean=(noisy-(1-ab).sqrt()*eps_hat)/ab.sqrt()
    raw=clean*std+mean
    return torch.where(valid_dim,raw,torch.zeros_like(raw))

```

对已知加噪公式求解 `clean` 得到本题表达式。`alpha_bar=0` 时干净信号完全消失，不能用这个除法恢复，应拒绝该输入。`std` 是检查点保存的正尺度，不应在推理阶段重新估计；有效维 Mask 最后排除填充命令。此函数恢复 \(x_0\) 估计，不等同于完整反向采样器。

### 断言测试

```python
torch.manual_seed(5)
clean=torch.randn(2,2,3)
eps=torch.randn_like(clean)
ab=torch.tensor([0.5,0.8])
m=torch.tensor([1.,2.,0.]); s=torch.tensor([0.1,0.2,1.])
v=torch.tensor([True,True,False])
noisy=ab[:,None,None].sqrt()*clean+(1-ab[:,None,None]).sqrt()*eps
a=decode_epsilon(noisy,eps,ab,m,s,v)
torch.testing.assert_close(a[...,:2],(clean*s+m)[...,:2])
assert torch.count_nonzero(a[...,2])==0
try:
    decode_epsilon(noisy,eps,torch.tensor([0.,0.8]),m,s,v)
    raise AssertionError('完全零信号系数不能用此除法恢复')
except ValueError:
    pass
print('epsilon 参数化、统计量、广播和填充维解码检查通过。')

```

## 练习：推导与分析

### 同样的测试输入在训练脚本与部署脚本产生不同动作，如何分层定位？

先固定权重、随机噪声、模型模式和输入，比较进入模型前的相机顺序、图像范围、语言 token、状态与归一化结果；再比较原始模型输出。若前处理或原始输出已不同，先定位这一层，而不是在最终动作上加补偿。

若模型输出相同，再检查采样器参数化、时间方向、步进配置和动作反变换的顺序。最后核对单位、参考坐标、关节顺序、命令周期与队列时间语义。每一步保存小张量或可审阅统计量，找到第一个分歧点。

代码定位：`normalizer_id`、`check_contract`、`recovered_clean` 与 `recovered_action`。

- 按前处理、模型、采样、后处理、执行分层。
- 提出固定噪声与首处分歧定位方法。

### 统计量和模型都来自训练集，是否足以排除评估泄漏？

不足。训练与评估可能共享同一轨迹的相邻帧、同一物品或采集会话，也可能在历史窗口里使用未来观测。模型选择和多次测试后的手工调参同样会使用评估信息，即使标准化实现完全正确。

应按目标泛化轴保留独立组，固定选模协议，检查窗口可见性与时间戳，并记录哪些条件已参与补采或调参。契约里的组 ID 和 causal 标记只是入口，还需用数据检查和因果干预测试验证。

代码定位：`train_groups/evaluation_groups` 的隔离与真实历史输入构造。

- 列出至少三种非统计量泄漏路径。
- 区分元数据声明与实际数据验证。

## 练习：辨析与纠错

### 权重相同就认定完整策略相同

预处理、统计量、采样、动作表示和执行周期都能改变行为。将它们共同版本化并检查真实加载值。

### 在最终动作上加补偿掩盖上游差异

这可能只对一个场景有效。固定输入与随机性，逐层找到第一个不同的中间量再修正。

### oracle 恢复成功就宣布网络已学会去噪

oracle 故意提供正确噪声或解析速度，只验证公式与接口。真实网络与闭环效果需另外测量。

### 两个配置都缺字段仍判为一致

缺失是单独错误；必需字段应先验检查，不能依赖 get 返回相同默认值。

### 保存了 causal 标记就排除未来泄漏

必须测试真实索引、插值与传感器到达时间。修改未来数据应不影响此前决策。

## 原始资料

- [OpenPI：训练与推理归一化统计量](https://github.com/Physical-Intelligence/openpi/blob/main/docs/norm_stats.md)
- [LeRobot：策略、预处理与后处理契约](https://huggingface.co/docs/lerobot/bring_your_own_policies)
- [Diffusers：DDPM 预测参数化与采样日程](https://huggingface.co/docs/diffusers/en/api/schedulers/ddpm)
- [scikit-learn：预处理与数据泄漏](https://scikit-learn.org/stable/common_pitfalls.html)
