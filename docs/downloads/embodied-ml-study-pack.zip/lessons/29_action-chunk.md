# 时间对齐与动作块

观测时间、动作索引、预测长度与重规划频率。

动作分块（Action Chunking）是让策略一次预测一段未来动作，而非只预测下一条命令的方法。观测窗口提供条件，预测时域定义输出覆盖多远，执行时域定义多久再次读取反馈；三者是不同长度。本章先建立统一时间原点，再定义边界填充、因果对齐与相对参考，最后说明重规划和重叠预测怎样对应真实执行时刻。

## 学习目标

- 正确构造历史观测和未来动作窗口并处理边界
- 区分预测长度、执行长度与控制频率
- 识别未来信息泄漏、跨轨迹拼接与延迟引起的错位

前置知识：[损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [状态与动作表示](https://wxb1870.github.io/embodied-ml-lab/learn/action-representation/) · [行为克隆](https://wxb1870.github.io/embodied-ml-lab/learn/behavior-cloning/)

## 给一个训练样本固定时间原点

动作窗口是相对于一次决策组织的未来命令片段，观测窗口则是该决策可读取的当前与历史信息。时间原点把这两部分放到同一索引约定中。先固定这一关系，才能判断标签是在预测未来还是误用了未来观测。





选择决策时刻 t 后，先定义观测历史 \(X_t=(o_{t-O+1},\ldots,o_t)\) 与动作标签 \(A_t=(a_t,\ldots,a_{t+H-1})\)。这里约定 \(o_t\) 在 \(a_t\) 发出前可获得。若数据集把发出动作后的图像记作 \(o_t\)，就需要重写这一对应关系。索引只是记录位置，不能代替真实采集与执行时间。 本章统一用 \(O\) 表示历史观测长度、\(H\) 表示预测动作长度、\(K\) 表示一次实际执行的前缀长度，三者不应由同一个符号兼任。





动作标签还可能是未来状态或控制参考，偏移一格的正确答案取决于它的定义。训练张量 x.shape=[B,O,…]、target.shape=[B,H,D] 即使完全符合配置，也可能让模型预测过去的动作或使用未来图像。因此必须从数据记录规范一路追到 __getitem__，再画出一组具体时间戳。





一个容易检查的方法是把观测内容暂时替换为时间索引，把动作替换为十倍索引。任意抽取起点后直接打印窗口，就能发现把观测结束在 t+1、把动作从 t−1 开始或跨回合拼接的问题。完成这个确定性检查后，再把图像张量和真实动作放回同一套索引逻辑。





$$
X_t=(o_{t-O+1},\ldots,o_t),\qquad A_t=(a_t,\ldots,a_{t+H-1})
$$





### 用索引哨兵验证时间对齐

复杂视觉张量可能使一个时间步的偏移难以识别，已知规律的数字标签可以直接暴露索引错误。

设置 \(o_i=i\)、\(a_i=10i\)，分别测试首帧、中间帧、末帧及回合连接处的窗口。

## 边界填充是输入协议与监督协议

边界填充是在历史或未来长度不足时，为统一形状补入数值的过程。历史填充改变输入，未来填充需要标记哪些动作不受监督。两种协议处理的未知信息不同，不能用同一个补零规则代替定义。





回合开头没有足够历史，回合结尾没有足够未来动作。历史可用首帧复制、零值配合有效位等明确策略填充；未来动作则应保存有效性 Mask，防止补出的数值被当成真实监督。历史填充影响模型输入分布，未来填充影响损失定义，二者不能共用一个模糊的“补零”解释。





轨迹常被存成一个长数组，读取窗口时不能只检查全局数组边界。两个回合在内存中相邻，并不表示物理上连续。必须以 episode ID 和回合内长度限制历史与未来，尤其是在成功后自动 reset 的环境中；否则一个动作块可能混合了上个任务末尾与新任务起点。





若模型内部使用注意力或循环结构，Padding 还需要参与可见性或状态更新的规则。Loss Mask 不会自动屏蔽输入。应分别扰动无效输入与无效标签，检查有效输出和损失是否按设计保持不变。对固定首帧重复填充，训练与推理必须采用相同规则，不能在线突然改成全零历史。







### 例：一条轨迹末尾的未来动作窗口

1. 轨迹长度为 8，索引 0…7，起点 t=6，预测长度 H=4。

2. 动作标签应为 [\(a_6\),\(a_7\),填充值,填充值]，有效位为 [True,True,False,False]。

3. 若动作记录为 10i，打印值就是 [60,70,0,0]；不能读取下一回合的 \(a_0\)、\(a_1\)。

标签数值与有效性分开存储；窗口应由回合边界而非整份文件长度限制。

### 文件连续就当作轨迹连续

跨回合混入的下一帧通常尺寸完全合法，模型甚至可以拟合这种错误标签。

检查窗口内所有记录的 episode ID，首尾窗口必须有专门断言。

## 不同传感器频率下的因果对齐

因果对齐是只使用决策截止时已经到达的信息，为不同频率的传感与动作建立时间对应。采集时间相近并不等于在线可同时获得。下面区分源时间、到达时间与插值所使用的信息。





插值本身也可能使用未来。离线线性插值常用左右两个邻近样本，但右侧样本在在线决策时尚未到达。若训练的观测由这种未来数据参与构造，模型就获得部署时不存在的平滑信息。可采用仅使用已到达记录的保持或因果估计，或在协议中明确增加等待延迟；不能只在表格里把时间戳改成过去。





重采样动作时还要尊重动作含义。绝对位置目标可按约定插值，单位时间速度需要对齐保持区间，离散夹爪切换不一定适合数值平均。把高频动作简单每隔若干帧抽取，可能漏掉短促事件；把相邻增量直接抽样而不聚合，则会改变累计位移。先确定物理语义，再选择重采样方法。









## 预测长度与执行长度控制不同问题

预测长度 H 是一次输出包含的未来命令数，执行长度 K 是读取新观测前实际消费的命令数。前者定义预测目标，后者定义反馈频率。先分清二者，再结合控制周期与生成耗时判断可用时域。





预测 H 步让模型在一次前向中表达动作之间的相关性，并可共享观测编码；每次实际执行 K 步后重新观察，则决定策略多久更新一次反馈。通常 K≤H，但具体系统还可能异步生成并重叠融合。增大 H 主要改变规划范围和输出目标，增大 K 则使更长一段动作沿用较旧条件。





例如策略动作频率 20 Hz，\(H=16\) 表示名义覆盖 0.8 秒，\(K=4\) 表示每 0.2 秒尝试更新计划。若每次生成需 0.3 秒，同步实现无法在这个周期持续获得新结果；异步实现也必须检查队列剩余时间是否足够。训练时的预测时域和部署时的可用未来时域不是同一个数。





动作块可能提升序列一致性，却不能保证对突发接触、目标移动或观测变化即时响应。选择 H、K 时要同时测量成功率、延迟、轨迹平滑程度与恢复能力。不能只根据模型每次调用较少就认定系统更快；单次调用的耗时、图像处理和动作消费节奏都参与闭环。







### 例：名义动作块与有效未来的差别

1. 以 20 Hz 预测 16 步，名义时长为 16×0.05=0.8 秒。

2. 若动作块从观测时刻开始标记，返回结果时已过去 0.25 秒，前 5 个槽位已经过去。

3. 剩余 11 步只覆盖约 0.55 秒；下一轮请求还需考虑传输、排队与延迟抖动。

使用实际起始时间和槽位计算剩余计划，不能把 H/fps 当成每次返回后的可用时长。

### 把推理步数当作动作执行步数

Diffusion/Flow 的采样迭代在生成空间更新整个动作块，机器人控制步沿物理时间消费动作。

分别命名 horizon、execution_steps、solver_steps、control_dt，并在日志中记录它们。

## 相对动作的参考不能在窗口内悄悄改变

相对动作的参考规则规定每个未来目标相对哪个姿态编码。固定锚点与逐步增量即使都被叫作 delta，恢复过程也不同。窗口推进或丢弃前缀时，不能无说明地更换这套参考。





若标签是相对观察时刻姿态的动作块，窗口内每个未来动作都以同一姿态为锚点。若标签是相邻时刻之间的位移，恢复时则要逐步累计。两者都可以训练，但网络输出与执行器必须采用同一种定义；把一个数组叫 delta_actions 并不能说明它属于哪一种。





丢弃过期前缀时，这个区别尤其重要。固定锚点的后续目标仍能用原锚点解码；逐步增量如果从中间开始执行，需要重新考虑已经执行的部分和当前参考。不能直接把剩余的第一个增量当成针对最新实测状态重新生成的闭环修正，因为模型生成它时的条件没有改变。





训练时也不要把未来实测姿态作为每个动作位置的附加输入，除非部署确实拥有对应预测或反馈机制。那会把一段开环预测变成带未来答案的条件任务。可以用明确的递推模型设计不同机制，但应重新定义训练和推理过程，而不是只修改标签构造函数。









## 重叠预测怎样对应同一个物理时刻

时间集成是把多次预测中对应同一执行时刻的候选动作合并。它要求先按真实时间和共同动作语义对齐，而不是平均相同数组下标。下面再讨论权重、来源年龄与重规划。





连续两次调用会对同一个未来执行时刻给出不同预测。若要做 temporal ensembling，必须先按绝对执行时间对齐：上一块的第 j 步，可能对应新块的第 j−K 步，而不是相同数组索引。每个候选还要带原始观测时间，便于识别动作虽然尚未过期、条件却已经过旧的情况。





对同一语义的连续位置目标做加权平均可以减轻接缝跳动，但不保证混合结果仍是一个有效策略。两个不同绕行模式的平均可能碰到障碍，离散夹爪状态也可能没有“半开半关”的任务含义。相对增量在不同锚点上不能直接混合；旋转平均还涉及几何表示，需要专门处理。





融合权重决定旧计划与新观测之间的折中。旧计划权重较大可能更平滑，也可能延迟纠错。应将是否融合、对哪些动作维融合、采用的时间对齐和权重随版本一起记录，并与不融合基线比较。只看轨迹曲线好看，无法说明抓取或接触任务真的更可靠。









## 用小窗口建立端到端验收

前面的时序规则可以在接入学习模型之前单独验证。让窗口和执行队列处理可手算的编号轨迹，能够把时间协议错误与模型误差分开。对照还需要覆盖边界与因果性，因为一个网络可能把稳定的错位关系也拟合得很好。





单轨迹窗口先核对 [B,O,…]、[B,H,D]、有效步数与边界值。多轨迹数据还要把 episode ID、时间戳、相机有效位与动作语义一起传递；构窗函数之前的数据排序和时间协议决定索引是否有物理含义。





至少保留四类测试：起点与终点的精确索引、跨回合不串接、修改未来观测不影响当前输入、以及训练和部署在同一记录上的一致性。对异步推理再增加返回延迟、乱序结果、指令切换和队列耗尽等时间场景，检查动作按真实时间被消费。





不要用模型训练成功替代这些检查。一个容量足够的网络可以学会稳定的一格错位，甚至利用未来泄漏得到更低误差。先把窗口变成可手算的确定性转换，再让模型学习其中的条件关系，才能判断失败来自时序接口、表征能力还是闭环决策本身。





动作块首先是带时间与参考语义的预测对象，而不只是一个较长数组。观测、预测、执行各有边界；保持时间、有效位与锚点一致，才能让一次生成和下一次反馈自然衔接。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| observation history | [B,O,D_obs] | 截至当前决策时刻的历史观测 |
| action chunk | [B,H,D_act] | 从当前命令开始的未来标签 |
| history / action mask | [B,O] / [B,H] | 区分真实记录和边界填充 |

## 完整代码与精读

```python
import torch

torch.manual_seed(7)

# STEP 1: 每一行代表同一决策时刻的观测和待发送动作
T, O, H = 8, 3, 4
observations = torch.stack([torch.arange(T), torch.arange(T) + 100], dim=1).float()
actions = (10 * torch.arange(T)).float().unsqueeze(-1)

# STEP 2: 只允许在本轨迹内索引，越界位置填零并提供 mask
def make_window(t):
    if not 0 <= t < T:
        raise ValueError('current time outside episode')
    obs_index = torch.arange(t - O + 1, t + 1)
    act_index = torch.arange(t, t + H)
    obs_valid = (obs_index >= 0) & (obs_index < T)
    act_valid = (act_index >= 0) & (act_index < T)
    obs = observations[obs_index.clamp(0, T - 1)]
    act = actions[act_index.clamp(0, T - 1)]
    obs = torch.where(obs_valid[:, None], obs, torch.zeros_like(obs))
    act = torch.where(act_valid[:, None], act, torch.zeros_like(act))
    return obs, act, obs_valid, act_valid

# STEP 3: 检查轨迹开头和结尾，而不仅检查中间帧
samples = [make_window(0), make_window(6)]
history, target, history_mask, target_mask = [torch.stack(x) for x in zip(*samples)]
assert history.shape == (2, O, 2)
assert target.shape == (2, H, 1)
assert history_mask[0].tolist() == [False, False, True]
assert target_mask[1].tolist() == [True, True, False, False]

# STEP 4: 执行长度是部署选择，不改变训练标签长度
execution_horizon = 2
commands_to_send = target[:, :execution_horizon]
print('history:', history.tolist())
print('target:', target.squeeze(-1).tolist())
print('target mask:', target_mask.tolist())
print('execute first steps:', commands_to_send.squeeze(-1).tolist())

```

- 第 5–9 行：本例的观测第二列人为加 100，便于区分观测与动作；它只演示索引，数值不代表真实机器人。
- 第 10–23 行：先构造真实索引和有效性，再使用 clamp 防止数组越界。clamp 只为安全读取，Mask 后才得到真正的填充语义。
- 第 24–31 行：开头历史不足、结尾标签不足是最容易出错的两个边界。应同时检查内容、形状和 Mask。
- 第 32–38 行：模型预测 H 步后可以只发送前两步，然后用新观测重规划。真实部署还要结合有效性与动作缓冲处理。

预期观察：输出 history 形状 (2,3,2)、target 形状 (2,4,1)。t=6 的标签为 [60,70,0,0]，后两步 Mask 为 False。

## 浏览器 Python 练习

实现 window_indices(length,t,history,horizon)，返回 (obs_indices, action_indices)。不存在的历史或未来记录使用 None，t 必须位于轨迹内，三个长度参数都必须为正。

```python
def window_indices(length, t, history, horizon):
    # TODO: 只生成同一条轨迹中的索引；越界处返回 None
    raise NotImplementedError

```

### 提示

- 历史区间的右端包含 t；动作区间的左端也包含 t。
- Python range 的终点不包含在结果中。

### 参考实现与解释

```python
def window_indices(length, t, history, horizon):
    if min(length, history, horizon) <= 0 or not 0 <= t < length:
        raise ValueError('invalid window configuration')
    obs = [i if 0 <= i < length else None for i in range(t-history+1, t+1)]
    act = [i if 0 <= i < length else None for i in range(t, t+horizon)]
    return obs, act

```

这些索引依赖上述时间约定。接入真实数据集时，先验证图像和命令的记录顺序，再确定标签应该从 t 还是其他索引开始。

### 断言测试

```python
assert window_indices(5,0,3,3) == ([None,None,0], [0,1,2])
assert window_indices(5,4,3,3) == ([2,3,4], [4,None,None])
assert window_indices(5,2,2,2) == ([1,2], [2,3])
try:
    window_indices(5,5,2,2)
    raise AssertionError('t 越界应报错')
except ValueError:
    pass
print('窗口边界与当前动作对齐检查通过。')

```

## 本地 PyTorch 练习

实现 chunkify(actions, starts, horizon)。actions 是单条轨迹 [T,D]，starts 是合法起点 [B]。返回零填充标签 [B,H,D] 与有效性 Mask [B,H]，不可越过轨迹末尾。

```python
import torch

def chunkify(actions, starts, horizon):
    # TODO: 向量化索引，返回 chunk 和 valid
    raise NotImplementedError

```

### 提示

- 用 starts[:,None]+arange(horizon) 构造 [B,H] 索引。
- clamp 只用于安全读取，超过轨迹长度的结果仍需归零并标 False。

### 参考实现与解释

```python
import torch

def chunkify(actions, starts, horizon):
    if horizon <= 0 or len(actions) == 0 or ((starts < 0) | (starts >= len(actions))).any():
        raise ValueError('invalid chunk configuration')
    index = starts[:, None] + torch.arange(horizon, device=starts.device)
    valid = index < len(actions)
    selected = actions[index.clamp(max=len(actions)-1)]
    chunk = torch.where(valid[..., None], selected, torch.zeros_like(selected))
    return chunk, valid

```

chunkify 处理的是一条轨迹，所以有效性由这条轨迹的长度决定。先保留真实索引形成 valid，再夹住索引防止访问越界，最后把无效位置归零。若直接把 clamp 得到的末帧复制值当标签，模型会被迫学习伪造的后续动作。起点应合法，H 必须为正；多轨迹数据要先分组，不能跨轨迹滑窗。

### 断言测试

```python
a = torch.arange(5).float().unsqueeze(-1)
c,v = chunkify(a, torch.tensor([0,3,4]), 3)
torch.testing.assert_close(c.squeeze(-1), torch.tensor([[0.,1.,2.],[3.,4.,0.],[4.,0.,0.]]))
assert v.tolist() == [[True,True,True],[True,True,False],[True,False,False]]
assert c.shape == (3,3,1)
print('向量化 Action Chunk 检查通过。')

```

## 练习：推导与分析

### 模型使用“前后各两帧”的图像窗口预测当前动作，离线效果很好。为什么这个实现可能无法部署？

当前决策只能使用已经获得的观测。前后窗口中的后两帧来自未来，训练时额外提供了执行尚未产生的信息。部署时等待这些帧会改变决策时刻和动作目标；不能仅把相同窗口索引复制到在线程序。

应先定义观测截止时刻和动作生效时刻，改为因果历史，或显式把预测目标对齐到等待后的时刻。用未来帧扰动检查：改动决策时刻之后的图像，不应改变该时刻本来可用的模型输入。窗口还需按 episode 隔离并在开头标记缺失历史。

代码定位：window_indices 的历史 range(t−history+1,t+1)；构造输入前的时间戳检查。

- 识别未来观测泄漏。
- 给出不使用未来信息的索引和测试方法。

### 预测 \(H=16\) 步、执行 E=4 步，推理延迟增加后，能否直接把 E 调大解决？

E 调大通常能延长已有动作的播放时间，但也延长了再次获得反馈前的开放执行阶段。它改变反应能力、源观测年龄与重规划节奏，并不消除延迟。先测量端到端延迟分布、动作间隔、可用队列长度和实际消费速度。

新的 chunk 到达时，要根据观测时间戳对齐到未执行的未来槽位，丢弃已经过去的部分。若有效剩余时长仍不足以覆盖下一次推理，调整 E 本身不一定解决问题。比较方法时应固定动作语义并记录停止、过期与队列耗尽事件。

代码定位：code.source 的 execution_horizon 与部署层的时间戳/队列消费逻辑。

- 区分 H、E、控制频率和推理延迟。
- 说明更长执行窗口对反馈新鲜度的影响。

## 练习：辨析与纠错

### 历史窗口里使用未来插值

检查插值使用的右端样本是否在线可用。必要时改因果保持或明确引入等待时间，并保持训练部署一致。

### 只对输出 Mask，忽略输入 Padding

跨位置网络可能读取无效输入。用无效输入扰动检查有效输出，并明确注意力或循环状态的处理。

### 预测 1 秒就认为拥有 1 秒反应余量

返回时已过去的前缀不能再次执行。用槽位时间、端到端延迟与剩余有效时长判断队列预算。

### 重叠动作按相同索引平均

不同生成时刻的数组索引不对应同一控制时刻。先做时间与参考锚点对齐，再决定能否融合。

### 把生成迭代与物理执行频率绑定

采样器迭代更新动作分布，执行频率决定物理命令时间。分别配置并测量，不能用一个 steps 变量表达两者。

## 原始资料

- [ACT 原论文：Action Chunking with Transformers](https://arxiv.org/abs/2304.13705)
- [Diffusion Policy：滚动执行与动作序列](https://diffusion-policy.cs.columbia.edu/)
- [PyTorch 数据加载官方文档](https://docs.pytorch.org/docs/stable/data.html)
