# Score、SDE 与概率流 ODE

从去噪恒等式和密度演化方程推导扩散、噪声预测与速度参数化的联系。

Score 是对数概率密度对样本坐标的梯度，描述当前位置附近密度增加的方向和速率。随机微分方程（SDE）用漂移与随机扰动描述样本运动，概率流 ODE 则在相应条件下用确定性运动得到同一组边际分布。本章先认识这些对象，再说明怎样从加噪监督学习 Score，以及它怎样用于反向生成和速度场转换。

## 学习目标

- 推导条件 score 与边际 score 的期望关系
- 从 Fokker–Planck 方程得到概率流 ODE
- 正确转换时间方向、噪声预测、干净样本预测与速度场

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [Diffusion：DDPM、目标参数化与 DDIM](https://wxb1870.github.io/embodied-ml-lab/learn/diffusion/)

## Score 是对状态的梯度，不是密度或模型参数梯度

Score 是对数密度关于状态坐标的梯度，是与样本同维的向量。它描述局部密度变化，不是密度值、分类分数或模型参数梯度。先用高斯直观认识方向与尺度，再进入生成动力学。





对正且可微的密度 \(p_t(x\mid c)\)，定义 \(s_t(x,c)=\nabla_x\log p_t(x\mid c)\)。它是 \(D\) 维向量，描述当前位置附近 log 密度如何变化；它不是 \(p_t\) 本身，也不是 \(\nabla_\theta\log p_\theta\) 的参数梯度。条件 \(c\) 在这个求导中固定。高斯 \(\mathcal N(m,\Sigma)\) 的 score 为 \(-\Sigma^{-1}(x-m)\)，各向同性时是 \(-\frac{x-m}{q}\)，\(q\) 表示方差而非标准差。



### 例：同一高斯的左右两侧，Score 指向哪里

1. 固定某个时间的 \(p_t=\mathcal N(2,4)\)，这里均值为 2、方差为 4，标准差为 2。状态 Score 是 \(s_t(x)=-(x-2)/4\)。

2. 在 x=0，Score 为 +0.5；在 x=2 为 0；在 x=4 为 −0.5。左右两侧的密度一样，Score 的方向却相反，因为它描述局部对数密度向哪里增加。

3. 把方差改为 1、均值仍为 2，在 x=0 的 Score 就变成 +2。方向没有改变，大小反映分布宽度；不能把它读成概率 2，也不能只凭这个向量就写出生成器的更新。

Score 是局部对数密度的空间梯度。真正的反向 SDE 或概率流 ODE 还需要漂移、时间系数和相应的时间方向。

对未归一化表达 \(p_\theta(x)=\frac{e^{-E_\theta(x)}}{Z_\theta}\)，\(Z_\theta\) 与 \(x\) 无关，因此状态 score 为 \(-\nabla_xE_\theta(x)\)，不需要显式计算 \(Z_\theta\)。这个消去只针对状态导数；对 \(\theta\) 求导时归一化常数通常不能忽略。直接输出向量场的网络也未必精确满足某个全局势函数的可积性，近似训练误差需要单独考虑。





离散经验样本、低维流形或带硬边界的变量不一定具有这里需要的光滑正密度。加入非退化高斯噪声后，在常见条件下得到平滑的中间密度，是噪声条件 score 模型可以进行这种回归的重要原因。接近零噪声的端点仍可能出现奇异性或较大的导数。





本篇采用前向加噪时间 \(t\)：\(t=0\) 是数据端，\(t=T\) 是高噪声端。随后引入反向时钟 \(\tau=T-t\) 说明生成。与[Flow Matching](#/learn/flow-matching?tab=theory)常用的“噪声 0→数据 1”约定比较时，需要同时转换时间输入、速度符号和积分方向。





$$
s_t(x,c)=\nabla_x\log p_t(x\mid c),\qquad p_t=\mathcal N(m_t,\Sigma_t)\Longrightarrow s_t(x)=-\Sigma_t^{-1}(x-m_t)
$$





## Score Matching 的未知目标如何通过分部积分消去

Score Matching 是通过匹配模型向量场与数据 Score 来学习分布信息的方法。真实 Score 通常未知，经典目标利用分部积分将它移出可优化表达式。下面说明这项改写依赖哪些边界条件。





如果真实 score 已知，可以最小化：





\[J(\theta)=\frac12\mathbb E_p\|s_\theta(X)-\nabla\log p(X)\|^2\]





但数据只提供样本，并不直接提供 \(\nabla\log p\)。展开平方后，只有交叉项涉及模型与未知 score 的乘积；真实 score 的平方期望对 \(\theta\) 是常数 \(C\)。





利用 \(p\nabla\log p=\nabla p\)，交叉项为 \(-\int s_\theta(x)\cdot\nabla p(x)\,dx\)。对每个坐标分部积分，在边界项消失的条件下，它等于 \(\int p(x)\nabla\!\cdot s_\theta(x)\,dx\)。于是可训练目标只含模型场的平方与散度，均可在观测样本上估计。负号转换来自分部积分，不能把散度项的符号凭直觉修改。





这一步要求相应的可微性、可积性和尾部或边界条件。对于有限区间上的密度，边界通量未必为零；直接照抄无界欧氏空间公式可能得到错误目标。散度是 \(\sum_i\frac{\partial s_{\theta,i}}{\partial x_i}\)，涉及模型对输入的导数；若 \(s_\theta\) 又来自一个能量梯度，还会涉及能量对输入的二阶导数。





Denoising Score Matching 采用另一路径：构造已知的条件加噪核，利用条件 score 回归来得到边际 score。它避免在这个基本训练目标中直接计算高维 score 网络的散度，但并不表示散度在密度计算等其他任务里不再需要。





$$
\begin{aligned}J(\theta)&=\tfrac12\mathbb E_p\|s_\theta-\nabla\log p\|^2\\&=\mathbb E_p[\tfrac12\|s_\theta\|^2]-\int s_\theta(x)\cdot\nabla p(x)\,dx+C\\&=\mathbb E_p[\tfrac12\|s_\theta\|^2+\nabla\cdot s_\theta]+C.\end{aligned}
$$





## 从条件加噪核推导边际 Score 与噪声预测

条件加噪核是在已知干净样本下生成带噪状态的分布，因此其 Score 可以直接计算。边际 Score 则对所有可能干净样本求平均。下面通过这个条件平均关系连接可监督的去噪目标与真正需要的场。





设干净随机变量 \(A\sim p_{\rm data}\)，\(E\sim\mathcal N(0,I)\)，且 \(A\) 与 \(E\) 独立。给定标量系数 \(\alpha_t\in\mathbb R,\ \sigma_t>0\)，构造 \(X_t=\alpha_t A+\sigma_t E\)。条件密度 \(q_t(x\mid a)\) 是均值 \(\alpha_t a\)、协方差 \(\sigma_t^2I\) 的高斯，因此条件 score 可直接求导为 \(-\frac{x-\alpha_t a}{\sigma_t^2}=-\frac{E}{\sigma_t}\)。





边际密度为 \(p_t(x)=\int q_t(x\mid a)p_{\rm data}(a)\,da\)。假设可以将空间求导移入积分，先求 \(\nabla p_t\)，再除以 \(p_t(x)>0\)。积分中的 \(\frac{q_t(x\mid a)p_{\rm data}(a)}{p_t(x)}\) 正是 \(p(a\mid x,t)\)，所以真实边际 score 等于条件 score 对隐藏干净样本后验的平均。





令 \(Y=-E/\sigma_t\)、\(Z=(X_t,t,c)\)。平方误差可以分解为网络到条件均值的距离，加上条件方差，完整等式见下方公式。后一项与 \(\theta\) 无关，只要采样机制固定、目标二阶可积。因此回归已知条件 score 与回归未知边际 score 具有相同的总体最优解和期望梯度；单个样本的梯度仍有噪声。





若训练网络预测 \(\epsilon_\theta\)，并定义 \(s_\theta=-\epsilon_\theta/\sigma_t\)，那么 score 平方误差等于噪声平方误差除以 \(\sigma_t^2\)。要把无权重噪声 MSE 写成相同的 score 目标，score loss 应带 \(\sigma_t^2\) 权重。二者可代数转换，不代表用均匀时间采样和同样的常数权重就得到相同训练目标。





当 \(\sigma_t\to0\) 时，单个条件 score 的尺度可能很大，即使边际场仍有适当极限。训练常需要处理时间端点、权重和数值精度；简单除以极小 \(\sigma\) 并不能自动提高精度。条件 \(c\) 存在时，所有期望都应在固定 \(c\) 的条件分布中计算，不能混合不同观测的后验权重。





$$
\begin{aligned}s_t(x)&=\frac{\int\nabla_xq_t(x\mid a)p_{\rm data}(a)\,da}{p_t(x)}\\&=\mathbb E[\nabla_x\log q_t(x\mid A)\mid X_t=x]= -\frac{\mathbb E[E\mid X_t=x]}{\sigma_t},\\\mathbb E\|s_\theta(Z)-Y\|^2&=\mathbb E\|s_\theta(Z)-\mathbb E[Y\mid Z]\|^2\\&\quad+\mathbb E\|Y-\mathbb E[Y\mid Z]\|^2,\\\left\|s_\theta+\frac E{\sigma_t}\right\|^2&=\frac1{\sigma_t^2}\|\epsilon_\theta-E\|^2.\end{aligned}
$$





## SDE 和 Fokker–Planck：样本噪声怎样改变密度

SDE 是同时含确定性漂移和随机增量的微分方程，用来描述单个样本的随机运动；Fokker–Planck 方程描述这些样本形成的密度怎样演化。二者分别观察轨迹与分布，下面从一个小时间步连接起来。





考虑 Itô SDE：\(dX_t=f(X_t,t)\,dt+g(t)\,dW_t\)，其中 \(f\in\mathbb R^D\) 是漂移，\(g(t)\ge0\) 是只依赖时间的标量扩散系数，\(W_t\) 为 \(D\) 维标准 Brownian motion。标准布朗运动从零出发，路径连续，互不重叠时间段的增量相互独立，长度为 h 的增量服从 \(\mathcal N(0,hI)\)。因此，对长度 h>0 的一步， Euler–Maruyama 更新中的噪声项是 \(g\sqrt h\,\xi\)，而不是 \(gh\,\xi\)；后者的噪声方差会错误地变成 \(h^2\) 量级。





先冻结当前 \(x,t\)，把一个小步近似写成 \(\Delta X=f(x,t)h+g(t)\sqrt h\,\xi\)，其中 \(\mathbb E\xi=0\)、\(\mathbb E[\xi\xi^\top]=I\)。其均值是 \(fh\)，二阶矩是 \(g^2hI+ff^\top h^2\)。对足够光滑的测试函数作二阶展开：\(\varphi(x+\Delta X)-\varphi(x)=\nabla\varphi(x)^\top\Delta X+\frac12\Delta X^\top H_\varphi(x)\Delta X+R\)，其中 \(H_\varphi\) 是 Hessian。





记号也要先固定：对标量函数 φ，\(\Delta\varphi=\sum_i\partial^2\varphi/\partial x_i^2\) 是 Laplace 算子；对向量场 j，\(\nabla\cdot j=\sum_i\partial j_i/\partial x_i\) 是散度。前者将二阶变化相加，后者在概率通量中表示局部净流出。它们都对状态坐标求导，而非对网络参数求导。





取条件期望并除以 \(h\)，一阶项给出 \(f\cdot\nabla\varphi\)，二阶项中的 \(g^2hI\) 给出 \(\frac12g^2\operatorname{tr}(H_\varphi)=\frac12g^2\Delta\varphi\)，\(ff^\top h^2\) 对应项则随 \(h\to0\) 消失。若局部矩与导数满足使余项满足 \(\mathbb E[R]/h\to0\) 的条件，便得到下面的生成元；Itô 公式对连续过程给出相同的期望恒等式。这说明随机增量虽只有零均值，仍通过二阶项改变密度。





\[\frac d{dt}\mathbb E[\varphi(X_t)]=\mathbb E[\nabla\varphi\cdot f+\frac{g^2}{2}\Delta\varphi]\]





再把对 \(X_t\) 的期望写成密度积分。在测试函数紧支撑，或边界衰减足以消去边界项的条件下，\(\int p f\cdot\nabla\varphi=-\int\varphi\nabla\cdot(fp)\)；扩散项分部积分两次，\(\int p\Delta\varphi=\int\varphi\Delta p\)。把导数移到 \(p_t\) 后，才能从所有测试函数的恒等式得到密度方程。





因此密度满足 \(\partial_t p=-\nabla\!\cdot(fp)+\frac{g^2}{2}\Delta p\)。第一项描述漂移产生的概率通量，第二项来自随机扩散；扩散项的 1/2 来自 Itô 的二阶项。这里 \(g\) 不依赖 \(x\)，才能把它提出空间微分之外。若扩散矩阵依赖状态，方程和相应反向漂移会出现更一般的导数项，本篇不将这个特例推广到那种情形。





VP（variance-preserving）SDE 取 \(f=-\beta(t)x/2\)、\(g=\sqrt{\beta(t)}\)。对线性方程使用积分因子，可得 \(\alpha_t=\exp\!\left[-\frac12\int_0^t\beta(s)\,ds\right]\)，\(\sigma_t^2=1-\alpha_t^2\)。名称中的“preserving”对应特定归一化：若起始分布已是单位高斯，它保持不变；任意数据分布的总协方差并不会在所有 \(t\) 下恒定。





下面选二次函数 \(\varphi(x)=x^\top Qx\)，用四个对称点精确提供零均值、单位协方差。由于二次函数没有三阶余项，可以直接核对有限步期望等于生成元加 \(h f^\top Qf\)。这验证二阶系数与噪声尺度，不把四点分布当成 Gaussian，也不声称有限步实验已经证明一般 SDE 的收敛定理。





$$
\begin{aligned}dX_t&=f(X_t,t)\,dt+g(t)\,dW_t,\\\frac d{dt}\mathbb E[\varphi(X_t)]&=\mathbb E[f\cdot\nabla\varphi+\tfrac12g^2\Delta\varphi],\\\partial_tp_t&=-\nabla\cdot(f p_t)+\tfrac12g(t)^2\Delta p_t.\end{aligned}
$$

```python
import torch

torch.set_default_dtype(torch.float64)
x = torch.tensor([0.4, -0.7])
Q = torch.tensor([[2., 0.3], [0.3, 1.]])
drift, g = -0.5*x, 0.8
# Four equal-weight points: exact mean 0 and covariance I.
xi = torch.tensor([[1., 0.], [-1., 0.], [0., 1.], [0., -1.]]) * 2**0.5
torch.testing.assert_close(xi.mean(0), torch.zeros(2))
torch.testing.assert_close(xi.T @ xi / 4, torch.eye(2))

def phi(values):
    return torch.einsum("...i,ij,...j->...", values, Q, values)

generator = 2*x @ Q @ drift + g*g*torch.trace(Q)
for h in [0.1, 0.01]:
    noise = g*h**0.5*xi
    increment = drift*h + noise
    observed = ((phi(x+increment)-phi(x))/h).mean()
    finite_step = generator + h*(drift @ Q @ drift)
    torch.testing.assert_close(observed, finite_step)
    torch.testing.assert_close(noise.T @ noise / 4, g*g*h*torch.eye(2))
    print("h:", h, "finite-step mean:", observed.item(),
          "generator:", generator.item())
print("passed: Brownian scale and second-order coefficient")

```

张量 xi 为 [4,2]，四行等权表示四个确定的积分节点；代码没有 Monte Carlo 误差。观测量与有限步公式严格对应，步长减小时剩余项 \(h f^\top Qf\) 缩小。把噪声中的 h**0.5 改成 h，会先破坏协方差断言，也会使每单位时间的扩散贡献错误地趋于零。





## 反向 SDE：时间方向、漂移修正和随机增量

反向 SDE 描述同一随机过程沿相反时间观察时的演化。它需要依据中间密度修正漂移，不是把前向步长变成负数就完成反演。下面分别定义时钟、Score 修正和反向随机增量。





在密度足够光滑、score 存在且时间反演所需正则条件成立时，前向过程的反向动力学使用 score 修正漂移。若仍用前向变量 \(t\)，但从 \(T\) 向 0 积分，常写为 \(dX_t=[f-g^2s_t]dt+g\,d\bar W_t\)，此处 \(dt<0\)，反向 Brownian 增量的协方差由 \(|dt|\) 决定。把负 dt 代入普通 `sqrt(dt)` 是实现错误。





更容易实现的方式是定义正向增加的反向时钟 \(\tau=T-t\)，并令 \(Y_\tau=X_{T-\tau}\)。此时漂移和随机项按下方公式改写。模型仍接收原始噪声等级 \(T-\tau\)；只有积分时钟发生变化。漂移符号与 Brownian 增量按 \(\sqrt{d\tau}\) 缩放，应分别处理。





反向漂移不是简单把 \(f\) 取负。给定当前带噪状态，哪些前向样本更可能到达这里取决于当前密度，这正是 score 修正的来源。仅使用 \(-f\) 会遗漏这种分布条件信息。具体高斯例可以通过已知联合高斯的反向条件分布核对这条关系。





生成需要从 \(p_T\) 抽样。若训练日程的终端仍含明显数据信息，直接用 \(\mathcal N(0,I)\) 替代 \(p_T\) 会引入先验失配；时间反演定理本身不会修复这个替代。网络 score 的近似误差、数值离散误差和终端分布误差应分开分析。





$$
dY_\tau=\left[-f(Y_\tau,T-\tau)+g(T-\tau)^2s_{T-\tau}(Y_\tau)\right]d\tau+g(T-\tau)\,d\bar W_\tau
$$





## 概率流 ODE：从同一个密度方程推导 1/2 系数

概率流 ODE 是与给定扩散过程具有相同边际密度演化的确定性微分方程。它用一个速度场替代随机扰动所产生的概率通量，但样本轨迹分布并不相同。下面从本章的密度方程推导这个速度。





利用 \(\nabla p=p\nabla\log p\)，把 Fokker–Planck 中的扩散项写成散度：





\[\frac{g^2}{2}\Delta p=\nabla\!\cdot\!\left[\frac{g^2}{2}p s_t\right]\]





将它与漂移通量合并，得到连续性方程 \(\partial_t p=-\nabla\!\cdot(pu_t)\)，其中 \(u_t=f-\frac{g^2}{2}s_t\)。满足适当的解存在性、唯一性与边界条件时，ODE \(\frac{dX}{dt}=u_t\) 与原 SDE 具有相同的各时刻边际密度。



### 例：同样保持标准高斯，样本可以运动，也可以静止

1. 考虑平稳单位高斯上的 VP 过程。取 β=2，在 x=1 处，Score 为 −1，前向漂移 \(f=-\beta x/2=-1\)，扩散强度 \(g=\sqrt2\) 不为零。

2. 概率流 ODE 的速度为 \(f-(g^2/2)s=-1-(2/2)(-1)=0\)，所以它的每个初始样本在这个平稳例子中保持原位。

3. SDE 仍有漂移和随机增量，单个样本继续运动，但群体的标准高斯边际不变。对反向时钟，反向 SDE 在这里也仍有非零随机项；这不是“把反向 SDE 的噪声删掉”得到的 ODE。

相同边际分布描述各时刻的样本群体，不要求相同的单条轨迹或多时刻联合分布。连续方程的这一关系也不意味着任意有限步离散器都精确保持边际。

这里的“一样”只针对边际分布 \(p_t\)，不表示样本路径、给定两端点的条件过程或多时刻联合分布相同。SDE 持续注入随机增量，ODE 在给定初始点后是确定的。逆向生成时，把这个 ODE 从 \(T\) 积分到 0，或使用 \(\tau\) 时钟下的 \(-f+\frac{g^2}{2}s_t\)。





反向 SDE 的 score 系数是 \(g^2\)，概率流 ODE 的系数是 \(g^2/2\)。因子不同来自它们密度方程中是否还含随机扩散项。不能删除反向 SDE 的随机项但保留原漂移，声称得到了概率流 ODE。





完整代码在一个二维高斯混合密度上，用 Autograd 分别计算时间导数、Fokker–Planck 右端和 ODE 连续性方程右端，逐点核对恒等式。这是公式层面的验证；学习到的 score 只有近似准确时，实际生成边际也只能近似遵循上述关系。





$$
\begin{aligned}\partial_tp_t&=-\nabla\cdot(f p_t)+\tfrac12g^2\nabla\cdot(p_ts_t)\\&=-\nabla\cdot\!\left[p_t\left(f-\tfrac12g^2s_t\right)\right],\\u_t(x)&=f(x,t)-\tfrac12g(t)^2s_t(x).\end{aligned}
$$





## 从 Score 与噪声推导速度场，而不是交换输出名称

输出参数化规定网络预测噪声、Score 还是路径速度。它们在声明的加噪路径下可通过条件均值关系联系，却不是给同一个输出换名字。下面明确路径系数与时间方向，再推导转换。





继续使用仿射随机路径 \(X_t=\alpha_t A+\sigma_t E\)，假设系数可微、\(A\) 与标准高斯 \(E\) 独立。固定端点时的路径导数为 \(U_t=\dot\alpha_t A+\dot\sigma_t E\)；边际速度是 \(v_t(x)=\mathbb E[U_t\mid X_t=x]\)。这一步与 Flow Matching 的条件期望原理一致。要与某个 SDE 的概率流比较，还需要这条概率路径确实是那个 SDE 的边际路径。





已知边际 score 后，\(\mathbb E[E\mid X_t=x]=-\sigma_t s_t(x)\)。再对 \(X_t=\alpha_t A+\sigma_t E\) 条件化，在 \(\alpha_t\ne0\) 的位置解出：





\[\mathbb E[A\mid X_t=x]=\frac{x+\sigma_t^2s_t(x)}{\alpha_t}\]





将两式代入条件速度，得到下面的通用仿射路径公式。转换不是把一次训练配对的隐藏 \(A\) 和 \(E\) 直接暴露给模型，而是转换它们的条件均值。





以 VP 路径为例，\(\dot\alpha/\alpha=-\beta/2\)，且 \(2\sigma\dot\sigma=\beta\alpha^2\)。由 \(\alpha^2+\sigma^2=1\)，速度中 score 的系数变为 \(-\beta/2\)，因此 \(v_t=-\beta x/2-\beta s_t/2\)，恰好等于前文概率流 ODE。这里两种推导一致，是因为 Gaussian 条件路径与 VP SDE 匹配。对于具有同一 Gaussian 条件加噪核、漂移 \(f(x,t)=\frac{\dot\alpha}{\alpha}x\) 的线性前向扩散，扩散系数必须满足 \(g^2=2\sigma\dot\sigma-2\frac{\dot\alpha}{\alpha}\sigma^2\ge0\)；任意指定的 \(\alpha\)、\(\sigma\) 不一定满足这个条件。这个限制仅针对该线性条件扩散，并不表示边际路径不能由任何 SDE 实现。若允许漂移依赖数据分布，在适当正则条件下可选非负 \(g^2\) 并令 \(f=v+\frac12g^2s\)，使 Fokker–Planck 方程仍对应同一边际 \(p_t\)。





若用 FM 的噪声到数据时间 \(r=1-t\)（取 \(T=1\)），同一条轨迹关于 \(r\) 的速度为 \(-v_{1-r}\)。因此路径系数、导数、时间输入和步长必须整体转换。另一个常见“\(v\) prediction”定义为 \(\alpha E-\sigma A\)；当 \(\alpha=\cos\varphi\)、\(\sigma=\sin\varphi\) 时，它是关于角度 \(\varphi\) 的导数，关于实际时间 \(t\) 的导数还要乘 \(\dot\varphi(t)\)。不能把它与任意 FM 速度直接等同。





变换在 \(\alpha=0\) 或 \(\sigma=0\) 的端点可能不再可逆，附近也可能放大预测误差。训练损失还会因缩放而获得不同时间权重。比较参数化时需要同时给出有效时间区间、噪声等级采样、输出转换和损失权重；仅比较网络输出的张量形状没有判别力。





$$
\begin{aligned}\widehat\epsilon_t(x)&=-\sigma_t s_t(x),&
\widehat a_t(x)&=\frac{x+\sigma_t^2s_t(x)}{\alpha_t}\\v_t(x)&=\dot\alpha_t\widehat a_t(x)+\dot\sigma_t\widehat\epsilon_t(x)\\&=\frac{\dot\alpha_t}{\alpha_t}x+
\left(\frac{\dot\alpha_t}{\alpha_t}\sigma_t^2-\sigma_t\dot\sigma_t\right)s_t(x).
\end{aligned}
$$





## 同一二维分布上的两条路径：从混合责任到速度

概率路径是一组随时间变化的分布，规定起点、终点之间每个阶段应如何分布。同一对端点可以由不同路径连接。下面用同一个二维混合数据，比较 VP 加噪路径与线性插值路径的中间状态。





沿用[前章的数据分布](#/learn/diffusion?tab=theory&section=0)，以 \(Y\) 表示干净数据、\(Z\sim\mathcal N(0,I)\) 表示独立噪声，\(c\) 表示条件。为统一图中的方向，这一例子用生成时钟 \(r\in[0,1]\)：\(X_r=\alpha_rY+\sigma_rZ\)。线性 FM 取 \((\alpha_r,\sigma_r)=(r,1-r)\)；VP 图示取 \((\sin(\pi r/2),\cos(\pi r/2))\)。两者起点与终点相同，系数却不相同；不能只把 \(r\) 改名就把一条路径变成另一条。





给定混合分量 \(J=j\)，独立 Gaussian 相加得到 \(X_r\mid J=j,c\sim\mathcal N(\alpha_r\mu_{cj},q_rI)\)，其中 \(q_r=\alpha_r^2s_d^2+\sigma_r^2\)。用 Bayes 公式得到责任权重 \(\rho_j=P(J=j\mid X_r=x,c)\)：\[\rho_j=\operatorname{softmax}_j\!\left(\log w_{cj}-\frac{\|x-\alpha_r\mu_{cj}\|^2}{2q_r}\right).\]所有分量共享 \(q_r\)，相同的 Gaussian 归一化常数在权重里抵消；密度本身仍必须保留该常数。

![同一条件双峰数据经过线性与 VP 两条路径时，端点相同而内部密度不同](../assets/figures/generative-shared-paths.svg)

原创计算图：固定条件 c=0，用同一组混合参数解析计算 pᵣ。列方向为噪声到数据；每一格是一个时刻的密度，不是某条 Brownian 样本轨迹。VP 行采用用于比较的连续余弦/正弦日程，与 DDPM 演示的有限离散日程区分。



对混合密度求导，Score 是分量 Score 的责任加权平均：\[s_r(x\mid c)=-\sum_j\rho_j\frac{x-\alpha_r\mu_{cj}}{q_r}.\]再利用联合 Gaussian 的条件均值公式，固定分量时有 \(\mathbb E[Y\mid x,j,c]=\mu_{cj}+\frac{\alpha_rs_d^2}{q_r}(x-\alpha_r\mu_{cj})\)、\(\mathbb E[Z\mid x,j,c]=\frac{\sigma_r}{q_r}(x-\alpha_r\mu_{cj})\)。分别按 \(\rho_j\) 平均，就能独立验证 \(\widehat Z=-\sigma_rs_r\) 和 \(\widehat Y=(x+\sigma_r^2s_r)/\alpha_r\)，后一式仅在 \(\alpha_r\ne0\) 使用。





最后计算 \(v_r=\dot\alpha_r\widehat Y+\dot\sigma_r\widehat Z\)。对线性路径，这就是 \(\mathbb E[Y-Z\mid X_r=x,c]\)；对 VP 路径，两个系数的导数分别为 \(\frac\pi2\cos(\pi r/2)\)、\(-\frac\pi2\sin(\pi r/2)\)，不能仍使用 \(Y-Z\)。完整代码对两种场分别检查 \(\partial_rp_r=-\nabla\cdot(p_rv_r)\)，从密度演化而非箭头外观验证速度含义。





VP 的前向时钟为 \(\tau=1-r\)。在 \(0<\tau<1\) 上，与图示条件边际对应的线性扩散有 \(\beta(\tau)=\pi\tan(\pi\tau/2)\)，并满足 \(dX_\tau=-\frac12\beta X_\tau d\tau+\sqrt\beta\,dW_\tau\)。由前文概率流公式并取 \(d\tau=-dr\)，生成时钟下的速度为 \(v_r(x\mid c)=+\frac12\beta(1-r)[x+s_r(x\mid c)]\)；这个正号来自时间反向，不是重新定义 Score。\(\tau\to1\) 时该日程奇异，图上的标准 Gaussian 端点表示边际极限；不能把发散的 \(\beta(1)\) 代入有限步 SDE。前章离散 DDPM 代码采用另一条有限日程，终端信号非零，图示 VP 曲线不是其逐步样本轨迹。





固定一对 \((Y,Z)\) 随时间画出的 \(\alpha_rY+\sigma_rZ\) 是条件插值；前向 SDE 的 Brownian 增量会持续重采样。它们可以对应相同的单时刻扰动核，却不具有相同的多时刻联合分布。图展示的是精确边际密度，代码核验解析恒等式；[FM 多峰实验](#/learn/flow-matching?tab=code&anchor=demo-conditional-mixture)另行展示学习场与数值积分误差。









## DDPM、DDIM、Score 与 Flow：等价到哪一层

方法等价需要说明比较的是哪一层：输出的代数转换、理想边际分布、训练目标，还是有限步采样结果。前面只建立了带条件的联系。下面据此分别定位 DDPM、DDIM、Score 与 Flow。





DDPM 指定离散前向加噪链和反向生成模型，其变分目标可以转成带时间权重的噪声回归；Denoising Score Matching 通过已知条件核学习中间边际 score。对同一个 Gaussian 扰动路径，噪声预测与 score 可以按前面的系数转换，但简化目标与加权目标并不自动相同。





DDIM 在保持相应训练边际与回归接口的同时，构造另一类采样过程；\(\eta=0\) 时给定初始噪声后可以确定性生成。它与连续 ODE 视角相关，但有限网格更新不应未经推导就等同于任意 Euler 或 Heun 离散式。采样过程、训练目标和模型参数化需要分别列清楚。





Flow Matching 直接回归所选概率路径的速度。使用与扩散一致的 Gaussian 路径时，可以把 score 学习和速度学习联系起来；采用线性端点插值等其他路径时，中间分布与数值几何会改变。Rectified Flow 的基础直线路径回归与这种条件流形式密切相关，Reflow 则进一步用学得流重新配对端点。





几种方法都可用于条件动作片段，但训练数据、条件编码器、动作坐标和归一化协议仍是独立设计。理论上的边际对应也不保证有限网络、有限训练、离散采样下达到相同质量。可靠的比较先固定数据与条件，再报告路径、训练权重、网络调用次数、随机性和闭环结果。





后续的 [Flow Matching 专题](#/learn/flow-matching?tab=theory)保留完整的连续性方程与条件期望推导，并用有解析边际场的二维多峰分布分别测量学习误差和积分误差。SDE 求解器则还需要针对随机误差选择强/弱收敛等评价标准，不能直接用 ODE 的逐路径误差阶数替代。





Score 提供分布的局部信息，SDE 与 ODE 则把局部运动连接到整体密度变化。只有固定路径、时间约定与正则条件，才能判断噪声、Score、速度和采样器之间哪些关系成立。







### 比较生成方法时固定的四个对象

| 方法视角 | 训练监督 | 中间分布/路径 | 生成机制 |

|---|---|---|---|

| DDPM | 后验均值或等价噪声等参数化；权重由目标决定 | 离散 Gaussian 前向加噪边际 | 带指定方差的反向 Markov 链 |

| Score / SDE | 条件核 score 或等价噪声回归 | 所选前向 SDE 的扰动边际 | 反向 SDE 或对应概率流 ODE |

| DDIM | 可复用相应噪声预测接口 | 与训练匹配的累计信号/噪声系数 | 指定 \(\eta\) 与非相邻时间网格的更新 |

| Flow Matching | 条件路径速度的平方误差回归 | 可选择扩散路径或其他可用路径 | 积分学习到的边际速度场 |



## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| \(x\) / \(\widehat\epsilon\) / \(s\) / \(v\) | \([B,D]\) | 状态、噪声估计、score 与速度均是 \(D\) 维向量，但含义及尺度不同 |
| \(\alpha\) / \(\sigma\) / \(\dot\alpha\) / \(\dot\sigma\) | \([B]\) → [\(B\),1] | 每样本时间对应的路径系数及其对指定时间的导数 |
| \(c\) | 由条件编码器约定 | 所有状态求导和条件期望中保持固定的观测条件 |
| \(h\) / \(\Delta W\) | 标量 / \([B,D]\) | 正积分时长与方差 \(h\) 的 Brownian 增量 |

## 完整代码与精读

```python
"""One conditional mixture, two marginal paths, exact score/velocity/PDE checks."""
import json
import math
from pathlib import Path
import torch

torch.set_num_threads(1)
torch.set_default_dtype(torch.float64)
torch.manual_seed(20261106)
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


def coefficients(t, path):
    # t is ALWAYS noise -> data here. The diffusion forward clock is tau=1-t.
    if path == "linear":
        return t, 1-t, torch.ones_like(t), -torch.ones_like(t)
    if path == "vp":
        angle = math.pi*t/2
        a, s = angle.sin(), angle.cos()
        return a, s, math.pi*s/2, -math.pi*a/2
    raise ValueError("path must be linear or vp")


def mixture(x, t, condition, path):
    a, s, ad, sd = coefficients(t, path)  # t is a scalar tensor in this example
    q = a.square()*DATA_STD**2 + s.square()
    means, weights = MEANS.to(x)[condition], WEIGHTS.to(x)[condition]
    residual = x[:, None, :] - a*means  # [B,K=2,D=2]
    logits = weights.log()-residual.square().sum(-1)/(2*q)
    logp = torch.logsumexp(logits, -1)-x.shape[-1]/2*torch.log(2*math.pi*q)
    rho = logits.softmax(-1)
    score = -(rho[:, :, None]*residual).sum(1)/q
    clean_mean = (rho[:, :, None]*(means+a*DATA_STD**2/q*residual)).sum(1)
    noise_mean = (rho[:, :, None]*(s/q*residual)).sum(1)
    velocity = ad*clean_mean+sd*noise_mean  # conditional expectation, not pair target
    return logp, score, clean_mean, noise_mean, velocity


def divergence(vector, x):
    return sum(torch.autograd.grad(vector[:, j].sum(), x, create_graph=True,
                                   retain_graph=True)[0][:, j] for j in range(x.shape[1]))


def run(output="score_mixture_results.json"):
    rows = []
    for path in ("linear", "vp"):
        x = torch.tensor([[0.2,-0.3], [1.4,0.2], [-1.2,0.4]], requires_grad=True)
        condition = torch.tensor([0, 1, 0])
        t = torch.tensor(0.4, requires_grad=True)
        logp, score, clean, noise, velocity = mixture(x,t,condition,path)
        a, s, ad, sd = coefficients(t,path)
        exact_score = torch.autograd.grad(logp.sum(),x,create_graph=True)[0]
        torch.testing.assert_close(score,exact_score,atol=1e-11,rtol=1e-10)
        torch.testing.assert_close(noise,-s*score,atol=1e-11,rtol=1e-10)
        torch.testing.assert_close(clean,(x+s.square()*score)/a,atol=1e-11,rtol=1e-10)
        from_score = ad/a*x+(ad/a*s.square()-s*sd)*score
        torch.testing.assert_close(velocity,from_score,atol=1e-11,rtol=1e-10)

        # Continuity equation on the GENERATION clock for both paths.
        p = logp.exp()
        dpdt = torch.stack([torch.autograd.grad(p[i],t,retain_graph=True)[0]
                           for i in range(len(p))])
        continuity = -divergence(p[:,None]*velocity,x)
        torch.testing.assert_close(dpdt,continuity,atol=1e-11,rtol=1e-9)
        row = {"path": path, "score_max_error": (score-exact_score).abs().max().item(),
               "continuity_max_error": (dpdt-continuity).abs().max().item()}

        if path == "vp":
            # Forward tau=1-t: beta(tau)=pi*tan(pi*tau/2)=pi*s/a.
            # beta diverges at tau=1: use interior times, not this endpoint formula.
            beta = math.pi*s/a
            forward_drift = -0.5*beta*x
            gradp = torch.autograd.grad(p.sum(),x,create_graph=True,retain_graph=True)[0]
            fp = -divergence(p[:,None]*forward_drift,x)+0.5*beta*divergence(gradp,x)
            torch.testing.assert_close(-dpdt,fp,atol=1e-11,rtol=1e-9)
            torch.testing.assert_close(velocity,0.5*beta*(x+score),atol=1e-11,rtol=1e-10)
            row["forward_fp_max_error"] = (-dpdt-fp).abs().max().item()
        rows.append(row)

    # Endpoints match, intermediate densities differ. No neural net is trained here.
    x = torch.tensor([[0.2,-0.3], [1.4,0.2], [-1.2,0.4]])
    condition = torch.tensor([0,1,0])
    for endpoint in (0.0,1.0):
        t = torch.tensor(endpoint)
        torch.testing.assert_close(mixture(x,t,condition,"linear")[0],
                                   mixture(x,t,condition,"vp")[0])
    t = torch.tensor(0.5)
    assert not torch.allclose(mixture(x,t,condition,"linear")[0],
                              mixture(x,t,condition,"vp")[0])
    # Pairwise paths with the SAME fixed noise must not be called Brownian sample paths.
    clean, noise = torch.randn(3,2), torch.randn(3,2)
    h = 1e-5
    for path in ("linear","vp"):
        a,s,ad,sd = coefficients(t,path)
        ap,sp,_,_ = coefficients(t+h,path)
        am,sm,_,_ = coefficients(t-h,path)
        finite_difference = ((ap*clean+sp*noise)-(am*clean+sm*noise))/(2*h)
        torch.testing.assert_close(finite_difference,ad*clean+sd*noise,atol=1e-9,rtol=1e-9)
    # Retain the stationary-Gaussian sign check from the original implementation.
    beta = 1.3
    stationary_score = -x
    forward_drift = -0.5*beta*x
    torch.testing.assert_close(forward_drift-0.5*beta*stationary_score,torch.zeros_like(x))
    torch.testing.assert_close(-forward_drift+beta*stationary_score,-0.5*beta*x)
    result = {"torch":torch.__version__,"device":"cpu","dtype":"float64",
              "means":MEANS.tolist(),"weights":WEIGHTS.tolist(),"data_std":DATA_STD,
              "checks":rows,"endpoints_equal":True,"middle_paths_differ":True,
              "limits":["Analytic identity checks, not trained generation results.",
                         "The VP interpolation gives SDE marginals, not Brownian trajectories.",
                         "Score-to-output division is only used at interior times."]}
    Path(output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    return result


if __name__ == "__main__":
    run()

```

- 第 9–24 行：复用 Diffusion/FM 的数据参数。此文件统一以 t=0 噪声、t=1 数据；VP 的前向扩散时钟是 τ=1−t，不可把两个方向的导数混用。
- 第 27–39 行：先得到每个 Gaussian 分量的中间均值和方差，再用 Bayes 责任权重计算边际密度、Score 及隐藏数据/噪声的条件均值；最终速度是条件速度的后验平均。
- 第 47–69 行：对两条路径分别核对 Autograd 的 \(\nabla_x\log p\)、噪声与数据估计、Score→Velocity，以及生成时钟下的连续性方程；所有比较均在相同点、条件、时间进行。
- 第 71–83 行：VP 的前向 β(τ) 在内部时间为 π·tan(πτ/2)。把生成时钟导数取负后，与前向 Fokker–Planck 核对；端点 β 发散，代码不在端点套该表达式。
- 第 85–111 行：两路径端点密度相同、中间密度不同。固定端点的有限差分只验证插值导数，不把插值当 Brownian 轨迹；另保留平稳标准 Gaussian 的漂移符号检查。

预期观察：float64 下，两条路径的解析 Score 与 Autograd 最大误差均为 4.45×10⁻¹⁶ 以下，连续性与 VP 前向 Fokker–Planck 误差均为 2.23×10⁻¹⁶ 以下（本次 CPU 观测）。代码还检查共同端点、不同中间密度、路径有限差分和标准 Gaussian 平稳性。这些是解析公式验证，没有训练神经网络；运行记录写入 score_mixture_results.json。

## 浏览器 Python 练习

仅用标准库实现 `reverse_vp_step(x,score,h,beta,noise)`。参数 `beta` 对应非负常数 \(\beta\)，\(h>0\) 表示正向增加的反向时钟 \(\tau=T-t\) 的步长；`score` 是当前前向时间 \(t\) 的状态 score，`noise` 是给定标准高斯抽样值。返回概率流 ODE 的 Euler 更新与反向 SDE 的 Euler–Maruyama 更新。拒绝非法步长和非有限值。

```python
def reverse_vp_step(x, score, h, beta, noise):
    # TODO: 两种漂移的 score 系数不同；SDE 噪声尺度为 sqrt(beta*h)。
    raise NotImplementedError

```

### 提示

- 前向 VP 漂移是 \(-\beta x/2\)，改为正的反向时钟后先取负号。
- ODE 的 score 系数为 beta/2，SDE 的系数为 beta。
- 用平稳高斯的 \(s(x)=-x\) 检查：ODE 速度应为零。

### 参考实现与解释

```python
import math

def reverse_vp_step(x, score, h, beta, noise):
    values = (x, score, h, beta, noise)
    if not all(math.isfinite(float(v)) for v in values) or h <= 0 or beta < 0:
        raise ValueError("finite values, h>0 and beta>=0 are required")
    # h advances tau=T-t, so the forward-time drift changes sign.
    ode = x + h * (0.5 * beta * x + 0.5 * beta * score)
    sde = x + h * (0.5 * beta * x + beta * score) + math.sqrt(beta*h) * noise
    return ode, sde

```

两个方法的差异同时包含漂移和随机项；删除 SDE 噪声而不改变漂移不是概率流 ODE。测试中的平稳高斯反例可以直接发现这一错误。

### 断言测试

```python
import math
ode, sde = reverse_vp_step(2.0, -2.0, 0.1, 1.0, 0.0)
assert math.isclose(ode, 2.0)
assert math.isclose(sde, 1.9)
ode, sde = reverse_vp_step(1.0, -0.4, 0.04, 2.0, 1.5)
assert math.isclose(ode, 1.024)
assert math.isclose(sde, 1.008 + math.sqrt(0.08)*1.5)
assert reverse_vp_step(3.0, 8.0, 0.1, 0.0, 99.0) == (3.0, 3.0)
for h, beta in [(0.0,1.0), (-0.1,1.0), (0.1,-1.0), (float("nan"),1.0)]:
    try:
        reverse_vp_step(0.0, 0.0, h, beta, 0.0)
        raise AssertionError("invalid step accepted")
    except ValueError:
        pass
print("passed: reverse clock, different score coefficients and sqrt(h) noise")

```

## 本地 PyTorch 练习

实现 `gaussian_path_quantities(noisy,eps_hat,alpha,sigma,alpha_dot,sigma_dot)`。`noisy` 和 `eps_hat` 为 \([B,D]\)，四个系数均为 \([B]\) 且采用同一个时间变量；仅处理 \(\alpha>0\)、\(\sigma>0\) 的内部时间区间。返回干净样本估计、score 估计和速度估计，保留梯度并正确广播；拒绝错误形状、非有限值和奇异端点。

```python
def gaussian_path_quantities(noisy, eps_hat, alpha, sigma, alpha_dot, sigma_dot):
    # TODO: 先恢复 clean_hat，再用路径导数组合 velocity_hat。
    raise NotImplementedError

```

### 提示

- 系数 \([B]\) 必须扩成 [\(B\),1]，否则 \(B\) 与 \(D\) 相同时可能掩盖广播错误。
- `score_hat = -eps_hat / sigma`。
- `velocity_hat = alpha_dot * clean_hat + sigma_dot * eps_hat`；不要把噪声估计直接当作速度。

### 参考实现与解释

```python
import torch

def gaussian_path_quantities(noisy, eps_hat, alpha, sigma, alpha_dot, sigma_dot):
    if (not torch.is_tensor(noisy) or noisy.ndim != 2 or noisy.numel() == 0
            or not noisy.is_floating_point() or not torch.is_tensor(eps_hat)
            or eps_hat.shape != noisy.shape):
        raise ValueError("noisy and eps_hat must be nonempty [B,D] tensors")
    values = (eps_hat, alpha, sigma, alpha_dot, sigma_dot)
    if any(not torch.is_tensor(v) or v.dtype != noisy.dtype or v.device != noisy.device
           for v in values):
        raise ValueError("dtype and device must match")
    if any(v.shape != (noisy.shape[0],) for v in (alpha,sigma,alpha_dot,sigma_dot)):
        raise ValueError("path coefficients must have shape [B]")
    if not all(torch.isfinite(v).all() for v in (noisy,*values)):
        raise ValueError("inputs must be finite")
    if (alpha <= 0).any() or (sigma <= 0).any():
        raise ValueError("this conversion is restricted to alpha>0, sigma>0")
    a, s, ad, sd = (v[:,None] for v in (alpha,sigma,alpha_dot,sigma_dot))
    clean_hat = (noisy - s * eps_hat) / a
    score_hat = -eps_hat / s
    velocity_hat = ad * clean_hat + sd * eps_hat
    return clean_hat, score_hat, velocity_hat

```

测试先用已知端点验证代数关系，再用 gradcheck 核对导数，并验证 \(\sigma^2\) 加权 score MSE 与噪声 MSE 的数值和梯度相同。这些已知端点是公式检验用的 oracle，不是部署时能获得的真实噪声标签。

### 断言测试

```python
import torch
torch.manual_seed(37)
torch.set_default_dtype(torch.float64)
B, D = 3, 2
clean, noise = torch.randn(B,D), torch.randn(B,D)
t = torch.tensor([0.2,0.4,0.7])
alpha, sigma = t, 1-t
alpha_dot, sigma_dot = torch.ones_like(t), -torch.ones_like(t)
noisy = alpha[:,None]*clean + sigma[:,None]*noise
a_hat,s_hat,v_hat = gaussian_path_quantities(noisy,noise,alpha,sigma,alpha_dot,sigma_dot)
torch.testing.assert_close(a_hat,clean)
torch.testing.assert_close(s_hat,-noise/sigma[:,None])
torch.testing.assert_close(v_hat,clean-noise)
noisy = noisy.requires_grad_()
estimate = (noise + 0.15*torch.randn_like(noise)).requires_grad_()
assert torch.autograd.gradcheck(
    lambda x,e: gaussian_path_quantities(x,e,alpha,sigma,alpha_dot,sigma_dot),
    (noisy,estimate))
_,score_hat,_ = gaussian_path_quantities(noisy,estimate,alpha,sigma,alpha_dot,sigma_dot)
noise_loss = (estimate-noise).square().sum()
weighted_score_loss = (sigma[:,None].square()*(score_hat+noise/sigma[:,None]).square()).sum()
torch.testing.assert_close(noise_loss,weighted_score_loss)
g1 = torch.autograd.grad(noise_loss,estimate,retain_graph=True)[0]
g2 = torch.autograd.grad(weighted_score_loss,estimate)[0]
torch.testing.assert_close(g1,g2)
try:
    gaussian_path_quantities(noisy,estimate,alpha,torch.zeros_like(sigma),alpha_dot,sigma_dot)
    raise AssertionError("singular endpoint accepted")
except ValueError:
    pass
print("passed: non-square dimensions, parameter conversion, loss weights and gradients")

try:
    gaussian_path_quantities(noisy,[[0.0]],alpha,sigma,alpha_dot,sigma_dot)
    raise AssertionError("non-tensor estimate accepted")
except ValueError:
    pass

```

## 练习：推导与分析

### 为什么条件 score 不等于边际 score，却可以作为训练目标？

同一个 \(x\),\(t\) 可能来自多个干净样本与噪声配对。边际 score 是条件 score 在这些隐藏配对后验下的平均。

平方误差将目标分解为到条件均值的模型误差与独立于模型参数的条件方差，因此共享总体最优解；单样本梯度仍然不同。

代码定位：mixture 函数的 rho、clean_mean 与 noise_mean；先固定条件 c，再对分量作后验平均。

- 写出边际密度求导
- 指出后验权重
- 说明总体等价与随机梯度的差别

### 相同边际密度为什么允许 SDE 在运动、ODE 却静止？

平稳高斯的随机扩散与收缩漂移可以互相抵消，使密度不变，但单条随机轨迹仍在变化。

概率流把密度的净变化写成确定性通量；在这个例子中该通量为零，因此 ODE 保持每个初值。相同边际不等于相同路径分布。

代码定位：完整代码末尾 stationary_score 的符号检查与 reverse_vp_step 的第一项测试。

- 计算两个漂移
- 解释扩散平衡
- 区分边际与路径

### 同一个二维数据分布同时使用线性 FM 与 VP 路径，为什么不能直接比较两种网络的原始 MSE，或认定同一初始噪声会得到同一终点？

固定状态、时间和同一路径时，噪声误差换成速度误差会乘 \((\dot\sigma-\dot\alpha\sigma/\alpha)^2\)。改变路径还改变训练状态分布，因此原始 MSE 的单位、时间权重和输入分布均可能不同。

两种精确场可以产生相同终点边际，但不必实现相同的端点耦合。共享初始噪声适合做受控计算，却不能把逐点终点差直接解释为哪一种生成分布更差。

先固定数据、条件和评价分布，再分别报告路径、预测目标、时间采样、NFE 和数值误差；有限训练观察不升级为方法优劣定理。

代码定位：同一 mixture 函数切换 path；在 t=0、t=1 对照密度，再比较内部时刻和路径系数。

- 说明共享数据不等于共享中间分布。
- 给出同一路径参数化误差的时间系数。
- 区分边际分布与端点耦合。

## 练习：辨析与纠错

### 把 score 理解成某个样本的概率大小

Score 是状态方向上的 log 密度梯度，维度与样本相同。它不能单独替代归一化密度或 `log_prob`，连续流求密度还需要相应的散度积分与初始密度。

### 忽略反向时钟导致两次变号

使用下降的前向时间 \(t\) 与使用上升的 \(\tau=T-t\) 是两套等价约定；目标时间、漂移符号和步长必须整体匹配。

### 从反向 SDE 删除随机项就称为概率流 ODE

反向 SDE 的 score 修正系数是 \(g^2\)，而概率流 ODE 是 \(g^2/2\)；随机扩散对密度演化的贡献不能凭空消失。

### 把所有 velocity 名称当成相同参数化

线性 FM 的端点差、一般仿射路径的时间导数、VP 的角度 \(v\) 参数化都依赖不同定义。应从路径系数及导数进行转换，端点也可能不可逆。

### 用更多积分步数修复错误模型

细化同一个场只减少相应数值误差，不保证修复 score/velocity 偏差、条件缺失或终端先验失配；三类误差应做分离实验。

## 原始资料

- [Hyvärinen · Score Matching（分部积分与边界假设）](https://jmlr.org/papers/v6/hyvarinen05a.html)
- [Vincent · A Connection Between Score Matching and Denoising Autoencoders](https://doi.org/10.1162/NECO_a_00142)
- [Song et al. · Score-Based Generative Modeling through SDEs](https://arxiv.org/abs/2011.13456)
- [Ho et al. · Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239)
- [Song et al. · Denoising Diffusion Implicit Models](https://arxiv.org/abs/2010.02502)
- [Lipman et al. · Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747)
- [Salimans & Ho · Progressive Distillation（VP 的 v 参数化）](https://arxiv.org/abs/2202.00512)
- [Yang Song · 作者对 Score、反向 SDE 与概率流 ODE 的推导说明](https://yang-song.net/blog/2021/score/)
