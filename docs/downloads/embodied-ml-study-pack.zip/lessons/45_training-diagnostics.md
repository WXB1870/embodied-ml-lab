# 训练诊断

从“loss 不降”走到可重复、可定位的具体证据。

训练诊断是把损失异常等现象转化为可区分假设，并用受控计算与对照定位首次偏离预期环节的过程。它不同于凭经验同时调整多个超参数。我们先建立样本、前向、目标、梯度和更新的完整链，再为各环节定义可观察基准，最后以单因素修复和回归检查结束排查。

## 学习目标

- 沿数据、计算图、梯度和优化器逐层收集证据。
- 区分无梯度、零梯度、非有限梯度与未更新参数。
- 设计小样本拟合和单变量对照，判断能排除什么问题。

前置知识：[PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [训练循环与指标归约](https://wxb1870.github.io/embodied-ml-lab/learn/training-loop/) · [混合精度训练](https://wxb1870.github.io/embodied-ml-lab/learn/mixed-precision/)

## 把训练拆成一条可检查的证据链

诊断证据链是按训练依赖顺序排列的一组可观察事实：数据正确、预测合理、目标匹配、梯度连通、更新发生。每项事实用于支持或排除具体假设。先建立这条链，再从异常结果定位首次分歧。





训练曲线不变只是现象，原因可能发生在数据、预处理、前向、损失、反向或更新。先建立顺序明确的证据链：样本和标签是否对应，模型看到的输入是否正确，预测是否依赖预期条件，loss 是否表达目标，参数是否收到梯度，优化器是否真正修改了这些参数。每一步都应有一个可以观察或断言的结果。





优先检查最早出现异常的位置。例如输入已经全零，后面的梯度图再完整也不能恢复缺失信息；目标被错位但模型能记住它，loss 可能下降得很好。不要把“能运行”“loss 有限”“有非零梯度”当作同一层次的正确性证明。将这些事实分开记录，能避免因一个指标正常就过早排除整条管线。





最小复现应保留引发问题的形状、Mask、模式和目标定义，同时去掉无关数据加载、日志服务和分布式组件。缩小系统是为了减少解释变量，不能把触发错误的条件一并删掉，再宣称原问题已消失。









## 先审查一条样本，再审查一个 Batch

样本审查核对单条观测与标签的含义，批次审查核对拼接、填充和采样是否保持这些对应。两者检查不同层级。保留样本身份并追到损失，可以让问题从最终曲线回到具体记录。





在进入模型前检查原始样本与预处理后的 Tensor：值域、单位、通道顺序、类别编码、时间偏移、有效位和字段顺序。对图像可视化增强后输入，对序列列出时间戳与对应目标。将样本 ID 一直保留到 loss 计算，可以判断 shuffle、collate 或窗口切片是否错配。一个 shape 正确的 Batch 仍可能由不属于同一时刻的数据组成。





再查看同一 Batch 内是否存在重复样本、全无效样本、异常长序列或权重集中。用简单基线比较目标难度：连续目标的常数均值、分类的多数类或均匀概率，可以帮助发现训练效果是否仅达到平凡预测。基线只能参照，不能替代任务含义；若标签泄漏，复杂模型和基线都可能得到误导性结果。





可以再做标签置乱对照：在明确独立验证的前提下，随机打乱训练标签后，模型不应仍保持原先的样本外识别能力。若结果几乎不变，应检查目标是否被读取、指标是否使用真实标签、划分是否泄漏，以及模型是否仅利用类别频率。这个实验用于排查监督与评估管线，不是评价正式模型的最终方案。









### 保留可追踪的样本 ID 与数据约定

否则最终错误难以回溯到原始轨迹和具体变换。

抽取一个样本贯通 Dataset、collate、模型输入和 loss，逐项对照同一 ID。

## 预测与 loss 的合理数量级如何检查

数值基准是对特定输入和参数可以手算的预期输出或损失，例如零 Logit 的分类代价。它提供独立参照，而不是凭经验猜测合理数量级。下面先让模型满足可解释基准，再恢复复杂配置。





对已知输入和简单参数设置预测输出。例如把线性分类器权重与偏置清零，会得到相同 logits，单标签 K 类交叉熵应为 log K；回归模型输出零时，MSE 应等于目标平方的平均。这样的基准比经验判断“loss 大约应该是 1”更可靠，因为它来自当前目标的明确定义。



### 例：用均匀分类器检查接口

1. 四类 logits 全为 0，Softmax 概率均为 \(\frac14\)。

2. 无类别权重、无特殊归约的单标签交叉熵应为 \(-\log\frac14=\log4\approx1.3863\)。

3. 若结果明显不同，先检查标签类型、重复 Softmax、ignore_index 与类别权重。

确定性基准能把 loss 解释从猜测变成可复查计算。

检查 loss 时将分项、误差和与有效数分别打印。总 loss 不变可能是某一项下降而另一项上升，也可能是显示精度不足；loss 突然缩小可能来自 Mask 大量丢失监督，而非预测改善。随机生成目标或噪声重采样会带来不可约波动，应区分单次 batch 误差、固定探针误差和真实独立验证误差。









## 固定小批次实验能证明什么，不能证明什么

固定小批次实验在相同样本、初值和随机性下重复优化，用于检查一条管线是否能够学习已知简单目标。它隔离实现问题，却不估计泛化。实验设计和结论都需要限定在这一用途。





固定少量样本、初始化与随机因素，让模型反复拟合相同目标，是检查管线可学习性的有效方法。先关闭不必要增强和 Dropout，使用明确的损失分母与可解释输出范围；对简单合成目标，应该观察到预测和参数沿正确方向变化。若无法拟合，应优先排查图、标签、优化器与容量，而不是先上更大数据。



### 例：同样输入、相反标签，MSE 能降到多少

1. 两条输入完全相同，目标分别为 −1 和 +1。任何确定性网络对同样输入都只能给出同一个预测 c。

2. 平均平方误差为 \(\tfrac12[(c+1)^2+(c-1)^2]=1+c^2\)，在 c=0 时达到最小值 1。

3. 因此，把确定性网络加宽也不能让这组监督的 MSE 归零。应检查是否遗漏条件、错配标签，或是否需要预测条件概率分布。

小批次拟合前先判断目标是否可实现；这是[条件均值分解](#/learn/probability?tab=theory&section=2)在诊断中的应用。

但错误标签、泄漏输入和错误单位也可能被记住，因此小批拟合通过不证明语义正确或泛化良好。生成模型如果不断重采噪声和时间，训练对象并非固定样本，损失也可能有不可约方差。需要固定完整的条件—噪声—目标三元组做最小过拟合检查，再恢复真实随机训练协议，两种结果分开解释。





少量样本的过拟合速度还受容量和目标复杂度影响，不能要求任意模型都在几步内归零。最小实验的意义是为某个假设提供对照证据，而不是建立一个所有任务必须达到的统一 loss 阈值。





```python
import torch
from torch import nn

torch.manual_seed(41)
target = torch.tensor([[-1.], [1.]], dtype=torch.float64)

def fit_fixed(x):
    model = nn.Linear(1, 1, dtype=torch.float64)
    with torch.no_grad():
        model.weight.zero_()
        model.bias.zero_()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    for _ in range(80):
        optimizer.zero_grad(set_to_none=True)
        loss = (model(x) - target).square().mean()
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        prediction = model(x)
        return float((prediction - target).square().mean()), prediction

representable_loss, _ = fit_fixed(target.clone())
conflicting_loss, prediction = fit_fixed(torch.ones_like(target))
assert representable_loss < 1e-12
torch.testing.assert_close(prediction[0], prediction[1])
torch.testing.assert_close(torch.tensor(conflicting_loss), torch.tensor(1.0))
print("可表示目标的 MSE:", representable_loss)
print("同输入冲突标签的 MSE:", conflicting_loss)

```

两个实验使用相同线性模型、零初始化、优化器和更新次数，仅改变输入是否包含区分标签的信息。后一个实验达到可证明的 MSE 下界，说明“未归零”本身不能证明训练代码错误；前一个阈值只用于这个明确的合成线性问题。



### 固定小批次结果如何改变下一步假设

| 观察 | 能够支持的判断 | 下一项区分实验 |

|---|---|---|

| 手算 loss 基准不符 | 目标或接口尚未得到确认，暂不应归因于容量 | 逐项对照输出、标签移位、有效集合与分母 |

| 基准正确，但简单且可表示的合成目标也拟合失败 | 图连接、更新配置或数值路径仍有问题 | 比较梯度是否存在、优化器成员与实际参数位移 |

| 合成目标能拟合，真实固定批次不能拟合 | 基本链路可工作，但未证明真实数据语义或容量充分 | 检查相同输入的冲突标签、缺失条件、输出约束及任务难度 |

| 固定真实批次能拟合，独立验证较差 | 该有限集合可学习，泛化问题仍未解决 | 统一 train/eval 统计口径，再检查划分、分布覆盖与正则化 |



## 把 None、零梯度和非有限梯度分开定位

None 表示该次检查没有得到参数梯度张量，零梯度表示得到的导数数值为零，非有限梯度表示出现 Inf 或 NaN。它们对应不同求导或数值状态。先区分现象，再沿预期路径排查。





参数 grad=None 可能因为它没有参与当前损失、被 detach、处于冻结状态，或检查时机不对。全零梯度则可能来自激活截断、损失局部平坦、相互抵消或无效监督；Inf/NaN 又是另一类数值异常。检查应放在 backward 后、下一次 zero_grad 前，并明确是叶子参数还是未 retain_grad 的中间激活。





使用 autograd.grad、retain_grad 或局部 hook 可以观察某段依赖，但不应无目的地对所有激活保存完整梯度。先沿期望路径选几个边界，判断信号在哪一处第一次消失。若上游模块之前有可训练参数，冻结模块内部仍可能需要输入梯度；误用 no_grad 就会留下后面有梯度、前面无梯度的典型分界。









### 梯度审计只输出一个全局范数

全局非零可以掩盖某个关键分支完全没有梯度。

按模块记录 None 数量、有限性、范数和有效参数量，再定位首次异常边界。

## 有梯度但不更新：检查优化器与执行边界

参数更新是优化器实际改变参数值的动作，与参数拥有梯度是两种关系。成员遗漏、旧对象、零学习率或跳步都可能让二者分离。下面将对象身份和真实位移作为直接证据。





参数参与求导和参与优化器是两种成员关系。新模块漏加参数组、替换了参数对象、学习率为零或 AMP 跳步，都可能导致有梯度却没有位移。优化器中还可能保留已不再使用的旧参数。应比较参数 ID，而不仅比较名称，并在 step 前后保存 detach().clone() 的快照来测量实际变化。



### 例：两种表面相似的失败

1. 断图案例：主干输出 detach，后面分类器仍有梯度，但主干 grad=None，且主干不移动。

2. 漏加优化器案例：分类器有非零梯度，optimizer.param_groups 却不包含它，分类器位移为零。

3. 两者最终都可能表现为 loss 改善有限，修复位置却分别是计算图和参数组。

同时观察图连接、优化器成员与实际位移，才能分清原因。

如果位移非零但训练仍异常，再检查是否更新了正确对象、是否每次 forward 重新创建层、是否加载 checkpoint 后又覆盖参数、是否验证仍引用旧模型。测量相对位移 \(\frac{\lVert\Delta\theta\rVert_2}{\lVert\theta\rVert_2+\varepsilon}\) 有助于比较不同层，但接近零参数时要解释分母；不要仅按一个统一比例判断所有层应具有相同学习速度。









### 把 optimizer.step 的调用次数当作有效更新次数

缩放器跳步、零学习率和遗漏参数都可能使调用不产生预期更新。

对目标参数记录前后差值、实际 lr、in_optimizer 和 AMP 有限性结果。

## 诊断日志、异常检测与性能剖析各有职责

诊断日志记录选定状态，异常检测定位出错的运算或反向路径，性能剖析测量时间和资源开销。三者回答不同问题。应围绕当前假设选择证据，而不将大量记录本身当作定位。





数值异常可用有限值检查、局部 hook 或 autograd 异常检测定位；训练速度与内存瓶颈需要 profiler、同步计时和分配统计。高耗时不等于梯度错误，低吞吐也可能来自数据读取或频繁 CPU/GPU 同步。不要把每一步大量 item()、打印和全模型梯度拷贝加入正式训练后，再用被诊断工具拖慢的结果判断性能。





日志保存标量或 detach 后的小摘要，避免不断保留带图 GPU 张量。定期抽样记录比每步保存全部激活更适合长期训练。发现异常时保存能重放问题的最小样本、配置、随机状态和错误信息，并减少无关输出。清晰的日志应该让人回答一个假设，而不是产生更多无法解释的曲线。









## 用单因素修复和回归测试结束排查

定位故障还需要一个闭环：只修改对应因素，再重放同一输入，确认预期机制恢复。将最小反例转为回归检查，可以保留这次诊断的因果证据，并防止相同错误在后续结构调整中重新出现。





配套代码在同一数据与初始化上构造正确、断图和漏加优化器三条路径，并用不同断言识别。修复时只改变对应因素，再重放完全相同输入，确认异常证据消失且预期更新恢复。若同时更换学习率、模型、数据和损失，即使训练改善，也无法知道真正原因，更难判断后续是否会复发。





将反例保留成小回归测试：比如新模块必须出现在 optimizer 中、冻结区之前的 Adapter 必须有梯度、有效零标签不能被 Mask 掉。测试应检验业务上重要的计算约定，不需要把实现每一行复制一遍。修复训练链路后，再恢复独立验证、真实增强和闭环评估，确认局部改动没有引入新的目标偏差。





一个完整诊断报告应包含现象、假设、控制变量、支持或反驳证据、修复以及剩余边界。比起“调了一下就正常”，这种记录能帮助下一次快速识别相似故障，也能把经验变成可复用的知识。





对于恢复后才出现的训练退化，保存加载前后的同一输入、模型状态和随机状态，对比下一次前向、梯度与更新。若前向已不同，先查模式、预处理与权重；前向相同而更新不同，再查优化器状态、scheduler、AMP 与累积边界。按首次分歧分层定位，能避免从整个训练曲线倒推所有可能原因。





诊断应尽量复用已经出现故障的同一个训练对象。[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)保留正常 Dataset、Mask 和 4→2 模型，只在 `verify_optimizer_diagnosis` 中漏掉 bias 的优化器成员；观察到非零 bias 梯度但零参数位移。另一个 `verify_masks` 只改变无效区或有效标签，用输入不变性与主动拒绝区分 Padding 处理错误。每个实验只改变一个假设，避免换一个模型后损失下降却无法解释原来的问题。





训练诊断的结果应是一个可复现、可反驳并能回归检验的解释。沿数据到参数的依赖找到证据，单独改变对应因素，再复查预期行为，才完成了从现象到修复的过程。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 参数与梯度 | 每个 named_parameter 对应同形状梯度 | None、全零、非有限值属于不同状态。 |
| 参数变化 | \(\lVert\theta_{\mathrm{after}}-\theta_{\mathrm{before}}\rVert_2\) | 在同一实际更新前后比较，不能用 grad 存在替代。 |
| 最小批次 | 固定 [B,D] 与 [B,A] | 固定样本与配置，把随机波动从初始排查中移除。 |

## 完整代码与精读

```python
import torch
from torch import nn

torch.manual_seed(31)
x = torch.randn(6, 3)
y = 2 * x[:, :1] - x[:, 1:2]
# STEP 1: 三种实验共享初始化与数据，控制唯一故障因素
def run_case(mode):
    torch.manual_seed(310)
    model = nn.ModuleDict({'trunk': nn.Linear(3, 4), 'head': nn.Linear(4, 1)})
    params = list(model['trunk'].parameters()) if mode == 'omit_head' else list(model.parameters())
    optimizer = torch.optim.SGD(params, lr=0.05)
    members = {id(p) for group in optimizer.param_groups for p in group['params']}
    before = {name: p.detach().clone() for name, p in model.named_parameters()}
    model.zero_grad(set_to_none=True)
    hidden = torch.tanh(model['trunk'](x))
    if mode == 'detach_trunk':
        hidden = hidden.detach()
    prediction = model['head'](hidden)
    loss = (prediction - y).square().mean()
    assert torch.isfinite(loss)
    loss.backward()
    optimizer.step()
    # STEP 2: 同时观察图连接、优化器成员和真实位移
    rows = {}
    for name, p in model.named_parameters():
        grad = p.grad
        rows[name] = {'in_optimizer': id(p) in members,
                      'has_grad': grad is not None,
                      'finite_grad': bool(torch.isfinite(grad).all()) if grad is not None else None,
                      'delta': float((p.detach() - before[name]).norm())}
    return rows

# STEP 3: 用有针对性的断言区分三种训练状态
for mode in ['correct', 'detach_trunk', 'omit_head']:
    report = run_case(mode)
    print(mode, report)
    if mode == 'correct':
        assert all(r['has_grad'] and r['in_optimizer'] and r['delta'] > 0 for r in report.values())
    elif mode == 'detach_trunk':
        assert not report['trunk.weight']['has_grad']
        assert report['trunk.weight']['in_optimizer']
        assert report['trunk.weight']['delta'] == 0
    else:
        assert report['head.weight']['has_grad']
        assert not report['head.weight']['in_optimizer']
        assert report['head.weight']['delta'] == 0
print('通过：断图和漏加优化器产生不同证据，不能混为一谈')

```

- 第 1–23 行：每个 case 重置相同种子。detach_trunk 切断主干梯度，omit_head 则保留完整计算图但只把主干参数交给优化器。
- 第 24–33 行：在一次 step 前后保存参数副本，分别查询梯度是否存在、是否有限，以及参数对象是否属于优化器。grad 存在不会自动意味着更新。
- 第 34–48 行：正常案例所有参数更新；断图案例主干无梯度；漏加案例头部有梯度但不更新。断言围绕真正的故障差异，不用 loss 是否下降替代。

预期观察：三个案例依次打印逐参数证据；断图主干 has_grad=False，漏加的头部 has_grad=True 但 in_optimizer=False 且 delta=0。

## 浏览器 Python 练习

实现 classify_records(records)，返回字典，键为 missing_optimizer、no_gradient、nonfinite_gradient、zero_gradient，对应按字母排序的参数名列表。每条记录含 name、trainable、in_optimizer 和 grad（None 或非空数列表）。只诊断 trainable=True 的记录；类别允许重叠，但非有限梯度不归入 zero_gradient。

```python
def classify_records(records):
     # TODO: 区分 None、全零与非有限值；冻结参数不计入异常
     raise NotImplementedError('请实现 classify_records')

```

### 提示

- grad is None 不能用 if not grad 来替代；零列表和缺失是两种语义。
- 先检查 trainable，再分别检查优化器成员关系和梯度状态。

### 参考实现与解释

```python
import math

def classify_records(records):
    report = {key: [] for key in ['missing_optimizer', 'no_gradient', 'nonfinite_gradient', 'zero_gradient']}
    for item in records:
        if not item['trainable']:
            continue
        name, grad = item['name'], item['grad']
        if not item['in_optimizer']:
            report['missing_optimizer'].append(name)
        if grad is None:
            report['no_gradient'].append(name)
        elif any(not math.isfinite(v) for v in grad):
            report['nonfinite_gradient'].append(name)
        elif all(v == 0 for v in grad):
            report['zero_gradient'].append(name)
    return {key: sorted(names) for key, names in report.items()}

```

同一个参数可以既没进入优化器又没有梯度，所以用允许重叠的证据列表。输出是后续排查线索，不是自动根因判定；例如条件分支中当前未使用的参数，无梯度可能完全符合设计。

### 断言测试

```python
records = [
    dict(name='good', trainable=True, in_optimizer=True, grad=[1, -2]),
    dict(name='missing', trainable=True, in_optimizer=False, grad=None),
    dict(name='zero', trainable=True, in_optimizer=True, grad=[0, 0]),
    dict(name='nan', trainable=True, in_optimizer=True, grad=[float('nan'), 1]),
    dict(name='frozen', trainable=False, in_optimizer=False, grad=None)]
assert classify_records(records) == {'missing_optimizer':['missing'], 'no_gradient':['missing'],
                                    'nonfinite_gradient':['nan'], 'zero_gradient':['zero']}
assert classify_records([]) == {k: [] for k in classify_records(records)}
print('通过：状态区分、重叠分类和冻结参数排除')

```

## 本地 PyTorch 练习

实现 audit_gradients(model, optimizer)，在 backward 后、清零前检查所有 requires_grad=True 的参数。返回 missing_optimizer、no_gradient、nonfinite_gradient、zero_gradient 四个按参数名称排序的列表；不改变梯度、参数或优化器。检查结果用于描述参数状态，不直接判定训练是否失败。

```python
import torch

def audit_gradients(model, optimizer):
    # TODO: 用参数对象 id 判断优化器成员；检查 None、有限性和零范数
    raise NotImplementedError('请实现 audit_gradients')

```

### 提示

- 不能用张量的 == 判断参数是否在列表中，使用 id 建立成员集合。
- 先排除 grad is None，再对梯度做 isfinite 和全零判断。

### 参考实现与解释

```python
import torch

def audit_gradients(model, optimizer):
    report = {k: [] for k in ['missing_optimizer', 'no_gradient', 'nonfinite_gradient', 'zero_gradient']}
    members = {id(p) for group in optimizer.param_groups for p in group['params']}
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if id(p) not in members:
            report['missing_optimizer'].append(name)
        if p.grad is None:
            report['no_gradient'].append(name)
        elif not bool(torch.isfinite(p.grad).all()):
            report['nonfinite_gradient'].append(name)
        elif bool((p.grad == 0).all()):
            report['zero_gradient'].append(name)
    return {key: sorted(names) for key, names in report.items()}

```

测试人为赋予不同梯度状态，隔离验证诊断器本身；演示源码另用真实前向反向复现两种错误。检查器不执行 backward 或 step，因此不会干扰正在排查的计算图。冻结参数跳过，避免把预期状态报告成故障。

### 断言测试

```python
torch.manual_seed(310)
model = torch.nn.ParameterDict({name: torch.nn.Parameter(torch.ones(2))
                               for name in ['good', 'zero', 'nan', 'missing', 'frozen']})
model['frozen'].requires_grad_(False)
model['good'].grad = torch.tensor([1.0, -1.0])
model['zero'].grad = torch.zeros(2)
model['nan'].grad = torch.tensor([float('nan'), 1.0])
opt = torch.optim.SGD([model['good'], model['zero'], model['nan']], lr=0.1)
before = model['good'].grad.clone()
result = audit_gradients(model, opt)
assert result == {'missing_optimizer':['missing'], 'no_gradient':['missing'],
                  'nonfinite_gradient':['nan'], 'zero_gradient':['zero']}
torch.testing.assert_close(model['good'].grad, before)
assert model['missing'].grad is None
print('PyTorch 通过：真实参数、优化器成员与四类梯度状态')

```

## 练习：推导与分析

### 为什么 requires_grad=True、grad 非零、参数更新，是三个不同问题？

requires_grad 控制是否追踪求导，grad 是本次反向得到的结果，参数更新还要求它进入优化器并实际执行有效 step。条件分支、detach、学习率和 AMP 都可能让三者不同。

演示的 omit_head 保留头部梯度，但优化器只有主干参数，所以头部位移为零。审计时还应区分 None 和全零，并确认检查时机位于 backward 后、下一次清零前。

代码定位：run_case 的 members、before 快照与 delta；audit_gradients。

- 能用漏加参数案例说明三者差异。
- 能说出至少一个合法的 grad=None 场景。

### 训练 loss 不下降时，为什么先做固定小批次实验？它不能证明什么？

固定数据和随机因素，可以减少排查变量，直接检查监督、图连接与更新是否能驱动学习。若简单合成目标都无法拟合，应优先修复计算或优化问题。

这个实验不证明实际任务泛化，也不能自动排除数据泄漏或坐标错误。应记录修复前后相同样本的预测、分项损失与参数变化，再用独立场景和闭环指标验证外部效果。

还需要检查可拟合性的前提。若相同输入对应 −1 与 +1 的冲突标签，确定性 MSE 的最小值就是 1；此时不归零可能由缺失条件或目标多样性造成，应先区分这一情况与断图、漏加优化器等实现故障。

代码定位：原理页固定批次的可表示／冲突标签对照，以及代码页 run_case 的正确／断图／漏加参数组对照。

- 能给出固定样本、配置与对照的排查步骤。
- 能区分管线可学习性与部署泛化证据。

## 练习：辨析与纠错

### 看到 loss 下降就停止检查

泄漏或错误目标也能被优化。核对样本语义、预处理和独立验证，而不只检查训练曲线。

### 有梯度就认定参数在学习

还需检查优化器成员、实际学习率、跳步和 step 前后位移。

### 生成训练重采随机量，却要求固定小批 loss 归零

重新采样改变监督，可能有不可约方差。最小过拟合应先固定完整随机三元组，再恢复真实协议。

### 长期保存所有带图激活和 loss

会延长图和设备张量生命周期，制造内存增长与性能扰动。日志保存 detach 后的必要摘要，按需抽样诊断。

## 原始资料

- [PyTorch：Autograd 异常检测与计算图](https://docs.pytorch.org/docs/stable/autograd.html)
- [PyTorch：Profiler recipe](https://docs.pytorch.org/tutorials/recipes/recipes/profiler_recipe.html)
- [PyTorch：Optimizer zero_grad](https://docs.pytorch.org/docs/stable/generated/torch.optim.Optimizer.zero_grad.html)
