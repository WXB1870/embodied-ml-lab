# 保存与恢复训练状态

权重、优化器、随机数和数据位置的恢复。

Checkpoint 是为稍后恢复计算而保存的一组状态，不一定只是一个模型权重文件。推理恢复需要模型函数及输入输出约定，继续训练还依赖优化器、进度、随机性与数据状态。本章先区分这两种恢复目标，再定义应保存的对象和时机，最后用中断前后的下一步对照检验恢复是否完整。

## 学习目标

- 区分用于推理的权重包与恢复训练的 Checkpoint。
- 按正确顺序恢复模型、优化器、调度器与随机状态。
- 比较中断前后下一步的损失和参数，说明可复现范围。

前置知识：[训练循环与指标归约](https://wxb1870.github.io/embodied-ml-lab/learn/training-loop/) · [PyTorch 模块、参数与状态](https://wxb1870.github.io/embodied-ml-lab/learn/modules/) · [梯度下降、动量与 AdamW](https://wxb1870.github.io/embodied-ml-lab/learn/optimization/)

## 推理导出与训练恢复

推理导出保存重建预测函数所需的状态，训练恢复还要继续原来的优化过程。两种目标对文件内容的要求不同。先确定希望恢复什么行为，再列出参数、统计量、优化器和数据进度。





例如 Adam 的更新依赖历史一阶与二阶矩及步数修正；同一组权重配不同优化器状态，会产生不同下一步。模型中 BN 的运行统计也会影响推理函数，但不属于可训练参数。仅以参数数量一致作为完整恢复的判断依据，会遗漏这些状态。保存前先列出后续计算依赖哪些量，再决定文件内容和恢复顺序，有助于避免恢复时遗漏必要状态。









### 保存内容由恢复目的决定

推理需要同一函数，续训还需要同一优化过程与数据序列。权重只是共同的一部分。

分别建立推理恢复清单和续训恢复清单，要求每个影响下一步的状态都有来源。

## 模型状态与结构配置

模型状态是参数与相关 Buffer 的当前值，结构配置定义这些值参与的具体计算。键名和形状匹配只检查部分接口，并不完整定义函数。恢复需要让状态和创建它的结构约定共同对应。





state_dict 记录注册参数和持久 Buffer 的键值，结构代码仍要正确创建。层数、宽度、激活、Norm ε、位置编码与输出含义等配置可能改变函数，即使部分权重 shape 仍相同。strict=True 可发现键缺失或多余，但不能证明所有非 Tensor 配置匹配。strict=False 应用于明确的迁移场景，逐条解释 missing/unexpected keys，不能作为消除加载错误的一行万能设置。





预处理统计、词表、图像尺寸、相机或模态顺序、动作单位及编码规则，也应与模型版本绑定。用于推理的输出后处理同样属于函数：同一个归一化预测配另一套反标准化统计，会变成不同物理量。保存代码版本、配置摘要和数据版本，能让后续人员解释结果来自哪套约定。参数文件成功读入仅是恢复链路中的一步，不保证恢复后的计算等价。









## 优化器状态与参数分组

优化器状态包括与参数绑定的动量、二阶统计和步数等历史信息，参数组还包含学习率与衰减配置。载入时需要把这些状态配回正确参数，而非只保持总参数量一致。





优化器的状态与参数集合、参数组顺序和各组超参数有关。重建模型后，应按原策略建立参数组并载入对应状态；只让总参数数量相同，不足以保证动量被配给正确参数。若新增模块、修改冻结范围或重排分组，原优化器状态可能需要有意识地部分继承或重建，此时应明确这是一项训练策略变化，而非严格续训。





学习率调度器还有自己的计数与基准状态，构造和加载顺序应遵守所用接口，避免初始化覆盖已恢复的学习率。AMP 的 GradScaler 也可能持有动态尺度和增长计数。恢复后打印每组参数名、当前学习率、权重衰减与优化器步数，再执行一小步对照。若参数值相同但下一步不同，先检查这些状态，再归因于随机性或硬件误差。







### 例：同一权重，动量不同，下一步就不同

1. 用简化动量更新 \(v_{\rm new}=0.9v+g\)，\(w_{\rm new}=w-\eta v_{\rm new}\)。

2. 两次恢复具有相同 w、g=1、η=0.1，但旧 v 分别为 0 和 2。

3. 新 v 分别为 1 与 2.8，参数位移分别为 −0.1 和 −0.28。

只恢复参数无法恢复优化器记忆，下一步等价才是续训的直接证据。

## 保存时机与更新边界

保存边界是声明状态快照对应训练流程中的哪一刻。完整更新之后与微批累积中途，需要保存的对象不同。先明确下一步应继续哪项操作，再决定快照内容与恢复顺序。





最容易解释的保存点通常是一次完整 optimizer update、调度器与必要日志状态更新之后，下一次取数据之前。若在梯度累积中间保存，除参数与优化器外，还要保存已累积梯度、累计有效分母、当前微步及精度相关状态，否则恢复后无法继续同一更新。若系统没有实现这些状态恢复，应把保存限制在完整更新边界，并清楚记录步数含义。





epoch、Batch 索引、optimizer_step 和已消费 token 数并不总成比例。最后一个短 Batch、被跳过的溢出更新、动态 Batch 与梯度累积都会造成差别。文件写入也应避免中途失败留下看似最新的半文件，可先写临时文件、验证完成再切换指向。多进程系统还要明确哪些 rank 写哪些状态、何时同步；不能让多个进程无约定地覆盖同一文件。









### “第 1000 步”必须说明是哪一种步

数据读取次数、微批次、实际优化器更新与 scheduler 计数可能不同。

同时记录 epoch、样本游标、micro_step、update_step 和有效元素量，并在恢复时打印核对。

## EMA 权重与训练状态分别保存

参数 EMA 是对实际训练参数维护的一套指数移动平均值，常用于评价或推理。它不是优化器动量，也不替代在线参数。继续训练和导出评价可能需要不同权重，因此应分别保存。





参数的指数移动平均（EMA）维护另一套用于评估或推理的权重。记 \(\theta_k\) 为第 k 次实际优化器更新后的在线参数，EMA 按 \(\bar\theta_k=\beta\bar\theta_{k-1}+(1-\beta)\theta_k\) 更新，本文取 \(\bar\theta_0=\theta_0\)。它平均的是模型参数，与 Adam 内部对梯度及梯度平方的移动平均不同。\(\beta\) 越接近 1，旧权重保留越久；第 j 次历史更新的系数按 \(\beta\) 的幂次衰减，约 \(\frac{1}{1-\beta}\) 次 EMA 更新给出常用的时间尺度估计。EMA 是否改善验证表现需要实测，不是所有微调都应默认启用。





在线模型仍承担前向、反向与优化器更新；EMA 模型使用独立存储、关闭梯度并在 no_grad 下更新。ema=model 只是给同一对象增加名称，不能得到平均模型；浅复制 state_dict 也不是历史快照。本文约定每次成功的 optimizer update 后更新 EMA：梯度累积的中间微批次不更新，AMP 溢出导致优化器跳步时也不推进。若改为每隔若干次更新才平均，或使用随步数变化的 \(\beta\)，必须保存 EMA 自身计数、频率和衰减配置，不能只比较 \(\beta\) 数值而忽略实际时间尺度。





参数之外还要确定 Buffer 的处理方式。整数计数器不能直接按浮点 EMA 处理；BatchNorm 的运行均值和方差可以选择复制在线统计、按约定平均，或用代表性数据重新估计，但三者得到的推理函数可能不同。本例统一复制全部 Buffer，并在 checkpoint 中保存该约定。使用 PyTorch AveragedModel 时还应注意：默认是等权平均，EMA 需要显式平均函数；avg_fn 和 multi_avg_fn 不随 state_dict 保存，恢复时必须重建相同规则。





完整续训应同时保存在线模型、EMA 模型、优化器及 EMA 规则和计数，再加上前文的调度器、随机与数据状态。不能把 EMA 权重载入在线模型，却沿用原在线模型的动量，并称为连续恢复。验证结果与推理导出应标明使用在线权重还是 EMA 权重；比较时使用相同数据和预处理。下面以无随机算子的 CPU 小模型验证两条路径，EMA 初始值和 Buffer 策略均明确，因此恢复后的连续更新可以逐项完全相等。





$$
\bar\theta_0=\theta_0,\qquad \bar\theta_k=\beta\bar\theta_{k-1}+(1-\beta)\theta_k,\quad 0\leq\beta<1
$$

```python
import copy
import io
import torch
from torch import nn

class TinyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = nn.Parameter(torch.tensor(0., dtype=torch.float64))
        self.register_buffer("updates_seen", torch.tensor(0))

    def forward(self, x):
        return self.weight * x

def make_training_state():
    online = TinyModel()
    ema = copy.deepcopy(online).requires_grad_(False).eval()
    optimizer = torch.optim.SGD(online.parameters(), lr=0.1, momentum=0.9)
    assert online.weight.data_ptr() != ema.weight.data_ptr()
    return online, ema, optimizer

@torch.no_grad()
def update_ema(online, ema, decay):
    ema_parameters = dict(ema.named_parameters())
    for name, parameter in online.named_parameters():
        ema_parameters[name].mul_(decay).add_(parameter, alpha=1-decay)
    # 本例的约定：所有 buffer 直接复制，整数计数器不做浮点平均。
    ema_buffers = dict(ema.named_buffers())
    for name, buffer in online.named_buffers():
        ema_buffers[name].copy_(buffer)

def train_step(online, ema, optimizer, step, decay):
    optimizer.zero_grad(set_to_none=True)
    (online(torch.tensor(1.)) - 2).square().backward()
    optimizer.step()  # 普通精度 CPU SGD；此处每次调用均实际完成更新。
    step += 1
    online.updates_seen.fill_(step)
    update_ema(online, ema, decay)
    return step

online, ema, optimizer = make_training_state()
decay = 0.9
step = train_step(online, ema, optimizer, 0, decay)
torch.testing.assert_close(online.weight, torch.tensor(0.4, dtype=torch.float64))
torch.testing.assert_close(ema.weight, torch.tensor(0.04, dtype=torch.float64))

# 序列化产生独立快照；仅保存 state_dict 的浅引用会随训练变化。
checkpoint = io.BytesIO()
torch.save({"online": online.state_dict(), "ema": ema.state_dict(),
            "optimizer": optimizer.state_dict(), "update_step": step,
            "ema_updates": step, "ema_decay": decay,
            "ema_buffer_policy": "copy"}, checkpoint)
for _ in range(2):
    step = train_step(online, ema, optimizer, step, decay)

restored_online, restored_ema, restored_optimizer = make_training_state()
checkpoint.seek(0)
saved = torch.load(checkpoint, weights_only=True)
restored_online.load_state_dict(saved["online"])
restored_ema.load_state_dict(saved["ema"])
restored_optimizer.load_state_dict(saved["optimizer"])
assert saved["ema_buffer_policy"] == "copy"
assert saved["ema_updates"] == saved["update_step"]
restored_step = saved["update_step"]
for _ in range(2):
    restored_step = train_step(restored_online, restored_ema,
                              restored_optimizer, restored_step, saved["ema_decay"])
for expected, actual in [(online, restored_online), (ema, restored_ema)]:
    for name, value in expected.state_dict().items():
        torch.testing.assert_close(value, actual.state_dict()[name], rtol=0, atol=0)
assert restored_step == step == 3
assert not restored_ema.weight.requires_grad and restored_ema.weight.grad is None
assert restored_online.weight.data_ptr() != restored_ema.weight.data_ptr()
print("EMA 与在线权重独立；保存恢复后两次连续更新及 buffer 完全一致。")

```

第一次 SGD 后在线权重为 0.4，\(\beta=0.9\) 的 EMA 为 0.04。检查点同时序列化两套权重、动量、更新次数与平均规则；基线再更新两次，恢复路径也更新两次，最后分别比较在线模型和 EMA 的全部 state_dict 项。此例直接初始化 EMA 为 \(\theta_0\)；PyTorch AveragedModel 则在第一次 update_parameters 时复制在线参数，使用该工具时须与自己的初始化约定保持一致。





### 在线权重与 EMA 权重不能共用存储或混合恢复

EMA 是另一套随训练推进的状态；只保存最终推理权重不足以恢复原来的优化与平均过程。

检查参数存储独立、EMA 无梯度、更新计数一致，并比较中断前后两套权重及 Buffer 的下一步。

## 随机状态与恢复顺序

随机种子定义序列起点，随机生成器状态记录当前进度。中断后继续相同噪声、Dropout 或数据顺序，需要恢复相应状态，而不只是重新设置起始种子。恢复操作本身也有顺序要求。





seed 描述随机序列的起点，训练运行一段时间后，需要的是当前生成器状态。Dropout、噪声采样、数据增强与采样顺序可能分别使用 PyTorch CPU、各 GPU、Python、NumPy 或显式 Generator。恢复时只重新设置最初 seed，会从序列开头重放，通常不同于未中断训练的下一步。应按实际使用的生成器保存和恢复状态，并注意模型重建本身可能消耗随机数。





恢复随机状态也不保证跨设备、跨内核或跨版本逐比特相同。非确定性算法、浮点求和顺序和并行调度都可能带来差异。可以在声明的同环境条件下做严格数值对照，在迁移环境时使用明确容差和任务指标验证。不要把“设置 deterministic”当成所有层面的复现承诺，也不要把所有差异都归咎于随机性而忽略错误的优化器或数据状态。









## 数据游标、Worker 与预取

数据游标记录已消费到的数据位置，预取队列则可能包含已经读取但尚未训练的记录。Worker 各自还可能拥有随机状态。它们共同决定下一批数据，仅保存主循环编号未必足够。





若下一批数据固定且无增强，恢复位置相对直接；实际 loader 可能已经预取多个 Batch，Worker 又各有随机增强状态。保存主循环的 Batch 编号，并不等于保存所有已预取但未消费的状态。IterableDataset 的流式游标、分布式 Sampler 的 epoch 与排序、动态长度分桶，都影响恢复后的数据序列。严格恢复需要数据管线支持，不能仅靠一个通用 checkpoint 字典自动完成。





可选策略包括在 epoch 边界恢复、使用可序列化 sampler 游标，或依据样本 ID 和明确随机规则重建下一批。每种策略都有成本与等价范围，应在文档中声明。单步恢复测试可先使用固定的下一批数据，单独验证模型与优化器状态；然后再加入真实 loader 和增强测试，将优化恢复与数据恢复分层定位，避免一次性把所有差异混在一起。









## 最佳模型与最新训练状态

最佳模型是按选定验证指标保存的状态，最新 checkpoint 是按训练进度保存的状态。两者服务于模型选择和继续计算两个目标，可能不在同一步，也可能包含不同对象。





最佳验证模型用于选取某个评价指标上的权重状态，最新 checkpoint 用于尽量少丢失训练进度；两者可能来自不同步数，也可能保存不同内容。内存中保存 best_state=model.state_dict() 不会自动生成独立历史快照，需要深拷贝或立即写入文件。训练结束再保存这个浅引用，可能得到最后一轮而非最佳一轮的权重。





选取最佳模型本身还涉及验证纪律：反复尝试配置会适配验证集，最终报告应保留独立测试或明确选择过程。多个指标冲突时要事先规定选择规则，不能在评价结束后仅报告最有利的指标。文件名或元信息应包含选取指标、步数、配置与来源，使读取者知道它是推理模型、迁移初始化还是完整续训状态，避免错误恢复后继续把日志拼接成同一个实验。







### 例：最佳模型与最新状态可以同时存在

1. 第 20 次更新验证最好，但训练继续到第 30 次更新后中断。

2. 部署可使用第 20 次的最佳权重；恢复训练通常需要第 30 次的完整优化与数据状态。

3. 若把第 20 次权重与第 30 次动量随意拼接，既不是最佳模型的原状态，也不是原训练的连续恢复。

明确文件用途能避免不一致状态被混用。

## 中断前后的单步等价

恢复是否完整最终可以通过同一下一步的计算来检验，而不是仅检查文件能否加载。未中断路径与重建路径应从相同输入和随机状态出发，逐项比较输出、梯度和更新后的状态。第一个出现差异的位置，能够把恢复错误缩小到具体依赖。





建立一条未中断基线，在某个更新边界复制完整状态，继续用固定下一批数据做一步；另一条路径重建模型与优化器、载入状态后处理同一批数据。比较这一步更新前的输出与 loss、梯度、更新后的参数和优化器状态。关闭或控制随机算子，使用合适 dtype 与容差。只比较刚载入时参数相同，仍不足以证明后续优化过程恢复正确。





单步恢复示例使用小型网络与可控随机性。分布式训练、动态数据流和不同硬件可能增加额外状态，应在相应环境比较中断前后的下一步。出现不一致时按输入与预处理、模型 Buffer/模式、随机状态、优化器、调度器和数据游标顺序查找第一个分叉。保存与恢复是训练算法的一部分，应该像前向与反向一样具有可检验约定。





固定下一批的短例通过后，可运行[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)的 `save_training` 与 main 中恢复分支：同一份变长数据、采样器和模型继续训练一整轮。序列化同时保存归一化 Buffer、AdamW 状态、按更新推进的 StepLR、CPU RNG、显式 DataLoader generator 和实际 update_step；构建新对象并加载后，再恢复随机状态。对照不仅要求参数相同，还要求样本顺序、下一轮 loss、优化器状态和调度器状态逐项相等。这个更完整的证据仍限定在当前 CPU 环境、num_workers=0、无随机增强且 epoch 边界保存；不能推断任意中途游标或跨设备恢复。





恢复是否完整，应由需要继续的行为来判断：推理重现同一函数，训练重现声明范围内的下一批与下一次更新。状态清单、保存边界和独立快照必须共同满足这个目标。









### 比较下一步，而非只看加载是否报错

同权重还可能配错动量、模式、随机数或下一批输入。下一步对照可直接揭示这些差异。

保留基线与恢复两条路径，逐项比较 loss、grad、参数、优化器状态及实际学习率。

## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| model.state_dict | 名称 → 参数 / Buffer Tensor | 定义模型当前函数的可序列化状态。 |
| optimizer.state_dict | 参数组与逐参数状态 | 包含 Adam 动量和超参数等。 |
| RNG 状态 | PyTorch ByteTensor + Python 状态元组 | 示例中使用的两个随机序列当前位置。 |
| global_step / config | 整数 / 基础类型字典 | 记录训练进度和数据约定，不能替代真实采样器状态。 |

## 完整代码与精读

```python
# [1] 一个有 Dropout 和随机输入的小训练过程
import copy
import io
import random
import torch
from torch import nn
torch.manual_seed(20)
random.seed(20)

def build():
    model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Dropout(0.2), nn.Linear(8, 2))
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=2, gamma=0.8)
    return model, optimizer, scheduler

def step(model, optimizer, scheduler):
    model.train()
    x = torch.randn(5, 4) + random.random() * 0.01
    target = x[:, :2] * 0.3
    optimizer.zero_grad(set_to_none=True)
    loss = (model(x)-target).square().mean()
    loss.backward()
    optimizer.step()
    scheduler.step()
    return float(loss.detach())

# [2] 保存独立快照与实际使用的随机状态
model, optimizer, scheduler = build()
for _ in range(3):
    step(model, optimizer, scheduler)
checkpoint = {
    "model": copy.deepcopy(model.state_dict()),
    "optimizer": copy.deepcopy(optimizer.state_dict()),
    "scheduler": copy.deepcopy(scheduler.state_dict()),
    "torch_rng": torch.get_rng_state().clone(),
    "python_rng": random.getstate(), "global_step": 3,
    "config": {"data_revision": "toy-v1", "normalization": "none"},
}
buffer = io.BytesIO()
torch.save(checkpoint, buffer)
expected_loss = step(model, optimizer, scheduler)
expected_state = copy.deepcopy(model.state_dict())

# [3] 先构造和加载，最后恢复 RNG，避免构造过程消耗它
resumed, opt2, sched2 = build()
loaded = torch.load(io.BytesIO(buffer.getvalue()), map_location="cpu", weights_only=True)
resumed.load_state_dict(loaded["model"])
opt2.load_state_dict(loaded["optimizer"])
sched2.load_state_dict(loaded["scheduler"])
torch.set_rng_state(loaded["torch_rng"])
random.setstate(loaded["python_rng"])
actual_loss = step(resumed, opt2, sched2)
assert abs(actual_loss-expected_loss) < 1e-12
for name, value in resumed.state_dict().items():
    torch.testing.assert_close(value, expected_state[name], atol=0, rtol=0)
print("下一步 loss 一致:", actual_loss == expected_loss)
print("已完成更新步数:", loaded["global_step"] + 1)
print("CPU 单进程恢复检查通过")

```

- 第 1–26 行：输入和 Dropout 都消耗随机状态；AdamW 和 StepLR 也各有需要恢复的内部状态。
- 第 27–43 行：以 deepcopy 避免内存中的状态引用随后被训练改变；BytesIO 让示例不依赖文件路径。
- 第 44–58 行：新对象先完成构造与状态加载，再恢复随机序列的位置，保证接下来的输入与 Dropout 相同。

预期观察：下一步 loss 一致为 True，恢复后累计完成 4 步；参数逐项与不中断训练完全一致（本示例的 CPU 单进程环境）。

## 浏览器 Python 练习

实现 snapshot_training(weights, optimizer_state, step)。返回含 weights、optimizer、step 的字典，前两项必须深拷贝。step 必须为非负整数。

```python
def snapshot_training(weights, optimizer_state, step):
    # TODO: 创建独立快照，不保留可变对象的共享引用
    raise NotImplementedError("请完成训练快照")

```

### 提示

- dict.copy 只拷贝最外层，里面的列表或字典仍然可能共享。
- 标准库 copy.deepcopy 可以递归创建独立状态。

### 参考实现与解释

```python
import copy

def snapshot_training(weights, optimizer_state, step):
    if not isinstance(step, int) or step < 0:
        raise ValueError("step 必须是非负整数")
    return {
        "weights": copy.deepcopy(weights),
        "optimizer": copy.deepcopy(optimizer_state),
        "step": step,
    }

```

内存里的最佳权重快照若共享底层状态，就可能随下一次更新变化；这是恢复与最佳模型选择中的常见陷阱。

### 断言测试

```python
weights = {"head": [[1.0, 2.0]]}
optimizer = {"momentum": {"head": [0.1, 0.2]}}
saved = snapshot_training(weights, optimizer, 7)
weights["head"][0][0] = 99.0
optimizer["momentum"]["head"][0] = 88.0
assert saved["weights"]["head"][0][0] == 1.0
assert saved["optimizer"]["momentum"]["head"][0] == 0.1
assert saved["step"] == 7
try:
    snapshot_training({}, {}, -1)
    raise AssertionError("负步数应被拒绝")
except ValueError:
    pass
print("通过：嵌套可变状态不共享引用，步数正确")

```

## 本地 PyTorch 练习

实现 restore_training。model、optimizer、scheduler 已按原结构构造；checkpoint 含 model、optimizer、scheduler、torch_rng、global_step。恢复后返回步数，最后设置 PyTorch CPU RNG。

```python
import torch

def restore_training(model, optimizer, scheduler, checkpoint):
    # TODO: 恢复三个状态字典和 CPU RNG，返回 global_step
    raise NotImplementedError("请实现训练恢复")

```

### 提示

- 调用方已创建对应模型、优化器和调度器，依次加载三个状态字典。
- 最后恢复 torch_rng，避免前面的准备过程消耗已恢复的随机序列。
- 返回保存的 global_step，不要擅自加一；完成新更新后才应推进步数。

### 参考实现与解释

```python
import torch

def restore_training(model, optimizer, scheduler, checkpoint):
    model.load_state_dict(checkpoint["model"])
    optimizer.load_state_dict(checkpoint["optimizer"])
    scheduler.load_state_dict(checkpoint["scheduler"])
    torch.set_rng_state(checkpoint["torch_rng"])
    return checkpoint["global_step"]

```

测试先训练一步，使 AdamW 动量和调度器学习率都不是初始状态，再构造新对象并恢复。参数对齐、学习率0.015、调度器步数和下一批随机数共同验证恢复范围；本练习只涵盖 PyTorch CPU RNG，完整项目还要处理其他随机源和数据游标。

### 断言测试

```python
import copy
torch.manual_seed(20)
m = torch.nn.Linear(2, 1)
opt = torch.optim.AdamW(m.parameters(), lr=0.03)
sched = torch.optim.lr_scheduler.StepLR(opt, step_size=1, gamma=0.5)
opt.zero_grad()
m(torch.ones(1, 2)).square().mean().backward()
opt.step()
sched.step()
ckpt = {"model": copy.deepcopy(m.state_dict()), "optimizer": copy.deepcopy(opt.state_dict()),
        "scheduler": copy.deepcopy(sched.state_dict()), "torch_rng": torch.get_rng_state(),
        "global_step": 1}
expected_random = torch.rand(3)
m2 = torch.nn.Linear(2, 1)
o2 = torch.optim.AdamW(m2.parameters(), lr=0.9)
s2 = torch.optim.lr_scheduler.StepLR(o2, step_size=1, gamma=0.5)
assert restore_training(m2, o2, s2, ckpt) == 1
torch.testing.assert_close(torch.rand(3), expected_random, atol=0, rtol=0)
torch.testing.assert_close(m2.weight, m.weight)
assert abs(o2.param_groups[0]["lr"]-0.015) < 1e-12
assert len(o2.state) == len(opt.state) and s2.last_epoch == sched.last_epoch
print("通过：权重、优化器、调度器、步数与 RNG")

```

## 练习：推导与分析

### 只加载 model.state_dict 后继续优化，与恢复一个完整训练 Checkpoint 有哪些不同？

模型状态恢复参数和持久 Buffer，但不自动恢复 Adam 动量、学习率调度进度、混合精度缩放器、全局更新步数或随机状态。因此相同权重出发的下一步参数更新也可能不同。

数据版本、归一化、动作定义和采样位置同样影响训练含义。应明确这是从已有权重启动新的微调，还是尝试延续原实验；两者都可能有用，但不能用同一个“完全恢复”描述。

代码定位：检查 checkpoint.keys()，核对 optimizer、scheduler、RNG 与数据配置是否各有明确来源。

- 至少说明优化器和学习率状态的差别。
- 提及数据约定或随机/采样状态影响下一步。

### 为什么恢复随机状态应放在模型重建之后？怎样证明恢复结果足以继续下一步，而不只是加载没有报错？

模型重建通常随机初始化参数，会消耗随机数。若先恢复 RNG 再重建，就把状态向前推进了；应完成构造和状态加载后，再恢复本实验实际使用的各个随机源。

在受控环境下保存一个检查点，不中断地执行下一步得到参考；重新构造并恢复后执行同一步，比较输入、loss 和参数。这个实验验证当前环境下的范围，不自动保证跨硬件、跨版本或多进程预取逐位一致。

代码定位：对照 expected_loss、actual_loss 和所有参数，同时检查 RNG 恢复前后是否还有随机调用。

- 解释随机初始化会消耗 RNG。
- 给出不中断与恢复后下一步对照，并说明验证范围。

## 练习：辨析与纠错

### 只载入权重就称为严格续训

动量、调度器、精度和数据状态可能不同。区分迁移初始化与恢复原实验，并提供下一步对照。

### strict=False 后忽略所有缺失键

这可能漏掉关键模块或 Buffer。逐项解释预期差异，核对配置与加载后的函数输出。

### 只重设最初 seed，不恢复当前随机状态

随机序列会从头开始。保存实际生成器状态，并考虑重建模型与 Worker 的随机数消费。

### 累积窗口中间只保存参数和优化器

已经累积的梯度及有效分母丢失会改变下一次更新。选择完整更新边界，或实现对应完整状态恢复。

### 把最佳权重与最新优化器状态任意组合

两者来自不同参数轨迹，不是原训练的连续状态。分别保存部署选择和续训检查点并注明用途。

## 原始资料

- [PyTorch：Saving and Loading Models](https://docs.pytorch.org/tutorials/beginner/saving_loading_models.html)
- [PyTorch：Reproducibility](https://docs.pytorch.org/docs/stable/notes/randomness.html)
- [PyTorch：Optimizer.load_state_dict](https://docs.pytorch.org/docs/stable/generated/torch.optim.Optimizer.load_state_dict.html)
- [PyTorch：AveragedModel 与 EMA 状态](https://docs.pytorch.org/docs/stable/generated/torch.optim.swa_utils.AveragedModel.html)
