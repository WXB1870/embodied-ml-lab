# 线性代数与矩阵求导

从局部线性近似到 JVP、VJP 与参数梯度。

线性代数研究向量、矩阵及其表示的变换；矩阵求导研究输出怎样随向量或矩阵输入的微小变化而改变。神经网络训练需要把这些局部变化沿计算图合成，得到损失对各参数的梯度。我们先用线性映射说明信息怎样变换，再用标量例子建立导数，随后推广到矩阵、链式法则和 Jacobian，最后独立核验梯度。

## 学习目标

- 推导批量线性回归的权重、偏置和输入梯度
- 说明 mean 与 sum 如何改变梯度尺度
- 用自动微分与有限差分交叉验证小模型

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/)

## 线性映射、秩与零空间

线性映射是保持向量加法与数乘关系的变换，可由矩阵乘法表示。矩阵的列空间是它能够产生的全部输出方向，秩是这些方向的独立数量，零空间则是被映射为零的输入方向。它们共同说明哪些输入差异能够穿过一层网络。





采用列向量约定，\(A\in\mathbb R^{m\times n}\) 将输入 \(x\in\mathbb R^n\) 映射成 \(Ax\in\mathbb R^m\)。展开矩阵乘法可得 \(Ax=\sum_j x_j A_{:,j}\)：输出是 A 各列的线性组合，所有可能输出组成列空间。秩 r 是列空间的维数，表示这个线性映射实际保留了多少个独立方向，不等于矩阵元素数或输出通道数。加入固定偏置 b 得到仿射映射，只会平移输出集合；两条输入的输出差仍是 \(A(x_1-x_2)\)。批量输入按行存储为 X:[B,n] 时，同一映射写成 X@A.T。





零空间 \(\ker(A)\) 是满足 \(Az=0\) 的输入方向集合。若 z 非零，则 x 与 \(x+z\) 不同，却有完全相同的输出；这些差异已经被映射消除，后续仅依赖该输出的函数无法恢复它们。秩与零空间满足 \(r+\dim\ker(A)=n\)，所以对整个 \(\mathbb R^n\) 上的输入，映射可辨别任意两点当且仅当 \(r=n\)，即 A 满列秩；这要求 \(m\ge n\)。反过来，\(m\ge n\) 只是必要条件，增加输出通道并不保证列线性无关。





例如 A 的两行为 [1,2] 与 [2,4]，第二行没有提供独立约束，秩只有 1；方向 z=[−2,1] 被完全消除。给输出加偏置、再接更宽的网络，都无法区分 x 与 \(x+z\)。这个结论针对整个输入空间；若数据被限制在一个低维集合上，降维映射仍可能在该集合上保持一一对应。因此，“维度减少必然损失任务信息”和“维度不减就一定可逆”都不成立，必须同时检查矩阵秩与实际输入约束。





$$
\begin{aligned}Ax&=\sum_{j=1}^{n}x_jA_{:,j},\\ \dim\ker A&=n-\operatorname{rank}(A),\qquad z\in\ker A\Rightarrow A(x+z)=Ax.\end{aligned}
$$

```python
import torch

dtype = torch.float64
A = torch.tensor([[1., 2.], [2., 4.]], dtype=dtype)
x = torch.tensor([3., -1.], dtype=dtype)
z = torch.tensor([-2., 1.], dtype=dtype)
assert torch.linalg.matrix_rank(A).item() == 1
torch.testing.assert_close(A @ z, torch.zeros(2, dtype=dtype))
assert not torch.equal(x, x + z)
torch.testing.assert_close(A @ x, A @ (x + z))

# 行数增加后，仍须检查列是否独立。
C = torch.tensor([[1., 0.], [0., 1.], [1., 1.]], dtype=dtype)
assert torch.linalg.matrix_rank(C).item() == 2
recovered = torch.linalg.lstsq(C, C @ x).solution
torch.testing.assert_close(recovered, x)
print("秩为 1 的映射存在输入碰撞；满列秩映射恢复了原输入。")
```

`A@z=0` 与 `A@x=A@(x+z)` 共同验证输入差异确实丢失，而不是仅凭 shape 推测。C 是 [3,2] 的满列秩矩阵，最小二乘求解得到唯一的原输入；这里右侧严格来自 C@x，没有测量噪声。matrix_rank 在浮点数中使用容差判断奇异值是否为零，近奇异矩阵的数值秩还依赖精度与容差。





## 导数回答的是局部变化，不是参数的重要性排名

导数描述函数在当前位置对微小输入变化的响应；梯度把标量函数对各输入坐标的偏导组织成向量。它是局部变化率，并不直接等于参数的重要性。下面先用一阶近似说明梯度能预测什么，再将它用于更新方向。





对标量函数 \(L(\theta)\)，梯度第 i 项表示只微小改变 \(\theta_i\) 时，损失的一阶变化率。近似式 \(L(\theta+\Delta\theta)\approx L(\theta)+g^\top\Delta\theta\) 将一个非线性函数在当前点附近用平面表示。沿 -g 做足够小的步长时一阶项下降，但步长过大时曲率项可能主导，所以“方向正确”不意味着任意学习率都能降低损失。





对向量输出 \(y=f(x)\in\mathbb R^m\)，把每个输出对每个输入的偏导排成 \(J_{ij}=\partial f_i/\partial x_j\)，就得到 \(J\in\mathbb R^{m\times n}\)。在可微点，\(f(x+\Delta x)=f(x)+J\Delta x+o(\lVert\Delta x\rVert)\)；它与前面的线性映射具有相同形状，只是矩阵通常随当前输入改变。若标量损失的二阶导存在，把一阶偏导再次求导得到 Hessian \(H_{ij}=\partial^2L/\partial\theta_i\partial\theta_j\)。在局部二阶连续可微时，二阶项为 \(\tfrac12\Delta\theta^\top H\Delta\theta\)，这说明步长增大后曲率为什么会改变一阶预测。后面先完成一阶求导，再用二次目标分析曲率。





梯度依赖当前参数、输入、损失归约和单位。某参数梯度大，可能只是其数值尺度不同；梯度暂时为零，也可能是当前样本落在平坦区，而非这个参数永远无用。区分局部导数、累计优化效果和验证集贡献，是理解后训练日志的前提。实际排查应同时记录梯度、参数大小和更新量，而不是仅按梯度绝对值给层排序。





$$
L(\theta+\Delta\theta)=L(\theta)+\nabla L(\theta)^\top\Delta\theta+O(\lVert\Delta\theta\rVert^2)
$$





## 从一维线性回归把分母算清楚

线性回归用输入的加权和加偏置预测连续数值，是连接前向函数、误差与参数梯度的最小例子。我们先固定一维模型与平均平方误差，再逐步追踪一个样本怎样贡献到权重和偏置的导数。





设预测 \(\hat y_i=wx_i+b\)，误差 \(e_i=\hat y_i-y_i\)，取 \(L=\frac1N\sum_i e_i^2\)。对预测的导数是 \(\frac{2e_i}{N}\)，再乘预测对 w 的导数 \(x_i\)，得到 \(\frac{\partial L}{\partial w}=\frac2N\sum_i e_i x_i\)；偏置导数为 \(\frac2N\sum_i e_i\)。若损失定义为半平方误差，因子 2 会消失；若使用 sum，\(\frac1N\) 会消失。这些差异来自目标定义，不能直接归咎于自动微分错误。





多输出 MSE 的 mean 通常平均所有 \(BO\) 个标量，而不是只除 B。手推梯度时若把 O 漏掉，会与框架结果相差固定倍数；虽然方向可能相同，学习率和多任务权重的实际含义已改变。最可靠的做法是在公式旁写清楚求和索引、分母和有效位，再把这一目标逐项翻译成代码。







### 例：两条样本的梯度

1. 取 x=[1,2]、y=[2,1]、w=1、b=0，预测为 [1,2]，误差为 [-1,1]。

2. \(\operatorname{MSE}=\frac{(-1)^2+1^2}{2}=1\)；\(\frac{\partial L}{\partial w}=\frac{2((-1)\times1+1\times2)}2=1\)。

3. \(\frac{\partial L}{\partial b}=\frac{2(-1+1)}2=0\)；学习率 0.1 的普通 SGD 将 w 更新为 0.9。

梯度的符号、求和和平均因子都可用两个样本手算。

### 把 mean 理解成只除 Batch

MSE 的逐元素 mean 包含输出维度，带 Mask 时还会改变有效元素总数。

先将误差张量打印成小数组，逐项求和并写出分母，再对照 autograd。

## 矩阵形式怎样从逐元素公式得到

矩阵梯度是损失对矩阵中每个元素的偏导按原形状排列的结果。共享权重被多个样本使用时，其梯度必须累加全部使用位置的贡献。由逐元素计算推出矩阵式，可以解释每个转置和归约，而非只记住结果。





令 X:[B,D]，W:[D,O]，\(Y=XW+b\)，\(G=\frac{\partial L}{\partial Y}\):[B,O]。某个 \(W_{do}\) 被全部 B 个样本复用，因此它的梯度要收集所有样本的贡献：\(\frac{\partial L}{\partial W_{do}}=\sum_b X_{bd}G_{bo}\)，写成矩阵就是 \(X^\top G\)。同理，输入梯度是 \(GW^\top\)，偏置在 Batch 上广播，梯度就在 Batch 上求和。每个梯度的 shape 必须与被求导变量相同。





PyTorch Linear 的参数按 [O,D] 保存，所以代码中 weight.grad 对应 \(G^\top X\)，而不是直接使用 \(X^\top G\)。数学推导与框架都可以正确，只是权重朝向不同。不要靠转置直到矩阵乘法能运行；从一个参数 \(W_{do}\) 的索引依赖出发推导，能同时说明求和轴、转置原因和偏置归约。高阶 [B,T,D] 输入相当于对所有 b,t 位置累加共享参数的贡献。





对共享时间投影还可以把 B 与 T 合并为 BT 行，再应用同一个矩阵梯度公式，最后恢复输入形状。两种实现应逐元素一致；若只沿 Batch 求和而遗漏时间轴，参数梯度会留下错误维度。这个推导同时说明为什么样本共享权重会聚合梯度，却不意味着前向允许样本之间混合信息。





$$
\bar W=X^\top G,\qquad \bar X=GW^\top,\qquad \bar b=\sum_b G_{b,:}
$$





### 先验证梯度形状，再核对索引求和

反向传播中的每个伴随张量，都与对应前向变量同形。

为 X、W、Y、G 和三组梯度逐一标 shape，再手算一个 weight.grad 元素。

## 链式法则是沿路径相乘，遇到分支相加

链式法则说明复合函数的局部变化怎样由各环节的导数组合：沿一条依赖路径相乘，多条路径汇合时相加。反向传播就是在计算图上组织这些计算。下面沿两层网络从损失回到第一层，明确每一步读取哪一份前向值。





对两层网络 \(Z=XW_1+b_1\)、\(H=\phi(Z)\)、\(Y=HW_2+b_2\)，先从损失得到输出梯度 G。第二层权重梯度为 \(H^\top G\)，传回隐藏层的是 \(GW_2^\top\)；经过逐元素激活后，再乘 \(\phi^{\prime}(Z)\)，得到第一层的上游梯度。计算的顺序与前向相反，但每一步只使用当前算子的局部导数和下游传来的信号。





如果一个变量参与多条路径，总导数需要将各条贡献相加。例如 \(y=x^2+x\)，对 x 的导数是 \(2x+1\)；如果错误地仅沿平方分支求导，会漏掉恒等路径。残差连接、共享权重和多任务损失都依赖这条规则。参数共享不表示梯度只计算一次局部贡献，而是所有使用位置的贡献在同一参数上汇总。







### 例：手推一个带激活和跳连的标量网络

1. 令 \(z=wx\)、\(h=\operatorname{ReLU}(z)\)、\(y=vh+x\)，取 x=2、w=3、v=4、目标 \(y^*=1\)，\(L=\frac12(y-y^*)^2\)。

2. 前向 z=6、h=6、y=26，输出梯度为 25。

3. \(\frac{\partial L}{\partial v}=25\times6=150\)；\(\frac{\partial L}{\partial w}=25\times4\times1\times2=200\)。

4. \(\frac{\partial L}{\partial x}=25(4\times1\times3+1)=325\)，最后的 +1 来自跳连。

路径内相乘，路径之间相加；“共享”不会消除任何一条贡献。

## JVP 与 VJP：沿输入方向推，沿输出梯度拉

Jacobian 是向量输出对向量输入的所有一阶偏导组成的矩阵。JVP 用它把一个输入扰动方向映射到输出扰动，VJP 则把输出端的梯度传回输入端。两者避免显式构造整个矩阵，是理解自动微分方向的基础。





设 \(x\in\mathbb R^n\)、\(y=f(x)\in\mathbb R^m\)，采用列向量约定，Jacobian J 的形状是 [m,n]。局部线性化 \(f(x+\varepsilon u)\approx f(x)+\varepsilon Ju\) 说明 \(\operatorname{JVP}=Ju\) 回答“输入沿 u 扰动时，每个输出怎样变”。这里 u 在输入空间，结果在输出空间。它适合求一个指定方向上的敏感度，不要求把整个 J 存下来。





反向模式从输出空间的向量 v 出发，计算 \(\operatorname{VJP}=J^\top v\)；也常按行向量写成 \(v^\top J\)。若标量损失为 L(y)，取 \(v=\nabla_y L\)，就得到 \(\nabla_x L=J^\top v\)。训练时输出梯度通常只有这一条需要传播的组合，因此反向模式可以逐层执行 VJP，而不展开“每个输出对每个参数”的全部偏导。





两个方向由内积对偶联系起来：\(v^\top(Ju)=(J^\top v)^\top u\)。左侧先计算输入扰动引起的输出变化，再沿 v 取投影；右侧先将 v 映射回输入空间，再沿 u 取投影。这个恒等式也能检查自定义 JVP/VJP 是否一致，但两种实现若存在相同错误，结果仍可能相互吻合，必要时还需独立有限差分。





对非标量 y 调用 backward(gradient=v)，提供的是反向种子，返回的是这次局部 VJP。v 被当作给定的上游量；全 1 对应对输出求和，全 1 除以元素数才对应 mean。若 v 本身依赖 x，想求完整的 \(\nabla_x[v(x)^\top f(x)]\)，还需要乘积法则中的另一项，不能把一次传入种子的 VJP 当作整个乘积的导数。





$$
J\in\mathbb R^{m\times n},\quad \mathrm{JVP}(u)=Ju,\quad \mathrm{VJP}(v)=J^\top v,\quad v^\top Ju=u^\top J^\top v
$$

```python
import torch
from torch.func import jvp, vjp

def f(x):
    return torch.stack((x[0] * x[1], x[0] + x[1].square()))

x = torch.tensor([2., 3.], dtype=torch.float64)
u = torch.tensor([1., -1.], dtype=torch.float64)
v = torch.tensor([1., -2.], dtype=torch.float64)
_, ju = jvp(f, (x,), (u,))
_, pullback = vjp(f, x)
(jtv,) = pullback(v)
torch.testing.assert_close(ju, torch.tensor([1., -5.], dtype=x.dtype))
torch.testing.assert_close(jtv, torch.tensor([1., -10.], dtype=x.dtype))
torch.testing.assert_close(v @ ju, u @ jtv)
print("JVP:", ju.tolist(), "VJP:", jtv.tolist())
```

jvp 接收输入方向 u；vjp 先建立返回映射，再接收输出种子 v。两种接口都没有在代码中显式构造 J，最后的内积等式核对它们的方向与数值。



### 例：同一个 Jacobian 的两个乘法方向

1. 取 \(f(x)=\begin{bmatrix}x_0x_1\\x_0+x_1^2\end{bmatrix}\)，在 x=[2,3] 处，J 的两行为 [3,2]、[1,6]。

2. 输入扰动 u=[1,−1] 给出 \(Ju=\begin{bmatrix}1\\-5\end{bmatrix}\)。这描述两个输出的一阶变化，并不是某个标量 loss 的梯度。

3. 输出权重 v=[1,−2] 给出 \(J^\top v=\begin{bmatrix}1\\-10\end{bmatrix}\)。它是固定加权和 \(f_0-2f_1\) 对 x 的梯度。

4. 核对 \(v^\top Ju=11\)，\(u^\top J^\top v=11\)；矩阵方向、向量所在空间与数值相互一致。

JVP 和 VJP 都是 Jacobian 的线性作用，输入方向和输出梯度不能互换。

## 广播的反向是归约，选择的反向是散射累加

广播的反向归约，是把共享输入在各使用位置产生的梯度相加；索引选择的反向散射累加，则把梯度放回对应的原位置。这两条规则都来自链式法则，用来保证共享或重复读取不会漏算贡献。





前向把偏置 b:[O] 复用到 [B,O]，反向就要把 B 个使用位置的梯度求和回 [O]。同样，先将时间标量扩展到多个位置再使用，时间标量的梯度会累积这些位置的作用。误以为广播会创建独立参数，会让手写 backward 得到错误维度或漏掉求和因子。





切片与索引选择则把上游梯度送回原张量的对应位置；若同一位置被多次使用，贡献相加。不可微的是很多离散决策本身，如 argmax 产生的整数索引，并非“凡是索引后的张量都不能反传”。检查可微性时追踪数值如何依赖输入：某个输入被选中仍可得梯度，但“为什么选中了它”的离散边界通常没有普通导数。









### 把 argmax 后的索引路径当连续训练路径

离散选择可能切断对选择分数的梯度，后续被选数值有梯度也不能证明选择器可训练。

分别检查选择分数与被选特征的梯度，必要时重新设计可微目标，而不是只检查最终 loss.requires_grad。

## 奇异值、低秩近似与优化条件数

奇异值分解把一个线性映射分解为输入方向、各方向的缩放和输出方向。奇异值衡量局部放大或压缩，低秩近似只保留部分方向，条件数比较最强与最弱的非零缩放。它们用于解释信息损失和优化几何。





对秩为 r 的实矩阵，紧致奇异值分解为 \(A=U_r\Sigma_r V_r^\top\)，其中 \(U_r\)、\(V_r\) 的列分别是正交单位向量，\(\Sigma_r\) 的对角线是按降序排列的正奇异值。等式 \(Av_i=\sigma_i u_i\) 给出几何解释：输入沿 \(v_i\) 的单位变化，在输出中变成沿 \(u_i\)、长度为 \(\sigma_i\) 的变化；零空间方向则完全消失。最大奇异值是欧氏范数下的最大放大倍数。特征值只对方阵定义，也不能普遍替代奇异值：剪切矩阵 \(\begin{bmatrix}1&10\\0&1\end{bmatrix}\) 的两个特征值都是 1，却能把 [0,1] 放大到长度 \(\sqrt{101}\)。





保留最大的 k 个奇异值得到 \(A_k=\sum_{i=1}^k\sigma_i u_i v_i^\top\)。它在所有秩不超过 k 的矩阵中最小化 Frobenius 范数误差，误差平方等于被舍弃奇异值的平方和。这解释了低秩近似保留主要变化方向的含义，但最优性只针对当前矩阵的未加权重建误差；训练数据、下游目标或输入协方差改变后，并不能直接推出任务损失也最优。LoRA 的低秩参数化限制的是可学习更新的秩，不等同于先对某个已知最优更新做截断 SVD。





当 A 满列秩时，\(\kappa_2(A)=\frac{\sigma_{\max}}{\sigma_{\min}}\) 描述不同输入方向的缩放差异；最小奇异值很小时，反推输入会放大某些输出扰动。若不能满列秩，恢复整个输入空间的条件数视为无穷大，不能只丢掉零奇异值再宣称可逆。对 \(L(\theta)=\frac12\lVert A\theta-y\rVert_2^2\)，梯度为 \(A^\top(A\theta-y)\)，Hessian 为 \(A^\top A\)，其特征值是 \(\sigma_i^2\)，因此条件数为 \(\kappa_2(A)^2\)。固定步长梯度下降中，各特征方向的误差每步乘以 \(1-\eta\sigma_i^2\)；\(0<\eta<\frac{2}{\sigma_{\max}^2}\) 保证这个满列秩二次问题收敛，但较小奇异值对应的方向可能收敛很慢。





条件数因此连接了数据尺度、数值敏感性与优化速度，而不仅是矩阵能否求逆。标准化或预条件可以改善方向间的尺度差异，但不保证消除特征相关性；正则化也会改变曲率和最优解。上述精确关系针对固定矩阵的二次目标，不能直接当成深层网络全局训练速度的公式。实际训练中通常不必反复对大矩阵做完整 SVD；这里用小矩阵建立判断依据，并区分“某方向接近零”与“所有方向都被稳定保留”。





$$
\begin{aligned}A&=U_r\operatorname{diag}(\sigma_1,\ldots,\sigma_r)V_r^\top,\qquad Av_i=\sigma_i u_i,\\ \lVert A-A_k\rVert_F^2&=\sum_{i>k}\sigma_i^2,\\ \kappa_2(A)&=\frac{\sigma_{\max}}{\sigma_{\min}},\qquad \kappa_2(A^\top A)=\kappa_2(A)^2\quad\text{(full column rank)}.\end{aligned}
$$

```python
import torch

dtype = torch.float64
A = torch.diag(torch.tensor([10., 0.1], dtype=dtype))
U, s, Vh = torch.linalg.svd(A, full_matrices=False)
torch.testing.assert_close((U * s) @ Vh, A)
rank_one = (U[:, :1] * s[:1]) @ Vh[:1]
error = (A - rank_one).square().sum()
torch.testing.assert_close(error, s[1:].square().sum())
kappa = s.max() / s.min()
torch.testing.assert_close(torch.linalg.cond(A.T @ A), kappa.square())

# 取 y=0，最优解为 0；验证每个奇异方向的误差缩放。
theta = torch.ones(2, dtype=dtype)
eta = 0.01  # 小于 2 / sigma_max**2 = 0.02
next_theta = theta - eta * (A.T @ (A @ theta))
torch.testing.assert_close(next_theta, (1 - eta * s.square()) * theta)

shear = torch.tensor([[1., 10.], [0., 1.]], dtype=dtype)
eigenvalues = torch.linalg.eigvals(shear)
torch.testing.assert_close(eigenvalues, torch.ones_like(eigenvalues))
v = torch.tensor([0., 1.], dtype=dtype)
assert torch.linalg.vector_norm(shear @ v).item() > 10
print("条件数:", kappa.item(), "Hessian 条件数:", kappa.square().item())
print("一步后的误差:", next_theta.tolist(), "秩 1 重建误差平方:", error.item())
```

PyTorch 返回 Vh，即 V 的转置；U*s 按列缩放后与 Vh 相乘，重建原矩阵。对角例子的条件数为 100，Hessian 条件数为 10000；一步更新消除了第一方向的误差，第二方向只从 1 降至 0.9999。剪切矩阵则独立验证特征值全为 1 并不意味着欧氏长度不变。代码不依赖奇异向量的符号，因为符号翻转不会改变重建结果。





## 有限差分怎样独立核验反向实现

有限差分通过微小扰动参数并重新计算函数值，近似它的导数。它不沿反向实现求导，因此能作为独立对照；误差同时受扰动步长和浮点舍入影响。下面用中心差分核验手推与自动微分。





中心差分用 \(\frac{L(\theta+\varepsilon e_i)-L(\theta-\varepsilon e_i)}{2\varepsilon}\) 近似第 i 个偏导。\(\varepsilon\) 太大时局部线性近似差，太小时两次几乎相等的数相减会放大舍入误差；float64 和适当步长通常更适合小型检查。固定输入、随机种子和模型模式，避免 Dropout 或重新采样把两次函数值变成不同任务。





ReLU 在零点不可微，硬阈值附近也不适合用中心差分要求完全一致。共享存储的 expanded 张量可能让扰动一个元素同时改动多个位置，因此 gradcheck 输入应满足工具约束。有限差分开销随参数数目增长，适合最小模型和自定义算子；它不是训练大模型的替代方法。比较时既看相对误差也看绝对误差，接近零的梯度不能只用相对误差判断。





方向有限差分也是一个有用补充：选定一个固定方向 u，比较 \(\frac{L(\theta+\varepsilon u)-L(\theta-\varepsilon u)}{2\varepsilon}\) 与 \(g^\top u\)。它一次检查很多参数的组合，成本较低，但可能遗漏与 u 正交的错误；不能把少数随机方向通过等同于完整逐元素证明。





$$
g_i^{FD}=\frac{L(\theta+\epsilon e_i)-L(\theta-\epsilon e_i)}{2\epsilon}
$$





## 从局部梯度到实际更新

梯度核验通过后，还剩一个工程问题：程序是否真的按照预期方向更新了同一组参数。将局部线性预测与一次实际训练步对照，可以把数学导数、自动微分和优化器行为连接起来，也为后续训练诊断提供参照。





示例让同一目标分别通过手推、自动微分和有限差分获得梯度。先独立写出目标和分母，再比较每个元素；只比较范数会遗漏整体符号反转或参数顺序错位。若结果不一致，先检查数据类型、权重朝向、mean/sum 和激活点，再检查局部导数。框架给出一个非零梯度，并不证明它对应了原本想优化的目标。





求导正确之后，还要证明更新正确。清零梯度、backward、optimizer.step 是不同动作：反向传播只计算或累积导数，不替你改变参数；错误地对带图张量反复求导可能需要重建图，但不应把 retain_graph=True 当成常规修复。每个训练步重新前向通常构建新的图，保留旧图只会增加生命周期和内存开销。





最终可用一个小步长实验核对局部预测：比较实际损失差与 \(g^\top\Delta\theta\) 的符号和数量级。若步长足够小且函数光滑，两者应接近；若不接近，排查更新向量是否包含权重衰减、动量或裁剪。这个实验把抽象链式法则连接到了真实优化器行为。





矩阵求导最终回答的是同一个问题：某个输入或参数的微小变化，会怎样改变标量目标。明确前向依赖、沿路径组合导数、在共享处求和，再用独立数值对照，才能把梯度连接到可解释的更新。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| X | [B,I] | 输入批量 |
| W | [O,I] | 与 nn.Linear 的权重布局一致 |
| G | [B,O] | 标量损失对预测张量的导数 |
| dW | [O,I] | 形状与被更新的参数一致 |

## 完整代码与精读

```python
import torch

torch.manual_seed(0)
# STEP 1: 定义小型双精度回归问题
X = torch.tensor([[1., 2.], [-1., 1.], [2., 0.]], dtype=torch.float64)
Y = torch.tensor([[3.], [0.], [4.]], dtype=torch.float64)
W = torch.tensor([[0.3, -0.2]], dtype=torch.float64, requires_grad=True)
b = torch.tensor([0.1], dtype=torch.float64, requires_grad=True)
pred = X @ W.T + b
loss = 0.5 * (pred - Y).square().mean()
loss.backward()

# STEP 2: 用与 mean 相同的分母推导矩阵梯度
with torch.no_grad():
    G = (pred - Y) / pred.numel()
    dW = G.T @ X
    db = G.sum(dim=0)
assert torch.allclose(W.grad, dW)
assert torch.allclose(b.grad, db)
print("dW:", dW.tolist(), "db:", db.tolist())

# STEP 3: 只扰动一个权重，独立检查该偏导
@torch.no_grad()
def value(w):
    return 0.5 * (X @ w.T + b - Y).square().mean()

eps = 1e-6
plus, minus = W.detach().clone(), W.detach().clone()
plus[0, 0] += eps
minus[0, 0] -= eps
finite_difference = (value(plus) - value(minus)) / (2 * eps)
assert torch.allclose(finite_difference, W.grad[0, 0], atol=1e-7)
print("finite difference:", finite_difference.item())
print("三种结果一致；参数此时尚未执行 optimizer.step()。")

```

- 第 4–12 行：半均方误差是一个标量；W、b 是需要求导的叶子张量。
- 第 13–21 行：pred.numel() 同时包含批量与输出维度。梯度推导必须和实际 loss 的归约一致。
- 第 22–34 行：改变副本而非原始参数，并以双精度计算中心差分。此处没有执行参数更新。

预期观察：手算与自动微分梯度一致；W[0,0] 的梯度约为 −3.066667，有限差分在容差内相同。

## 浏览器 Python 练习

预测是 w*x+b，损失是误差平方平均值的 \(\frac12\)。返回 (dw, db)。输入 x 与 y 是等长非空列表。

```python
def mse_gradient(x, y, w, b):
    # TODO: 对每条样本贡献求和，再除以样本数
    raise NotImplementedError("请实现 mse_gradient")

```

### 提示

- 每条样本的误差 e 对 w 的贡献是 e*x，对 b 的贡献是 e。
- 题目已经包含 \(\frac12\)，不需要再额外乘 2。

### 参考实现与解释

```python
def mse_gradient(x, y, w, b):
    n = len(x)
    errors = [w * xi + b - yi for xi, yi in zip(x, y)]
    dw = sum(e * xi for e, xi in zip(errors, x)) / n
    db = sum(errors) / n
    return dw, db

```

若把 loss 改成平方误差的 sum，梯度会是当前结果的样本数倍。检查代码中的归约后再比较学习率。

### 断言测试

```python
assert mse_gradient([1., 2.], [3., 5.], 0., 0.) == (-6.5, -4.0)
assert mse_gradient([1., 2.], [3., 5.], 2., 1.) == (0., 0.)
x, y, w, b = [-1., 0., 2.], [2., 1., -1.], 0.4, 0.2
def loss(w_value):
    return sum((w_value * xi + b - yi) ** 2 for xi, yi in zip(x, y)) / (2 * len(x))
eps = 1e-6
numerical = (loss(w + eps) - loss(w - eps)) / (2 * eps)
assert abs(mse_gradient(x, y, w, b)[0] - numerical) < 1e-6
print("通过：解析梯度与有限差分一致。")

```

## 本地 PyTorch 练习

不用 autograd，返回半均方误差对 W、b 的解析梯度。W 为 [O,I]，X 为 [B,I]，Y 为 [B,O]。

```python
import torch

def linear_grads(X, Y, W, b):
    # TODO: 返回与 W、b 形状相同的梯度
    raise NotImplementedError("请实现 linear_grads")

```

### 提示

- 先确认 W 采用 [O,I]，因此预测是 X@W.T+b。
- 半均方误差对预测的梯度为误差除以 pred.numel()，不只除以 B。

### 参考实现与解释

```python
import torch

def linear_grads(X, Y, W, b):
    pred = X @ W.T + b
    G = (pred - Y) / pred.numel()
    return G.T @ X, G.sum(dim=0)

```

线性层共享同一权重作用于全部样本，因此 dW=G.T@X 汇总每条样本对权重的贡献，db=G.sum(0) 汇总偏置贡献。测试刻意使用 O=2，使只按 Batch 平均的错误实现不能通过。函数应返回解析梯度，不需要调用 backward。

### 断言测试

```python
torch.manual_seed(4)
X = torch.randn(5, 3, dtype=torch.float64)
Y = torch.randn(5, 2, dtype=torch.float64)
W = torch.randn(2, 3, dtype=torch.float64, requires_grad=True)
b = torch.randn(2, dtype=torch.float64, requires_grad=True)
loss = 0.5 * (X @ W.T + b - Y).square().mean()
loss.backward()
dW, db = linear_grads(X, Y, W.detach(), b.detach())
assert dW.shape == W.shape and db.shape == b.shape
assert torch.allclose(dW, W.grad, atol=1e-10)
assert torch.allclose(db, b.grad, atol=1e-10)
print("PyTorch 测试通过：多输出维度的分母正确。")

```

## 练习：推导与分析

### 为什么对向量输出传全 1 反向，只得到一个 VJP，而不是完整 Jacobian？

全 1 将 Jacobian 的所有输出行相加，得到 \(J^\top\mathbf1=\nabla_x\sum_i f_i\)。很多不同的 J 都有相同的行和，因此这一结果无法恢复全部逐输出偏导。若目标是 mean，还必须把种子除以输出数。

例如 \(f(x)=\begin{bmatrix}x\\-x\end{bmatrix}\) 的 Jacobian 为 \(\begin{bmatrix}1\\-1\end{bmatrix}\)，输出对 x 都有依赖，但全 1 的 VJP 是 0。只看这个零梯度，不能判定两条路径都断开；它们可能恰好抵消。

完整 Jacobian 可用不同基向量的 VJP/JVP 组织得到，或调用 torch.func.jacrev/jacfwd。普通标量损失训练只需要自己的上游种子；排查多任务抵消时则应分别查看各目标的梯度。

代码定位：原理中的 jvp/vjp 对照；练习中 G 的归约分母。

- 能写出全 1 VJP 丢掉了哪些逐输出信息。
- 能区分路径断开与多条非零路径相互抵消。

### 有限差分为什么需要合适的 \(\varepsilon\)，且最好避开 ReLU 的零点？

中心差分近似 \(\frac{L(w+\varepsilon)-L(w-\varepsilon)}{2\varepsilon}\)。\(\varepsilon\) 太大时局部线性近似不准，太小时两个接近损失的相减会放大舍入误差，所以演示使用 float64 和小型问题。

ReLU 零点不可微，框架选择的次梯度约定不必等于跨过两侧计算的有限差分。应在光滑测试点核对自定义梯度，同时避免把有限差分当作大模型训练算法。

代码定位：演示 STEP 3 的参数副本、eps=1e-6 与双精度比较。

- 能说明截断误差和舍入误差的两种极端。
- 能解释不可微点不适合作为唯一梯度正确性证据。

## 练习：辨析与纠错

### 手推只除 Batch，代码却平均全部元素

多输出 mean 会引入输出维度的因子。先写出逐元素目标，再统一手推、框架和测试的分母；不要直接通过改学习率掩盖差异。

### 只比较梯度范数

正负相反或元素置换的向量可以有相同范数。至少逐参数逐元素比较，并核对参数顺序；同时使用绝对与相对容差。

### 在 ReLU 零点强行要求中心差分一致

非光滑点没有唯一普通导数。换到远离拐点的确定性输入，或按所采用次梯度约定解释结果，避免将边界数学误认为实现错误。

### 把 backward 当成参数更新

backward 产生梯度，optimizer.step 才执行优化算法。分别检查 grad、优化器成员和 step 前后参数，才能确认完整训练路径。

## 原始资料

- [PyTorch：Automatic differentiation](https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html)
- [PyTorch：Linear](https://docs.pytorch.org/docs/stable/generated/torch.nn.Linear.html)
- [PyTorch：gradcheck mechanics](https://docs.pytorch.org/docs/stable/notes/gradcheck.html)
- [PyTorch：Autograd mechanics，VJP 与梯度累积](https://docs.pytorch.org/docs/stable/notes/autograd.html)
- [PyTorch：Jacobians, Hessians, JVP and VJP](https://docs.pytorch.org/tutorials/intermediate/jacobians_hessians.html)
- [PyTorch：torch.func.jvp](https://docs.pytorch.org/docs/2.15/generated/torch.func.jvp.html)
- [Goodfellow、Bengio、Courville：Linear Algebra，秩、零空间与奇异值分解](https://www.deeplearningbook.org/contents/linear_algebra.html)
- [PyTorch：torch.linalg.svd](https://docs.pytorch.org/docs/stable/generated/torch.linalg.svd.html)
- [Goodfellow、Bengio、Courville：Numerical Computation，条件数与二次目标优化](https://www.deeplearningbook.org/contents/numerical.html)
