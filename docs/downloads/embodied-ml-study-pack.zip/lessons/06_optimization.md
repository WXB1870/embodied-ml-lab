# 梯度下降、动量与 AdamW

从随机梯度估计到历史状态、自适应尺度与实际参数更新。

优化算法规定怎样利用当前梯度与历史状态修改模型参数，使训练目标逐步降低。梯度下降按当前下降方向移动，动量平滑历史方向，Adam 按坐标估计梯度尺度，AdamW 另行施加权重衰减。它们是参数更新规则，不是网络结构或损失函数。本章先建立一次更新，再解释状态、学习率、裁剪和恢复怎样共同决定实际参数位移。

## 学习目标

- 说明梯度下降、动量与自适应缩放分别改变什么
- 写出标量 AdamW 更新并与 PyTorch 对照
- 区分学习率调度、参数分组与梯度累积的作用

前置知识：[线性代数与矩阵求导](https://wxb1870.github.io/embodied-ml-lab/learn/matrix-grad/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/)

## 梯度下降与随机梯度估计

梯度下降是沿目标函数负梯度更新参数的方法，随机梯度下降则用抽样数据估计这个梯度。梯度提供局部方向，学习率决定实际步长。先以完整目标为参照，才能区分曲率限制与采样波动。





设训练集目标为 \(J(\theta)=\frac1N\sum_{i=1}^{N}\ell_i(\theta)\)，完整梯度下降使用 \(g=\nabla J(\theta)\)，按 \(\theta_{\mathrm{next}}=\theta-\eta g\) 更新。由局部展开可得一阶变化 \(g^\top(-\eta g)=-\eta\lVert g\rVert_2^2\)。因此在光滑点、非零梯度及足够小步长下，负梯度是下降方向；较大的步长还受到曲率影响。参数尺度改变后，欧氏空间中的“同样距离”也随之改变，不能只根据方向选择任意学习率。





完整梯度每次都需要处理所有样本，SGD 用采样估计减少每次更新的计算量。固定当前参数，从训练索引中独立、有放回且均匀抽取 \(I_1,\ldots,I_B\)，得到 \(g_B=\frac1B\sum_{j=1}^{B}\nabla\ell_{I_j}(\theta)\)。期望的线性性给出 \(\mathbb E[g_B\mid\theta]=\frac1N\sum_i\nabla\ell_i(\theta)=\nabla J(\theta)\)。这说明该采样方案估计的是训练集目标梯度，不是已经知道了未知部署分布的梯度；也不保证每个实际小批次都使全目标下降。





记单个均匀样本梯度的协方差为 \(\Sigma_g\)。在上述独立抽样条件下，展开 \(g_B\) 的协方差，交叉项为零，得到 \(\operatorname{Cov}(g_B\mid\theta)=\Sigma_g/B\)。标准差因此按 \(1/\sqrt B\) 缩小，而非按 \(1/B\) 缩小。无放回采样、条件于已经消耗样本的随机重排、非均匀抽样或批内耦合损失需要使用各自的计算，不能直接照搬此公式。下面枚举一个小数据集全部有序二元批次，避免用蒙特卡洛近似代替这条恒等式。





加入动量、自适应缩放、权重衰减和裁剪后，最终 \(\Delta\theta\) 不再简单等于 \(-\eta g_B\)。诊断时应分别记录梯度、参数与 step 后的位移：梯度大却更新小，可能来自分母、裁剪或学习率；梯度为零但参数仍变化，可能来自动量或衰减。后续各节逐项解释这些机制。





一次具体更新可沿 [MLP 的 17 参数案例](#/learn/mlp?tab=theory&anchor=section-backpropagation)复算：先在旧参数点算完四组参数梯度，再统一使用 \(\eta=0.1\) 的 SGD。修改某层参数之后再计算其他层原本应属于旧点的梯度，会产生另一种算法。理解这一步后，再加入动量状态和坐标缩放，才能把优化器差异定位到更新规则。





$$
J(\theta)=\frac1N\sum_i\ell_i(\theta),\qquad g_B=\frac1B\sum_{j=1}^{B}\nabla\ell_{I_j}(\theta),\qquad \mathbb E[g_B\mid\theta]=\nabla J(\theta),\quad \operatorname{Cov}(g_B\mid\theta)=\frac{\Sigma_g}{B}
$$

```python
import torch

x = torch.tensor([-2., -1., 1., 3.], dtype=torch.float64)
y = torch.tensor([1., -1., 2., 0.], dtype=torch.float64)
theta = torch.tensor(0.4, dtype=torch.float64, requires_grad=True)
losses = 0.5 * (theta * x - y).square()
full_grad = torch.autograd.grad(losses.mean(), theta)[0]
per_sample = (theta.detach() * x - y) * x
torch.testing.assert_close(full_grad, per_sample.mean())

# 枚举均匀有放回采样的全部 4^2 个有序批次，B=2。
pairs = torch.cartesian_prod(torch.arange(4), torch.arange(4))
batch_grad = per_sample[pairs].mean(dim=1)
torch.testing.assert_close(batch_grad.mean(), full_grad)
torch.testing.assert_close(batch_grad.var(correction=0),
                           per_sample.var(correction=0) / 2)
print("完整梯度:", full_grad.item())
print("枚举的二样本梯度均值与方差:", batch_grad.mean().item(),
      batch_grad.var(correction=0).item())

```

固定参数后，全部有序索引对等概率出现，因此枚举均值和方差就是该有限采样分布的精确统计。例子检验 SGD 的估计对象和批量方差关系，不含模型训练，也不从中推断最优 Batch 大小。





## 动量把历史方向带入当前更新

动量是在优化器中维护梯度历史的加权平均，并用这份状态参与当前更新的方法。它让一次更新依赖此前方向，而非只看当前批次。下面展开递推式，说明平滑、启动偏差与学习率之间的关系。





先采用归一化指数平均约定：\(v_t=\beta v_{t-1}+(1-\beta)g_t\)，其中 \(0\le\beta<1\)、\(v_0=0\)，再令 \(\theta_{t+1}=\theta_t-\eta v_t\)。逐步代入前一时刻状态，得到 \(v_t=(1-\beta)\sum_{j=1}^{t}\beta^{t-j}g_j\)。最近梯度权重较大，较早梯度按时间差衰减；持续同向的贡献相加，快速变号的贡献可能部分抵消。这个滤波机制并不保证任何损失曲线都会更平滑。





若当前梯度始终等于常向量 \(g\)，几何级数给出 \(v_t=(1-\beta^t)g\)，说明零初始状态在早期尚未积累完整历史。反过来，如果最近梯度突然变号，旧贡献仍可能占优势。例如 \(\beta=0.8\)、梯度依次为 2、2、−1 时，\(v_t\) 依次为 0.4、0.72、0.376；第三步仍沿原来的参数下降方向移动。记忆可以滤去摆动，也会延迟对目标变化的响应。





另一常见约定是 \(u_t=\beta u_{t-1}+g_t\)，此时 \(v_t=(1-\beta)u_t\)。在固定 \(\beta\)、相容的零初始状态、无 dampening 且无 Nesterov 的条件下，若把第二种约定的学习率设为第一种的 \((1-\beta)\) 倍，两者参数位移相同。PyTorch SGD 的基础动量采用第二种形式，首个缓冲区取第一步梯度；开启 dampening、Nesterov 或其他约定后需重新对照，不能只复制同一个 momentum 数值。





动量保存了梯度历史，因此只加载模型权重不能完整恢复后续更新。冻结、解冻或改变任务分布时，也要决定是否延续既有状态。比较不同动量系数应保持数据与更新预算可比，并在状态改变后观察真实参数位移；把动量简单视为学习率的固定放大倍数，会遗漏瞬态过程。





$$
v_t=\beta v_{t-1}+(1-\beta)g_t=(1-\beta)\sum_{j=1}^{t}\beta^{t-j}g_j,\qquad g_j=g\ \Rightarrow\ v_t=(1-\beta^t)g
$$

```python
import torch

beta, ema_lr = 0.8, 0.1
p = torch.tensor([1.], dtype=torch.float64, requires_grad=True)
opt = torch.optim.SGD([p], lr=ema_lr * (1 - beta), momentum=beta,
                       dampening=0., nesterov=False)
manual = torch.tensor([1.], dtype=torch.float64)
v = torch.zeros_like(manual)
history = []
for value in [2., 2., -1.]:
    g = torch.tensor([value], dtype=torch.float64)
    v = beta * v + (1 - beta) * g
    manual -= ema_lr * v
    p.grad = g.clone()
    opt.step()
    torch.testing.assert_close(p.detach(), manual)
    history.append(v.item())
assert history[-1] > 0  # 当前 g<0，历史平均仍为正。
torch.testing.assert_close(torch.tensor(history), torch.tensor([0.4, 0.72, 0.376]))
print("归一化动量:", history, "最终参数:", p.item())

```

这里人为给定梯度序列，把优化器状态的差异与模型前向分开。学习率的 \((1-\beta)\) 因子对应两种动量定义，最后一次梯度变号则验证历史造成的滞后；这些关系只针对代码中声明的算法选项。





## Adam 的一阶、二阶矩与偏置修正

Adam 是同时维护梯度一阶矩与平方梯度二阶矩的自适应优化算法。前者汇总方向，后者估计逐坐标尺度，偏置修正补偿零初始状态带来的早期偏差。理解这三步以后，再写出完整更新。





Adam 分别维护梯度的一阶矩 \(m_t\) 和平方梯度的二阶矩 \(v_t\)。\(m_t\) 提供平滑方向，\(\sqrt{v_t}\) 提供逐坐标尺度，两者都以指数平均方式更新。由于初始状态通常为零，早期平均会偏向零，因此使用 \(\frac{m_t}{1-\beta_1^t}\) 和 \(\frac{v_t}{1-\beta_2^t}\) 做修正。这里的 t 是该参数实际经历的优化步计数，不是前向次数。



### 例：第一次 Adam 更新的手算

1. 令 \(m_0=v_0=0\)、\(g_1=2\)、\(\beta_1=0.9\)、\(\beta_2=0.999\)。

2. 得到 \(m_1=0.2\)、\(v_1=0.004\)；偏置修正后 \(\hat m_1=2\)、\(\hat v_1=4\)。

3. 忽略很小的 \(\varepsilon\)，更新为 \(-\eta\frac22=-\eta\)，而不是普通 SGD 的 \(-2\eta\)。

自适应尺度使“梯度翻倍，第一步也翻倍”的 SGD 直觉不再成立。

偏置修正可以从指数平均的展开看清。以一阶矩为例，\(m_t=(1-\beta_1)\sum_{j=1}^{t}\beta_1^{t-j}g_j\)，系数之和为 \(1-\beta_1^t\)。若各时刻梯度具有相同均值 \(\mu_g\)，则 \(\mathbb E[m_t]=(1-\beta_1^t)\mu_g\)；除以这个系数后才能恢复该平稳均值。二阶原点矩同理。实际梯度分布随训练变化时，修正仍归一化了有限历史的权重，但不能据此宣称它无偏估计了当前时刻的真实梯度或方差。





把梯度平方的平均误称为“梯度方差”容易混淆：\(v_t\) 没有减去均值平方，更准确是二阶原点矩。\(\varepsilon\) 放在 \(\sqrt{\hat v_t}\) 后作为分母稳定项，其位置影响小梯度区域。不同实现还可能包含 AMSGrad、foreach 或 fused 路径；做数值对照应明确算法选项和 dtype，同为 Adam 的实现不一定逐位一致。





若两次运行从同一零状态出发，并在每个对应步骤都有 \(g_t^{\prime}=cg_t\)，其中 \(c>0\) 是整个历史固定不变的数，则 \(m_t^{\prime}=cm_t\)、\(v_t^{\prime}=c^2v_t\)，偏置修正后也成立。代入更新式，相当于把 \(\varepsilon\) 改成 \(\frac\varepsilon c\)；只有 \(\varepsilon\) 可忽略且对应梯度历史确实保持这个比例时，任务更新才具有相应尺度不变性。开始训练若干步后突然把 loss 乘 c，旧状态不会同步缩放；各步有效分母发生非一致变化、多任务相对权重改变、非有限检查或裁剪改变历史，也都不满足这一结论的前提。





这解释了两个看似矛盾的现象：整体 loss 常数缩放未必像 SGD 一样线性放大 Adam 步长，但一个错误分母仍然可以改变训练。先判断它是所有样本、所有任务、整个历史共同乘同一个常数，还是改变了样本之间和步骤之间的权重，再讨论优化器能否抵消。





$$
m_t=\beta_1m_{t-1}+(1-\beta_1)g_t,\quad v_t=\beta_2v_{t-1}+(1-\beta_2)g_t^2,\quad \Delta\theta=-\eta\frac{\hat m_t}{\sqrt{\hat v_t}+\epsilon}
$$





## AdamW 为什么把权重衰减单独处理

权重衰减是在更新时使参数按比例缩小的机制；AdamW 将这项缩小与 Adam 的梯度统计分开处理。它与向损失加入 L2 惩罚在自适应优化中通常不等价，因为后者还会进入矩估计和逐坐标缩放。





向损失加入 \(\frac\lambda2\lVert\theta\rVert_2^2\) 会给梯度增加 \(\lambda\theta\)。对最简单的无动量 SGD，这与每步乘 \((1-\eta\lambda)\) 的权重衰减可对应；在 Adam 中，这部分梯度也会进入一阶与二阶矩，经过自适应缩放，不再等同于独立收缩。AdamW 将衰减直接作用于参数，并只用任务梯度更新矩估计，使两种作用分开。





典型 AdamW 更新可写为 \(\theta_{\mathrm{next}}=(1-\eta\lambda)\theta-\eta\frac{\hat m_t}{\sqrt{\hat v_t}+\varepsilon}\)。即使称为“解耦”，每步收缩仍显式依赖当前学习率 \(\eta\)；学习率日程改变累计衰减量。不要既使用 AdamW.weight_decay，又无意在 loss 中重复加入相同 L2 项，除非确实希望组合两种目标。Bias 和 Norm 参数是否衰减是训练策略，需要用参数组明确实现。





只考虑衰减、所有任务梯度为零且没有历史动量时，K 步后的参数为 \(\theta_K=\theta_0\prod_{t=1}^K(1-\eta_t\lambda)\)。因此相同 weight_decay 在不同更新次数或学习率日程下，累计收缩不同；“解耦”指不让衰减进入梯度矩估计，不是说它与学习率、训练预算无关。PyTorch AdamW 对 grad=None 的参数跳过更新，零张量梯度则仍可触发衰减；冻结、未被分支使用和有梯度但数值为零要分别检查。





$$
\theta_{t+1}=(1-\eta_t\lambda)\theta_t-\eta_t\frac{\hat m_t}{\sqrt{\hat v_t}+\epsilon}
$$



### 例：只有衰减的一步

1. 在一个明确提供零梯度的参数上，取 \(\theta=10\)、学习率 0.01、weight_decay=0.1，且没有历史动量。

2. 收缩因子为 \(1-0.01\times0.1=0.999\)，参数变成 9.99。

3. 若参数 grad=None，优化器可能跳过该参数，上述零梯度示例不适用于这种情况。

零梯度、None 梯度与零更新不是同一个条件。

### 把 AdamW 与给 loss 加 L2 当作同一实现

在自适应优化器中，L2 梯度会进入矩估计，而独立衰减不会。

用同一标量参数和梯度序列分别手算两种更新，对照任务梯度与衰减项。

## 学习率日程要绑定真实 optimizer step

学习率日程是让更新步长随训练进度变化的规则，Warmup 是其中从较小步长逐渐升高的一段。它改变每一步的更新幅度，因此进度应与真实参数更新相匹配，而非默认等于读取批次的次数。





Warmup 让学习率从较小值逐渐升到目标值，常用于降低训练初期突然更新的风险；后续可保持、分段降低或按余弦衰减。具体选择应根据训练预算和曲线验证，不能把某个比例视为通用定律。日程中的总步数必须明确是优化更新次数，还是代码额外定义的 token/样本进度。





采用梯度累积时，多个微批次只对应一次 step。如果每个微批次都推进按更新步定义的 scheduler，日程会提前走完。AMP 检测非有限梯度后可能跳过实际参数更新，这时是否推进日程也应遵守既定计数协议。恢复 checkpoint 时还要恢复优化器和 scheduler 状态，并核对当前学习率；只加载 epoch 数字不保证状态一致。





学习率 warmup 并不是修复任意 NaN 的通用机制。若错误来自除零或错误标签，降低初期步长只会延后暴露。先验证一个 FP32、固定小批次的更新，再决定是否需要调整日程，并在固定总预算下比较。









### 把样本步、微批步与优化步分别命名

不同计数会影响学习率、日志、保存频率和训练预算解释。

在日志中同时输出 micro_step、optimizer_step、有效样本数和每组实际 lr。

## 参数组、冻结与优化器成员检查

优化器参数组是将待更新参数分组、分别指定学习率和衰减等选项的管理方式。优化器操作的是创建时传入的参数对象，不能自动发现所有新模块。先定义更新范围，再核对冻结状态与成员身份。





优化器只更新传入的参数对象。新建模块后忘记加入优化器，会出现梯度正常但参数不动；重新替换模型参数对象后，优化器可能仍引用旧对象。创建优化器时审计参数 ID、名称、学习率和衰减配置，检查遗漏与重复，是微调工程中的高频基础工作。





冻结参数通常通过 requires_grad=False 并正确管理参数组实现，但已有 .grad 可能残留，不能只改一个标记就假定优化器永远不会碰它。解冻时要决定是否恢复历史状态或初始化新状态。不同模块采用不同学习率是可行策略，但应记录实际组配置，并先证明目标参数确实收到梯度、发生预期更新和正确保存。









### 只检查 requires_grad，不检查优化器对象

求导与更新是两套关系；参数可以有梯度却不在优化器里。

比较模型中目标参数的 id 与 optimizer.param_groups，并检查一次 step 前后的快照。

## 梯度裁剪与 Adam 更新限制不是一回事

梯度裁剪是在传给优化器之前，按约定限制梯度幅度的操作。全局范数裁剪在超阈值时整体缩放梯度；Adam 随后还会按内部状态改变更新，因此限制梯度范数不等于直接限制最终参数位移。





全局范数裁剪将梯度向量 g 缩放为 \(g\min\!\left(1,\frac c{\lVert g\rVert_2}\right)\)，在超阈值时保持当前梯度方向、限制其范数。它应作用于完整累积且已还原 AMP 缩放的梯度；逐微批次裁剪再相加，会得到不同方向与幅度。非有限梯度应先定位原因，不能指望裁剪将 NaN 修成正确数值。





Adam 还会用历史矩重新缩放各坐标，所以限制原始梯度范数不等于严格限制最终参数位移范数。记录裁剪前后的范数有助于识别频繁异常，但阈值过小也会长期削弱学习信号。观察裁剪发生比例、实际 \(\Delta\theta\) 与任务指标，才能判断它是在保护偶发极值，还是掩盖了目标尺度或学习率设置不当。





一个明确反例是 Adam 的第一步，初始矩为零、忽略 \(\varepsilon\)，且所有坐标非零时，更新的每个坐标为 \(-\eta\operatorname{sign}(g_i)\)。把 \(g=[1,100]\) 先做统一范数裁剪，只乘同一个正数，归一化后仍得到两个大小约为 \(\eta\) 的更新。阈值缩小不必按比例缩小这一步的参数位移。后续有历史状态时裁剪会改变矩估计，不能根据第一步的反例推断裁剪始终无效。





$$
\operatorname{clip}_c(g)=g\min\left(1,\frac{c}{\|g\|}\right),\qquad \Delta\theta_i\approx-\eta\operatorname{sign}(g_i)\quad(t=1,\ m_0=v_0=0,\ \epsilon\approx0)
$$





## 状态恢复与一次更新对照

优化器具有历史状态，因此相同权重和相同输入未必产生相同的下一步。用一段可手算梯度序列检验更新，再比较保存恢复后的下一次位移，可以直接核对算法是否完整延续。





用确定的标量梯度序列手算多次 AdamW 更新，再对照官方优化器，可以独立检查矩估计、偏置修正、\(\varepsilon\) 与衰减位置。只看最终 loss 下降无法区分这些机制，因为不正确的更新也可能在简单任务上下降。扩展到模型时，从同一初始权重和 Batch 出发，比较完整批次与累积实现的参数位移。





训练不稳定时，先确认梯度有限、分母正确、参数组完整，再做学习率对照。一次修改只改变一个因素，保持数据顺序、有效 Batch 和初始化可复查。不要用“Adam 会自动调学习率”来忽略基础尺度；它提供逐坐标自适应，但整体学习率、权重衰减、目标归约和训练预算仍然是独立决策。





模型权重相同而优化器状态不同，后续训练可以明显分叉。因此完整恢复要保存权重、优化器、调度器、缩放器以及与数据随机性有关的状态，并用恢复前后的下一步对照验证，而不只检查 load_state_dict 没有报错。





优化器把梯度变成位移，但实际位移还由历史状态、学习率、参数组和衰减决定。只有在同一目标、同一更新边界上比较这些量，才能解释为什么相同梯度会得到不同训练行为。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| parameter | 任意参数形状 | 被优化的权重或偏置 |
| exp_avg / exp_avg_sq | 与参数相同 | Adam 为参数保存的一阶、二阶矩状态 |
| learning rate | 每个参数组一个标量 | 在每次优化更新时使用的步长 |

## 完整代码与精读

```python
import math
import torch

torch.manual_seed(0)
# STEP 1: 标量目标与 AdamW 配置
parameter = torch.tensor([2.], dtype=torch.float64, requires_grad=True)
lr, weight_decay = 0.1, 0.01
beta1, beta2, eps = 0.9, 0.999, 1e-8
optimizer = torch.optim.AdamW([parameter], lr=lr, betas=(beta1, beta2),
                              eps=eps, weight_decay=weight_decay)
manual_parameter, m, v = 2., 0., 0.

# STEP 2: 两条独立路径执行同样的更新
for step in range(1, 4):
    optimizer.zero_grad(set_to_none=True)
    loss = 0.5 * (parameter - 1.).square().sum()
    loss.backward()
    grad = manual_parameter - 1.
    m = beta1 * m + (1 - beta1) * grad
    v = beta2 * v + (1 - beta2) * grad * grad
    m_hat = m / (1 - beta1 ** step)
    v_hat = v / (1 - beta2 ** step)
    manual_parameter *= 1 - lr * weight_decay
    manual_parameter -= lr * m_hat / (math.sqrt(v_hat) + eps)
    optimizer.step()
    assert abs(parameter.item() - manual_parameter) < 1e-10
    print("update", step, "parameter", round(parameter.item(), 8))

# STEP 3: Warmup 以优化器更新次数计数
peak_lr, warmup_updates = 1e-3, 4
def lr_for_update(index):
    return peak_lr * min((index + 1) / warmup_updates, 1.)

print("warmup:", [lr_for_update(i) for i in range(6)])
print("saved optimizer state:", sorted(optimizer.state[parameter].keys()))

```

- 第 5–12 行：学习率、衰减系数、矩系数和 eps 各司其职。这里使用双精度以严格核对数值。
- 第 13–28 行：先做偏差修正，再计算自适应更新；权重衰减独立作用于参数。
- 第 29–35 行：warmup 的索引表示真实参数更新次数。优化器还保存矩和步数，恢复训练时不能只恢复模型权重。

预期观察：每一步手工值与 AdamW 一致；第一次参数约为 1.898。Warmup 的前四次学习率是 0.00025、0.0005、0.00075、0.001。

## 浏览器 Python 练习

输入参数、当前梯度、上一时刻 m/v，以及从 1 开始的 step。返回 (新参数, 新m, 新v)。参数采用解耦衰减。

```python
import math

def adamw_step(theta, grad, m, v, step, lr=0.1,
               beta1=0.9, beta2=0.999, eps=1e-8, weight_decay=0.01):
    # TODO: 更新矩、偏差修正、解耦衰减、自适应更新
    raise NotImplementedError("请实现 adamw_step")

```

### 提示

- 偏差修正的指数使用当前 step；第一步是 1。
- 把 theta 乘 (1-lr*weight_decay)，不要把衰减项混入 grad。

### 参考实现与解释

```python
import math

def adamw_step(theta, grad, m, v, step, lr=0.1,
               beta1=0.9, beta2=0.999, eps=1e-8, weight_decay=0.01):
    m = beta1 * m + (1 - beta1) * grad
    v = beta2 * v + (1 - beta2) * grad * grad
    m_hat = m / (1 - beta1 ** step)
    v_hat = v / (1 - beta2 ** step)
    theta = theta * (1 - lr * weight_decay)
    theta -= lr * m_hat / (math.sqrt(v_hat) + eps)
    return theta, m, v

```

这个标量练习忽略分布式、混合精度等系统细节，但保留了 AdamW 的核心更新规则。

### 断言测试

```python
theta, m, v = adamw_step(2., 4., 0., 0., 1)
assert abs(theta - (1.998 - 0.1 * 4 / (4 + 1e-8))) < 1e-12
assert abs(m - 0.4) < 1e-12 and abs(v - 0.016) < 1e-12
zero, mz, vz = adamw_step(2., 0., 0., 0., 1)
assert zero == 1.998 and mz == 0. and vz == 0.
second, m2, v2 = adamw_step(theta, 1., m, v, 2)
assert abs(m2 - 0.46) < 1e-12
assert abs(v2 - (0.999 * v + 0.001)) < 1e-12
assert second < theta
print("通过：矩估计、偏差修正及解耦衰减。")

```

## 本地 PyTorch 练习

构造 AdamW 参数组：仅加入 requires_grad=True 的参数；本题约定 ndim<2 不衰减，其余使用指定衰减。每个参数只能出现一次。

```python
import torch

def make_optimizer(model, lr, weight_decay):
    # TODO: 分组后返回 torch.optim.AdamW
    raise NotImplementedError("请实现 make_optimizer")

```

### 提示

- 只遍历 requires_grad=True 的参数，按本题 ndim<2 的约定分组。
- 在每个 group 内显式设置 weight_decay，并检查参数没有遗漏或重复。

### 参考实现与解释

```python
import torch

def make_optimizer(model, lr, weight_decay):
    decay, no_decay = [], []
    for parameter in model.parameters():
        if parameter.requires_grad:
            (no_decay if parameter.ndim < 2 else decay).append(parameter)
    return torch.optim.AdamW([
        {"params": decay, "weight_decay": weight_decay},
        {"params": no_decay, "weight_decay": 0.},
    ], lr=lr)

```

参数组是训练策略的一部分。函数将低维参数设为零衰减、矩阵参数设为指定衰减；这只是本题约定，不是对所有网络都必须采用的规则。测试基于参数对象身份核对覆盖与唯一性，并排除被冻结的权重。

### 断言测试

```python
from torch import nn
model = nn.Sequential(nn.Linear(3, 4), nn.LayerNorm(4), nn.Linear(4, 2))
model[0].weight.requires_grad_(False)
optimizer = make_optimizer(model, 1e-3, 0.1)
ids = [id(p) for group in optimizer.param_groups for p in group['params']]
expected = {id(p) for p in model.parameters() if p.requires_grad}
assert len(ids) == len(set(ids)) and set(ids) == expected
for group in optimizer.param_groups:
    assert group['lr'] == 1e-3
    for parameter in group['params']:
        wanted_decay = 0. if parameter.ndim < 2 else 0.1
        assert group['weight_decay'] == wanted_decay
print("PyTorch 测试通过：冻结、覆盖和分组规则正确。")

```

## 练习：推导与分析

### Adam 会抵消 loss 的尺度，为什么修改分母和梯度裁剪仍需满足相应条件？

尺度抵消要求整个对应梯度历史共同乘固定正数 c，且 \(\varepsilon\) 足够小；此时 m 乘 c、v 乘 \(c^2\)。一步步变化的归约分母、对某个任务单独加权，或中途改变 loss 系数，都不满足这个条件。

全局梯度裁剪是非线性变换，通常会改变各步进入状态的相对强度。但第一步、无历史且忽略 \(\varepsilon\) 时，Adam 可以抵消一次统一正缩放，所以裁剪阈值不是通用的参数位移上限。检查更新大小时应直接记录 \(\Delta\theta\)。

AdamW 的衰减不进入 m、v；把 L2 写进 loss 则会改变它们。因此数据损失缩放、L2 系数与独立 weight_decay 的作用不能凭一个“自适应”名称混在一起。

代码定位：标量 AdamW 演示的矩估计、\(\varepsilon\)、衰减位置；裁剪前后范数与实际参数差。

- 能说出固定历史缩放与逐步改变权重的区别。
- 能构造梯度已裁剪但 Adam 位移没有按同一比例缩小的反例。

### 使用梯度累积或跳过异常更新时，学习率调度的“步”应该如何定义？

必须按设计统一。如果 Warmup 定义为优化器更新次数，多个微批只构成一次更新，调度器就不能每个微批都推进。混合精度可能跳过非有限梯度的更新，是否推进日程也需明确并记录。

恢复训练要保留调度进度与优化器状态，并记录有效样本数量。只对齐读取 Batch 的次数，可能让两个实验具有不同的参数更新次数和学习率轨迹。

代码定位：lr_for_update；后续 gradient-accumulation 与 mixed-precision 的更新边界。

- 能区分 micro-batch、有效 Batch 与参数更新。
- 能说明恢复或跳步时应核对哪些状态。

## 练习：辨析与纠错

### 把 Adam 当成不需要选择学习率

逐坐标自适应不消除整体步长和目标尺度问题。用固定初始化、数据与预算对比学习率，并记录真实参数位移。

### AdamW 同时重复加入同一个 L2 项

两者经过不同路径，组合会改变目标与更新。除非实验明确要求，否则选择一种并记录参数组的衰减设置。

### 每个微批次都推进更新步日程

累计 K 次才更新一次时，这会让 scheduler 快 K 倍。明确计数单位，在真正更新边界推进对应状态。

### 只有模型 state_dict 就称为精确续训

动量、二阶矩、调度与随机状态缺失会改变后续轨迹。保存完整状态，并核对恢复后的下一步结果。

## 原始资料

- [PyTorch：AdamW](https://docs.pytorch.org/docs/stable/generated/torch.optim.AdamW.html)
- [Decoupled Weight Decay Regularization](https://arxiv.org/abs/1711.05101)
- [PyTorch：Optimizing Model Parameters](https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html)
- [PyTorch：AdamW 更新式与 None 梯度语义](https://docs.pytorch.org/docs/2.15/generated/torch.optim.AdamW.html)
- [PyTorch：SGD 的动量、dampening 与缓冲区约定](https://docs.pytorch.org/docs/stable/generated/torch.optim.SGD.html)
- [Goodfellow、Bengio、Courville：Minibatch Algorithms 与 Momentum](https://www.deeplearningbook.org/contents/optimization.html)
