# 策略梯度

概率梯度、基线、连续动作密度与旧数据复用。

策略梯度是直接对策略参数求期望回报梯度、据此改进动作分布的方法。常见估计用采样动作的对数概率梯度，乘以回报或优势，让结果较好的动作更可能被选择；它不要求真实环境可微。本章先推导这种估计，再定义基线、连续动作密度与采样梯度，最后连接重要性比率和 PPO 的局部代理目标。

## 学习目标

- 读写最小 score-function 策略梯度损失并判断更新方向
- 区分价值基线的独立训练与 actor 中的梯度阻断
- 实现对角 Gaussian 的联合 `log_prob`，解释 `sample` 与 `rsample` 的适用目标

前置知识：[回报与 Bellman 方程](https://wxb1870.github.io/embodied-ml-lab/learn/returns-bellman/) · [概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/)

## 从示教标签转向期望回报

随机策略是给定状态后动作的概率分布，策略目标是它产生轨迹时的期望回报。策略梯度研究怎样调整这些概率以改善结果，区别于模仿学习拟合专家动作。先固定这个目标，再对轨迹概率求导。





行为克隆告诉模型在条件 c 下示教做了什么；强化学习则依据执行结果评价一个动作或整段轨迹的收益。随机策略 \(\pi_\theta(a\mid s)\) 定义在状态下采取不同动作的概率或密度，目标 \(J(\theta)\) 是由该策略产生轨迹时的期望回报。奖励不是正确动作向量，不能把奖励大小直接当作动作监督标签。





轨迹概率可以分解为初始状态分布、各步策略概率和环境转移概率。若初始状态分布、环境动力学与奖励函数均不依赖 \(\theta\)，对轨迹概率使用 \(\nabla p=p\nabla\log p\)，参数梯度只需要经过策略 `log_prob`。这个 score-function 估计不要求对真实环境求导，所以能在不可微的机器人或模拟器中使用。下式针对有限时域、无折扣目标，\(G_t\) 是从 t 起的奖励和；若 J 定义为从起点计算的折扣回报，精确推导还需相应的 \(\gamma^t\) 权重，或明确采用折扣状态访问分布的约定。





把中间步骤展开，令 \(\tau=(s_0,a_0,\ldots,s_T)\)，无折扣总奖励为 \(R(\tau)=\sum_{t=0}^{T-1}r_t\)，初始分布为 \(\rho_0\)、转移为 \(P\)。假设轨迹概率（密度）在参数无关的共同支持上可微，并满足交换参数求导与积分的正则条件，则\[\begin{aligned}p_\theta(\tau)&=\rho_0(s_0)\prod_{t=0}^{T-1}\pi_\theta(a_t\mid s_t)P(s_{t+1}\mid s_t,a_t),\\\nabla_\theta J&=\int R(\tau)\nabla_\theta p_\theta(\tau)\,d\tau\\&=\mathbb E_{\tau\sim p_\theta}\!\left[R(\tau)\sum_t\nabla_\theta\log\pi_\theta(a_t\mid s_t)\right].\end{aligned}\]对一条固定轨迹求对数概率梯度时，环境因子没有策略参数；这并不表示真实的状态访问分布与参数无关，后者已经包含在外层采样分布中。 离散状态和动作的情形将积分换成求和。





为什么可以把整段 \(R\) 换成从当前时刻起的 \(G_t\)？在给定采样动作前的历史后，更早奖励已经确定，且 \(\mathbb E_{a_t\sim\pi_\theta}[\nabla_\theta\log\pi_\theta(a_t\mid s_t)]=0\)。因此过去奖励与当前 score 的乘积期望为零，可以从估计器删除；未来奖励不能删除，因为它受到当前动作影响。下面枚举一个两步系统的全部轨迹，直接核对完整概率求导、整段回报权重和 reward-to-go 三种计算。





估计式仍依赖数据来自对应策略及相应分布假设。拿一份任意旧策略数据，直接套同一个 on-policy 公式，并不自动得到当前策略的无偏梯度；数据复用需要对应的重要性比率、目标设计或其他 off-policy 方法。回报定义、状态访问权重和估计方式都属于算法的一部分。





$$
\nabla_\theta J=\mathbb E_{\tau\sim\pi_\theta}\left[\sum_t\nabla_\theta\log\pi_\theta(a_t\mid s_t)\,G_t\right]
$$

```python
import torch

theta = torch.tensor([0.3, -0.4], dtype=torch.float64, requires_grad=True)
def probability(action, state):
    p = torch.sigmoid(theta[state])
    return p if action else 1 - p

expected_return = torch.zeros((), dtype=theta.dtype)
for a0 in (0, 1):
    for a1 in (0, 1):
        r0, r1 = float(a0), (2.0 if a1 == a0 else -1.0)
        expected_return = expected_return + probability(a0, 0) * probability(a1, a0) * (r0 + r1)
exact = torch.autograd.grad(expected_return, theta)[0]
full = torch.zeros_like(theta)
to_go = torch.zeros_like(theta)
wrong = torch.zeros_like(theta)
for a0 in (0, 1):
    for a1 in (0, 1):
        r0, r1 = float(a0), (2.0 if a1 == a0 else -1.0)
        p0, p1 = probability(a0, 0), probability(a1, a0)
        mass = (p0 * p1).detach()
        g0 = torch.autograd.grad(p0.log(), theta)[0]
        g1 = torch.autograd.grad(p1.log(), theta)[0]
        full += mass * (g0 + g1) * (r0 + r1)
        to_go += mass * (g0 * (r0 + r1) + g1 * r1)
        wrong += mass * (g0 + g1) * r1
torch.testing.assert_close(full, exact, rtol=1e-12, atol=1e-12)
torch.testing.assert_close(to_go, exact, rtol=1e-12, atol=1e-12)
assert not torch.allclose(wrong, exact)
print("通过：整轨迹求导与两种 score 估计一致，错误删除当前奖励的版本不一致。")

```

状态从 0 开始，第一步动作决定第二步状态，两个状态分别使用一个 Bernoulli logit。穷举四条轨迹消除了采样方差；对 score 加权时把轨迹概率作为数值权重，而 exact 路径对完整概率求导。错误版本把第一步自己的奖励也删除，测试应拒绝这种混淆。





### 先核对动作数据由哪一个策略采集

策略梯度的期望不是对任意日志求平均，行为策略变化会改变分布与概率比率。

保存采样时策略版本、动作、`log_prob` 和回合边界，明确算法允许如何复用这些数据。

## 损失负号与更新方向要能手算

actor 是参数化的策略，actor loss 是为梯度下降程序构造的优化表达式。回报最大化常通过负号转换为损失最小化，优势则给动作概率的改变提供方向与权重。下面用可手算例子核对符号。





优化器通常做梯度下降，而策略目标是最大化期望回报，因此 actor 常写 \(L_\pi=-\operatorname{mean}\bigl(\log\pi_\theta(a\mid s)\,\hat A\bigr)\)。优势为正时，下降应提高该样本动作的概率；优势为负时，应降低它的概率。检查这一方向比仅看 actor loss 数值是否下降更重要，因为负 `log_prob` 与正负优势组合没有统一的“越接近零越好”解释。





对离散 Softmax，选择动作 j 时，\(-A\log p_j\) 对 logit \(z_i\) 的梯度为 \(A(p_i-\mathbf1_{i=j})\)。这来自交叉熵梯度乘一个有符号权重。优势不是概率，允许为负；它表达相对基线更好或更差，而不是要求模型拟合某个固定类别标签。





同一损失数值可以对应不同更新方向，尤其 Batch 中正负优势互相抵消时。记录概率变化、梯度范数、熵和实际回报比单一 actor loss 更有解释力。构造一个单样本、两个动作的小例子，检查正优势和负优势是否产生相反更新，是接入复杂训练循环前的必要步骤。





$$
L_\pi=-\operatorname{mean}(\log\pi_\theta(a\mid s)\operatorname{stopgrad}(\hat A)),\qquad \frac{\partial L}{\partial z_i}=\hat A(p_i-\mathbf1_{i=j})
$$



### 例：两动作的正优势更新方向

1. 初始概率 \(p=(0.5,0.5)\)，采到第二个动作，优势 \(A=2\)。

2. logits 梯度为 [1,−1]；梯度下降使第一个 logit 降低，第二个升高。

3. 若 \(A=-2\)，梯度反号，第二个动作的概率应降低。

先用最小例子检查符号，再讨论复杂 actor-critic 训练曲线。

## 基线无偏，需要怎样的独立性

基线是从回报权重中减去的参考值，目的是降低策略梯度估计的方差。给定状态后不依赖当前采样动作的适当基线，可以保持期望梯度不变。下面推导这条独立性要求，而非假定任意均值都无偏。





固定状态 s，记 \(g(a,s)=\nabla_\theta\log\pi_\theta(a\mid s)\)。在分布支持和求导交换满足正则条件时，\(\mathbb E_a[g\mid s]=\nabla_\theta\int\pi_\theta(a\mid s)\,da=0\)。因此给定 s 后不依赖这次动作抽样的 \(b(s)\)，满足 \(\mathbb E[g\,b(s)\mid s]=0\)。基线可以由过去数据训练，也可以随参数变化；在当前 actor 更新里，将其数值作为固定权重。





“输入没有动作”不自动等于统计独立。若先用当前样本的奖励拟合基线，再把这个基线用于同一动作样本，拟合结果可能通过数据依赖该动作。需要按实际采集、拟合、复用顺序判断，不能只看 `critic.forward` 是否只收 s。下一节的同批均值给出可以精确计算的反例。





无偏与最小方差也是两回事。在固定状态、用梯度向量的总方差作为标准时，最小化 \(\mathbb E[\|g\|^2(G-b)^2\mid s]\)，对 b 求导为零，得到 \(b^*=\frac{\mathbb E[G\|g\|^2\mid s]}{\mathbb E[\|g\|^2\mid s]}\)，分母须为正。常用 \(V(s)=\mathbb E[G\mid s]\) 没有这个梯度范数权重，通常是方便的选择，不能无条件说它一定是最优方差基线。





代码里使用 `stopgrad(advantage)`，是为了阻止 actor 通过修改权重本身来降低乘积损失；它不能消除数据造成的统计依赖。critic 另用回报或 TD 目标更新，共享骨干可以同时收到两项损失的梯度。GAE、bootstrap 和优势标准化又有各自的估计性质，不能全部归为同一个“减基线不改变期望”的结论。





$$
\mathbb E[g\,b(s)\mid s]=b(s)\mathbb E[g\mid s]=0,\qquad b^*(s)=\frac{\mathbb E[G\|g\|^2\mid s]}{\mathbb E[\|g\|^2\mid s]}
$$





### 让 actor 沿着 advantage 反传到 critic

这增加了不属于所写策略梯度估计的路径，模型可通过改变权重而不是动作概率影响损失。

检查 actor-only backward 时 advantage 和独立 critic 参数没有梯度，再单独验证 critic 的训练目标。

## 同一批回报的均值，为什么会带来有限样本偏差

同批回报基线是用本批数据的平均回报作为各样本的参考值。它包含当前样本自身的信息，因此与逐动作独立的基线不同。下面在独立的一步采样中计算由此产生的有限样本偏差。





取同一个状态下 N 个独立的一步样本 \((a_i,R_i)\)，令 \(g_i=\nabla\log\pi(a_i)\)，真实梯度 \(g^*=\mathbb E[g_iR_i]\)。用同批均值 \(\bar R=\frac1N\sum_jR_j\) 作每个样本的基线。展开 \(\mathbb E[g_i\bar R]\)：\(j=i\) 的项是 \(g^*/N\)；\(j\ne i\) 的项因独立而成为 \(\mathbb E[g_i]\mathbb E[R_j]=0\)。于是整个中心化估计的期望是 \((1-1/N)g^*\)。





\(N=1\) 时 \(R_1-\bar R=0\)，更新直接消失；\(N=2\) 时期望只剩一半。\(\operatorname{detach}(\bar R)\) 不改变这个结果，因为这里讨论的是抽样依赖，不是反向传播路径。使用不含样本 i 的 leave-one-out 均值，在这个独立同分布的一步例子中可以恢复无偏；跨时间相关的轨迹不能直接沿用这份证明。





再除以同批回报的标准差，会引入额外的随机尺度，不能简单地解释成除以一个固定常数。实际优势中心化或标准化可能对优化有帮助，但应把它视为具有自身性质的估计与优化选择。





$$
\mathbb E\left[\frac1N\sum_i g_i(R_i-\bar R)\right]=\left(1-\frac1N\right)g^*
$$

```python
from itertools import product
import math

# Bernoulli policy at p=0.5; reward is the sampled action.
# With logit as parameter, score = action - p.
p = 0.5
plain = centered = leave_one_out = 0.0
for actions in product((0, 1), repeat=2):
    probability = math.prod(p if a else 1 - p for a in actions)
    rewards = actions
    scores = [a - p for a in actions]
    mean_reward = sum(rewards) / 2
    plain += probability * sum(g * r for g, r in zip(scores, rewards)) / 2
    centered += probability * sum(g * (r - mean_reward)
                                  for g, r in zip(scores, rewards)) / 2
    leave_one_out += probability * sum(
        scores[i] * (rewards[i] - rewards[1 - i]) for i in range(2)) / 2
assert math.isclose(plain, 0.25)
assert math.isclose(centered, 0.125)
assert math.isclose(leave_one_out, 0.25)
print('plain / same-batch / leave-one-out:', plain, centered, leave_one_out)
```

四种二动作组合穷举了整个分布，不用 Monte Carlo 近似。probability 是该组合出现的概率，scores 是对 logit 求导的 `log_prob`。三个估计分别得到 0.25、0.125、0.25：相同数值处理只有在依赖关系不同的条件下才有不同的无偏性。





## 连续动作的联合密度与动作轴

连续策略用概率密度描述动作向量，联合对数密度描述整条多维动作，而每维 log_prob 只描述一个坐标。是否先沿动作轴求和决定所用统计对象。下面以对角高斯建立这项约定。





对角 Gaussian 常由 \(\mu\in\mathbb R^{B\times D}\) 与标准差 \(\sigma\) 给出，假设给定状态时各动作坐标条件独立。联合 `log_prob` 是各维 log 密度之和；`torch.distributions.Normal.log_prob` 返回逐维值，需要 `sum(-1)`，或者用 Independent 正确声明事件维。Batch 平均则在得到每样本联合值之后进行。





连续概率密度可以大于 1，所以 `log_prob` 也可以为正，这不违反概率归一化。密度的数值还随动作单位变化，不能把连续 `log_prob` 直接当离散类别概率来解释。若将动作维上的 sum 改成 mean，基础梯度多出一个维度尺度；在 PPO 比率等非线性运算里，更会改变完整联合分布的比值。





使用 `log_std` 有助于表达正标准差，但 exp 后仍需合理的数值范围。过小方差会产生很大的 `log_prob` 梯度，过大方差会导致探索动作偏离可用区域。clamp 是一种明确的参数约束，超出范围的梯度行为也要理解；它不替代动作边界与执行接口的处理。





$$
\log\pi(a\mid s)=-\frac12\sum_{d=1}^{D}\left[\left(\frac{a_d-\mu_d}{\sigma_d}\right)^2+2\log\sigma_d+\log(2\pi)\right]
$$



### 例：为什么联合 log_prob 要沿动作维相加

1. 两个动作坐标在给定状态下独立，某个动作处密度分别是 0.2 和 0.3。

2. 联合密度为 0.06，联合 log 密度为 \(\log(0.2)+\log(0.3)\)。

3. 把两项平均后再取 exp 得到 \(\sqrt{0.06}\)，并不是这个二维动作的联合密度。

事件维求和与 Batch 平均是两种归约，不能用一次 mean 代替。

## sample 与 rsample：不要混用梯度估计

Score-function 估计通过动作的对数概率求参数梯度，重参数化估计则通过可微采样值传播梯度。sample 和 rsample 支持这两类不同用法。先选定估计器，再决定哪些动作和优势应保持为固定数据。





score-function 估计把采样动作视为固定数据，对 \(\log\pi_\theta(a\mid s)\) 关于 \(\theta\) 求导。通常使用 `sample` 获得不带重参数化路径的动作；若动作来自其他带图的计算，应在这个损失中 `detach`。环境返回的优势也按估计式作为固定权重，而不是沿环境执行过程直接反传。





`rsample` 使用 \(a=\mu+\sigma\epsilon\) 让动作对分布参数可微，适合通过可微奖励或 critic 计算 pathwise 梯度的目标。若把同一 `rsample` 动作不 `detach` 地送回 `Normal.log_prob`，并声称在做普通 REINFORCE，均值项的路径可能互相抵消：\(a-\mu=\sigma\epsilon\) 的总导数不再是固定动作下的 score 梯度。





二者都可以用于合理算法，关键是目标是否需要 \(\partial Q/\partial a\) 或其他通过动作的导数。不能看到 `rsample`“可微”就认为总比 `sample` 更好。先写清估计式，再检查自动微分实际包含的路径；Gaussian score-function 练习把 action 与 advantage 作为固定样本和权重，明确停止它们的梯度。









### 在 score-function 损失里保留 rsample 的动作路径

这会改变固定样本求 `log_prob` 梯度的含义，甚至使均值梯度抵消。

对同一数值动作比较 `detach` 前后 \(\mu\) 的梯度，并说明当前算法使用的是 score-function 还是 pathwise 目标。

## 有界动作与熵项的额外约定

有界动作分布需要将概率模型与动作范围共同定义；采样后裁剪会改变实际分布，不能只当作无影响的数值处理。熵正则又是对分布分散程度的额外目标。下面分别说明密度变换与目标约定。





Gaussian 支持整个实数轴，而机器人动作通常有边界。直接在采样后 clip 动作，会把很多原始样本映射到同一个边界点，实际执行分布不再是原来的 Gaussian。若还用未裁剪密度作为执行动作的 `log_prob`，需要明确算法如何处理这一差异，不能认为一个 clamp 没改变概率模型。





常见平滑方法是 \(a=\tanh(u)\) 并做幅值缩放。对变换后动作计算密度时，应加入变量变换的 Jacobian 修正，例如 \(\log\pi_a(a)=\log\pi_u(u)-\sum_d\log(1-\tanh^2u_d)\)，再包含固定尺度的修正。接近边界时需要稳定数值实现。未压缩 Gaussian 的 `log_prob` 不能直接解释压缩后的动作密度。





熵奖励鼓励分布保持一定随机性，通常在最小化损失中以 \(-\lambda\mathcal H\) 的形式加入；但探索更多并不保证收益更高。系数、动作尺度和方差共同影响行为。评估时应说明是采样动作还是使用均值/模式执行，因为训练探索策略与确定性部署策略可能产生不同结果。









## 重要性比率校正了动作，是否也校正了状态

重要性比率是目标分布密度与采样分布密度的比，用来对已有样本重新加权。动作条件分布的校正不自动校正访问状态的分布。先明确期望针对哪些随机变量，再判断比率修正了什么。





固定同一个状态 s，若行为策略 \(\mu\) 在 \(\pi_\theta\) 可能采到的动作上都有正概率，\(\rho(a,s)=\pi_\theta(a\mid s)/\mu(a\mid s)\) 可以把 \(\mathbb E_{a\sim\mu}[\rho f(s,a)]\) 改写成 \(\mathbb E_{a\sim\pi_\theta}[f(s,a)]\)。这一步只改变给定状态下的动作测度；若状态仍来自旧策略 \(d_\mu\)，它没有自动变成当前策略的访问分布 \(d_{\pi_\theta}\)。





在有限轨迹上，若初始分布与环境动力学相同且有支持覆盖，整条轨迹的重要性比率是各步策略比率的乘积。它可以形式上校正轨迹分布，但连乘会使方差很大；逐决策校正、价值函数方法等有各自目标与条件，不能把任意一个单步 ratio 当成完整修复。





PPO 的常见 surrogate 固定旧策略采集的状态与优势，在其附近优化新动作概率；它不是任意新策略完整回报梯度的精确无偏估计。裁剪进一步有意改变目标，限制某些样本继续推动概率的激励。旧策略覆盖不足、更新过大或错误的动作 `log_prob`，都不能由一个 clip 自动解决。





$$
\mathbb E_{s\sim d_\mu,a\sim\mu}[\rho f]=\mathbb E_{s\sim d_\mu,a\sim\pi_\theta}[f],\qquad \frac{p_{\pi_\theta}(\tau)}{p_\mu(\tau)}=\prod_t\frac{\pi_\theta(a_t\mid s_t)}{\mu(a_t\mid s_t)}
$$





## PPO 的比率、裁剪与旧策略快照

PPO（近端策略优化）使用旧策略采样的数据、动作概率比率和裁剪代理目标来训练新策略。裁剪改变过大比率带来的优化激励，并非硬性保证策略变化不超过某个范围。下面将目标与旧策略快照逐项对应。





PPO 常保存采集数据时旧策略的 `log_prob`，训练时计算 \(r=\exp(\log\pi_{\mathrm{new}}-\log\pi_{\mathrm{old}})\)，再使用带裁剪的 surrogate objective。旧 `log_prob` 应对应同一个动作、状态、事件维归约和动作变换，并在优化期间作为固定值。它表示行为策略快照，不等于某个长期固定的参考模型或监督数据策略。 下式的裁剪 surrogate 是要最大化的目标；若用梯度下降实现 actor loss，应对它取负，再按约定加入价值与熵项。





对正优势，过大的比率不再增加裁剪目标；对负优势，过小比率同样被限制额外收益。这里取 min 的分支需要结合优势符号理解，不能把所有 ratio 无条件 clamp 后就认为等价。裁剪只改变这个样本目标的激励，并不严格保证所有状态下的 KL 或策略变化都在固定范围内。



### 例：正负优势下，PPO 的 min 选择不同分支

1. 取裁剪幅度 ε=0.2，并讨论要最大化的单样本代理目标。若优势 A=2、比率 r=1.4，未裁剪项为 2.8，裁剪项为 \(1.2\times2=2.4\)，min 取 2.4；继续提高这个比率不再增加该项收益。

2. 若优势 A=−2、比率 r=0.6，未裁剪项为 −1.2，裁剪项为 \(0.8\times(-2)=-1.6\)，min 取 −1.6；把已不受欢迎动作的概率继续压低，也不再从该项获得额外收益。

3. 但 A=−2、r=1.4 时，min 取 −2.8，惩罚仍随比率变化；不能无条件把所有比率先 clamp，再只计算那一个乘积。梯度下降实现还要对上述代理目标取负。

裁剪改变单样本的优化激励，不是对所有状态、参数更新或策略 KL 的硬性范围保证。

多轮小批更新还需监控 KL、clip fraction、熵、critic 误差与真实回报，防止数据很快偏离当前策略。完整 PPO 包含 rollout、优势估计、边界处理与优化协议，不能仅靠一个 ratio 公式成为完整后训练方法。特别是生成式动作模型，普通去噪或 FM MSE 不自动提供 PPO 所需的精确动作 `log_prob`。





$$
L_{\rm clip}=\mathbb E\left[\min\left(r\hat A,\operatorname{clip}(r,1-\epsilon,1+\epsilon)\hat A\right)\right],\qquad r=e^{\log\pi_\theta-\log\pi_{\rm old}}
$$



### 裁剪分支随优势符号改变

| 优势 | 比率（裁剪范围 0.8～1.2） | 被选择的目标 | 对比率的局部导数 |

|---|---|---|---|

| +1 | 1.3 | 1.2 | 0 |

| +1 | 0.7 | 0.7 | +1 |

| −1 | 1.3 | −1.3 | −1 |

| −1 | 0.7 | −0.8 | 0 |



## 从单步检查到完整后训练

局部梯度正确只是奖励驱动后训练的起点，还需要采样、优势估计和执行共同使用一致的语义。把这些接口接回动作块和生成模型，可以识别哪些基础估计能够直接沿用，哪些需要新的概率目标。





完整示例在一步合成任务上分别训练 actor 与 critic，并用解析 logit 梯度核对方向。扩展到多步环境时，需要接通回报、终止/截断、bootstrap 和策略版本，才能分析长时信用分配。





局部检查覆盖四件事：正负优势方向、动作维 `log_prob` 归约、优势与动作样本的梯度路径、采样策略身份。多回合表现还依赖评价协议；单独的 actor loss 无法区分策略改善、概率塌缩、基线变化和目标尺度变化。





对于 VLA 的奖励驱动后训练，还要定义一次动作决策覆盖多少控制步、动作序列概率怎样计算、环境回报怎样分配以及旧数据如何复用。确定性 ODE 生成仍含初始噪声的随机性，但要得到密度或可用的替代优化目标，需要另外的数学与实现。先把基础估计器边界弄清楚，才能可靠阅读这些方法。





一个具体连接是 [DPPO：Diffusion Policy Policy Optimization（2024，ICLR 2025）](https://arxiv.org/abs/2409.00588v3)。它把环境决策和内部去噪组织为两层扩展 MDP：当前环境状态、带噪动作与去噪步共同确定内部决策，下一次去噪结果作为内部动作；只有最终结果被执行时，环境才推进并产生任务奖励。在采用正方差的高斯反向转移时，每一步的条件 `log_prob` 可解析计算。保存旧策略生成的去噪链后，就能在相应扩展状态上构造新旧概率比，并用环境回报形成优势，将前面的 PPO 机制用于扩散策略后训练。





这里计算的是给定当前带噪动作与条件后的下一步概率，不是把所有中间潜变量积分掉之后的最终动作边缘密度。因此它既没有将负去噪 MSE 直接当作最终动作 `log_prob`，也不自动适用于确定性 Flow ODE：固定当前点后的确定性转移是 Dirac 分布，不能直接套用非退化 Gaussian 的密度比。实际训练还需要环境反馈、完整采样记录、对应的旧策略快照，以及明确的噪声方差和优势估计协议；修改采样方差或概率计算方式会改变估计的含义。阅读 [DPPO 官方实现](https://github.com/irom-princeton/dppo) 时应一起核对这些配置，而不是只移植一个 ratio 表达式。





策略梯度把执行结果转成动作分布的更新信号。估计器、基线、动作密度、采样来源与策略版本共同决定这份信号是否对应原目标；单步数值检查与完整多步训练应据此分开评价。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| categorical logits | [B,A] | 每个样本的离散动作分布参数 |
| Gaussian mean / `log_std` | [B,D] / [D] 或 [B,D] | 连续动作每维均值与对数标准差 |
| joint `log_prob` / advantage | [B] | 动作轴归约后的联合对数概率及样本权重 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.distributions import Categorical

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 观测正负决定哪一个离散动作得到奖励
actor=nn.Linear(1,2)
critic=nn.Linear(1,1)
optimizer=torch.optim.Adam(list(actor.parameters())+list(critic.parameters()),lr=0.03)

# STEP 2: 用当前策略采样；这个一步任务中 reward=return
for _ in range(160):
    obs=torch.rand(128,1)*2-1
    distribution=Categorical(logits=actor(obs))
    actions=distribution.sample()
    correct=(obs[:,0]>0).long()
    rewards=(actions==correct).float()
    values=critic(obs).squeeze(-1)
    advantages=rewards-values

    # actor 不通过 advantage 更新 critic；critic 有自己的回归损失。
    actor_loss=-(distribution.log_prob(actions)*advantages.detach()).mean()
    critic_loss=(values-rewards.detach()).square().mean()
    optimizer.zero_grad(set_to_none=True)
    (actor_loss+0.5*critic_loss).backward()
    optimizer.step()

# STEP 3: 独立网格只用于检查合成决策，不是机器人评估
with torch.no_grad():
    test_obs=torch.linspace(-1,1,101).unsqueeze(-1)
    greedy=actor(test_obs).argmax(dim=-1)
    accuracy=(greedy==(test_obs[:,0]>0).long()).float().mean()
print('synthetic greedy accuracy:',round(accuracy.item(),3))

# STEP 4: 对单个正优势样本检查梯度方向
logits=torch.zeros(1,2,requires_grad=True)
dist=Categorical(logits=logits)
loss=-(dist.log_prob(torch.tensor([1]))*torch.tensor([2.])).mean()
loss.backward()
print('logit gradients:',logits.grad.tolist())
torch.testing.assert_close(logits.grad,torch.tensor([[1.,-1.]]))
print('Gradient descent increases the positive-advantage action logit.')

```

- 第 8–12 行：这是一步、二动作的合成环境，避免回报长度和复杂动力学遮住概率更新本身。
- 第 13–29 行：动作由当前分布采样。actor 使用 detached advantage；critic 通过独立损失学习奖励期望，不通过 actor 乘积取巧。
- 第 30–36 行：额外网格只检验这个小任务的决策趋势。真实机器人还涉及连续动作、约束、部分观测和多步反馈。
- 第 37–44 行：正优势动作 1 的 logit 梯度为负，梯度下降会增大它。直接看这个符号比记忆损失前面的负号更可靠。

预期观察：单样本梯度检查得到 [[1,-1]]，合成分类决策逐渐学习观测符号。这个示例不是完整 actor-critic 控制算法或真实 VLA 后训练配方。

## 浏览器 Python 练习

实现 `categorical_logit_gradient(probabilities,chosen,advantage)`，返回损失 \(-A\log p(\mathrm{chosen})\) 对 logits 的梯度。输入概率应非负且和为 1，chosen 合法。

```python
import math

def categorical_logit_gradient(probabilities,chosen,advantage):
    # TODO: 使用 softmax 对数概率的导数
    raise NotImplementedError

```

### 提示

- \(-\log\operatorname{softmax}\) 的导数是 \(p-\operatorname{one\_hot}(a)\)。
- 梯度下降减去梯度，所以选中动作的负梯度会提高它的 logit。

### 参考实现与解释

```python
import math

def categorical_logit_gradient(probabilities,chosen,advantage):
    if not probabilities or not 0<=chosen<len(probabilities):
        raise ValueError('invalid action')
    if any(p<0 or not math.isfinite(p) for p in probabilities) or not math.isclose(sum(probabilities),1.0):
        raise ValueError('invalid distribution')
    return [advantage*(p-(1.0 if j==chosen else 0.0)) for j,p in enumerate(probabilities)]

```

优势是这个交叉熵式梯度的带符号权重。正优势和负优势方向相反，零优势不贡献此项更新。概率为零时真实 `log_prob` 有边界问题；本练习给出的是 softmax 有限 logits 情况下导数公式的计算。

### 断言测试

```python
assert categorical_logit_gradient([0.5,0.5],1,2.0)==[1.0,-1.0]
assert categorical_logit_gradient([0.5,0.5],1,-2.0)==[-1.0,1.0]
g=categorical_logit_gradient([0.2,0.3,0.5],2,1.)
assert abs(sum(g))<1e-12 and g[2]<0
print('正优势增大动作概率，负优势减小动作概率；梯度方向检查通过。')

```

## 本地 PyTorch 练习

实现 `gaussian_actor_loss(mu,log_std,actions,advantages)`。mu/actions 为 `[B,D]`，`log_std` 为 [D] 或 `[B,D]`，advantages 为 `[B]`。`log_std` clamp 到 [−5,2]，对动作轴求和；停止 action 与 advantage 的梯度，仅实现未压缩对角 Gaussian 的 score-function 损失。

```python
import torch
from torch.distributions import Normal

def gaussian_actor_loss(mu,log_std,actions,advantages):
    # TODO: 正标准差、联合 log_prob、正确的梯度边界
    raise NotImplementedError

```

### 提示

- `Normal.log_prob` 返回 `[B,D]`；只沿 `dim=-1` 求和后才能与 `[B]` 优势逐样本相乘。
- `actions.detach()` 防止 `rsample` 的路径改变 score-function 估计；advantages.`detach`() 阻止 actor 乘积训练基线。

### 参考实现与解释

```python
import torch
from torch.distributions import Normal

def gaussian_actor_loss(mu,log_std,actions,advantages):
    if mu.ndim!=2 or actions.shape!=mu.shape or advantages.shape!=(len(mu),):
        raise ValueError('shape mismatch')
    if log_std.shape not in ((mu.shape[1],),mu.shape):
        raise ValueError('invalid log_std shape')
    std=log_std.clamp(-5.,2.).exp()
    distribution=Normal(mu,std)
    joint_log_prob=distribution.log_prob(actions.detach()).sum(dim=-1)
    return -(joint_log_prob*advantages.detach()).mean()

```

对角独立分布的联合 `log_prob` 是各动作维的和。`log_std` 保证标准差正值，clamp 是本题明确的数值约定，范围外梯度会为零。actions 的路径应停止以实现此处估计；依赖可微 Q 的重参数化 actor 目标则可能有意保留。tanh 压缩或动作裁剪需要另行处理密度，不能直接使用本函数宣称正确。

### 断言测试

```python
mu=torch.zeros(1,2,requires_grad=True)
log_std=torch.zeros(2,requires_grad=True)
actions=torch.tensor([[1.,-2.]],requires_grad=True)
advantages=torch.tensor([2.],requires_grad=True)
loss=gaussian_actor_loss(mu,log_std,actions,advantages)
loss.backward()
torch.testing.assert_close(mu.grad,torch.tensor([[-2.,4.]]))
assert log_std.grad is not None
assert actions.grad is None and advantages.grad is None
# rsample 的路径必须停止，才能得到这里声明的 score-function 项。
torch.manual_seed(4)
m=torch.zeros(1,requires_grad=True)
d=Normal(m,torch.ones(1))
a=d.rsample()
bad=torch.autograd.grad(-d.log_prob(a).sum(),m,retain_graph=True)[0]
good=torch.autograd.grad(-d.log_prob(a.detach()).sum(),m)[0]
torch.testing.assert_close(bad,torch.zeros_like(bad))
assert good.abs().item()>1e-6
print('动作轴求和、可学习方差和 sample/rsample 梯度边界检查通过。')

```

## 练习：推导与分析

### 基线只输入状态且已经 `detach`，为什么仍不能断言 actor 梯度无偏？

`detach` 只停止自动微分路径。如果基线用当前样本自己的回报计算或拟合，其数值仍可能依赖当前动作。N 个独立一步样本使用同批回报均值，会把梯度期望乘以 \(1-1/N\)；\(N=1\) 时更新为零。

零期望抵消需要给定状态后的相应独立性与分布条件。独立数据训练的状态基线，或在上述独立样本例子中的 leave-one-out 基线，可以满足该条件；整段轨迹中相关样本需要重新分析。

代码定位：穷举两次 Bernoulli 抽样，比较无基线、同批均值和 leave-one-out。

- 区分计算图依赖与抽样依赖。
- 推导或复核 \(1-1/N\) 因子。

### Normal 的 `sample` 与 `rsample` 对策略梯度有什么区别？为什么连续动作 `log_prob` 要求和？

`sample` 不携带采样路径梯度，适合把动作当固定样本的 score-function 更新。`rsample` 将动作表示为 `mu+std*epsilon`；若未经 `detach` 计算同一个 Normal 的 `log_prob`，总导数可能抵消均值的 score 项。若目标通过可微 Q 对动作求导，保留这条路径可能正是算法需要的。

对角 Gaussian 各动作维独立，联合密度是乘积，所以联合 `log_prob` 沿动作轴求和。可学习 `log_std` 通过 exp 得到正标准差，限制范围有数值与梯度代价；tanh 变换需要 Jacobian 修正。要先写清估计目标和动作变换，不能只看张量形状。

代码定位：`gaussian_actor_loss` 的 `sum(-1)`、`actions.detach()` 与测试中的 bad/good 梯度。

- 解释 score-function 与路径梯度的区别。
- 说明动作轴求和、`log_std` 与变换密度边界。

### 给旧轨迹每步乘 \(\pi_{\mathrm{new}}/\pi_{\mathrm{old}}\)，为什么不等于获得任意新策略的无偏梯度？

单步比率在固定状态下校正动作分布，状态访问频率仍由旧策略产生。新策略会改变未来状态；完整轨迹校正涉及多步比率与支持覆盖，且可能有很大方差。

PPO 固定旧数据与优势来构造近邻 surrogate，再通过裁剪改变样本激励。它需要匹配动作变换与联合 `log_prob`，并控制数据陈旧程度；不能把 clip 解释为严格限制所有状态 KL 的保证。

代码定位：`log_prob_old` 的策略版本、同一动作的事件维归约与 rollout 状态来源。

- 说明单步比率没有改变旧状态分布。
- 区分 surrogate 与完整新策略目标。

## 练习：辨析与纠错

### 将 reward 当动作回归标签

收益用于调整动作概率或价值目标，维度和语义与动作监督不同。先写明 J 与实际梯度估计。

### actor 经 advantage 反向修改 critic

普通 score-function 将优势作为固定权重。分开 actor/critic 的损失与梯度路径，检查共享模块的更新来源。

### 对 log_prob 的 Batch 与动作维一起平均

事件维应形成联合 `log_prob`，再对样本归约；PPO 比率尤其依赖正确联合密度。

### rsample 一定比 sample 更适合所有策略梯度

是否需要动作路径取决于估计式。固定样本 score-function 需阻断该路径，pathwise 方法则有不同目标。

### clip 后仍使用原 Gaussian 的执行动作密度

裁剪或 tanh 会改变分布。按变换定义概率，并检查边界与 Jacobian；未压缩练习不覆盖这些情况。

### PPO 裁剪保证所有更新都安全且改善回报

裁剪 surrogate 不构成全局 KL 或性能保证。监控策略变化、价值误差和独立闭环结果。

## 原始资料

- [Spinning Up：策略梯度推导、基线与代码](https://spinningup.openai.com/en/latest/spinningup/rl_intro3.html)
- [PyTorch distributions：sample、rsample 与 log_prob](https://docs.pytorch.org/docs/stable/distributions.html)
- [Spinning Up：Vanilla Policy Gradient](https://spinningup.openai.com/en/latest/algorithms/vpg.html)
- [Schulman et al. · PPO 原论文](https://arxiv.org/abs/1707.06347)
- [Greensmith et al. · 策略梯度中的基线与方差](https://www.jmlr.org/papers/v5/greensmith04a.html)
- [Ren et al. · DPPO（2409.00588v3 / ICLR 2025）：扩展去噪 MDP 与逐步概率](https://arxiv.org/abs/2409.00588v3)
- [DPPO 官方实现：Diffusion Policy 的 PPO 后训练](https://github.com/irom-princeton/dppo)
