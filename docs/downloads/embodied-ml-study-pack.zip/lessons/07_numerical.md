# 数值精度与标准化

区分数值范围、有效精度与优化条件数。

数值精度描述计算机表示和运算实数时能保留多少差异，数值稳定性描述算法怎样传播和放大这些有限精度误差。标准化则是将数据移到选定尺度的坐标变换，它还会影响优化与误差权重。这三件事共同影响训练，却不是同一个开关。本章分别分析表示、数据尺度与运算形式，再用往返关系和数学不变量检查实现。

## 学习目标

- 只用训练数据拟合并保存标准化统计量
- 解释标准化怎样改变各输出维度的误差权重
- 定位 NaN/Inf 的首个来源而不是只处理最终损失

前置知识：[损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [梯度下降、动量与 AdamW](https://wxb1870.github.io/embodied-ml-lab/learn/optimization/)

## 数值表示的精度、范围与算法稳定性

浮点表示用有限位数近似实数，表示范围限制可容纳的数量级，精度限制相邻数之间可分辨的差异。数值稳定性则属于计算方法，关注输入与舍入误差怎样影响结果。先分清这三个对象，再判断应改数据尺度、dtype 还是公式。





浮点数只有有限的可表示值，两个相近实数可能映射到同一个浮点数，过大的数可能溢出，过小的数可能下溢。指数位影响动态范围，尾数位影响相邻数的间距；更宽的范围不等于更精细的局部表示。训练中需要区分输入本身的尺度、运算公式的稳定性和所用 dtype 的精度，三者不是一个开关能解决的。





数学上等价的表达式在浮点中可以表现不同。先计算很大指数再除，可能已经产生 Inf；先减最大值再计算指数却可以保持有限。把整段运算改成 float64 有时能帮助定位，但不是所有部署路径都适合，也不能修复错误单位、错误标签或除以零。先把数值问题还原成具体操作，才知道应该改公式、数据还是精度。









## 输入标准化为何影响优化速度

输入标准化是用声明的统计量对输入进行平移和缩放，使特征具有选定的数值尺度。常见 z-score 使用训练集均值与标准差。它改变优化坐标，因此需要同时明确统计轴、数据来源及推理时复用的参数。





常见 z-score 使用 \(z=\frac{x-\mu}{s}\)，使训练特征在选定统计轴上具有较合适的尺度。\(\mu\)、s 来自训练集或明确指定的统计数据，不能用验证或测试数据共同拟合。若对每个特征分别统计，参数 shape 应保留特征轴；把相机、时间和通道混合在一起求一个总均值，会应用另一种变换。





将逐维尺度组成可逆对角矩阵 \(S=\operatorname{diag}(s_1,\ldots,s_D)\)，设 \(X_c\) 是已经按列减去训练均值的设计矩阵。标准化后 \(Z=X_cS^{-1}\)。原模型 \(X_cw+b\) 与新坐标下 \(Z\beta+b\) 表示同一组预测，只要 \(\beta=Sw\)；若从未中心化的输入出发，还需把均值贡献吸收到偏置中。这里改变的是参数化，而不是自动增加模型表达能力。





固定特征的线性回归 \(L(w)=\lVert X_cw-y\rVert_2^2/(2B)\) 有梯度 \(X_c^\top(X_cw-y)/B\)，继续求导得到 Hessian \(H_w=X_c^\top X_c/B\)。在标准化坐标中，\(H_\beta=Z^\top Z/B=S^{-1}H_wS^{-1}\)。因此统一学习率在两种参数化中不再对应同一原坐标位移；这正是尺度调整能够改变优化速度的原因。





对这个二次目标，在正曲率特征方向上，相对最优解的误差每步乘以 \(1-\eta\lambda_i\)。较大曲率限制可用学习率，较小曲率又使收敛缓慢。不同单位可能拉大这些尺度差异，即使数值始终有限，训练也可能缓慢或振荡。这个分析针对固定设计矩阵；深层网络的曲率会随训练变化，不能把同一个界限当作全网络保证。



### 例：没有任何溢出，梯度下降仍然会发散

1. 考虑局部二次目标的 Hessian 为 \(\operatorname{diag}(1,100)\)。两个方向的误差倍率为 \(1-\eta\) 与 \(1-100\eta\)。

2. 取 \(\eta=0.03\)，倍率是 0.97 与 −2；第二方向每步翻向并放大两倍。

3. 改为 \(\eta=0.01\)，倍率是 0.99 与 0；高曲率方向一步消掉，低曲率方向却每步只减少 1%。

同一个学习率需要适应不同曲率方向；尺度差异会造成高曲率方向振荡、低曲率方向进展缓慢。

常量或近常量特征的 s 很小，直接相除会放大噪声。可以设定最小尺度、将常量维固定处理或使用稳健统计，但必须把规则写入预处理约定。标准化后不要求每个单独 Batch 都严格零均值、单位方差；这些属性针对拟合统计的数据分布。不要把随机 Batch 的偏离误判为统计量损坏。





统计实现还需明确方差分母采用 N 还是 N-1；两者对应不同估计约定，少量样本时差异明显。标准化只要拟合与应用一致可以采用明确规则，但不能在 NumPy 与 PyTorch 默认设置之间切换而不核对。尤其 N=1 或常量维时，必须给出可解释的退化处理。





统计量应只包含真正有效的训练元素。将大量 Padding 零值纳入均值和尺度，会让统计量随最大窗口长度变化；不同任务采样比例也会改变拟合分布。拟合时保存各维有效计数，拒绝无观测维度，并在复现时采用同样的筛选规则。对掩码维度单独做计数，能区分常量信号与根本没有标签。





逐维标准化相当于重新缩放参数坐标，可以改善这种几何，但单位方差不意味着特征之间互不相关，也不保证 Hessian 条件数良好。若两列特征几乎重复，标准化后它们仍接近线性相关。白化还会处理相关结构，代价和统计假设也不同；不要把标准化、白化与“所有方向同样好学”画等号。





$$
Z=X_cS^{-1},\quad \beta=Sw,\quad H_w=\frac{X_c^\top X_c}{B},\quad H_\beta=S^{-1}H_wS^{-1};\qquad e_{t+1}^{(i)}=(1-\eta\lambda_i)e_t^{(i)}
$$

```python
import torch

X = torch.tensor([[-2., -20.], [-1., -9.], [1., 12.], [2., 17.]],
                 dtype=torch.float64)
Xc = X - X.mean(dim=0)
scale = Xc.square().mean(dim=0).sqrt()
Z = Xc / scale
w = torch.tensor([0.3, -0.2], dtype=torch.float64)
beta = scale * w
torch.testing.assert_close(Z @ beta, Xc @ w)
y = torch.tensor([-1., 0., 1., 2.], dtype=torch.float64)
Hw = torch.autograd.functional.hessian(
    lambda q: 0.5 * (Xc @ q - y).square().mean(), w)
Hb = torch.autograd.functional.hessian(
    lambda q: 0.5 * (Z @ q - y).square().mean(), beta)
torch.testing.assert_close(Hw, Xc.T @ Xc / Xc.shape[0])
torch.testing.assert_close(Hb, Hw / scale[:, None] / scale[None, :])
torch.testing.assert_close(Hb.diag(), torch.ones_like(scale))
assert Hb[0, 1].abs() > 0.9  # 单位方差后仍保留强相关性。
print("标准化后的 Hessian:", Hb.tolist())

```

显式的坐标关系先证明两种参数化可以产生相同预测，再通过 Autograd 检验 Hessian 的变换。例子特意使用相关特征：标准化把对角项变为 1，却没有消除非对角相关性，因此不能由单位方差直接推断白化或良好条件数。





### 先分清统计的轴和应用的轴

一组 [D] 统计量通常跨样本拟合，再广播到每个样本的同一特征维。

使用小数组手算每维 \(\mu\)、s；验证广播形状与反变换误差。

## 目标标准化怎样改变优化权重

目标标准化是对预测标签进行坐标变换，并要求输出按同一约定还原。标准化坐标中的等权平方误差，对应原坐标中按尺度加权的误差。下面追踪这一变化，说明它为何同时属于数值处理和目标设计。





对目标 y 做逐维标准化后使用等权 MSE，相当于在原单位下按 \(\frac1{s_d^2}\) 加权各维误差。这样可避免大尺度维度仅因单位较大而主导梯度，但它不是完全中性的数值处理。若某维统计方差很小，权重可能变得很大；需要结合测量噪声和任务意义选择最小尺度或权重。



### 例：相同归一化误差对应不同原单位误差

1. 两维的尺度分别为 \(s_1=2\)、\(s_2=10\)，归一化残差均为 0.1。

2. 还原到原单位后，残差分别为 0.2 和 1。

3. 若原单位残差都为 1，归一化平方误差则分别为 \(\frac14\) 和 \(\frac1{100}\)。

标准化同时决定了训练更关注哪些原单位误差。

训练可在标准化空间进行，评估应同时还原到实际单位。一个维度的归一化误差下降，不一定意味着所有物理误差都达到要求。均值与尺度必须跟随模型保存，推理使用同一变换，并检查训练、验证与部署是否对同一字段重复标准化或遗漏反变换。不能只存权重文件而依赖记忆重建统计量。





以两个输出维为例，若尺度分别为 1 和 100，原单位误差相同时，前一维在标准化 MSE 中的权重是后一维的一万倍。若任务要求两个维度遵守独立容差，可以按明确容差定义权重，而不必假定数据标准差就是正确的任务代价。优化条件和任务偏好应分开审查。





还要区分两种结论：对不受限制、逐维可自由选择的预测函数，固定的逐维正权重不改变各维最优条件均值；对共享参数或有容量限制的模型，权重会改变可实现解之间的取舍，训练路径也会改变。标准化“改变了损失度量”始终成立，但不能据此断言无限容量下的条件均值也必然改变。









## 稳定地计算概率、指数与对数

稳定表达式是与原公式在实数上等价、却能减少中间溢出或下溢的计算方式。概率计算中的减最大值、log-sum-exp 与直接计算对数概率，都属于这种设计。目标是保留原函数，而非改变其概率含义。





Softmax 可先减最大 logit，log-sum-exp 可写成 \(m+\log\sum_j\exp(z_j-m)\)。这些变形利用精确数学中的不变性，把中间结果限制在更合适的范围。用 log_softmax 直接输出对数概率，比先 Softmax 得到可能下溢的概率再 log 更可靠。二分类也优先用接收 logits 的组合损失，避免手工把极端概率送入 log。



### 例：极大 logits 也可以有正常概率

1. 取 logits=[1000,1001]，直接计算两个指数可能溢出。

2. 先减去最大值 1001，得到 [-1,0]，指数约为 [0.3679,1]。

3. 归一化得到约 [0.2689,0.7311]；减去常数没有改变理论概率。

稳定公式避免非法中间量，同时避免通过任意截断改变合理概率。

给 log 的输入统一加 \(\varepsilon\)，并不总是等价修复：它改变了目标，且 \(\varepsilon\) 相对于数据尺度可能过大或过小。对于本来必须严格为正的变量，应先检查建模和输入是否合法；对于公式允许的稳定重写，优先使用对应算子。clamp 可以作为明确的数值或物理约束，但需要说明边界梯度和被裁剪样本比例，不能静默掩盖异常。









### 先发生溢出，再希望后续除法恢复

Inf/Inf 或 log(0) 已经丢失有限结果，后续运算不会自动恢复。

检查每个中间张量的有限性，使用稳定组合算子并构造极端输入回归测试。

## 归约顺序、抵消与大数加小数

舍入误差是精确结果被近似为可表示数时的偏差；消减误差常出现在相近大数相减、有效数字丢失时。加法顺序又会改变累计舍入。下面用这些机制解释为什么等价归约通常只能在容差内一致。





浮点加法不满足严格结合律。许多小数累加、正负大数相减或大数加微小增量，都可能损失有效数字。CPU/GPU、批处理/逐项循环以及不同内核的归约顺序不同，因此结果一般只要求在合理容差内一致。逐位相同不是所有正确实现的普遍验证标准。





但容差不应无限放宽。先检查算法的合理数量级，再比较绝对误差与相对误差：接近零的参考值需要绝对容差，大数需要考虑相对误差。若某统计量经过大量加和，使用更高精度累计可能有帮助。方差若写成 \(\mathbb E[x^2]-(\mathbb E[x])^2\)，在均值很大而波动很小时可能发生严重抵消；与单纯增加 Batch 相比，稳定实现更直接地解决这一问题。









## Mask 与定义域：无效值应在危险运算之前处理

定义域是一个运算允许输入的集合，例如实对数要求正数。有效位则标记哪些数据属于当前问题；二者需要在危险运算之前结合，避免先制造无效值，再期待零权重将它消除。





无效标签、零长度和缺失传感器值要有独立的有效位。NaN×0 仍是 NaN，所以不能先把全部误差计算出来再乘 Mask。对除法、平方根、对数等有定义域约束的运算，应先确保被实际计算的输入合法；torch.where 的分支表达式可能已提前执行，不能假定它天然避免非法分支的数值或梯度。





异常处理应区分可预期缺失与程序错误。已知缺失值可按协议屏蔽，未知 Inf/NaN 则应定位首个产生位置并保留样本。每次遇到异常都用 nan_to_num 变成零，可能把错误监督转换成貌似稳定的训练信号。必要的保护规则应同时记录计数与触发原因，以便发现数据管线是否逐渐恶化。









### 用 nan_to_num 让训练继续就算修复

替换只改变数值，不说明异常来源和原本应该计算的目标。

保存首个异常样本，按输入→预处理→前向→loss→梯度顺序检查，并报告替换比例。

## 精度选择与损失缩放的适用边界

混合精度是在同一计算中为不同算子选择不同数值格式；损失缩放是先放大损失与梯度、随后还原梯度的机制。前者分配表示精度，后者主要缓解某些低精度梯度的下溢，作用范围应分别判断。





BF16 和 FP16 都较紧凑，但指数与尾数分配不同。BF16 的动态范围较宽，并不意味着它能精确表达很小的相对变化；FP16 的范围较窄，梯度更容易在某些模型中下溢。混合精度按算子选择计算 dtype，不能简单理解成所有 Tensor 都变成同一种低精度。敏感归约和最终误差可以在更高精度下计算。





梯度缩放通过放大 loss 保护小梯度，然后在更新前还原；它不改变正确目标，却不能修复前向已溢出、错误归一化或无效标签。排错时可用 FP32 的最小输入对照低精度版本，找到首次显著偏离的算子。若改变 dtype 只是让错误更晚出现，应继续查尺度与公式，不能将“完成执行”直接视为训练正确性的证据。









## 用往返、极端值与不变量验证预处理

预处理通常缺少可直接比较的标准答案，却具有明确的数学性质。往返关系、平移不变性和有效位不变性提供了可执行的检验，使数值配置能够成为随模型保存和复现的接口，而不是隐含假设。





对标准化函数首先测试 `inverse(transform(x)) ≈ x`，覆盖负数、常量维、批次边界和多种 shape；同时确认原始输入没有被意外原地修改。对概率函数测试加常数不变性、概率和为 1、极端 logits 有限。对加权平均测试整体权重缩放不变性以及全无效输入的明确策略。不同模块应由各自数学性质设计测试。





演示拟合统计量、应用变换、反变换并检查有限值。进一步接到真实训练时，应把统计量版本、字段顺序、单位和尺度策略保存到 checkpoint 元数据。一个有效的训练—推理一致性检查，是将同一条样本分别走训练与推理预处理，逐字段比较送入模型的 Tensor；只比较最终预测会让误差来源难以区分。





统计量改变后，旧权重未必仍适配新输入。重新拟合尺度、改变图像归一化或更换动作单位都应视为模型接口变化，通过固定样本和独立验证检查，而不是当作无影响的配置整理。





往返测试还应覆盖序列和批次广播：用不同样本、不同时间但相同特征索引的值，验证同一统计量应用到正确轴。若将均值向量误对齐到 Batch 维，某个方形测试可能仍通过。故意取 B、T、D 不同，可以发现这类静默错误。





可靠的数值实现应保留原问题的函数与单位：数据变换要能还原，公式变形要保持数学关系，精度选择要用误差证据判断。数值有限只是起点，含义一致才是标准化与稳定计算的共同目标。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| train | [N,D] | 只包含训练部分的有效状态或动作 |
| mean / scale | [D] | 与每个物理维度绑定的固定统计量 |
| normalized | [N,D] | 保留样本与维度身份的标准化数据 |

## 完整代码与精读

```python
import torch

torch.manual_seed(5)
# STEP 1: 三个输出使用不同物理尺度
train = torch.randn(64, 3) * torch.tensor([0.1, 10., 100.])
train += torch.tensor([0.5, 0., 1000.])
mean = train.mean(dim=0)
scale = train.std(dim=0, unbiased=False).clamp_min(1e-6)
z = (train - mean) / scale
assert torch.allclose(z.mean(dim=0), torch.zeros(3), atol=2e-6)
assert torch.allclose(z.std(dim=0, unbiased=False), torch.ones(3), atol=1e-6)
restored = z * scale + mean
assert torch.allclose(restored, train, atol=1e-5)
print("mean:", mean.tolist(), "scale:", scale.tolist())

# STEP 2: 验证集只使用训练统计量，不重新 fit
validation = train[:4] + torch.tensor([0.2, 0., 0.])
validation_z = (validation - mean) / scale
assert validation_z.shape == validation.shape
raw_error = torch.tensor([0.01, 1., 10.])
normalized_mse = (raw_error / scale).square().mean()
weighted_raw_mse = (raw_error.square() / scale.square()).mean()
assert torch.allclose(normalized_mse, weighted_raw_mse)

# STEP 3: 常数维度与非有限值需要明确处理
constant = torch.ones(8, 1)
constant_scale = constant.std(0, unbiased=False).clamp_min(1e-6)
assert torch.isfinite((constant - constant.mean(0)) / constant_scale).all()
def require_finite(name, tensor):
    if not torch.isfinite(tensor).all():
        raise ValueError(name + " 首次出现非有限值")

require_finite("normalized training data", z)
try:
    require_finite("bad example", torch.tensor([1., float("inf")]))
except ValueError as error:
    print(error)

```

- 第 4–15 行：统计量在训练数据上逐维拟合。这里使用总体标准差，避免样本数为 1 时的无偏估计问题。
- 第 16–24 行：评估数据只 transform，标准化损失等价于原始误差按 \(\frac1{\mathrm{scale}^2}\) 加权。
- 第 25–37 行：eps 解决除零的数值问题；isfinite 用于主动定位异常，不能代替分析其成因。

预期观察：标准化训练数据每维均值接近 0、标准差接近 1；反变换能恢复原始值；人工注入 Inf 后检查函数明确报告异常。

## 浏览器 Python 练习

实现 fit_normalizer(rows,eps) 返回逐维 (mean,scale)，scale 使用总体标准差并至少为 eps；normalize 只使用已有统计量，不重新拟合。

```python
import math

def fit_normalizer(rows, eps=1e-6):
    # TODO: 每一维独立计算训练均值与总体标准差
    raise NotImplementedError("请实现 fit_normalizer")

def normalize(rows, mean, scale):
    # TODO: 只应用给定统计量
    raise NotImplementedError("请实现 normalize")

```

### 提示

- 方差先求 \((x-\text{均值})^2\) 的平均，再开平方。
- normalize 没有必要访问原始训练数据，也不能对当前输入再求均值。

### 参考实现与解释

```python
import math

def fit_normalizer(rows, eps=1e-6):
    n, d = len(rows), len(rows[0])
    mean = [sum(row[j] for row in rows) / n for j in range(d)]
    scale = [max(eps, math.sqrt(sum((row[j] - mean[j]) ** 2
                                   for row in rows) / n)) for j in range(d)]
    return mean, scale

def normalize(rows, mean, scale):
    return [[(x - m) / s for x, m, s in zip(row, mean, scale)] for row in rows]

```

验证样本的归一化值不需要落在 −1 到 1。超出范围可能表示分布变化，不应未经分析就裁剪。

### 断言测试

```python
train = [[1., 10.], [3., 10.]]
mean, scale = fit_normalizer(train)
assert mean == [2., 10.]
assert scale == [1., 1e-6]
assert normalize(train, mean, scale) == [[-1., 0.], [1., 0.]]
assert normalize([[5., 10.]], mean, scale) == [[3., 0.]]
assert mean == [2., 10.], "应用验证数据不应修改统计量"
one_mean, one_scale = fit_normalizer([[3., 4.]])
assert normalize([[3., 4.]], one_mean, one_scale) == [[0., 0.]]
print("通过：总体标准差、常数维度与评估隔离。")

```

## 本地 PyTorch 练习

实现逐维 fit_stats、normalize_tensor 与 denormalize_tensor。统计量只在 fit_stats 中计算，总体标准差的最小值为 eps。

```python
import torch

def fit_stats(train, eps=1e-6):
    # TODO: 返回 [D] 的 mean 与 scale
    raise NotImplementedError("请实现 fit_stats")

def normalize_tensor(x, mean, scale):
    raise NotImplementedError("请实现 normalize_tensor")

def denormalize_tensor(z, mean, scale):
    raise NotImplementedError("请实现 denormalize_tensor")

```

### 提示

- 沿样本轴 dim=0 求均值与总体标准差，使用 unbiased=False。
- normalize 和 denormalize 只应用已有统计量，不能偷偷重新 fit。

### 参考实现与解释

```python
import torch

def fit_stats(train, eps=1e-6):
    return train.mean(dim=0), train.std(dim=0, unbiased=False).clamp_min(eps)

def normalize_tensor(x, mean, scale):
    return (x - mean) / scale

def denormalize_tensor(z, mean, scale):
    return z * scale + mean

```

总体标准差在单样本时仍可定义为零，再用 eps 避免除零。测试同时验证常数维、往返一致性和应用验证数据不会改变统计量。eps 的下界是数值约定，固定动作通道是否保留仍需要按物理语义决定。

### 断言测试

```python
torch.manual_seed(1)
x = torch.randn(12, 3, dtype=torch.float64)
x[:, 2] = 7.
mean, scale = fit_stats(x)
z = normalize_tensor(x, mean, scale)
assert mean.shape == scale.shape == (3,)
assert torch.isfinite(z).all()
assert torch.allclose(z[:, 2], torch.zeros(12, dtype=x.dtype))
assert torch.allclose(denormalize_tensor(z, mean, scale), x, atol=1e-12)
old_mean = mean.clone()
_ = normalize_tensor(x + 100, mean, scale)
assert torch.equal(mean, old_mean)
single_mean, single_scale = fit_stats(torch.tensor([[1., 2.]]))
assert torch.isfinite(single_scale).all() and (single_scale > 0).all()
print("PyTorch 测试通过：统计量、反变换和单样本边界正确。")

```

## 练习：推导与分析

### 标准化后的 MSE 更低，为什么不能直接说物理误差按同样比例改善？

标准化空间的第 d 维误差平方等于原始误差平方除以 \(\mathrm{scale}_d^2\)，单位和各维权重已经改变。因此前后两个 loss 数值不在同一标尺上。

应把预测反变换到统一物理单位，逐维报告位置、旋转或夹爪误差，并结合任务结果。训练和部署必须使用同一套统计量，否则相同网络输出会映射成不同命令。

代码定位：normalized_mse 与 weighted_raw_mse 对照；denormalize_tensor。

- 能推导 \(\frac1{\mathrm{scale}^2}\) 的权重。
- 能列出应报告的物理单位与部署一致性检查。

### 常数动作维的标准差为零，添加 eps 就足够了吗？

eps 能防止除零，但不能补充缺失的变化信息，也不能证明该维应参与学习。很小的尺度还可能把微小物理误差放大成很大的标准化误差。

需要判断该维是人为填充、固定命令、数据覆盖不足，还是确实需要控制。可按语义屏蔽、固定或使用有意义的尺度，并将选择保存到动作配置。

代码定位：fit_stats 的 clamp_min；动作表示课程的 valid_dim。

- 能区分数值稳定问题与数据/动作语义问题。
- 能说明为什么不能对所有零方差维度不加区分地采用同一处理。

## 练习：辨析与纠错

### 在全量数据上拟合标准化统计

测试数据进入统计量会泄漏分布信息。训练集拟合，验证和测试仅应用，并记录分组划分与统计版本。

### 近常量维直接除以极小标准差

噪声会被大幅放大。明确最小尺度或常量维策略，记录被保护的维度并检查其任务意义。

### 只看归一化误差不还原单位

不同尺度对应不同原单位容差。保存反变换，按维度报告误差及与任务要求的关系。

### 任意增大 epsilon 或容差直到通过

这可能改变目标或隐藏错误。先分析数值量级与稳定公式，再确定有依据的 epsilon、atol 和 rtol。

## 原始资料

- [OpenPI：Normalization statistics](https://github.com/Physical-Intelligence/openpi/blob/main/docs/norm_stats.md)
- [scikit-learn：Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html)
- [PyTorch：Numerical accuracy](https://docs.pytorch.org/docs/stable/notes/numerical_accuracy.html)
- [Goodfellow、Bengio、Courville：Optimization for Training Deep Models，病态条件](https://www.deeplearningbook.org/contents/optimization.html)
