# 回报与 Bellman 方程

价值目标、半梯度、终止与外部截断。

奖励评价一次转移的结果，回报累计从当前时刻开始的未来奖励，价值函数则对给定状态或动作后的回报取策略条件下的期望。Bellman 方程把当前价值写成即时奖励与后继价值的期望，从而建立跨时间递推。本章先认识这些不同对象，再构造 TD、多步回报与优势估计，最后明确终止、截断和求导边界。

## 学习目标

- 计算一段轨迹的折扣回报，并区分即时奖励与价值
- 实现带明确 bootstrap 边界的一步 TD target
- 区分环境真正终止、采样外部截断和自动 reset 后的观测

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [部分观测与记忆](https://wxb1870.github.io/embodied-ml-lab/learn/partial-observability/)

## 从一步奖励到整段回报

奖励是一次动作转移后收到的反馈，回报是从当前时刻起按声明规则累计的未来奖励。折扣因子调节不同远期结果的权重。先把单步反馈与整段结果分清，再建立可以递推计算的形式。





将 \(r_t\) 定义为执行 \(a_t\)、从 \(s_t\) 转移到 \(s_{t+1}\) 后收到的奖励。回报 \(G_t=r_t+\gamma r_{t+1}+\gamma^2r_{t+2}+\cdots\) 衡量从当前时刻往后的结果，\(\gamma\) 控制未来奖励的折扣。文献有时把同一步奖励记为 \(r_{t+1}\)，只是索引约定不同，代码与公式需要统一。





\(\gamma=0\) 时只看即时奖励；在无限时域且奖励有界时，\(\gamma<1\) 使折扣和有界。有限回合可以使用 \(\gamma=1\)，但仍要明确结束条件与尾部回报。折扣既可用于数学收敛，也会改变任务偏好：两条最终成功的轨迹若到达时间不同，\(\gamma<1\) 可能偏好更快的成功，不能把它只当无意义的数值参数。





奖励尺度与回报尺度也不同。持续每步奖励 1、\(\gamma=0.99\) 的无限序列回报为 100；critic 输出 100 不一定异常。诊断数值范围时应依据奖励定义、回合长度和折扣，而不是期待价值总在 [0,1]。成功概率只在特定奖励与终止设计下才与价值有直接关系。





$$
G_t=\sum_{j=0}^{T-t-1}\gamma^j r_{t+j},\qquad G_t=r_t+\gamma G_{t+1}
$$



### 例：倒序计算完整终止轨迹

1. 奖励依次是 `[1,2,3]`，\(\gamma=0.9\)，真正终止后的尾值为 0。

2. \(G_2=3\)；\(G_1=2+0.9\times3=4.7\)。

3. \(G_0=1+0.9\times4.7=5.23\)；每个时间点都有自己的 reward-to-go。

倒序递推对应几何折扣，不能把同一个总奖励复制为所有时间点的回报。

## 价值与动作价值是带策略条件的期望

状态价值是从某状态出发、随后按指定策略行动的期望回报，动作价值还固定了第一步动作。Bellman 关系将它们连接到奖励与后继价值。价值是带策略条件的期望，不是某条轨迹已实现的结果。





\(V^\pi(s)=\mathbb E_\pi[G_t\mid s_t=s]\) 是在状态 s 开始、之后按照策略 \(\pi\) 行动的期望回报。\(Q^\pi(s,a)\) 则先固定当前动作 a，之后再跟随 \(\pi\)。它们不是某一条 rollout 的实际回报，也不是脱离策略的环境常数；策略改变，未来动作分布和价值一般也会改变。





从回报递推取条件期望，可得 Bellman 期望关系 \(V^\pi(s)=\mathbb E[r+\gamma V^\pi(s^\prime)]\)，其中动作由 \(\pi\) 采样、下一状态由环境转移产生。若状态并不满足 Markov 性，这种以单个观测为条件的简单递推可能缺少必要信息，循环 critic 或信念表示就需要明确历史状态。



### 例：两状态价值来自联立关系

1. 固定策略下，状态 0 总转移到 1，状态 1 总转移到 0；离开状态 0 得到奖励 1，离开状态 1 得到奖励 0，折扣为 \(\gamma=0.9\)。

2. Bellman 关系为 \(V_0=1+\gamma V_1\)、\(V_1=\gamma V_0\)。代入得到 \(V_0=1/(1-\gamma^2)\)、\(V_1=\gamma/(1-\gamma^2)\)。代入 γ=0.9，得到 \(V_0\approx5.2632\)、\(V_1\approx4.7368\)，它们均不是当前一步的奖励。

3. 这与直接累加交替奖励的几何级数一致。价值来自固定策略下的未来回报，而非当前一步奖励。

联立方程与轨迹回报给出同一结果，展示 Bellman 关系如何把长时信息变成局部自洽条件。

递推中的关键是全期望，而不是把一个随机回报直接换成常数。先对 \(G_t=r_t+\gamma G_{t+1}\) 在 \(s_t=s\) 下取期望，再按动作和下一状态细分：\[V^\pi(s)=\sum_a\pi(a\mid s)\sum_{s^\prime}P(s^\prime\mid s,a)\left[\bar r(s,a,s^\prime)+\gamma\mathbb E[G_{t+1}\mid s^\prime,\pi]\right].\]其中 \(\bar r\) 是该转移的期望奖励。Markov 性使更早历史可以在最后一个条件期望中去掉，后续仍使用同一策略，于是该项就是 \(V^\pi(s^\prime)\)。连续状态与动作时把求和换成相应积分；非平稳有限时域则应保留价值的时间索引。





Bellman 期望方程与最优性方程不同。后者在后续动作中取最大值或按相应最优算子处理，描述最佳可达价值；不能在评估固定策略时随意把后续 V 改成 max Q，就仍称为同一个目标。离线数据来自别的策略时，还要分析覆盖和 off-policy 方法，不能只凭能算出 target 就保证估计正确。





$$
V^\pi(s)=\mathbb E_{a\sim\pi,s^\prime}[r+\gamma V^\pi(s^\prime)],\qquad V^\pi(s)=\mathbb E_{a\sim\pi}[Q^\pi(s,a)]
$$

```python
import torch

dtype = torch.float64
gamma = 0.9
p = torch.tensor([[0., 1.], [1., 0.]], dtype=dtype)
r = torch.tensor([1., 0.], dtype=dtype)
v = torch.linalg.solve(torch.eye(2, dtype=dtype) - gamma * p, r)
closed = torch.tensor([1 / (1 - gamma ** 2), gamma / (1 - gamma ** 2)], dtype=dtype)
torch.testing.assert_close(v, closed, rtol=1e-12, atol=1e-12)
torch.testing.assert_close(v, r + gamma * p @ v, rtol=1e-12, atol=1e-12)
direct = sum(gamma ** k for k in range(0, 1000, 2))
torch.testing.assert_close(v[0], torch.tensor(direct, dtype=dtype))
print("通过：Bellman 联立解、解析几何级数与直接奖励累加一致。")

```

此处转移矩阵由一个固定策略确定，奖励有界且折扣小于 1。求解两个标量价值用于核对方程含义，不涉及神经网络拟合或策略改进，也不能据此推断任意 critic 训练都会收敛。





## TD 目标与半梯度更新为什么要分开

时间差分（TD）用即时奖励与已有后继价值估计组成训练目标，bootstrap 指用估计的尾部价值代替完整未来。半梯度更新只对当前预测求导，不穿过这份目标。下面说明三者怎样组成一次价值学习。





一步 TD 使用 \(y_t=r_t+\gamma V(s_{t+1})\) 作为当前 \(V(s_t)\) 的训练目标，真正终止时去掉后半项。这用已有价值估计代替等待完整未来回报，称为 bootstrap。它通常比完整 Monte Carlo 回报更早获得更新，但目标也继承了后续估计的误差；这是偏差与方差的取舍。





常见半梯度 TD 将 \(y_t\) 视为固定目标，对当前预测回传梯度，因此会对 target 使用 `detach` 或 `no_grad`。如果同一网络计算 `next_value` 又不停止目标梯度，优化器会同时改变目标端以降低残差，得到另一种更新规则。不是所有对 Bellman 残差求完整梯度的方法都非法，但那不再是代码原本声称的普通半梯度 TD。





一些算法使用独立或延迟更新的 target network，缓解目标快速移动；它与 `stop_gradient` 不是同一个操作。目标网络改变用于计算 y 的参数来源，停止梯度决定本次优化沿哪条路径更新。读代码时应分别检查当前网络、目标网络、目标更新节奏和梯度流，避免把这几项混成一个 target 变量。





$$
y_t=r_t+\gamma(1-d_t)V_{\rm target}(s_{t+1}),\qquad L_V=\frac12\left(V_\theta(s_t)-\operatorname{stopgrad}(y_t)\right)^2
$$





### target 叫目标就认为不会有梯度

普通 Tensor 仍可能带计算图，目标端的梯度会改变更新规则。

检查 `y.requires_grad`，并在最小样例中确认 loss 只更新预期的当前价值路径。

## 真正终止与外部截断有不同含义

终止表示任务定义的后续回报已经结束，外部截断表示数据收集停止但任务可能继续。它们对尾部价值是否保留的含义不同。先定义这两个边界，再决定 reset 与 bootstrap 的掩码。





`terminated` 表示任务定义中的终止状态，例如成功、失败或任务本身规定的有限时域结束，此后回报为零。`truncated` 表示收集过程因任务外部原因停止，例如为无限任务设置的采样上限；环境理论上仍可继续，因此通常保留最后状态的 bootstrap。两者都可能触发 reset，却不应共用同一个价值边界。





“时间到了”并不总是截断。若任务就是必须在给定时间内完成，时间限额属于 MDP 定义，终点可以是真正终止；为了保持 Markov 性，还应把剩余时间纳入适当状态。若只是采集器到达预算就切一段，才是外部截断。应以任务语义判断，而不是只查看产生结束信号的代码行是否叫 TimeLimit。





自动 reset 环境可能在结束后返回新回合的首个观测。bootstrap 需要的是旧回合真正的最后观测，不能拿新初始状态的价值替代。不同向量化接口保存终态观测的字段和时机不同，应按所用 API 核对；如果没有保存到正确观测，简单改 done Mask 仍无法修正标签。







### 例：同样奖励，三个边界标签不同

1. 奖励 \(r=1\)、\(\gamma=0.9\)、下一状态价值 \(V=10\)。

2. 正常继续或外部截断的 TD target 都为 \(1+0.9\times10=10\)。

3. 真正终止时 \(\mathrm{target}=1\)；若错误使用 `done=terminated OR truncated`，则截断也会被错误标成 1。

是否 reset 与是否 bootstrap 是两个判断，需要分别保留标志。

### 所有 done 都把 next_value 清零

这会把外部截断错误地解释成任务无未来回报；反过来，真正终止后继续 bootstrap 也会污染目标。

分别测试普通转移、`terminated`、`truncated` 和自动 reset，并核对使用的末状态观测。

## 多步回报、尾值与递推边界

n 步回报将已观察的若干奖励与尚未结束部分的尾值连接起来。递推长度决定折扣次数，终止边界决定尾值是否存在。下面沿一个片段从末端倒推，避免将尾值误作额外即时奖励。





一段长度 n 的采样片段如果尚未真正终止，回报可写成 n 步奖励加 \(\gamma^nV(s_{t+n})\)。代码倒序从 bootstrap 尾值开始，每处理一个奖励就乘一次 \(\gamma\)。尾值不是再加一条即时奖励，也不能只乘一次 \(\gamma\)；片段长短改变时，幂次错误会形成系统性偏差。





真正终止片段的尾值为零，外部切片的尾值则来自正确最后状态的估计。对于带多个回合的数组，不能把下一个回合的奖励继续递推到上一个回合。每个环境有自己的结束边界；Batch 维度和时间维度都需要明确，Padding 也不能参与真实回报累计。





优势估计如 GAE 把多个 TD 残差按 \(\gamma\lambda\) 加权，用于折中估计误差与方差。其 bootstrap Mask 与跨回合递推 Mask 可能不同：截断边界可以对旧回合末状态 bootstrap，但优势递推不能穿到 reset 后的新回合。下一节用递推公式与可运行代码具体区分这两个作用。





$$
G_t^{(n)}=\sum_{j=0}^{n-1}\gamma^j r_{t+j}+\gamma^nV(s_{t+n})
$$





### 分开保存 bootstrap 与递推连续性

截断时允许末状态估值，不意味着可以把下一回合的奖励或优势接进来。

用两个相邻短回合手算多步回报，分别检查尾值、\(\gamma\) 幂次和 reset 后的断开位置。

## GAE：TD 残差的递推与两个 Mask

优势是某动作价值相对当前状态价值的差，广义优势估计（GAE）用多步 TD 残差的加权和近似它。自举是否保留与残差递推能否跨过边界，是两种不同的 Mask 语义。下面先分清它们再写递推。





优势 \(A^\pi(s,a)=Q^\pi(s,a)-V^\pi(s)\) 衡量动作相对于当前状态平均行为的改进。GAE 使用采样轨迹上的 TD 残差 \(\delta_t=r_t+\gamma b_tV(s_{t+1})-V(s_t)\) 估计优势，把相邻残差按 \(\gamma\lambda\) 递减加权。向后递推只需保存下一时刻的一个累计量；\(\lambda=0\) 时只使用一步 TD 残差，\(\lambda=1\) 时在连续片段内展开为带尾值回报减去当前 V。较小 \(\lambda\) 通常更依赖 critic，较大 \(\lambda\) 使用更长的奖励序列；价值误差、采样方差和截断尾值共同影响估计，不能把 \(\lambda=1\) 简单称为任意条件下无偏。





这里需要两个不同的布尔条件。bootstrap Mask \(b_t=1-\mathbf1[\mathrm{terminated}_t]\) 决定该转移是否还有任务内的后续价值；递推 Mask \(c_t=1-\mathbf1[\mathrm{terminated}_t\lor\mathrm{truncated}_t]\) 决定数组中的下一行是否仍属于同一回合。外部截断时 \(b_t=1,\ c_t=0\)：保留旧回合最后状态的 V，但停止接入 reset 后的新回合优势。若 `terminated` 与 `truncated` 同时为真，以真正终止为准，两个 Mask 都为零。



### 例：两条转移的 GAE 可以倒序手算

1. 取同一回合连续两条转移，奖励为 [1,2]，价值估计为 \(V(s_0)=0.5,V(s_1)=1\)，第二条真正终止。令 γ=0.9、λ=0.5，真实终态不使用后继价值。

2. 两个 TD 残差为 \(\delta_0=1+0.9\times1-0.5=1.4\) 与 \(\delta_1=2-1=1\)。从片段末端令 \(\hat A_2=0\)，倒序得到 \(\hat A_1=1\)、\(\hat A_0=1.4+0.9\times0.5\times1=1.85\)。

3. 若某条转移是外部截断，仍要用该回合真实末观测的 V 构造它的 δ；但下一数组行若已是新回合，递推 Mask c 必须为零，不能再接入那个回合的优势。

先在每条真实转移上算 TD 残差，再在同一回合内倒序组合。是否保留 bootstrap 与是否继续跨行递推，必须分开决定。

采集器应为每条转移保存真实下一观测的估值 `next_value`，不能无条件用 value 数组向前错一位。自动 reset 时，下一行可能已经是新回合的初始状态；截断位置必须从接口提供的旧回合最终观测计算 `next_value`。对于 `[T,N]` 的向量化 rollout，每列独立递推。数组到达 T 只是本次估计的有限边界：令 \(\hat A_T=0\) 来停止继续累加残差，最后一条非终止转移仍保留真实下一状态的 bootstrap，不应仅因批次收满就伪造 `terminated`。





计算 actor 与 critic 的训练目标时，先固定采样阶段的价值预测并停止梯度。常用 critic 目标为 \(V_{\mathrm{old}}(s_t)+\hat A_t\)，称为此处有限片段的 \(\lambda\)-return；它与 actor 使用的优势共享同一边界约定。若为 actor 标准化优势，应在原始优势构造 critic 目标后另取副本，不能把标准化后的优势直接加回 V 作为回报。该片段只检查优势估计，不包含 PPO 的策略比率、多轮小批次优化或完整采样器。





$$
\begin{aligned}b_t&=1-\mathbf1[\mathrm{terminated}_t],\quad c_t=1-\mathbf1[\mathrm{terminated}_t\lor\mathrm{truncated}_t]\\\delta_t&=r_t+\gamma b_tV_{\rm old}(s_{t+1})-V_{\rm old}(s_t)\\\hat A_t&=\delta_t+\gamma\lambda c_t\hat A_{t+1},\quad\hat A_T=0\\\hat R_t^{\lambda}&=\hat A_t+V_{\rm old}(s_t)\end{aligned}
$$

```python
import torch

@torch.no_grad()
def gae(reward, value, next_value, terminated, truncated, gamma, lam):
    # 每列是一条环境轨迹；next_value 来自各转移真实的下一观测。
    assert reward.ndim == 2 and reward.shape[0] > 0  # [T, N]
    assert all(x.shape == reward.shape for x in
               (value, next_value, terminated, truncated))
    assert terminated.dtype == truncated.dtype == torch.bool
    assert 0 <= gamma <= 1 and 0 <= lam <= 1
    # 真实终态不取尾值；where 也避免无效终态值的 0 * NaN。
    bootstrap = torch.where(terminated, torch.zeros_like(next_value), next_value)
    delta = reward + gamma * bootstrap - value
    assert torch.isfinite(delta).all()
    continuation = ~(terminated | truncated)
    advantage = torch.zeros_like(reward)
    future = torch.zeros_like(reward[0])  # 有限 rollout 之外不再累加 TD 残差。
    for t in reversed(range(reward.shape[0])):
        future = delta[t] + gamma * lam * continuation[t].to(value.dtype) * future
        advantage[t] = future
    return advantage, advantage + value  # critic 的 lambda-return 目标

def column(items):
    return torch.tensor(items, dtype=torch.float64)[:, None]

# t=1 外部截断，t=2 已经 reset 到新回合；t=3 真正终止。
r, v = column([1, 2, 100, 3]), column([0.5, 1, 2, 3])
nv = column([1, 10, 3, float("nan")])
v.requires_grad_()
nv.requires_grad_()  # 输出目标仍应无梯度。
term = torch.tensor([[False], [False], [False], [True]])
trunc = torch.tensor([[False], [True], [False], [False]])
a, target = gae(r, v, nv, term, trunc, gamma=0.9, lam=0.5)
torch.testing.assert_close(a, column([5.9, 10, 100.7, 0]))
# 改变 reset 后的奖励，前一个回合的优势不应改变。
changed = r.clone()
changed[2] = 10000
a_changed, _ = gae(changed, v, nv, term, trunc, 0.9, 0.5)
torch.testing.assert_close(a_changed[:2], a[:2])
# lambda=0 只剩一步 TD 残差；lambda=1 得到分段 bootstrap 回报。
a0, _ = gae(r, v, nv, term, trunc, 0.9, 0.0)
torch.testing.assert_close(a0, column([1.4, 10, 100.7, 0]))
_, target1 = gae(r, v, nv, term, trunc, 0.9, 1.0)
torch.testing.assert_close(target1, column([10.9, 11, 102.7, 3]))
# 仅因 rollout 数组到尾部而停收集，无需伪造环境终止。
no_end = torch.zeros((1, 1), dtype=torch.bool)
_, tail = gae(column([1]), column([0.5]), column([10]),
              no_end, no_end, 0.9, 0.95)
torch.testing.assert_close(tail, column([10]))
assert not a.requires_grad and not target.requires_grad
print("GAE：终止、截断、跨回合隔离与 rollout 尾值检查通过。")

```

第一段在 \(t=1\) 截断：真实末状态的价值 10 被保留，但 \(t=2\) 新回合的奖励 100 不会传回。\(\gamma=0.9\)、\(\lambda=0.5\) 时前两项优势为 5.9 和 10；把新回合奖励改成 10000 后两者保持不变。最后分别用 \(\lambda=0\)、\(\lambda=1\) 以及非终止 rollout 尾部验证递推和 bootstrap；真正终态的无效 `next_value` 用 where 安全排除。





### 允许截断状态 bootstrap，不允许优势穿过 reset

同一个 done Mask 同时用于 TD 残差和 GAE 递推，会丢失截断尾值或串接两个回合。

单独改变新回合奖励，旧回合优势必须不变；单独改变截断末状态价值，旧回合优势应按 \(\gamma\) 与 \(\lambda\) 的系数变化。

## 让数值与张量操作遵循同一语义

一条转移包含当前行为之后的奖励、后继状态价值和结束标志。批量张量的各行必须保持这份一一对应，否则广播可能组合成不存在的转移。数值计算应先服从这套样本语义。





reward、`next_value`、`terminated` 和 `truncated` 常为 `[B]`，标志应保持布尔类型并严格对应每条转移。若其中一个变成 `[B,1]`，与 `[B]` 相加可能广播成 `[B,B]`，产生每条奖励与所有下一价值的交叉组合。损失仍能成为标量，因此需在计算 target 前后断言精确形状。





终止位置乘零不一定能清理非有限 `next_value`：\(0\times\mathrm{NaN}\) 仍是 NaN。如果终态没有合法价值输入，应在求值或组合前用安全选择排除，或用明确的有限占位值。数学里写 \((1-d)V\) 的边界含义，落到浮点实现还需要检查值域与无效样本。





奖励缩放、折扣、bootstrap 估计来源与终止定义都应写入训练配置。比较 critic loss 前先确认它们一致，否则目标尺度不同，loss 大小没有直接可比性。记录 target 的均值、分位数和按终止类型分组统计，有助于识别截断误处理或 reset 观测混入。









## 把 Bellman 计算与算法保证分开

方程定义了理想价值应满足的关系，神经网络优化则是在有限数据上寻找近似解。分开这两层问题，可以明确小型数值验证能够支持哪些结论，以及哪些稳定性仍需完整训练证据。





正确实现 TD 标签只证明局部计算与已声明目标一致，不保证 critic 收敛、更不保证策略提高。函数逼近、off-policy 数据、bootstrap 的组合可能带来困难；目标网络、采样分布与优化设置会影响实际稳定性。不要把 Bellman 等式当成任意神经网络训练都正确的证明。





学习时先做 \(\gamma=0\)、全终止、无终止、单步片段和带尾值片段等可手算情况，再检查梯度阻断和形状。最后才放入真实 rollout，核对环境结束标志和最终观测。一个能训练下降的 value loss 可能是在拟合错误 target，所以训练曲线不能替代这些边界检查。





代码分别计算真正终止与外部截断的目标，观察 bootstrap 项是否保留。阅读 actor-critic 或离线价值算法时，可以沿这条边界继续追踪策略评估、数据来源与重要性校正，避免把所有 done 都解释为后续价值为零。





从奖励到回报，再到价值和 Bellman 递推，每一步都在定义对未来结果的不同概括。TD、GAE 与边界处理只有回到这些定义才有意义；计算局部目标正确并不自动证明策略优化成功。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| rewards / values | [N] | 一批转移的即时奖励、当前或下一状态价值 |
| `terminated` / `truncated` | [N] bool | 终止语义与收集截断分别保存 |
| segment returns | [T] | 同一连续片段的逐时刻回报，可在片段末 bootstrap |

## 完整代码与精读

```python
import torch
from torch import nn

torch.manual_seed(7)

# STEP 1: 三个独立转移例子：继续、真正终止、外部截断
rewards=torch.tensor([1.,1.,1.])
next_values=torch.tensor([10.,10.,10.],requires_grad=True)
terminated=torch.tensor([False,True,False])
truncated=torch.tensor([False,False,True])
gamma=0.9

# STEP 2: reset 条件可以合并，bootstrap 条件不能照抄
needs_reset=terminated|truncated
with torch.no_grad():
    targets=rewards+gamma*torch.where(terminated,torch.zeros_like(next_values),next_values)
    wrong_targets=rewards+gamma*(~needs_reset).float()*next_values
print('correct targets:',targets.tolist())
print('wrong done-mask targets:',wrong_targets.tolist())
torch.testing.assert_close(targets,torch.tensor([10.,1.,10.]))

# STEP 3: 当前价值可训练，target 分支不接收该损失的梯度
value=nn.Embedding(3,1)
current_values=value(torch.arange(3)).squeeze(-1)
loss=(current_values-targets).square().mean()
loss.backward()
assert value.weight.grad is not None
assert next_values.grad is None and not targets.requires_grad

# STEP 4: 对同一段奖励，分别计算终止回报和截断 bootstrap 回报
def segment_returns(rewards,gamma,bootstrap):
    result=[]
    future=float(bootstrap)
    for reward in reversed(rewards):
        future=float(reward)+gamma*future
        result.append(future)
    return list(reversed(result))

print('terminal returns:',segment_returns([1,2,3],gamma,0.0))
print('truncated returns:',segment_returns([1,2,3],gamma,4.0))
print('Use the final observation before reset for the bootstrap value.')

```

- 第 6–12 行：这些是三条独立转移，不是一条连续三步轨迹。下一状态价值相同，结束语义不同。
- 第 13–21 行：外部截断需要 reset，但不是任务终态；把 needs_reset 用作 bootstrap Mask 会低估第三个标签。
- 第 22–29 行：target 在 no_grad 中构造，当前价值分支仍可反传。这是标准半梯度 TD 更新的计算边界。
- 第 30–41 行：完整终止轨迹用零尾值；提前截断的连续片段可用其最后真实状态价值补尾，不能用 reset 后新观测。

预期观察：正确 TD targets 为 [10,1,10]，错误合并 done 后为 [10,1,1]。终止回报约 [5.23,4.7,3]，尾值为 4 时约 [8.146,7.94,6.6]。

## 浏览器 Python 练习

实现 `discounted_returns(rewards,gamma,bootstrap=0.0)`。输入是一段连续轨迹，按 \(G_t=r_t+\gamma G_{t+1}\) 倒序计算。\(\gamma\in[0,1]\)，完整终止片段使用 `bootstrap=0`。

```python
def discounted_returns(rewards,gamma,bootstrap=0.0):
    # TODO: 从片段末端向前递推，不跨 episode
    raise NotImplementedError

```

### 提示

- future 初始为片段末状态的估计价值。
- 最后一条奖励也要先加奖励再乘上后续值，注意不是把奖励再整体乘 gamma。

### 参考实现与解释

```python
def discounted_returns(rewards,gamma,bootstrap=0.0):
    if not 0<=gamma<=1:
        raise ValueError('gamma outside [0,1]')
    result=[]
    future=float(bootstrap)
    for reward in reversed(rewards):
        future=float(reward)+gamma*future
        result.append(future)
    return result[::-1]

```

倒序递推只对同一连续片段成立。真正终止时 `future=0`；外部截断时可使用最后状态的价值。若下一行已经属于新 episode，必须切开片段，不能继续累加其奖励。

### 断言测试

```python
a=discounted_returns([1,2,3],0.9)
assert all(abs(x-y)<1e-10 for x,y in zip(a,[5.23,4.7,3.]))
b=discounted_returns([1,2,3],0.9,4.)
assert all(abs(x-y)<1e-10 for x,y in zip(b,[8.146,7.94,6.6]))
assert discounted_returns([1,2],0.0,99.)==[1.,2.]
assert discounted_returns([],0.9)==[]
print('回报、折扣和片段末 bootstrap 检查通过。')

```

## 本地 PyTorch 练习

实现 `td_targets(reward,next_value,terminated,truncated,gamma)`。四个张量均为 `[B]`，两个标志为布尔值。返回无梯度 target；外部 `truncated` 不取消 bootstrap，但真正 `terminated` 取消。 真正终态允许 next_value 为 NaN，必须在计算目标前排除；仍参与 bootstrap 的非有限值和非有限奖励应报错。

```python
import torch

def td_targets(reward,next_value,terminated,truncated,gamma):
    # TODO: reset 标志与 bootstrap 标志要分开
    raise NotImplementedError

```

### 提示

- 在标准一步 TD 中，仅乘以 ~`terminated`。
- `no_grad` 包围 target 构造，不要把待训练的 V(s) 也放进去。
- 先用 where 构造合法 bootstrap，再检查参与目标的值是否有限；不能先乘终止 Mask 来清理 NaN。

### 参考实现与解释

```python
import torch

def td_targets(reward,next_value,terminated,truncated,gamma):
    if reward.ndim!=1 or any(x.shape!=reward.shape for x in (next_value,terminated,truncated)):
        raise ValueError('shape mismatch')
    if terminated.dtype!=torch.bool or truncated.dtype!=torch.bool or not 0<=gamma<=1:
        raise ValueError('invalid flags or discount')
    # truncated 仅用于外层回合管理，不属于这个 bootstrap mask。
    with torch.no_grad():
        bootstrap = torch.where(terminated, torch.zeros_like(next_value), next_value)
        if not torch.isfinite(reward).all() or not torch.isfinite(bootstrap).all():
            raise ValueError("non-finite valid reward or bootstrap")
        return reward + gamma * bootstrap

```

外部截断停止了收集，而不是定义任务没有未来。调用者必须传入截断前的真实 `next_value`。target 不参与求导，符合这里采用的半梯度更新约定；若研究其他残差目标，需要重新推导而非随意移除 `detach`。 使用 where 排除真正终态不存在的尾值，使代码与正文的浮点边界一致；非终态无效尾值不能伪装成零。

### 断言测试

```python
r=torch.tensor([1.,1.,1.],requires_grad=True)
v=torch.tensor([10.,10.,10.],requires_grad=True)
term=torch.tensor([False,True,False])
trunc=torch.tensor([False,False,True])
y=td_targets(r,v,term,trunc,0.9)
torch.testing.assert_close(y,torch.tensor([10.,1.,10.]))
assert not y.requires_grad
y2=td_targets(r,v,term,torch.zeros_like(trunc),0.9)
torch.testing.assert_close(y,y2)
print('真正终止、外部截断与 target 梯度边界检查通过。')

# 终态无合法尾值时，不能用 0 * NaN 处理。
nan_at_terminal = v.detach().clone()
nan_at_terminal[1] = float("nan")
torch.testing.assert_close(td_targets(r,nan_at_terminal,term,trunc,0.9),y)
invalid = v.detach().clone()
invalid[2] = float("nan")
try:
    td_targets(r,invalid,term,trunc,0.9)
    raise AssertionError("非终止转移需要有限的 bootstrap")
except ValueError:
    pass
print("终态 NaN 排除与非终态非法值检查通过。")

```

## 练习：推导与分析

### 为什么 `terminated|truncated` 适合 reset，却未必适合 TD target？

两种情况都可能结束本次收集并需要环境重置，但其任务语义不同。真正终态没有该任务的后续价值；外部截断只是未继续观察，仍可用末状态估计补齐。因此 reset 的操作条件与价值目标的数学边界不能直接共用。

先确认时间限制是否属于任务定义。内在有限时域到期可能是真正终止，并应将剩余时间纳入状态；外部预算则通常保留 bootstrap。还要使用重置前的末观测，避免把新回合价值接到旧回合。

代码定位：`needs_reset` 与 targets 中两个不同 Mask。

- 区分操作性 reset 与任务终态。
- 说明内在有限时域、外部截断及末观测。

### critic loss 下降意味着策略一定更好吗？

不意味着。critic 在拟合某个由奖励和 bootstrap 构成的目标；目标可能有估计误差，数据分布也可能变化。仅降低当前批次的价值误差，没有直接证明 actor 产生了更高回报的行为。

应分别检查 target 的终止和梯度边界、价值预测误差或校准，以及固定评估条件下的实际回报或成功率。若 actor 同时在变，critic 的学习对象也在变，曲线需要结合数据来源解释。

代码定位：`loss=(current_values-targets).square().mean()` 与独立 rollout 评估。

- 不将 critic 拟合误差等同策略性能。
- 给出目标检查和闭环评估两个层次。

## 练习：辨析与纠错

### 把即时奖励当价值标签的全部含义

价值包含未来回报并依赖策略。先写奖励索引、折扣、时域和终止规则，再解释数值尺度。

### 用 done 统一取消所有 bootstrap

外部截断与真正终止不同。保留两个标志，并从旧回合正确末状态估计尾值。

### 把自动 reset 后的首帧当 next_state

这会把另一个回合的价值接入当前转移。检查所用环境 API 保存终态观测的方式与时机。

### 多步尾值只乘一次 gamma

尾值应乘 \(\gamma\)^n。用倒序递推与显式展开互相核对不同长度片段。

### 没有 detach 的 TD target 仍称普通半梯度更新

目标端梯度改变优化问题。分别检查 target 参数来源、图连接与目标网络更新机制。

## 原始资料

- [Spinning Up：回报、价值与 Bellman 方程](https://spinningup.openai.com/en/latest/spinningup/rl_intro.html)
- [Gymnasium：正确处理终止与时间截断](https://gymnasium.farama.org/tutorials/gymnasium_basics/handling_time_limits/)
- [PyTorch：自动微分机制](https://docs.pytorch.org/docs/stable/notes/autograd.html)
- [GAE：High-Dimensional Continuous Control Using Generalized Advantage Estimation](https://arxiv.org/abs/1506.02438)
