# 多任务梯度

连续动作回归与离散状态分类共享主干时，如何分析梯度组合。

多任务训练让多个目标共同更新一组共享参数；任务梯度是每个目标在这组参数上的导数，合成梯度由任务权重与采样共同决定。梯度点积可以解释局部相互作用，却不直接等于长期迁移收益。本章先定义共享坐标与加权目标，再推导一阶关系、读取各任务梯度，最后用独立任务评价判断训练取舍。

## 学习目标

- 把加权损失展开为共享参数上的梯度组合。
- 用 autograd.grad 测量各任务的范数与夹角，处理未使用参数。
- 依据独立任务指标和对照实验解释辅助目标的作用边界。

前置知识：[PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [微调与 LoRA](https://wxb1870.github.io/embodied-ml-lab/learn/finetuning/) · [训练诊断](https://wxb1870.github.io/embodied-ml-lab/learn/training-diagnostics/)

## 损失权重最终作用于共享参数的梯度

共享参数是同时参与多个任务预测的参数，任务梯度是各损失对同一组参数的导数。加权目标将这些梯度线性组合，任务专属头则有各自坐标。先固定共享范围，再讨论协作或竞争。





多个任务可以共享一个表征网络，再接独立的分类或回归输出。总目标 \(L=L_a+\lambda L_b\) 对共享参数 \(\theta\) 的梯度为 \(g_a+\lambda g_b\)；任务专属头只接收与自己有关的梯度。任务相互促进或竞争主要需要在共享参数坐标上讨论，把两个独立头的不同坐标混进一个向量，会掩盖真正的交互位置。





配套网络让连续向量回归与四类状态分类共享一个主干。两项损失的数值和输出维数不同，但它们最终都通过同一组参数起作用。把两项梯度分别取出，再与加权总目标的梯度比较，可以直接看见这种叠加。





选择辅助任务应首先说明它与主任务的关系、标签是否可靠、部署时是否需要对应输出。增加一个能下降的 loss 并不自动产生有用表征；只有独立主任务和相关能力指标上的对照，才能回答辅助监督是否值得保留。





$$
\nabla_\theta(L_a+\lambda L_b)=g_a+\lambda g_b
$$





## loss 数值不能直接表示训练影响

损失值是目标在当前样本上的数值，训练影响则通过它对参数的导数和优化更新产生。常数偏置可以改变前者却不改变后者。因此比较任务影响，需要先统一参数坐标、单位与归约。





给某项 loss 加上不依赖参数的常数，不改变其梯度，却可以任意改变显示数值；改变目标单位、归约分母或输出维数，也会改变 loss 与梯度的尺度关系。因此把两项 loss 调到数字差不多，只是一种非常粗糙的观察，不能作为平衡任务影响的充分标准。





先分别审查每项监督的单位、Mask、样本权重和归约。再在同一批次、同一参数状态上读取共享梯度范数，观察加权后的量 \(\lambda\lVert g_b\rVert_2\) 相对于 \(\lVert g_a\rVert_2\) 的大小。梯度还可能集中在不同层，单个全局比值会遗漏局部变化；必要时按共享模块分组统计，但不应把大量日志本身当作结论。







### 例：相同梯度可以对应不同 loss 数字

1. 令 \(L_a(\theta)=\theta^2\)，\(L_b(\theta)=\theta^2+1000\)。

2. 在 \(\theta=1\) 时，两项 loss 分别为 1 与 1001，梯度却都为 2。

3. 若仅按 loss 数值把第二项缩小一千倍，就会人为降低一个本来同等强度的梯度。

数值大小与优化作用必须通过导数联系，不能直接等同。

### 调到相同 loss 数值就认为平衡

常数、单位与分母会改变数值解释。

分别报告原始指标、有效数量及同一共享参数集合上的加权梯度范数。

## 点积怎样描述局部任务关系

梯度点积衡量一个任务的局部下降方向怎样影响另一任务的一阶损失变化，余弦则只比较方向而忽略幅度。这个解释基于小步展开。下面先推导局部关系，再说明它不能推出什么。





若只沿任务 a 做小步 SGD，\(\Delta\theta=-\eta g_a\)，则任务 b 的一阶变化约为 \(-\eta g_b^\top g_a\)。点积为正时，这一步在局部倾向于同时降低 b；为负时，b 可能上升。余弦将点积除以两者范数，保留方向关系而去掉绝对尺度。任一梯度为零时，它没有方向，余弦应记录为未定义而不是强行解释为正交。





这个推导只是一阶局部关系，依赖足够小的步长和当前样本。网络非线性、曲率、不同训练阶段与数据噪声都会改变后续行为。Adam 的预条件还会改变实际更新方向，因此原始梯度余弦不直接等于优化器一步的任务变化。需要时可直接计算真实 \(\Delta\theta\) 与各任务梯度的点积，再对照实际 loss 差。





还可以比较每一任务在真实更新后的损失差与一阶预测 \(g_i^\top\Delta\theta\)。两者相近时局部线性解释有参考价值；差异较大时可能因为步长、曲率或随机前向，不能再仅靠梯度夹角解释全部变化。这个对照也能发现记录的梯度是否来自更新前同一参数状态。





$$
\Delta L_b\approx-\eta g_b^\top g_a,\qquad \cos(g_a,g_b)=\frac{g_a^\top g_b}{\lVert g_a\rVert\lVert g_b\rVert}
$$





### 余弦看方向，范数和权重看强度

只有余弦无法判断合成后谁占主导，也无法区分几乎为零的梯度。

同时记录两个范数、加权范数比、点积和零范数状态。

## 负余弦不等于辅助任务一定有害

梯度冲突通常指任务梯度在共享坐标中点积为负；合成更新则还包含权重与其他任务贡献。冲突不必然使主任务损失上升，更不直接判定辅助任务长期有害。下面区分这几层结论。





总梯度 \(g=g_a+\lambda g_b\) 对主任务的一阶作用由 \(-\eta g_a^\top g\) 决定。即便 \(g_a\) 与 \(g_b\) 反向，只要主任务项占优势，合成更新仍可降低主任务；权重过大才可能把方向推向相反。局部冲突也可能伴随更好的长期表示或正则作用，这需要固定预算的训练与验证，而不是从一次夹角直接推断。





反过来，正余弦也不能保证部署收益：两个任务可能共享同一个数据捷径，在训练集上共同下降，却在新场景失效。应跨批次和训练阶段采样统计，结合独立主任务指标、旧能力与任务分组表现。诊断的目的在于提出可验证假设，不是给某辅助目标贴上永久有益或有害的标签。







### 例：完全反向时，权重决定是否抵消

1. 取一维 \(g_a=1\)、\(g_b=-2\)，余弦为 -1。

2. \(\lambda=0.25\) 时总梯度为 0.5，SGD 仍沿降低任务 a 的局部方向更新。

3. \(\lambda=0.5\) 时总梯度为 0，\(\lambda=0.75\) 时总梯度为 -0.5，方向反转。

同一个负余弦对应降低、抵消或反转，必须一起看范数与权重。

## 用 autograd.grad 获取一致的共享坐标

逐任务梯度读取是在固定共享参数列表上，分别计算各损失导数的诊断操作。列表顺序定义同一向量坐标，未参与某任务的参数仍需保留其位置。下面据此组织可比较的梯度。





autograd.grad 返回对指定参数的导数，默认不写入 .grad，可用于诊断而不直接污染训练梯度。先固定共享参数列表顺序，对每项 loss 分别求导；未参与某任务的参数可返回 None，应在其原位置填同形状零，然后按相同顺序展平。删除 None 项会让两个向量的坐标不再对应，点积数值即使可计算也失去意义。





如果后面还要对总目标 backward，前面的诊断求导需要按需 retain_graph=True；通常只做一阶统计，不需要 create_graph=True。保留图和多次求导有额外时间与内存成本，适合定期抽样而非无条件每步用于整个大模型。若某 loss 本身完全不连接任何所选参数，还需明确处理其图状态，不要把 allow_unused 当成所有断图问题的自动修复。





余弦的数值实现还需避免中间溢出。即便各梯度坐标有限，直接平方、点积或范数乘积也可能超过 dtype 的范围；分别将两个向量除以各自最大绝对值，再计算单位方向的点积，数学上不改变余弦。零向量单独返回未定义；非有限梯度先拒绝，不能用 clamp 将 NaN 伪装成合法方向。对应练习保留大数反例以核验这一实现边界。









### 把 None 梯度删掉再拼接

两个任务将拥有不同的参数坐标排列，余弦可能没有数学意义。

固定参数 ID 顺序，用同形状零占位；随后用总 loss.backward 验证组合梯度。

## 多任务采样与权重共同定义训练期望

任务采样概率决定某目标被计算的频率，损失权重决定每次计算的梯度系数。它们共同定义长期训练期望。先写出两者的乘积作用，再判断均衡策略有没有重复加强某项任务。





如果每个 Batch 同时包含两个任务的标签，\(\lambda\) 决定每个共同样本上两项损失的相对系数；如果交替抽取不同任务，任务抽样概率也会影响长期更新频率。把某任务采样概率提高两倍又将其权重提高两倍，可能产生重复加强。需要同时记录任务采样、标签可用率和有效元素归约，而不是只保存一个 \(\lambda\)。





缺失标签应通过各任务自己的有效位处理，不能把缺失类别当成负类、把缺失回归值当成零。每项分母要对应自己的目标；没有标签的分支可以不贡献监督，但共享主干仍可能被其他任务更新。看辅助分支验证误差时，也要区分它自身标签覆盖的变化与共享表征的真实变化。





当两个任务标签来自不同样本集合，梯度夹角还受抽到哪些条件影响。一个批次上看到竞争，可能是样本难度和类别构成造成的。可以在固定诊断集合上跨训练阶段重复测量，再与真实训练采样的统计比较，从而区分数据组成变化与参数状态变化。









## 调整权重与进阶梯度方法的边界

任务平衡方法通过选择权重、采样或修改梯度来控制共享更新。它们改变优化过程，需要与单任务和固定权重基线比较。梯度几何提供线索，最终取舍仍由各任务的独立结果判断。





固定权重是可解释的起点。先验证单任务基线，再加入第二任务，用多个 \(\lambda\) 在相同预算下比较主任务、辅助任务和需要保持的能力。权重太小可能几乎不起作用，太大可能主导共享表示；但最佳值不能只由初始一个 Batch 的梯度比确定，因为任务难度和梯度尺度会随训练改变。





GradNorm、梯度投影等进阶方法试图处理训练速度或局部冲突，但它们引入新的目标和超参数。它们不会修复数据泄漏、错误 Mask 或不相关标签，也不保证每项部署指标同时提高。阅读这些方法时先弄清实际修改的是损失系数还是梯度方向，再用可复查例子理解它与普通加权和的区别。





如果希望辅助任务只影响某些层，可以通过结构或梯度路径限定共享范围，但这也是模型设计变化。需要说明哪些参数接受哪些监督，保存完整参数组与消融结果，避免仅在论文或说明中声称“辅助监督”而代码实际更新了不同模块。





调整共享范围时，某个任务不再影响主干并不等于该任务不存在。它仍可能训练独立模块，但不能再用它的 loss 变化支持“共享表示得到改善”的结论。报告应列出每个目标连接的参数集合，让结构声明与实际梯度路径一致。









## 从数学恒等式走向可审查实验

梯度分解恒等式可以证明代码符合目标，却不能单独证明辅助监督改善部署表现。把数学核验与独立实验分别设计，能够保留局部诊断的价值，同时避免从一张梯度曲线推断长期收益。





双任务网络的梯度验证分成两个对照：分别读取共享梯度，与总目标 backward 的结果逐元素核对 \(g_{\mathrm{total}}=g_a+\lambda g_b\)；再构造确定性相反目标，观察抵消。随机网络的余弦由实际计算决定，不预设必然冲突。未使用参数也保留同一坐标位置，诊断不写入 .grad，避免诊断过程本身改变后续训练。





实际实验应记录共同初始化、任务采样、训练步数、有效监督数量、梯度统计位置与独立指标。诊断时看到负余弦，提出一个具体假设，例如某阶段辅助任务过强，再通过调整权重或共享范围的单因素对照检验。不要只挑选支持假设的一个 Batch 或最好的一个种子。





最终验证关心的是需要保留的能力是否改善或至少满足约束，而不是某条余弦曲线是否看起来更漂亮。数学检查确保梯度实现符合定义，独立实验再回答这个定义是否适合任务；两种证据相互补充。





多任务梯度分析围绕同一共享参数展开：目标与采样决定合成梯度，局部几何解释短期作用，独立评价检验长期收益。损失大小、方向冲突和任务表现因此需要分开记录，再共同判断。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 共享表征 | [B,H] | 两个任务头接收同一个主干输出。 |
| 回归输出 / 分类 logits | [B,2] / [B,4] | 两个教学任务的目标类型不同，共享梯度在同一主干参数上比较。 |
| 共享梯度 | [P_shared] | 必须用完全一致的参数顺序展平，None 位置填零。 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(34)
# STEP 1: 连续向量回归与四类状态分类共享主干
trunk = nn.Linear(3, 4)
action_head = nn.Linear(4, 2)
state_head = nn.Linear(4, 4)
x = torch.randn(5, 3)
action_target = torch.randn(5, 2)
state_target = torch.tensor([0, 1, 2, 3, 1])
hidden = torch.tanh(trunk(x))
loss_action = (action_head(hidden) - action_target).square().mean()
loss_state = F.cross_entropy(state_head(hidden), state_target)
shared = tuple(trunk.parameters())

# STEP 2: 读取相同共享坐标，核验加权梯度恒等式
ga_parts = torch.autograd.grad(loss_action, shared, retain_graph=True)
gs_parts = torch.autograd.grad(loss_state, shared, retain_graph=True)
ga = torch.cat([g.reshape(-1) for g in ga_parts])
gs = torch.cat([g.reshape(-1) for g in gs_parts])
denominator = ga.norm() * gs.norm()
cosine = None if float(denominator) == 0 else float(torch.dot(ga, gs) / denominator)
assert all(p.grad is None for p in shared)
weight = 0.25
(loss_action + weight * loss_state).backward()
combined = torch.cat([p.grad.reshape(-1) for p in shared])
torch.testing.assert_close(combined, ga + weight * gs)
print('回归 / 分类 loss:', float(loss_action.detach()), float(loss_state.detach()))
print('共享梯度范数:', float(ga.norm()), float(gs.norm()), '余弦:', cosine)

# STEP 3: 确定性相反目标，区分数学反例与随机网络观察
point = torch.tensor([0.0, 0.0], requires_grad=True)
toward_positive = (point - 1).square().sum()
toward_negative = (point + 1).square().sum()
gp = torch.autograd.grad(toward_positive, point, retain_graph=True)[0]
gn = torch.autograd.grad(toward_negative, point)[0]
torch.testing.assert_close(gp, torch.tensor([-2.0, -2.0]))
torch.testing.assert_close(gn, -gp)
torch.testing.assert_close(gp + gn, torch.zeros(2))
print('构造案例：相反梯度等权组合为', (gp + gn).tolist())
print('通过：真实回归与分类梯度组合，以及确定性抵消反例')

```

- 第 1–16 行：两个任务共享 trunk，但输出类型分别为连续向量与四类 logits；分类标签为 long 整数索引。
- 第 18–31 行：分别用 autograd.grad 读取主干梯度，不写入 .grad；再以总目标 backward 验证 g_action+0.25*g_state 的逐元素恒等式。
- 第 33–43 行：另构造相反梯度作为确定性反例，说明等权抵消可以发生；不将随机网络某一次余弦推广为普遍规律。

预期观察：一般回归与四类分类的加权共享梯度等于总目标反向结果；确定性二维反例得到 [-2,-2] 与 [2,2]，等权组合为零。

## 浏览器 Python 练习

实现 gradient_relation(g_a, g_b, weight)，返回 (combined, cosine)。两个输入为等长非空有限数列表，weight 为有限非负数；combined = g_a + weight*g_b。cosine 比较两个原始梯度，任一个范数为零时返回 None。非法输入抛 ValueError。 合成梯度溢出时抛 ValueError；余弦应避免直接相乘大数范数造成的中间溢出。

```python
def gradient_relation(g_a, g_b, weight):
     # TODO: 同顺序合成梯度；零范数时明确表示夹角未定义
     raise NotImplementedError('请实现 gradient_relation')

```

### 提示

- 合成梯度包含 weight；夹角比较的是两个原始梯度。
- cosine 的分母为两个范数的乘积，零分母应返回 None。

### 参考实现与解释

```python
import math

def gradient_relation(g_a, g_b, weight):
    if not g_a or len(g_a) != len(g_b):
        raise ValueError('向量形状不同')
    if not math.isfinite(weight) or weight < 0 or any(not math.isfinite(v) for v in g_a + g_b):
        raise ValueError('必须是有限数且权重非负')
    combined = [a + weight * b for a, b in zip(g_a, g_b)]
    if any(not math.isfinite(v) for v in combined):
        raise ValueError('合成梯度超出浮点有限范围')
    sa, sb = max(map(abs, g_a)), max(map(abs, g_b))
    if sa == 0 or sb == 0:
        return combined, None
    # 两个正尺度分别约掉，不直接计算可能溢出的 dot 或 norm 乘积。
    a, b = [v / sa for v in g_a], [v / sb for v in g_b]
    na, nb = math.hypot(*a), math.hypot(*b)
    cosine = math.fsum((u / na) * (v / nb) for u, v in zip(a, b))
    return combined, max(-1.0, min(1.0, cosine))

```

余弦只比较方向，不包含梯度强度；相反方向是否完全抵消还取决于范数和权重。分别除以每个向量的最大绝对值，不改变它们的方向，再对尺度化向量求范数和点积，可避免有限坐标在直接平方或范数相乘时溢出。边界截断只修正正常舍入；非有限输入或合成结果必须先拒绝，不能把 NaN 截断成看似合法的余弦。

### 断言测试

```python
combined, cosine = gradient_relation([1, 0], [-2, 0], 0.5)
assert combined == [0, 0] and cosine == -1
assert gradient_relation([1, 0], [0, 2], 2) == ([1, 4], 0.0)
assert gradient_relation([0, 0], [1, 2], 3) == ([3, 6], None)
assert gradient_relation([1, 2], [1, 2], 0)[0] == [1, 2]
for args in [([], [], 1), ([1], [1, 2], 1), ([1], [float('nan')], 1)]:
    try:
        gradient_relation(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法向量')
assert gradient_relation([1e200, 0], [-1e200, 0], 1) == ([0, 0], -1.0)
assert abs(gradient_relation([1.7e308, 1.7e308], [1.7e308, 1.7e308], 0)[1] - 1) < 1e-12
try:
    gradient_relation([1e308], [1e308], 1)
except ValueError:
    pass
else:
    raise AssertionError('应拒绝合成梯度溢出')
print('通过：抵消、正交、零范数、大数余弦与输入边界')

```

## 本地 PyTorch 练习

实现 shared_gradient_report(loss_a, loss_b, parameters, weight_b)，返回字典 g_a、g_b、combined（展平 Tensor）与 cosine（float 或 None）。parameters 为同一组非空、需要梯度的参数列表，loss 为标量，weight_b 为非负有限数。用 autograd.grad 读取而不写 .grad，允许某些参数未参与任务并在原位置填零；保留图供之后 total.backward 使用。 非有限梯度或合成结果应拒绝；余弦采用独立尺度化，避免大数中间溢出。

```python
import torch

def shared_gradient_report(loss_a, loss_b, parameters, weight_b):
    # TODO: 分别读取梯度，None 用同形状零填充，再按固定顺序展平
    raise NotImplementedError('请实现 shared_gradient_report')

```

### 提示

- allow_unused=True 的 None 表示该任务没有使用这个参数；填零保持展平坐标一致。
- 两次读取都要 retain_graph=True，因为之后还需总损失 backward；默认 create_graph=False 足够诊断。

### 参考实现与解释

```python
import math
import torch

def shared_gradient_report(loss_a, loss_b, parameters, weight_b):
    params = tuple(parameters)
    if not math.isfinite(weight_b) or weight_b < 0:
        raise ValueError('任务权重必须是有限非负数')
    def read(loss):
        grads = torch.autograd.grad(loss, params, retain_graph=True, allow_unused=True)
        return torch.cat([(torch.zeros_like(p) if g is None else g).reshape(-1)
                          for p, g in zip(params, grads)])
    ga, gb = read(loss_a), read(loss_b)
    if not bool(torch.isfinite(ga).all() & torch.isfinite(gb).all()):
        raise ValueError('非有限梯度不能解释为方向')
    combined = ga + weight_b * gb
    if not bool(torch.isfinite(combined).all()):
        raise ValueError('合成梯度超出当前 dtype 的有限范围')
    sa, sb = ga.abs().max(), gb.abs().max()
    if float(sa) == 0 or float(sb) == 0:
        cosine = None
    else:
        a, b = ga / sa, gb / sb
        cosine = float(torch.dot(a / a.norm(), b / b.norm()).clamp(-1, 1))
    return dict(g_a=ga, g_b=gb, combined=combined, cosine=cosine)

```

测试手算两个梯度 [2,-4]、[0,-6]，并加入未使用参数，识别坐标错位与删除 None 的错误。读取不修改 .grad，随后真正 backward 与报告逐项一致。零梯度没有方向；大数案例使用两个反向但有限的梯度，检验独立尺度化能避免直接点积/范数乘积的溢出。若原始梯度已非有限，则拒绝解释其方向，而不以 clamp 掩盖错误。参数列表、标量损失与图连接约定由题设保证。

### 断言测试

```python
torch.manual_seed(340)
p = torch.nn.Parameter(torch.tensor([1.0, -2.0], dtype=torch.float64))
unused = torch.nn.Parameter(torch.tensor([5.0], dtype=torch.float64))
la = p.square().sum()
lb = (p - 1).square().sum()
report = shared_gradient_report(la, lb, [p, unused], 0.25)
torch.testing.assert_close(report['g_a'], torch.tensor([2.0, -4.0, 0.0], dtype=torch.float64))
torch.testing.assert_close(report['g_b'], torch.tensor([0.0, -6.0, 0.0], dtype=torch.float64))
assert p.grad is None and unused.grad is None
(la + 0.25 * lb).backward()
torch.testing.assert_close(report['combined'][:2], p.grad)
assert report['combined'][2] == 0 and unused.grad is None
zero_case = shared_gradient_report((p * 0).sum(), p.square().sum(), [p], 1)
assert zero_case['cosine'] is None
expected_cosine = 24 / ((20 ** 0.5) * 6)
assert abs(report['cosine'] - expected_cosine) < 1e-12
huge = torch.tensor([1e200, -1e200], dtype=torch.float64)
large_case = shared_gradient_report((p * huge).sum(), -(p * huge).sum(), [p], 1)
assert abs(large_case['cosine'] + 1) < 1e-12
torch.testing.assert_close(large_case['combined'], torch.zeros_like(p))
print('PyTorch 通过：实际求导、未用参数、零范数、大数余弦与总梯度对照')

```

## 练习：推导与分析

### 回归 loss 是 0.1，分类 loss 是 10，能否直接断言分类主导共享训练？

不能。loss 数值受单位、常数项、分母和函数形状影响，而共享参数受到的是梯度。即使 loss 很小，也可能对某些参数产生较大梯度。

应固定共享参数范围，分别用 autograd.grad 读取范数与方向，再观察加权组合及各任务指标。示例只比较 trunk，避免把独立输出头的参数误当作共享干扰。

代码定位：演示 shared 的参数范围与 ga、gs；shared_gradient_report。

- 能用给 loss 加常数的反例说明数值与梯度不同。
- 能说明应该在哪组参数上比较任务作用。

### 发现两个任务梯度余弦为负，是否说明辅助任务一定有害？

负点积说明在当前参数与数据上，单独沿一个任务的梯度下降方向，另一个任务的一阶变化可能上升。它不直接决定多步训练、预条件优化器和独立部署数据上的结果。

应汇总不同批次和阶段的统计，并用固定预算比较权重设置。二维抵消案例证明竞争可能发生，但不能把人工构造推广为所有辅助任务的效果；零范数时必须先标记方向未定义。

代码定位：演示 STEP 3 的确定性抵消；练习 cosine 的 None 分支。

- 能用点积解释局部一阶竞争。
- 能列出单批次夹角无法保证的外部效果。
- 能正确处理零梯度夹角。

## 练习：辨析与纠错

### 辅助 loss 下降就认定主任务受益

共享表示可能偏向辅助任务或共同捷径。比较独立主任务、旧能力和部署指标，保留单任务基线。

### 只凭一次负夹角删除辅助任务

局部方向随样本和训练阶段变化，权重也影响合成方向。汇总跨批次统计并做固定预算对照。

### 用不同参数集合的梯度计算余弦

坐标不一致时结果没有可比意义。选择同一共享列表，None 保留零位置。

### 每步保留全模型图做梯度分析

可能显著增加内存与耗时并扰动训练。定期抽样、选定共享层，并在诊断后释放不需要的图。

## 原始资料

- [PyTorch：torch.autograd.grad](https://docs.pytorch.org/docs/stable/generated/torch.autograd.grad.html)
- [GradNorm：多任务梯度归一化原论文（进阶阅读）](https://arxiv.org/abs/1711.02257)
- [Gradient Surgery for Multi-Task Learning（进阶阅读）](https://arxiv.org/abs/2001.06782)
