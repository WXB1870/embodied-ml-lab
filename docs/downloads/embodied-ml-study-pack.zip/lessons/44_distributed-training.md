# DDP 与全局统计

每个进程算局部数据，但训练目标必须在全局保持一致。

分布式数据并行（DDP）是在多个进程中复制模型、让各副本处理不同数据，并同步对应参数梯度的训练方式。它扩大单次协作的数据处理能力，但不会自动定义全局样本权重、数据分片或日志统计。本章先认识副本、rank 和同步，再从单进程目标推导梯度平均，最后组织累积、通信和恢复。

## 学习目标

- 解释 DDP 的参数副本、梯度同步与输入分片边界。
- 正确处理不等有效标签数和分布式指标的分母。
- 理解两进程 CPU/Gloo 示例，并明确多张 GPU 的显存不会自动合并。

前置知识：[数据采样与批处理](https://wxb1870.github.io/embodied-ml-lab/learn/dataloader/) · [梯度累积](https://wxb1870.github.io/embodied-ml-lab/learn/gradient-accumulation/) · [训练显存与重计算](https://wxb1870.github.io/embodied-ml-lab/learn/memory-checkpointing/)

## 数据并行复制模型，分开处理输入

数据并行把模型复制到多个协作进程，各自读取不同数据，再组合梯度以保持一致更新。rank 是进程身份，world_size 是参与进程数。先认识这一计算结构，再讨论设备和输入怎样分工。





普通 DistributedDataParallel（DDP）让多个进程各持有一份模型，处理不同输入，在反向过程中同步对应参数的梯度。每个进程称为一个 rank，world_size 是参与进程数，local_rank 常用于选择本机设备。多 GPU 的常见组织是一进程一设备，但核心概念是协作进程，而不是一个 Python 进程里简单循环多次模型。





DDP 的数据并行不自动将参数、梯度和优化器状态分片到不同进程；每个 rank 通常仍有完整副本。因此它主要增加吞吐和可用全局 Batch，不意味着一份放不进单卡的模型可以靠普通 DDP 自动装下。参数或状态分片属于其他机制，需分别理解其通信与保存协议。





不同 rank 必须构造相容的模型和参数注册顺序，并从协调的初始状态开始。同步梯度之后，各进程执行相同的优化器更新，才能保持副本一致。只让 rank 0 调 optimizer.step、其余 rank 不更新，会破坏这种基本流程。









## 从梯度平均推导全局目标

全局训练目标是所有参与进程的数据共同构成的损失，梯度平均则是 DDP 的一种归约行为。二者只有在相应本地权重和有效计数匹配时才等价。下面从目标推导本地应计算什么。





在标准 DDP 的默认归约行为下，进程间梯度被平均。若每个 rank 有 n 个样本并对本地损失求 mean，那么所有 rank 的梯度平均等于这 Rn 个样本的总体平均，前提是样本前向与分块无关。若本地用 sum，平均后会比全局 sum 少一个 world_size 因子。学习率不能脱离归约定义单独讨论。





机器人序列可能有不同有效长度，rank 的样本数相同也不保证有效元素数相同。设本地误差和为 \(S_r\)、全局有效数 \(N=\sum_r n_r\)，所需目标为 \(\frac{\sum_r S_r}{N}\)。因 DDP 最终除 R，本地可对 \(\frac{R S_r}{N}\) 反向，平均后恢复正确全局梯度。这个推导假设分母由数据决定、采用默认平均协议；自定义 hook 或动态参与需要重新核对。





$$
\frac1R\sum_r\nabla_\theta\left(\frac{R S_r}{N}\right)=\nabla_\theta\frac{\sum_rS_r}{N}
$$



### 例：两个 rank 的有效长度不同

1. rank 0 有 2 个有效元素、平均梯度 10；rank 1 有 6 个有效元素、平均梯度 2。

2. 直接平均本地 mean 得到 \(\frac{10+2}{2}=6\)。

3. 全局元素平均为 \(\frac{2\times10+6\times2}{8}=4\)；本地应分别反向 \(\frac{2S_0}{8}\) 与 \(\frac{2S_1}{8}\)。

进程等权平均与元素等权平均只有在相应计数一致时才相同。

### 以为 DDP 会自动修正所有 Mask 分母

DDP 只处理传来的梯度，不知道哪些输出是真正有效监督。

用不等有效长度的两块数据手算全局目标，再对照单进程与多进程的一次更新。

## DistributedSampler 与 DataLoader worker 各做什么

DistributedSampler 为不同训练 rank 分配数据索引，DataLoader Worker 在一个进程的数据管线中并行读取。它们分别解决协作副本间和读取管线内的分工，DDP 本身不会自动替代这两项职责。





DDP 不会自动切分输入，需要由 sampler 或其他数据协议为每个 rank 分配索引。DistributedSampler 使用同一数据集和协调随机顺序生成不同分片；训练每个 epoch 调 set_epoch，可以让分片的随机打乱按新 epoch 变化。DataLoader 的 num_workers 则是在每个 rank 内并行读取数据，两种进程层级不能混为一谈。





样本数不能整除 world_size 时，sampler 可根据设置补齐重复样本或丢弃尾部；DataLoader 自己的 drop_last 又控制本地不满 Batch。两层策略组合会改变实际看过的样本数量。训练时重复或丢弃应明示，评估时重复样本会影响指标，应去重或采用无重复分片，并保证最终汇总覆盖所声称的集合。





如果 Dataset 是可迭代流，还需额外协调 rank 与 worker 的分片，不能直接照搬固定索引数据集的假设。记录样本 ID 与每 rank 的覆盖范围，是检查重复、遗漏和错误分片的直接方法。









## 集合通信要求所有参与者遵守同一顺序

集合通信是多个进程共同参与的归约、广播或同步操作。每个参与者需要按相容顺序进入对应调用，否则其他进程可能等待缺失者。下面将通信顺序与数据、分支和异常处理联系起来。





all_reduce、broadcast 和 barrier 等操作需要对应进程按相容顺序参与。如果某个 rank 因空数据、条件分支或异常先退出，其他进程可能在等待相应通信时挂住。遇到停滞时，应先查看各 rank 最后执行到哪一个步骤、是否拥有相同步数，以及是否有更早的异常，而不是只盯着最终超时消息。





本地没有有效标签并不等于可以直接跳过 backward；其他 rank 可能有监督，仍需所有进程参与预期同步。若全局监督为空，可以依据协调后的全局计数共同跳过这次更新。带条件分支且某些参数未使用的模型，还要与 DDP 的未使用参数处理约定匹配。额外 barrier 可以帮助定位阶段，但不能修复根本不一致的控制流。







### 例：一个 rank 跳步如何造成等待

1. rank 0 判断自己的 Mask 全 False，直接 continue。

2. rank 1 正常 backward，并进入等待所有 rank 的梯度归约。

3. rank 0 没有执行对应通信，rank 1 可能一直等到超时；本地判断必须改成全局协调的协议。

分布式控制流也是算法正确性的一部分。

### 每个异常都带上 rank 与阶段信息

只有 rank 0 的日志常看不到真正最早失败的进程。

记录数据取出、前向、反向、归约和 step 的阶段标记，先找最早异常。

## no_sync 与梯度累积的通信边界

no_sync 是暂时不进行 DDP 梯度同步的上下文，用于将若干本地微批累积到统一同步边界。它减少通信次数，却不改变完整更新应包含的梯度。下面明确前向、反向与最终同步的范围。





默认每次反向都可能触发梯度同步。累积多个微批时，可在前几次使用 ddp.no_sync，最后一次恢复同步；这样保持一个完整更新的梯度组合，同时减少通信次数。官方接口要求 forward 也处在 no_sync 上下文中，只包 backward 不会按预期关闭同步。所有 rank 的周期长度和同步边界必须协调。





通信减少不改变分母问题。若每个 rank 内又有不同长度微批，仍要按整个更新的全局有效数缩放；AMP 的缩放因子也要在本次累积内保持一致。统一同步后再按所需完整梯度裁剪，最后各 rank 更新模型。将每一步操作标成微批级或更新级，可以避免在多个机制叠加时产生隐蔽的计数错误。









### no_sync 只包 backward

forward 也参与 DDP 同步行为的设置，遗漏它可能仍产生通信。

用清晰的上下文包住对应微批次的 forward 和 backward，并记录同步周期。

## 日志指标应归约分子和分母

全局指标是所有进程样本共同定义的统计，而本地 loss.item 只属于当前 rank。梯度通信不会自动归约日志。要得到元素等权平均，应分别组合误差总和与有效数量。





训练梯度同步不代表 Python 日志变量自动变成全局统计。每个 rank 的 loss.item() 仍是本地值。若本地有效数不同，直接平均这些标量会得到错误指标；应汇总误差和 S 与有效数 N，再计算 \(\frac{\sum S}{\sum N}\)。成功率、准确率也应累计成功/正确次数与总次数，而不是无条件平均各 rank 的比例。





指标归约通常不需要梯度，应使用已 detach 的统计量，避免把日志通信混进训练图。还要审查 sampler 是否补齐了重复评估样本，否则即使分子分母数学正确，也统计了错误集合。按任务或场景报告时，分别归约各组计数，避免全局均值掩盖只在少数 rank 出现的困难样本。









## 模式、随机性与保存恢复

分布式训练状态包含各副本的模型与优化状态，也包含各自数据进度和随机序列。同步模型不等于让所有数据增强相同。下面分别确定哪些状态应一致、哪些应按设计分开。





DDP 同步参数相关状态不意味着每个样本的随机增强必须完全相同。模型初始化需要协调，数据顺序和增强则需按设计既可复现又避免重复。BatchNorm 的本地 Batch 统计、同步 BatchNorm 和 LayerNorm 行为不同；普通 DDP 不会自动把所有前向统计都变成全局统计。评估切换 eval 与求导模式仍是各进程需要明确执行的操作。





通常由 rank 0 保存公共模型与优化器状态，避免多个进程同时覆盖文件；恢复时所有 rank 读取相容状态并核对设备映射与 step。若要求严格续训，还需要各 rank 的随机状态、sampler 进度和数据位置。只保存 rank 0 的一个种子，不能自动恢复所有进程已消耗的随机序列。





改变 world_size 会改变分片、全局 Batch 和可能的调度含义，因此应作为训练配置变更记录。即使参数可加载，后续轨迹也未必与原运行精确相同；应区分可继续训练与逐步复现实验。









## 先证明单进程等价，再扩展真实训练

并行程序的问题来源较多，直接从大模型吞吐或损失曲线判断等价性并不可靠。先让一个可手算模型与单进程更新逐项对照，再增加真实机制，可以把数学归约、数据分片和通信实现的证据分开。





演示启动两个真实 CPU/Gloo 进程，使用可整除的小数据集，将一次 DDP 更新与单进程完整批次更新逐参数对照。它检验的是简单线性模型、相等本地计数与默认梯度平均条件下的等价，不覆盖特殊分片、批内对比或所有通信实现。Gloo 是本例使用的进程通信后端；运行程序需要允许本地进程通信。不能建立通信时，单进程数学练习仍可核对缩放公式，但不能代替两进程演示。





在具备通信权限的本地环境运行时，先使用小数据、固定初始化和简单模型，确认分片无重复、全局计数正确、各副本一致。再逐项引入变长 Mask、累积、AMP 和实际模型。若一次加入所有组件，loss 差异可能来自数据、随机性、归约或通信，很难定位。





最终还需评估扩展效率：更多进程带来更大总 Batch，但通信、数据加载和不均匀工作量可能限制吞吐。正确性和性能分别验证，记录有效样本吞吐、同步耗时与每 rank 工作量，而不是只报告使用了多少张卡。





共同训练项目的 `masked_error_sum` 已返回局部分子 \(S_r\) 和有效标量数 \(N_r\)。若扩展到 R 个默认平均梯度的 DDP rank，先以相同通信顺序汇总 \(N=\sum_rN_r\)，每个 rank 反传 \(R S_r/N\)，DDP 平均后得到 \(\sum_r\nabla S_r/N\)；日志另外归约 detached 的分子与分母。非最后微步的前向和反向应一同放在 no_sync 内，最后微步完成同步。必须保证各 rank 更新/通信边界一致，包括空监督与尾批；这只是把单进程项目扩展为 DDP 的适配关系；完成后仍需在真实进程通信中对照各副本参数和全局更新，不能从单进程累积等价直接推出通信正确。





DDP 是协作计算方式，目标的全局定义仍需由数据分片、局部权重、梯度归约与更新边界共同实现。先以单进程参照解释等价条件，再扩展通信与恢复，才能判断一次同步是否完成了所需训练。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| rank 的模型副本 | 每进程完整 \(\theta\) | 各进程复制模型、分配不同样本；参数与优化器状态没有在进程间分片。 |
| 本地输入 | [Bᵣ,D] | 由采样器分配，DDP 不自动切分输入。 |
| 统计归约 | [误差总和, 有效计数] | 先跨 rank 求和，再计算全局平均。 |

## 完整代码与精读

此示例启动两个本地 CPU/Gloo 进程；当前交付环境限制本机通信，未能完成此项运行验证。请下载后在支持本地进程通信的环境执行。

```python
import os
import tempfile
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import TensorDataset, DistributedSampler

# STEP 1: 每个 worker 是真实进程，Gloo 仍需本机进程通信
def worker(rank, world_size, rendezvous):
    torch.set_num_threads(1)
    torch.manual_seed(33)
    dist.init_process_group('gloo', init_method='file://' + rendezvous,
                            rank=rank, world_size=world_size)
    try:
        x = torch.tensor([[1., 0.], [0., 1.], [1., 1.], [2., -1.]])
        y = torch.tensor([[1.], [2.], [3.], [0.]])
        model = nn.Linear(2, 1)
        reference = nn.Linear(2, 1)
        reference.load_state_dict(model.state_dict())
        ddp = DDP(model)
        # STEP 2: 输入由 sampler 分片；backward 中同步梯度
        sampler = DistributedSampler(TensorDataset(x, y), num_replicas=world_size,
                                     rank=rank, shuffle=False, drop_last=False)
        sampler.set_epoch(0)
        indices = list(sampler)
        optimizer = torch.optim.SGD(ddp.parameters(), lr=0.1)
        optimizer.zero_grad(set_to_none=True)
        loss = (ddp(x[indices]) - y[indices]).square().mean()
        loss.backward()
        optimizer.step()
        # STEP 3: 与完整批次更新对齐，再按分子与分母归约日志
        ref_opt = torch.optim.SGD(reference.parameters(), lr=0.1)
        ref_opt.zero_grad(set_to_none=True)
        (reference(x) - y).square().mean().backward()
        ref_opt.step()
        for p, q in zip(model.parameters(), reference.parameters()):
            torch.testing.assert_close(p, q)
        stats = torch.tensor([loss.item() * len(indices), float(len(indices))])
        dist.all_reduce(stats, op=dist.ReduceOp.SUM)
        if rank == 0:
            print('CPU Gloo 进程数:', world_size, '全局 MSE:', float(stats[0] / stats[1]))
            print('通过：两进程更新与单进程完整批次一致')
    finally:
        dist.destroy_process_group()

if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='eml-ddp-') as folder:
        mp.spawn(worker, args=(2, os.path.join(folder, 'rendezvous')), nprocs=2, join=True)

```

- 第 1–22 行：mp.spawn 启动独立进程，file:// 只用于进程发现与初始化协调（rendezvous）；Gloo 的数据通信仍需要本机 socket，因此共享同一文件不能代替通信权限。
- 第 23–32 行：数据量 4 可以被两个进程整除，因此各 rank 各有 2 条样本，没有补齐重复。此等分条件下局部 MSE 的 DDP 平均与全局 MSE 一致。
- 第 33–50 行：每个 rank 都做参数对照与 all_reduce；只有打印限制在 rank 0。支持本机通信的环境运行通过后，才可确认这项两进程演示。

预期观察：运行成功时应启动两个 Gloo 进程，并通过各 rank 与单进程更新的参数断言；具体 loss 只对应本例固定数据。

## 浏览器 Python 练习

counts[r] 是 rank r 的有效元素数。实现 ddp_mean_weights(counts)，返回每个局部 mean 应乘的权重，使随后按 rank 平均得到全局有效元素平均。counts 为非空非负整数列表，总数必须大于零；零计数 rank 的权重为零。本题只是标准库数学练习，不启动分布式进程。

```python
def ddp_mean_weights(counts):
     # TODO: DDP 后面还会除以进程数，需要把这个因子补回
     raise NotImplementedError('请实现 ddp_mean_weights')

```

### 提示

- 希望每组最终权重为 nᵣ/N，但 DDP 会再除以 R。
- 因此局部 mean 先乘 \(\frac{Rn_r}{N}\)；零计数时不能真正计算 0/0 的局部 mean。

### 参考实现与解释

```python
def ddp_mean_weights(counts):
    if not counts or any(not isinstance(n, int) or n < 0 for n in counts):
        raise ValueError('有效计数不合法')
    total = sum(counts)
    if total == 0:
        raise ValueError('全局没有有效元素')
    world_size = len(counts)
    return [world_size * n / total for n in counts]

```

数学权重为零只说明该 rank 不贡献监督，不表示可以跳过同步。真实代码宜使用保持计算图的局部 sum，再乘 R/N；这样避免零计数 rank 先计算不存在的 mean。全局分母需通过真实通信或已知窗口计数获得。

### 断言测试

```python
assert ddp_mean_weights([2, 6]) == [0.5, 1.5]
assert ddp_mean_weights([4, 4, 4]) == [1.0, 1.0, 1.0]
assert ddp_mean_weights([0, 5]) == [0.0, 2.0]
weights = ddp_mean_weights([2, 6])
combined = sum(w * g for w, g in zip(weights, [2, 6])) / 2
assert combined == (2 * 2 + 6 * 6) / 8 == 5.0
for counts in [[], [0, 0], [-1, 2]]:
    try:
        ddp_mean_weights(counts)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法计数')
print('通过：DDP 平均与全局有效元素平均的缩放推导')

```

## 本地 PyTorch 练习

实现 ddp_scaled_local_loss(local_error_sum, global_valid_count, world_size)，返回标准 DDP 平均梯度前应反传的局部损失。local_error_sum 是标量 Tensor，后两个参数为正整数。测试在单个 CPU 进程中用 autograd 明确模拟 rank 梯度平均，与全局 MSE 对比；此练习不运行多卡或 Gloo。

```python
import torch

def ddp_scaled_local_loss(local_error_sum, global_valid_count, world_size):
    # TODO: 补偿标准 DDP 的 world_size 平均因子，保留计算图
    raise NotImplementedError('请实现 ddp_scaled_local_loss')

```

### 提示

- 目标是 \(\frac1R\sum_r\nabla\,\mathrm{local\_loss}_r=\nabla\!\left(\frac{\sum_r S_r}{N}\right)\)。
- 必须保留 local_error_sum 的 Tensor 运算，不要转换为 item 后重建。

### 参考实现与解释

```python
import torch

def ddp_scaled_local_loss(local_error_sum, global_valid_count, world_size):
    if global_valid_count <= 0 or world_size <= 0:
        raise ValueError('全局有效数与进程数必须为正')
    return local_error_sum * (world_size / global_valid_count)

```

测试使用有效计数 1 与 3，简单平均局部 mean 会失败；忘记补乘 world_size 也会使结果小一半。autograd.grad 返回各局部梯度而不写入 p.grad，随后手动 mean 只是验证 DDP 的数学缩放，不构成通信系统的运行验证。

### 断言测试

```python
torch.manual_seed(330)
p = torch.tensor(0.7, dtype=torch.float64, requires_grad=True)
targets = [torch.tensor([1.0], dtype=torch.float64),
           torch.tensor([2.0, -1.0, 3.0], dtype=torch.float64)]
total = sum(t.numel() for t in targets)
rank_gradients = []
for target in targets:
    local_sum = (p - target).square().sum()
    local_loss = ddp_scaled_local_loss(local_sum, total, 2)
    rank_gradients.append(torch.autograd.grad(local_loss, p)[0])
averaged = torch.stack(rank_gradients).mean()
reference_loss = (p - torch.cat(targets)).square().mean()
reference = torch.autograd.grad(reference_loss, p)[0]
torch.testing.assert_close(averaged, reference, atol=1e-12, rtol=1e-12)
assert p.grad is None
try:
    ddp_scaled_local_loss(p.square(), 0, 2)
except ValueError:
    pass
else:
    raise AssertionError('应拒绝零全局分母')
print('PyTorch 通过：单进程数学模拟的不等计数 DDP 梯度缩放')

```

## 练习：推导与分析

### 为什么 4 张卡上的 DDP 不等于拥有一张 4 倍显存的卡？

数据并行复制模型，各进程处理不同数据并同步梯度；默认没有把权重和优化器状态拆成四份。因此单张卡仍需装得下自己的完整模型状态与局部激活。

演示每个 worker 都创建独立 Linear 和 optimizer，DDP 包装后只是同步训练。若模型本身放不下，需要考虑降低状态或激活开销，或进一步学习 FSDP、ZeRO，而不是只增加 DDP world_size。

代码定位：worker 内模型、优化器与 DDP 的初始化。

- 能区分数据分片与模型状态分片。
- 能指出 DDP 对本地容量和全局 Batch 的不同影响。

### 各 rank 的有效动作数不同，怎样让梯度和日志都对应全局平均？

梯度采用本地误差 sum 乘 R/N，再由标准 DDP 平均；N 是所有 rank 的有效计数之和。局部 mean 需要额外按有效数量加权，不能直接等权平均。

日志归约误差总和与计数，再相除。所有 rank 共同参加归约；零有效 rank 也需保持同步，评估还要核查 sampler 补齐造成的重复。PyTorch 练习仅验证这个数学关系，实际 Gloo 演示仍受交付环境通信限制。

代码定位：ddp_scaled_local_loss；演示 stats 的 all_reduce 与全局分母。

- 能推导 R/N 的来由。
- 能分别写出梯度和日志的正确汇聚方式。
- 能说明数学模拟与分布式运行验证的边界。

## 练习：辨析与纠错

### 每个 rank 都读取完整数据却当作不同分片

DDP 不替代 sampler。记录各 rank 样本 ID，检查预期覆盖、重复和尾部策略。

### 平均各 rank 的 mean 就当全局均值

当有效数不同，这会赋予进程相同权重。归约分子和分母，并对训练梯度使用相匹配的缩放。

### 某 rank 发现空监督就自行 continue

会破坏其他进程的同步顺序。先协调全局有效计数，保持所有 rank 的通信协议一致。

### 双进程无法启动却把单进程检查写成已通过 DDP

真实通信、初始化与同步没有被验证。应明确标注环境阻塞，在可用环境重新运行真实进程测试。

## 原始资料

- [PyTorch：DistributedDataParallel](https://docs.pytorch.org/docs/stable/generated/torch.nn.parallel.DistributedDataParallel.html)
- [PyTorch：DistributedSampler](https://docs.pytorch.org/docs/stable/data.html#torch.utils.data.distributed.DistributedSampler)
- [PyTorch：DDP tutorial](https://docs.pytorch.org/tutorials/intermediate/ddp_tutorial.html)
