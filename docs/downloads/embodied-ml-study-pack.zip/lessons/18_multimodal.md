# 视觉编码器与多模态融合

区分视觉骨干、预训练目标与输出接口，再理解跨模态融合。

视觉编码器是把像素转换为特征向量或空间特征序列的网络；多模态融合则让来自图像、文字或状态的表示在同一预测中相互作用。视觉语言模型（VLM）据此联合使用图像与文字信息，但具体连接方式可以不同。本章先沿像素到视觉 Token 建立数据流，再解释投影、位置与融合，最后判断压缩保留的信息和训练梯度的范围。

## 学习目标

- 计算图像 Patch 数量，追踪单图与多图 token 的组织方式。
- 区分 CLIP/SigLIP、DINOv2、MAE 与 SAM 的训练目标、输出形式和适用任务。
- 根据具体检查点的约定区分全局向量、Patch、CLS 与 Register token，正确恢复空间布局。
- 说明维度投影、特征对齐和语言条件融合的区别。
- 检查冻结视觉编码器与可训练连接模块的梯度边界。

前置知识：[Embedding 与位置编码](https://wxb1870.github.io/embodied-ml-lab/learn/embeddings/) · [注意力：匹配、聚合与梯度](https://wxb1870.github.io/embodied-ml-lab/learn/attention/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [视觉预处理与坐标变换](https://wxb1870.github.io/embodied-ml-lab/learn/vision-preprocessing/)

## 像素布局与数值范围

视觉输入约定定义像素进入模型时的通道含义、轴布局、数值范围与尺寸。这些预处理是视觉编码器实际函数的一部分，不是外部无关步骤。本节先固定接口，完整几何规则可对照视觉预处理专章。





图像张量进入视觉编码器之前，已经经历解码、通道顺序、尺寸变换和数值标准化。uint8 的 0–255 与浮点 0–1、RGB 与 BGR、HWC 与 CHW 都可能具有相同元素数量，却对应不同输入。预训练模型的能力依赖其训练时的处理约定，不能只把图片变成一个 Tensor 就认为接口正确。先用固定图像核对最小值、最大值、各通道统计和空间方向，再考虑模型内部结构。





尺寸变化同时影响内容与 token 数。直接拉伸会改变长宽比例，裁剪可能删除任务信息，Letterbox 增加的边缘又需要相应有效位或处理规则。图像增强若改变标签坐标、可见性或相机对应关系，需要同步维护监督。几何变换与坐标处理见[视觉预处理](#/learn/vision-preprocessing)；视觉编码器则把处理后的像素映射成语言与动作模块可读取的表示。









## 局部像素到 Patch token

Patch Token 是把一个图像区域编码为特征向量后形成的序列位置。Patch 投影负责初始局部映射，后续视觉网络才进一步组合区域信息。先追踪一个小块怎样变成向量，再讨论整个网格的组织。





将 \(H\times W\) 图像按 \(P\times P\) 不重叠窗口划分，每个 patch 展平成 \(C P^2\) 维，再用共享 Linear 映射到 D 维。无额外 Padding 且尺寸可整除时，token 数为 \((H/P)(W/P)\)。Conv2d(C,D,kernel_size=P,stride=P) 可以实现同样的局部线性投影，但必须对齐像素展平顺序和权重布局；“卷积 patchify 与 Linear 等价”只在这些条件下成立。





Patch 投影本身还不是完整 ViT：它没有让远处 patch 交流，也不自动提供全局语义。随后通常要加入位置表示，并经过多个视觉块。P 变小提高空间采样密度，也增加 token 数；若图像边长同时扩大两倍，token 数约增至四倍，稠密视觉自注意力的矩阵项可增至十六倍。空间精细程度、计算预算和下游需求需要共同考虑，不能只追求更高分辨率。





$$
N=\frac{H}{P}\frac{W}{P},\qquad z_i=W\,\operatorname{vec}(\text{patch}_i)+b
$$



### 例：从 224×224 到 448×448

1. RGB 图像用 16×16 patch，224 分辨率对应 14×14=196 个 patch，每个窗口含 768 个标量。

2. 448 分辨率对应 28×28=784 个 patch，是原来的 4 倍。

3. 仅比较 \(N^2\) 项，\(\frac{784^2}{196^2}=16\)；真实延迟还受投影、FFN、内核与额外 token 影响。

改变图像尺寸既改变信息分辨率，也改变序列与计算成本。

## 位置、视角与来源身份

视觉位置编码标识一个 Token 来自图像的哪里，视角或来源编码标识它来自哪幅图或相机。它们提供模型可使用的身份线索，但不是相机几何标定本身。多视图融合需要同时保留这些来源区别。





视觉 token 的位置编码让模型区分它来自图像的哪个区域。多图或多相机输入还可能加入来源身份，区分第几张图或哪个视角。这些编码提供可学习的离散或连续线索，但不会自动等同于相机内参、外参和真实空间几何。两个 token 即便拥有相同二维 patch 序号，也可能来自完全不同的图像与视角。阅读特征时必须保留原来的排列约定。





常见做法把 [B,V,C,H,W] 临时合并为 [B×V,C,H,W]，共享视觉编码器后恢复 V 维。这个操作只应合并样本与视角，不能混进时间或通道；恢复顺序也必须一致。不同图像若产生不同数量的 token，拼接和池化就隐含不同权重。Padding、缺失图像与真实黑色图像不是同一种情况，需要显式有效位，而不是依赖模型从像素值推断数据是否缺失。









### 来源编码不会替代几何或同步信息

相机/图像 ID 只是身份线索，不能自动提供标定、时间对齐或遮挡关系。

保留每段 token 的来源、位置、有效位与时间元数据，用交换视角和缺失输入测试检查接口。

## Projector 与跨模态融合

Projector 是把一类特征映射到另一接口宽度的模块，跨模态融合则进一步建立不同模态之间的计算依赖。宽度对齐只使连接可计算，不会自动让视觉特征受语言影响。下面区分映射与交互这两项工作。





视觉骨干可能输出 Dv 维，语言骨干使用 Dl 维，Projector 用 Linear 或 MLP 把向量映射到所需宽度。它首先解决可连接的表示接口，训练后可学习任务相关映射，但一个线性投影不会自行建立语言条件：若它只读取视觉特征，输出仍然只依赖图像。跨模态依赖可能发生在 token 拼接后的 Self-Attention、Cross-Attention 或其他条件调制模块中。



### 例：图文条件分类的形状追踪

1. 视觉特征为 [B,16,12]，Projector 将每个 token 映射成 [B,16,24]。

2. 文本汇聚成一个 Query [B,1,24]，Cross-Attention 读取视觉后仍为 [B,1,24]。

3. 二类分类层输出 [B,2] logits，交叉熵标签为 [B] 的整数类别；输出不是空间坐标。

形状与目标明确后，才能逐段检查视觉、文本和分类损失之间的依赖。

在“文本 Query 读取视觉 Key/Value”的结构中，输出长度跟随文本 Query；若交换 Q 与 K/V，输出就变成按视觉位置排列，是不同接口。早期融合、后期融合和多次交叉读取各有成本与信息瓶颈。想知道一个分类或生成输出能否随文本改变，应沿计算图反向追踪语言路径，而不是只看模型名字里是否含 VLM，或最后一层是不是足够大。





一个可手算的融合例子是两个视觉 Key/Value 均为 \([1,0]\)、\([0,1]\)，并暂用未缩放的点积分数。文本 Query 为 \([1,0]\) 时，权重为 \([e/(e+1),1/(e+1)]\)；换成 \([0,1]\) 后两项交换，读出也随之改变。这里改变的是匹配路径，而视觉内容保持不变。真实模型使用投影和相应缩放，但仍可按同样方式固定图像、替换文本，检验条件从何处进入输出。





[原始 LLaVA（2023）](https://arxiv.org/abs/2304.08485v2)给出了逐 token 投影的具体实例：CLIP ViT-L/14 提取空间特征，线性层将其宽度映射到语言模型的嵌入维度，再与文本一起进入语言模型。[LLaVA-1.5](https://arxiv.org/abs/2310.03744v2) 使用两层 MLP 连接器，并采用 CLIP ViT-L/14 的 336 像素版本。这里的 MLP 主要变换每个视觉 token 的通道；真正的跨模态交互还依赖后续语言模型的注意力和训练。不能把 1.5 的连接器当作最初版本，也不能把它当成所有 VLM 的共同结构。





[BLIP-2（2023）](https://arxiv.org/abs/2301.12597v3)展示了另一种选择：Q-Former 用可学习查询通过 Cross-Attention 读取冻结图像特征，先学习图文相关表示，再把查询输出投影为冻结语言模型的视觉前缀。论文配置使用 32 个查询；它们是模型参数，不是 32 个预先指定的图像区域。因而逐 token 投影通常保留原 token 数，Q-Former 则可将变长视觉输入压缩为固定数量的输出。它引入的是可学习的信息选择与瓶颈；是否适合细粒度空间任务仍须验证。









## 预训练目标、经典工作与表示能力

视觉骨干规定特征怎样计算，预训练目标规定参数从什么监督中学习。卷积或 ViT 属于结构选择，图文匹配、重建等属于训练问题。先分清这两个层次，才能解释一个预训练表示适合什么任务。





先分清两个层次：ResNet、ConvNeXt、ViT、Swin 描述特征如何计算，CLIP、SigLIP、DINOv2、MAE 则主要描述怎样学习这些特征及相应的预训练权重。ResNet/ConvNeXt 通过卷积构成分层空间特征，标准 ViT 保持 Patch 网格并用全局注意力交互，Swin 用移动窗口和分层合并构造多尺度表示。架构影响空间分辨率与计算成本，不能单凭名称推断语义能力。卷积结构的详细比较见 [CNN 网络设计](#/learn/cnn-receptive-field?section=architecture-design)。





图文对比预训练通常鼓励匹配图像与文本的全局表示接近；图像描述生成训练鼓励根据视觉条件预测语言；掩码重建、检测或其他目标又强调不同信息。这些训练可产生可迁移表示，但不能推断每个中间 token 都编码了下游需要的全部状态。全局语义匹配好，不代表细粒度计数、空间关系、动作时序或物理可行性已经被充分解决。





提取“视觉特征”时要记录来自哪一层、是否已与语言交互、是否经过归一化与池化。纯视觉 backbone token 与已经融合文本的 VLM hidden state 可能形状相同，却包含不同条件。冻结某个骨干后，下游训练只改变可训练部分；它能选择和变换已有表征，但不能据此宣称骨干学到了新知识。下游能力应由独立验证、条件干预和闭环任务证据支持。





下面按训练信号比较少数代表工作。需要图文检索或用文本定义类别时，可以从图文对齐的表示入手；需要对每个空间位置进行预测时，应保留 Patch 或特征图，再训练、评估相应读出。用于机器人策略时，还应固定数据、动作头和训练预算比较闭环表现；图文匹配或图像分类的优势不能直接推出几何精度或任务成功率的优势。CLIP 与 SigLIP 的损失及梯度差异在 [图文对比学习](#/learn/contrastive-pretraining) 中推导。







### 代表预训练工作：先看监督，再看输出

| 工作与版本 | 核心训练机制 | 可使用的表示与典型任务 |

|---|---|---|

| [CLIP（2021）](https://arxiv.org/abs/2103.00020) / [SigLIP（2023）](https://arxiv.org/abs/2303.15343v4) | 图文双编码器；CLIP 在候选配对间做 Softmax 对比，SigLIP 对每个图文对做 Sigmoid 二分类。它们学习跨模态匹配，不直接训练动作。 | 全局图文向量用于检索与文本提示分类；ViT 版本的 Patch 特征可供 VLM 连接器读取。全局匹配所用的投影向量不能直接替代整组空间 token。 |

| [DINOv2（2023）](https://arxiv.org/abs/2304.07193v2) | 不依赖配对文本；学生对齐教师的图像级预测，并对齐被遮挡位置的教师 Patch 预测。基础自监督训练中，教师由学生参数的指数移动平均更新。 | CLS 表示可用于图像分类或检索；Patch 表示可配合读出用于分割、深度估计等密集任务。基础特征本身不是深度值或分割结果。 |

| [MAE（2021，CVPR 2022）](https://arxiv.org/abs/2111.06377v3) | 编码器只处理可见 Patch，轻量解码器结合 Mask token 重建被遮挡像素，以遮挡位置的重建误差学习表示。 | 迁移时使用编码器并增加任务头；完整图像编码与预训练时的稀疏输入须区分。解码器输出的像素和编码器的潜在特征具有不同含义。 |

| [SAM，第一代（2023）](https://arxiv.org/abs/2304.02643v1) | 面向提示式分割：图像编码器、提示编码器与 Mask 解码器共同服务于掩码预测。论文使用 MAE 预训练的 ViT 初始化。 | 图像编码器给出空间特征；结合点、框或掩码提示可生成分割掩码，用于交互分割与标注。它不是直接完成开放词汇图文检索的双编码器。 |



## 全局向量、Patch 与特殊 token 的读取约定

全局向量汇总整幅图，Patch 序列保留多个局部位置，特殊 Token 则是按模型协议设置的专用位置。这些输出接口具有不同信息范围。选择时应先定义下游需要读取什么，而非只比较特征宽度。





设 Batch 大小为 \(B\)，视觉通道宽度为 \(D_v\)，Patch 网格为 \(H_g\times W_g\)，则空间 token 是 \([B,H_gW_g,D_v]\)，特征图是 \([B,D_v,H_g,W_g]\)。在已知网格顺序时，两者只是重排；全局向量 \([B,D_v]\) 则经过聚合。CLS 是随网络更新的特殊 token，不等同于 Patch 均值；经过全局注意力的一个 Patch 也可能包含远处信息，不能把它理解成只描述原始小窗口。





记完整序列为 \(Z\)，Register 数为 \(R\)。DINOv2 的官方实现区分 `x_norm_clstoken`、`x_norm_regtokens` 与 `x_norm_patchtokens`。其带 Register 的版本在 CLS 之后加入额外 token，提供不占据图像网格位置的计算空间；这些 token 不应当被当作像素位置重排。以 \(224\times224\) 输入、Patch 大小 14 为例，空间 token 数为 \(16\times16=256\)；带 4 个 Register 的版本总数为 \(1+4+256=261\)。必须依据具体模型配置切片，不能普遍写成“去掉第一个 token 后全部 reshape”。





还要区分归一化与投影：DINOv2 的上述 `x_norm_*` 表示经过末端 LayerNorm，并不表示向量的 \(L_2\) 范数已为 1。CLIP 的匹配路径则使用投影到共同空间并做 \(L_2\) 归一化的图文向量。框架中的 `pooler_output`、`last_hidden_state`、`image_embeds` 等名称没有跨模型统一的数学含义；核对所用实现的池化方式、选取层、投影矩阵与归一化位置，再决定是否能接入现有头。





实践中应先用一张图确认预处理后尺寸、空间 token 数、特殊 token 数和输出通道，再检查位置顺序与梯度路径。下面代码页的 [token 布局实验](#/learn/multimodal?tab=code&anchor=demo-visual-token-contract) 使用合成张量验证这些约定，不下载预训练权重。它能发现把 Register 混入网格或误用网格尺寸的问题；它不能证明某组权重具备任务所需的视觉能力。





$$
N_{\mathrm{all}}=1+R+H_gW_g,\qquad Z_{\mathrm{patch}}=Z[:,\,1+R:\,,\,:]
$$



### 例：同样叫“视觉特征”，接口仍不同

1. DINOv2 的带 Register 版本需要分别读取 CLS、4 个 Register 和 256 个 Patch；其中只有 Patch 对应上述 16×16 网格。

2. 第一代 SAM 在论文的 1024×1024 输入配置下，经编码器和通道变换输出 256 通道、64×64 的图像特征。该特征仍需与提示结合并通过 Mask 解码器才成为分割结果。

记录实际输入尺寸、所取层和输出接口，而不是只记录“用了 ViT”。上式仅描述本节指定的 CLS→Register→Patch 排列；其他模型须按其实现处理。

## 压缩后的信息能否由后层恢复

表示压缩是将较多输入自由度映射为较少或更受约束的特征。若两种任务所需区别已经被压成同一表示，只读取该表示的后层无法重新区分。下面用这个条件解释池化与特征选择的边界。





设视觉压缩器为 \(z=g(\mathrm{image})\)。若两张需要不同输出的图像被映射成同一个 z，则任何只读取 z 的确定性头 h 都满足 \(h(g(\mathrm{image}_1))=h(g(\mathrm{image}_2))\)。无论头多深，这个冲突都无法修复；它是表示的不可区分性，不是学习率不足。随机输出头也只能给两者相同的条件分布。判断瓶颈需要检查任务要求区分的输入是否仍能在表示中区分。





直接平均原始 token 对重排不敏感；简单加位置后立即平均也有 \(\operatorname{mean}_i(x_i+p_i)=\operatorname{mean}_i(x_i)+\operatorname{mean}_i(p_i)\)，并未保留内容与位置的配对。若骨干先通过非线性或注意力将空间关系写入通道，池化则可能保留任务需要的关系。需要检查信息在压缩之前做过什么计算，而不是把所有全局向量都认定为有用或无用。





线性 projector 的输出宽度增加也不代表新增了视觉信息。对 \(z\in\mathbb R^d\)，\(Wz\in\mathbb R^D\) 的可变维数至多为 \(\operatorname{rank}(W)\le d\)；\(D>d\) 可以提供更适合后续网络的坐标系，却不能分开已经相同的两个 z。可学习 Query 或 resampler 改变了压缩函数，可能保留更有用的信息，但应在相同数据与目标下检验。





带 Mask 的均值只归约有效 token，并按有效数目归一化。每 token 等权也不等于每张图等权，高分辨率图可能因此获得更大权重。全无效输入应拒绝、跳过或使用约定的缺失表示；不能让除零后的数值问题被后续网络掩盖。









### 池化丢掉的信息无法靠后层保证恢复

不同输入若被映射成同一个特征，后续确定性计算必然给出相同输出。需区分表示瓶颈与优化失败。

构造仅空间顺序不同的 token 集，比较简单均值和保留位置的汇聚输出，并使用有效位测试 Padding 不变性。

## 冻结骨干与梯度边界

冻结视觉骨干是停止更新其参数，梯度边界则决定损失还可以传回哪些上游模块。它们不是同一操作。下面沿编码器前后的可训练模块，判断哪些求导路径需要保留。





冻结参数表示不对这些参数求更新，并不意味着任何穿过该模块的计算图都能关闭。若视觉骨干之前还有可训练输入适配器，需要梯度经过骨干传回适配器，此时整体 no_grad 会切断所需路径。若输入只是固定像素、骨干权重冻结、可训练 Projector 在其后，使用 no_grad 提取原始特征通常可以减少保存的激活；两种情况的计算依赖不同。





同时检查模块行为：外层 train() 可能改变冻结骨干里的 Dropout 或 BN 状态；“参数不更新”与“提取函数确定”是不同要求。预先缓存特征只有在视觉输入、增强、骨干状态和预处理固定时才对应同一任务。若训练使用动态裁剪、不断变化的视觉编码或依赖文本的特征，缓存旧表示会改变训练数据分布。先明确允许变化的部分，再选择冻结、缓存与梯度策略。









### 先画出可训练模块的位置再决定 no_grad

位于冻结模块前面的可训练适配器仍可能需要穿过它的输入梯度；后面的模块只需要固定特征。

逐模块列出 requires_grad、实际 grad、train/eval 与 Buffer 变化，确认所有计划学习的部分真的收到梯度。

## 图文分类中的接口与梯度

前面建立了视觉 token、语言条件与融合模块的职责，现在需要用一个完整前向和反向验证它们确实连接。合成分类例子适合检查接口与梯度，真实能力则需要另外的数据与任务证据。两类验证回答不同问题，应保留各自的结论范围。





图文分类示例包含随机初始化的 patch 编码器、文本条件、Cross-Attention 和二类分类损失，用来对照 token 组织与梯度边界。它的合成标签只支持实现验证，不能评估预训练视觉语言能力。检查重点是输出类别维度、标签 dtype、冻结参数无梯度，以及 Projector、文本嵌入和融合模块是否收到有限梯度。





接入真实模型后，至少做三种对照：固定图像替换相关文本、固定文本替换图像、保持有效输入但改变 Padding 或来源顺序。前两种检查条件依赖，后一种检查接口约定；输出有所变化本身不证明变化正确。再用明确划分的数据检验类别或生成指标，记录失败类型。如果语言无效，沿融合位置排查；如果细粒度信息不足，先检查分辨率、token 提取层与压缩方式，再考虑更大的下游模块。





多模态系统先为每种输入建立表示，再以明确的信息路径组合这些表示。预处理、位置身份、投影、融合与读出共同决定输出可利用什么；梯度对照只能检验路径，语义能力仍需对应任务的证据。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 图像 | [B,C,H,W] | 演示为 [2,3,16,16]，每个样本一张合成图像。 |
| 原始 Patch 特征 | [B,N,Dv] | P=4 时，每张图 N=16，视觉宽度 Dv=12。 |
| 视觉 Projector 输出 | [B,N,D] | 演示为 [2,16,24]，加入相同宽度的空间位置表示。 |
| 文本查询 / 分类 logits | [B,1,D] / [B,2] | 文本查询读取视觉信息；分类器输出两个未归一化类别分数。 |

## 完整代码与精读

```python
# [1] 随机初始化的接口教学，不代表已训练好的 VLM
import torch
from torch import nn
from torch.nn import functional as F
torch.manual_seed(16)
B, D = 2, 24
images = torch.randn(B, 3, 16, 16)
vision = nn.Conv2d(3, 12, kernel_size=4, stride=4)
vision.requires_grad_(False)
vision.eval()
projector = nn.Linear(12, D)
patch_position = nn.Parameter(torch.randn(1, 16, D) * 0.02)
text_embedding = nn.Embedding(32, D)
fusion = nn.MultiheadAttention(D, 4, dropout=0.0, batch_first=True)
classifier = nn.Linear(D, 2)

# [2] 输入前没有可训练模块；只关闭固定视觉编码器的图记录
def classify(images, token_ids):
    with torch.no_grad():
        raw = vision(images).flatten(2).transpose(1, 2)
    visual = projector(raw) + patch_position
    # 固定长度、无 padding 的教学文本；真实变长输入需要有效位
    query = text_embedding(token_ids).mean(dim=1, keepdim=True)
    pooled, _ = fusion(query, visual, visual, need_weights=False)
    return classifier(pooled[:, 0]), visual, query

# [3] 两类合成标签使用整数类别，CrossEntropy 接收原始 logits
token_ids = torch.tensor([[2, 4, 7], [2, 9, 7]], dtype=torch.long)
labels = torch.tensor([0, 1], dtype=torch.long)
logits, visual, query = classify(images, token_ids)
loss = F.cross_entropy(logits, labels)
loss.backward()
assert logits.shape == (B, 2)
assert all(p.grad is None for p in vision.parameters())
tracked = [projector.weight, patch_position, text_embedding.weight,
           fusion.in_proj_weight, classifier.weight]
assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in tracked)
assert all(p.grad.norm() > 0 for p in tracked)

# [4] 固定图像，只替换一个样本的文本，检查条件路径与样本隔离
changed_ids = token_ids.clone()
changed_ids[0, 1] = 11
with torch.no_grad():
    changed, _, _ = classify(images, changed_ids)
    torch.testing.assert_close(changed[1], logits.detach()[1])
    assert not torch.allclose(changed[0], logits.detach()[0])
print("视觉 / 查询 / 分类 logits:", visual.shape, query.shape, logits.shape)
print("冻结边界、可训练梯度和文本条件路径检查通过")

```

- 第 1–16 行：16×16 图像经 4×4 非重叠卷积得到 16 个 Patch。视觉编码器冻结；Projector、位置、文本、融合与二类分类器可训练。
- 第 17–26 行：no_grad 只包围固定视觉前向。Projector 位于作用域外，文本 Query 读取视觉 K/V；文本均值仅适用于本例等长且无 padding 的输入。
- 第 27–39 行：CrossEntropy 输入 [B,2] logits 与 [B] 整数标签；检查视觉参数无梯度，以及五处可训练路径梯度有限且非零。
- 第 40–48 行：固定图像只改变第一个样本的文本，验证其输出变化且第二个样本不变。这说明结构连通与样本隔离，不代表模型已经学会图文语义。

预期观察：视觉 token 为 [2,16,24]，查询为 [2,1,24]，二类 logits 为 [2,2]。冻结视觉无梯度，可训练连接部分有有限非零梯度；只改变一条文本仅影响对应样本。

### 从特殊 token 中正确抽取空间特征

用已编码的合成张量检查 CLS、Register 与行优先 Patch 的切片、非方形网格重排及梯度。无权重下载；该实验验证读取约定，不模拟 DINOv2 的训练或评价其表示质量。

[完整可运行代码](../demos/multimodal/visual-token-contract.py)

- 第 1–19 行：函数明确限定 CLS→Register→Patch 的输入排列。先验证总数 1+R+H_gW_g，再取空间 token；转置后重排为特征图，不重新学习或聚合任何信息。这里不推断“所有 ViT 都有 CLS”。
- 第 21–32 行：分别检查 0 和 4 个 Register，故意使用 2×3 非方形网格。除了总形状，还用行列 (1,2) 对应 Patch 索引 5 验证实际位置，防止形状正确而轴或顺序错误。
- 第 33–37 行：对空间均值求和，直接验证当前读取操作的 Jacobian：每个 Patch 分量得到 1/6 梯度，当前张量中的 CLS/Register 位置为零。这不表示完整 Transformer 内的特殊 token 不会收到梯度；上游注意力可能已使 Patch 依赖它们。
- 第 39–44 行：将实际带 4 个 Register 的张量误声明为无 Register，或给错网格大小，必须报错而不是静默截断 token。
- 第 46–52 行：末端 LayerNorm 的中心化、方差缩放和 L2 单位长度缩放是不同运算。实验固定种子并使用双精度，检查均值及范数；接口名称中的 norm 不能代替数学定义。

预期观察：两种布局分别输出 tokens=(2,7,8) 与 (2,11,8)，都恢复为 grid=(2,8,2,3)。空间顺序、读取层梯度及错误元数据的断言通过；LayerNorm 输出和单位 L2 范数不混同。

## 浏览器 Python 练习

实现 pack_multiview(text_tokens, cameras)。先放文本 token，再按相机顺序拼接 token；同时返回每个相机的半开区间 (start,end)。不要修改输入列表。

```python
def pack_multiview(text_tokens, cameras):
    # TODO: 返回 (packed_tokens, camera_spans)
    raise NotImplementedError("请完成多视角 token 打包")

```

### 提示

- 半开区间 end 不包含最后一个元素后的那个位置，因此可以直接用于 Python 切片。
- 每拼接一个相机前后，分别记录列表长度。

### 参考实现与解释

```python
def pack_multiview(text_tokens, cameras):
    packed = list(text_tokens)
    spans = []
    for camera in cameras:
        start = len(packed)
        packed.extend(camera)
        spans.append((start, len(packed)))
    return packed, spans

```

索引范围是调试多模态可见性和可视化注意力的基础；丢失来源信息后，难以确认读出内容的来源。

### 断言测试

```python
text_tokens = ["抓", "红杯"]
cameras = [["front0", "front1"], ["wrist0"], []]
packed, spans = pack_multiview(text_tokens, cameras)
assert packed == ["抓", "红杯", "front0", "front1", "wrist0"]
assert spans == [(2, 4), (4, 5), (5, 5)]
assert text_tokens == ["抓", "红杯"] and cameras[0] == ["front0", "front1"]
assert packed[spans[1][0]:spans[1][1]] == ["wrist0"]
assert pack_multiview([], []) == ([], [])
print("通过：顺序、半开区间、空视角与输入不变")

```

## 本地 PyTorch 练习

实现 masked_pool(tokens, valid)。tokens 为浮点张量 [B,N,D]，valid 为布尔张量 [B,N]。按有效 token 求平均；无效位置可含 NaN。某样本没有有效 token，或有效 token 非有限时，抛出 ValueError。验证每个有效 token 的梯度为 \(\frac{1}{n_{\rm valid}}\)。

```python
import torch

def masked_pool(tokens, valid):
    # TODO: 在求和前替换无效位置，按每个样本的有效数量归一化
    raise NotImplementedError

```

### 提示

- 用 torch.where 在求和前将无效位置替换为零；乘零无法消除 NaN。
- 分母为每个样本有效 token 数 [B,1]，与通道数 D 无关。
- 对于输出各分量之和，有效 token 的每个分量应得到 \(\frac{1}{n_{\rm valid}}\) 的梯度。

### 参考实现与解释

```python
import torch

def masked_pool(tokens, valid):
    if tokens.ndim != 3 or valid.shape != tokens.shape[:2] or valid.dtype != torch.bool:
        raise ValueError('expected [B,N,D] and boolean [B,N]')
    counts = valid.sum(dim=1, keepdim=True)
    if bool((counts == 0).any()):
        raise ValueError('every sample needs a valid token')
    if not bool(torch.isfinite(tokens[valid]).all()):
        raise ValueError('nonfinite valid token')
    safe = torch.where(valid.unsqueeze(-1), tokens, torch.zeros_like(tokens))
    return safe.sum(dim=1) / counts.to(tokens.dtype)

```

求和只接收安全的零填充张量，分母按样本计算。两个样本的有效长度分别为 2 和 1，验证梯度分别为 1/2 和 1，而非按整个 Batch 统一平均。无效输入的 NaN 被排除，有效输入的 NaN 被明确拒绝。这只是池化层的接口保证；若前面的跨 token 网络已经读取了无效值，还需要在上游处理可见性与填充。

### 断言测试

```python
nan = float('nan')
x = torch.tensor([[[1.,2.],[3.,4.],[nan,nan]],
                  [[5.,6.],[nan,nan],[nan,nan]]], requires_grad=True)
valid = torch.tensor([[True,True,False],[True,False,False]])
y = masked_pool(x, valid)
torch.testing.assert_close(y, torch.tensor([[2.,3.],[5.,6.]]))
y.sum().backward()
torch.testing.assert_close(x.grad, torch.tensor([[[.5,.5],[.5,.5],[0.,0.]],
                                                [[1.,1.],[0.,0.],[0.,0.]]]))
for values, mask in [(x, torch.zeros_like(valid)),
                     (torch.full_like(x, nan), valid), (x, valid.float())]:
    try:
        masked_pool(values, mask)
        raise AssertionError('invalid pooling input must be rejected')
    except ValueError:
        pass
print('passed: per-example denominator, analytic gradient and ignored nonfinite padding')

```

## 练习：推导与分析

### 为什么把纯视觉 token 平均池化后，接一个从未接收文本的分类器，不能期待它按不同文本条件给出不同类别判断？

如果图像、参数和其他输入完全相同，而语言没有进入任何上游特征或读出计算，读出头接收的输入就相同，确定性输出也应相同。扩大头或训练更久不会补足缺失的条件通路。

如果取的是已经与语言交互后的 VLM token，则其表示可能包含任务信息，但仍需要指令替换实验验证。要先确认特征提取位置，再判断池化和小头是否保留了可用的任务条件。

代码定位：从分类 loss 反向追踪文本输入的计算依赖，固定图像只改变文本做对照。

- 指出计算图中必须存在语言条件路径。
- 区分纯视觉特征与已融合语言的 VLM 特征。

### 多相机视觉 token 直接求平均隐含了什么权重？Padding 与不同相机 token 数怎样影响结果？

直接对全部 token 平均，相当于每个 token 权重相同，因此 token 更多的相机在总向量中占更大比例。它不是自动按相机等权，也不能自动恢复各相机的几何关系。

Padding 应通过显式有效位排除，并用有效 token 数作分母。若希望相机等权，可以先按每个相机的有效 token 池化再融合，但缺失视角与不同质量视角仍需定义策略并评估。

代码定位：分别统计每个视角 N、有效位和最终池化分母，确认设计的权重口径。

- 说明 token 等权不等于相机等权。
- 明确 Padding 同时从分子和分母排除。

### 视觉特征从 256 维投影到 2048 维后，为什么仍不能保证恢复压缩前的空间细节？怎样区分表示瓶颈与优化失败？

线性投影 W 的秩最多为 256，增加输出坐标数不能新增独立输入信息。更一般地，两张图若编码后 z 完全相同，任意只读取 z 的确定性网络都给相同输出。

可先构造只改变目标所需空间关系的输入对，比较压缩前 token 与压缩后表示。如果在目标不同的输入上压缩后完全相同，已能证明该接口无法完成区分；若表示不同，则尚不能断言可容易学出答案，仍可能有优化、标签或数据问题。

代码定位：对成对输入分别记录 token、池化向量和 projector 输出；避免只比较 shape。

- 用相同表示必有相同输出的论证解释不可恢复。
- 不把宽度增加等同于新增信息。

### 一个带 4 个 Register 的 DINOv2 编码器接收 224×224 图像，Patch 大小为 14，输出 [B,261,D]。请写出 CLS、Register、Patch 的切片及恢复空间特征图的过程。为什么不能仅根据 N 开平方推断网格？

在本章核验的排列下，CLS 为 Z[:,0]，Register 为 Z[:,1:5]，Patch 为 Z[:,5:]，其数量是 16×16=256。先转置为 [B,D,256]，再按已知行优先顺序恢复为 [B,D,16,16]。应断言总数与 1+4+16×16 一致。

完整 token 数含非空间位置，开平方没有网格意义；即使只取 Patch，非方形输入也可能产生非方形网格。同一个数量还可能对应不同长宽组合，必须保留编码器实际使用的网格元数据。

代码定位：独立实现代码页中的 split_visual_tokens，再用 2×3 网格、0/4 个 Register 和错误元数据验证；额外检查一个明确的行列位置。

- 明确三个切片的边界并核对 261=1+4+256。
- 维持行列对应关系，不依赖 sqrt(N) 或静默丢弃多余 token。

### 要将 CLIP、DINOv2 或 MAE 编码器接到同一个策略头，只要把通道投影成相同宽度就能公平比较吗？

相同宽度只约束张量接口。还要固定或记录输入分辨率、预处理、所取层、特殊 token、空间 token 数、池化与归一化，以及是否微调编码器。全局匹配向量与空间 token 即使投影到同一宽度，仍可能丢失不同的信息。

在一致的数据切分、动作表示、策略头和训练预算下做受控比较，并报告任务相关指标。文本检索、像素重建或图像分类的表现不能替代闭环任务成功率；需要根据模型预训练目标提出假设，再用实验检验。

代码定位：保存各候选模型的输出约定和预处理配置，对相同输入记录实际 shape；设计仅替换视觉表示的对照实验。

- 区分骨干结构、预训练目标、输出接口和任务头。
- 不将语义匹配能力直接等同于空间精度或策略表现。

## 练习：辨析与纠错

### 把任何 [B,N,D] 都当成同一种 VLM 表征

确认层位置、是否融合文本、位置与归一化状态。形状相同不能证明信息或条件相同。

### 只加视觉 Projector 就期待输出跟随文本

若语言未进入计算图，确定性输出不会因未使用的指令改变。沿损失反向追踪条件路径，并做文本替换对照。

### 平均所有 token 但没有处理来源数量与 Padding

先定义 token 等权还是图像等权，再同时修正有效分子与分母；全无效情况应显式处理。

### 冻结参数后无条件包住整个 no_grad

若前面有可训练模块，需要梯度穿过冻结网络。分别检查参数梯度和输入梯度，不能用冻结状态替代依赖分析。

### 用合成例子的梯度通过宣称模型具备视觉理解

教学例子只验证接口和计算。真实迁移需预训练权重、匹配预处理、独立数据与任务评价。

## 原始资料

- [An Image is Worth 16×16 Words](https://arxiv.org/abs/2010.11929)
- [原始 LLaVA：Visual Instruction Tuning（v2）](https://arxiv.org/abs/2304.08485v2)
- [PyTorch：Conv2d](https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv2d.html)
- [PyTorch：MultiheadAttention 的 Q/K/V 与 Mask](https://docs.pytorch.org/docs/stable/generated/torch.nn.MultiheadAttention.html)
- [PyTorch：CrossEntropyLoss 的类别与维度约定](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html)
- [CLIP（2021）：图文双编码器与共享表示空间](https://arxiv.org/abs/2103.00020)
- [SigLIP（2023，v4）：逐对 Sigmoid 图文训练](https://arxiv.org/abs/2303.15343v4)
- [DINOv2（2023，v2）：图像级与 Patch 级自监督](https://arxiv.org/abs/2304.07193v2)
- [DINOv2 官方模型卡：Patch、CLS 与 Register 输出](https://github.com/facebookresearch/dinov2/blob/main/MODEL_CARD.md)
- [DINOv2 官方实现：forward_features 的输出约定](https://github.com/facebookresearch/dinov2/blob/main/dinov2/models/vision_transformer.py)
- [Vision Transformers Need Registers（v2）](https://arxiv.org/abs/2309.16588v2)
- [MAE（v3，CVPR 2022）：编码器与重建解码器](https://arxiv.org/abs/2111.06377v3)
- [SAM 第一代（2023，v1）：提示式分割与空间特征](https://arxiv.org/abs/2304.02643v1)
- [Swin Transformer（2021，v2）：移动窗口与分层表示](https://arxiv.org/abs/2103.14030v2)
- [LLaVA-1.5：Improved Baselines with Visual Instruction Tuning（v2）](https://arxiv.org/abs/2310.03744v2)
- [BLIP-2（2023，v3）：Q-Former 与两阶段预训练](https://arxiv.org/abs/2301.12597v3)
