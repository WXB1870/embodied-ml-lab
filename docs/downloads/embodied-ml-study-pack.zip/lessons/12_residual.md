# 残差连接与深层优化

恒等路径、归一化位置、残差尺度与初始化。

残差连接是一种网络连接方式：将输入沿直接路径传到输出端，再与可训练分支的结果相加，形成“原表示＋学习到的更新”。它让深层网络可以保留已有表示、逐层学习修正，并为梯度提供不经过分支变换的路径，从而改善某些深层网络的优化困难。它不保证梯度永不消失，也不要求每层更新都很小。本章先看这两条路径怎样组成一个块，再推导它们的梯度，最后分析多层堆叠、归一化与尺度控制。

## 学习目标

- 推导残差连接对输入的 Jacobian。
- 实现并区分 Pre-Norm 和 Post-Norm。
- 用零分支检查模块是否保留预期的恒等路径。

前置知识：[归一化：统计轴、梯度与不变性](https://wxb1870.github.io/embodied-ml-lab/learn/normalization/) · [MLP：表达、梯度与优化](https://wxb1870.github.io/embodied-ml-lab/learn/mlp/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/)

## 增量参数化与残差流

一个残差块由两条路径组成：直接路径传递输入，变换分支计算更新，两路在输出处逐元素相加。这里的“残差”指需要学到的修正量，不是必须额外标注的训练标签。这样组织网络，是为了让“保留输入”和“修改输入”都容易表达；梯度上的作用随后再推导。

![《动手学深度学习》的普通块与残差块对照：左侧直接学习映射，右侧学习修正量并通过旁路与输入相加。](../assets/figures/residual-d2l-classic.svg)

先比较左右两图：左侧直接学习 f(x)，右侧学习 g(x)=f(x)−x，再由旁路把 x 加回来。本文把图中的 g 记作 F，y=x+F(x) 表示加法核心；图顶端的激活另计。原图：[《动手学深度学习》图 8.6.2](https://d2l.ai/chapter_convolutional-modern/resnet.html#residual-blocks)，按 [CC BY-SA 4.0](/assets/figures/d2l-classic-LICENSE.txt) 原样复用。



残差块写作 \(y=x+F(x;\theta)\)。其中，可训练分支 F 表示对已有表示的更新，并不需要预先给出每一层的正确输出。若当前层没有必要改变输入，只要 F 接近零就能接近恒等映射；普通串联层需要整套参数共同学出恒等关系。这改变了优化问题的参数化，而不是保证每一层都会提升性能，也不意味着 F 的数值一定很小。



### 例：先看一次相加，再看恒等旁路

1. 输入表示为 (1,2)，分支输出为 (−0.1,0.3)，两路相加得到 (0.9,2.3)。分支学习的是这次修正，整个块输出的仍是更新后的表示。

2. 若分支输出为 (0,0)，整个块就原样返回 (1,2)。直接路径是恒等映射，意思是它在此处不改变输入；这不要求整个网络都不学习。

3. 下一层读取更新后的 (0.9,2.3)，再计算自己的修正。多个这样的块就形成沿深度反复更新的残差流。

先把残差连接理解成“直接传递＋分支修正”，再用公式分析它怎样改变前向函数和反向梯度。

以下先采用列向量约定：第 \(\ell\) 层表示 \(x_\ell\in\mathbb R^D\)，分支 \(F_\ell:\mathbb R^D\to\mathbb R^D\)，参数 \(\theta_\ell\in\mathbb R^p\)。所有层暂时保持同一宽度 D，且加法之后没有额外激活或归一化；若还有这些操作，必须把它们的 Jacobian 继续乘入。Batch 或 token 情形可以逐位置理解，涉及跨位置运算时则把全部相关元素展平成同一个向量。





残差流 x 可以理解为沿深度传递的当前表示，每个模块读它并写回更新。对于 Transformer，Attention 产生跨位置更新，FFN 产生逐位置非线性更新，二者都通过加法保留上一阶段的表示。加法要求两路的元素语义对齐，不能仅检查元素个数。若把 token 顺序打乱后再加回原输入，即使 shape 完全相同，也已经把不同位置的表示混在一起。





$$
y=x+F(x;\theta)
$$





### 残差两路的元素语义必须一致

残差是逐元素更新同一组表示，要求 Batch、位置和通道语义对齐。

给每个位置放不同哨兵值，将分支临时置零，确认输出逐元素还原输入。

## 从微分到输入梯度与参数梯度

输入梯度是损失对残差块输入的变化率，参数梯度是损失对变换分支参数的变化率。输入同时沿直接路径和分支到达输出，因此前者需要合并两条路径；后者则沿参数所在的分支求导。下面将这个区分写成微分。





把参数固定，只改变输入一个小量 \(dx_\ell\)。对 \(x_{\ell+1}=x_\ell+F_\ell(x_\ell;\theta_\ell)\) 作一阶展开，直接路径贡献 \(dx_\ell\)，分支贡献 \(J_\ell\,dx_\ell\)，其中 \(J_\ell=\frac{\partial F_\ell}{\partial x_\ell}\in\mathbb R^{D\times D}\)，每一项 \((J_\ell)_{ij}\) 表示第 j 个输入坐标对第 i 个分支输出的局部影响。二者相加才得到本块的输入 Jacobian \(A_\ell=I+J_\ell\)。





设标量损失为 \(\mathcal L\)，\(g_{\ell+1}=\nabla_{x_{\ell+1}}\mathcal L\in\mathbb R^D\) 是上游列梯度。微分定义给出 \(d\mathcal L=g_{\ell+1}^\top dx_{\ell+1}=g_{\ell+1}^\top A_\ell\,dx_\ell\)。把 \(dx_\ell\) 前的系数改写成列梯度，便得到 \(g_\ell=A_\ell^\top g_{\ell+1}\)。转置来自标量内积的方向，不是额外的经验规则。可先复习 [Jacobian、VJP 与链式法则](#/learn/matrix-grad)。



### 例：一个标量残差块的梯度

1. 设 F(x)=0.1x，y=1.1x；对 y 的上游梯度为 2，则对 x 的梯度为 2.2。

2. 若误写 y=F(x)，相同上游梯度只得到 0.2。

3. 若改 \(F(x)=-x\)，正确残差输出与输入梯度都为零，说明恒等项仍可能被抵消。

残差提供额外路径，但不承诺所有方向的梯度下界。

参数梯度则沿另一条路径产生。记 \(B_\ell=\frac{\partial F_\ell}{\partial\theta_\ell}\in\mathbb R^{D\times p}\)，则 \(\nabla_{\theta_\ell}\mathcal L=B_\ell^\top g_{\ell+1}\)。恒等旁路不含 \(\theta_\ell\)，所以没有向这条参数梯度直接加入一个 I。输入梯度能沿旁路传播，不代表分支的每个参数都必然获得非零或足够大的梯度。





若某一局部分支导数接近零，恒等项仍保留输入梯度通路。但 \(F(x)=-x\) 时 \(A=0\)，旁路与分支恰好抵消；\(F(x)=x\) 时 \(A=2I\)，连续 L 层可放大为 \(2^L\)。残差结构改变了梯度的代数结构，没有给任意参数和任意深度下的梯度下界。





$$
\begin{aligned}dx_{\ell+1}&=(I+J_\ell)\,dx_\ell+B_\ell\,d\theta_\ell,\\ g_\ell&=(I+J_\ell)^\top g_{\ell+1},\qquad \nabla_{\theta_\ell}\mathcal L=B_\ell^\top g_{\ell+1}.\end{aligned}
$$





## 多层 Jacobian：乘积顺序、奇异值界与深度

多层网络的整体 Jacobian 是各层局部 Jacobian 按实际计算顺序组成的乘积，刻画输入扰动穿过整网后的变化。残差块为每个局部因子加入恒等项，但多层增益仍取决于这些因子的大小和方向。先展开两层，再讨论有条件的界。





L 个残差块连续作用时，输入扰动先经过 \(A_0\)，再经过 \(A_1\)，最后经过 \(A_{L-1}\)，所以整体前向 Jacobian 为 \(A_{L-1}\cdots A_0\)，反向乘积顺序相应转置。每个 \(J_\ell\) 都在该层实际输入 \(x_\ell\) 处求值；它们通常不交换，不能将矩阵乘积改成逐元素乘积，也不能把同一个 J 重复代入所有层。





两层时 \((I+J_1)(I+J_0)=I+J_0+J_1+J_1J_0\)。恒等项对应完全绕过分支的局部传播，其余项对应经过一条或两条分支。更多层可作类似展开，但各项可能相消，且共享同一前向轨迹中的输入相关 Jacobian。这种代数展开不意味着训练了 \(2^L\) 个相互独立的模型。





可以给出一个带条件的界。假设沿当前前向轨迹每层都满足算子范数 \(\lVert J_\ell\rVert_2\le\epsilon_\ell<1\)。对任意向量 v，由三角不等式有 \(\lVert(I+J_\ell)v\rVert\le(1+\epsilon_\ell)\lVert v\rVert\)；反向三角不等式给出 \(\lVert(I+J_\ell)v\rVert\ge(1-\epsilon_\ell)\lVert v\rVert\)。逐层应用，得到整体奇异值的上下界。这里 \(\lVert\cdot\rVert_2\) 对矩阵表示最大奇异值，对向量表示欧氏范数。





即使每层的 \(\epsilon_\ell\) 都较小，固定的非零 \(\epsilon\) 在很深的网络中仍产生 \((1\pm\epsilon)^L\)；取 \(J_\ell=\pm\epsilon I\) 就能分别达到这两种增长或衰减。若使用 \(x_{\ell+1}=x_\ell+\alpha_\ell F_\ell(x_\ell)\)，则界中的 \(\epsilon_\ell\) 换成 \(|\alpha_\ell|\,\lVert J_{F_\ell}\rVert_2\)。令这些量的总和保持有限，可以控制最坏情形上界；这是需要额外假设的分析，不是一个加号自动带来的性质。





单层特征值也不够。若每层 \(A=\begin{bmatrix}1&k\\0&1\end{bmatrix}\)，其两个特征值都为 1，但 \(A^L=\begin{bmatrix}1&Lk\\0&1\end{bmatrix}\)，第二个坐标的扰动可向第一个坐标不断积累。非正规矩阵的方向耦合使特征值不能直接替代奇异值；实际诊断应区分局部输出幅度、单个 VJP 的增益，以及完整 Jacobian 的最强或最弱方向。





$$
\begin{gathered}J_{0\to L}=A_{L-1}\cdots A_0,\qquad g_0=A_0^\top\cdots A_{L-1}^\top g_L,\\ \prod_{\ell=0}^{L-1}(1-\epsilon_\ell)\le\sigma_{\min}(J_{0\to L})\le\sigma_{\max}(J_{0\to L})\le\prod_{\ell=0}^{L-1}(1+\epsilon_\ell).\end{gathered}
$$





## Pre-Norm 与 Post-Norm

Pre-Norm 将归一化放在残差分支的入口，Post-Norm 将它放在两路相加之后。它们的区别是直接路径是否也要经过归一化。先认识这两种完整连接方式，再推导梯度为何不同。





Pre-Norm 为 \(y=x+F(N(x))\)，先归一化，再让分支读取该表示；Post-Norm 为 \(y=N(x+F(x))\)，整个残差和都经过归一化。设 \(N:\mathbb R^D\to\mathbb R^D\)，按前一节的微分规则，Pre-Norm 的分支 Jacobian 是 \(J_F(N(x))J_N(x)\)，而 Post-Norm 最外层先贡献 \(J_N(x+F(x))\)。矩阵的顺序由函数复合确定。





因此 Pre-Norm 的输入 Jacobian 保留一个结构上的 I；Post-Norm 的每条通路都要乘外层 Norm 的 Jacobian。LayerNorm 会删去共同平移方向，并在一定条件下压缩尺度方向，具体过程见 [归一化的微分与不变性](#/learn/normalization)。这些方向性质应作用在它实际接收的张量上，不能跳过前面的分支映射直接套到原输入。





把分支置零可得到最简单的反例：Pre-Norm 返回 x、Jacobian 为 I；Post-Norm 返回 N(x)、Jacobian 为 \(J_N(x)\)。置零分支是结构测试，不是任意网络默认都应采用的初始化。如果最终输出还有一个 Norm，Pre-Norm 模型的整体梯度也必须经过这一最终层。





Pre-Norm 在不少深层模型的初始化与优化中更易处理，但它的 I 仍会与分支导数相加。原论文的均值场结论依赖参数初始化、宽度和具体架构，不能据此保证所有任务都不需要 warmup，也不能宣称 Post-Norm 必然无法训练。替换预训练模型的 Norm 位置会改变前向函数及梯度，原权重通常不再对应同一计算。





$$
\begin{aligned}J_{\rm pre}(x)&=I+J_F(N(x))J_N(x),\\ J_{\rm post}(x)&=J_N(x+F(x))\bigl(I+J_F(x)\bigr).\end{aligned}
$$

```python
# [1] 构造同样的分支，仅改变 Norm 的位置
import torch
from torch import nn
torch.manual_seed(12)

class ResidualFFN(nn.Module):
    def __init__(self, dim, pre_norm=True):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, 4 * dim), nn.GELU(), nn.Linear(4 * dim, dim)
        )
        self.pre_norm = pre_norm

    def forward(self, x):
        if self.pre_norm:
            return x + self.ffn(self.norm(x))
        return self.norm(x + self.ffn(x))

# [2] 零分支是结构测试，不是所有网络的默认初始化方案
pre = ResidualFFN(8, pre_norm=True)
nn.init.zeros_(pre.ffn[-1].weight)
nn.init.zeros_(pre.ffn[-1].bias)
post = ResidualFFN(8, pre_norm=False)
post.load_state_dict(pre.state_dict())
x = torch.randn(2, 3, 8, requires_grad=True)
y_pre, y_post = pre(x), post(x)
torch.testing.assert_close(y_pre, x)
torch.testing.assert_close(y_post, post.norm(x))
assert not torch.allclose(y_post, x)

# [3] 检查主路径上的梯度，并观察零末层的影响
loss = y_pre.square().mean()
loss.backward()
assert x.grad is not None and torch.isfinite(x.grad).all()
print("Pre-Norm 恒等误差:", (y_pre - x).abs().max().item())
print("末层权重梯度范数:", pre.ffn[-1].weight.grad.norm().item())
print("首层权重梯度范数:", pre.ffn[0].weight.grad.norm().item())
print("残差结构检查通过")

```

两种结构共享同一组分支和 Norm 参数。末端投影置零后，前向对照区分 x 与 N(x)，反向打印展示首层和末层的不同梯度路径。完整代码页进一步比较多个深度的传播与真实训练。





### 置零分支测试要匹配实际结构

Post-Norm 的零分支仍有外层 Norm；把它断言成严格恒等会误判正确代码。

先写出完整代数表达式，再决定单元测试的预期值；对照 norm_first 配置和权重来源。

## 残差尺度、门控与零初始化

残差缩放是在分支输出前乘一个系数，门控则让这个系数可以学习或随条件改变。零初始化可以使某条更新初始为零，但不同置零位置会产生不同梯度。下面分别分析前向更新与参数最初怎样开始学习。





带缩放的残差可写为 \(y=x+\alpha F(x)\)，\(\alpha\) 可以是固定数、可学习标量或由条件产生的向量。较小的初始缩放能让模型从接近原表示的状态开始，但也会缩小分支参数最初得到的梯度。若 \(\alpha\) 恰为零，分支内部 \(\theta\) 的梯度在第一步可能为零，而门控 \(\alpha\) 仍可通过 F 的输出得到梯度；“整个模块首步都不学习”并不一定成立，需要分别看参数组。





另一种常见设计把分支末端投影初始化为零。此时分支输出为零、块接近恒等，末端投影通常先得到梯度，前面的层可能要等末端权重离开零后才获得非零梯度。零初始化并不意味着训练必定卡死，也不能把某一层初始零梯度立即当作断图。应根据乘法结构预测第一步哪些参数应更新，再连续检查几步，避免把有意的稳定初始化误诊为优化器故障。



### 例：门控为零时谁能收到梯度

1. 令 y=x+\(\alpha\)wx，当前 \(\alpha\)=0、w=2、x=3，上游梯度为 1。

2. \(\frac{\partial L}{\partial w}=\alpha x=0\)；\(\frac{\partial L}{\partial\alpha}=wx=6\)；\(\frac{\partial L}{\partial x}=1\)。

3. 更新 \(\alpha\) 后，下一步 w 就可能获得梯度。

查看不同参数的梯度路径比笼统地说“梯度为零”更有意义。

对一个标量通道，\(\operatorname{Var}(x+\alpha F)=\operatorname{Var}(x)+2\alpha\operatorname{Cov}(x,F)+\alpha^2\operatorname{Var}(F)\)。若 L 层分支增量零均值、彼此不相关且方差近似相同，累积方差才约为 \(L\alpha^2\operatorname{Var}(F)\)，因此 \(\alpha\propto L^{-1/2}\) 可以控制这一估计。实际分支与残差流常相关，协方差项不能直接丢掉。把残差看作固定时间区间上的离散动力系统时，步长 \(\alpha\propto L^{-1}\) 又是另一种假设；二者不是可互换的通用初始化规则。





在最坏情形 Jacobian 分析中，若 \(\lVert J_{F_\ell}\rVert_2\le C\)、\(C>0\) 且 \(\alpha=1/L\)，则每层偏离恒等至多 C/L。\(L\ge2C\) 时，利用 \(\log(1-u)\ge-2u\)（\(0\le u\le\tfrac12\)）和 \(\log(1+u)\le u\)，可给出 \(e^{-2C}\) 与 \(e^C\) 的统一上下界；有限 L 的乘积界 \((1\pm C/L)^L\) 在 \(L\to\infty\) 时分别趋于 \(e^{-C}\) 与 \(e^C\)。这里的 C 必须沿整条轨迹统一受控。\(\alpha=L^{-1/2}\) 来自不相关增量的方差估计，不能直接给出相同的最坏情形界。前向方差假设与反向算子界回答不同问题。





$$
\begin{aligned}\operatorname{Var}(x+\alpha F)&=\operatorname{Var}(x)+2\alpha\operatorname{Cov}(x,F)+\alpha^2\operatorname{Var}(F),\\ \nabla_\theta\mathcal L&=\alpha J_{F,\theta}^\top g,\qquad \partial_\alpha\mathcal L=F(x)^\top g.\end{aligned}
$$





## 投影旁路与维度变化

投影旁路是用一个映射代替原样传递的直接路径，使两路输出能够在相同形状与语义上相加。它用于通道数或分辨率变化的残差块。此时旁路不再是恒等映射，信息与梯度性质需要重新推导。





若输入和输出宽度不同，通常使用投影旁路 \(y=P(x)+F(x)\)，例如 1×1 卷积改变通道数，或 Linear 改变特征宽度；若空间分辨率也变化，还要对齐 stride 与采样位置。此时 Jacobian 是 \(J_P+J_F\)，不能再把旁路描述为严格恒等。投影参数也要注册、训练和保存；冻结主分支而遗漏旁路的更新范围，会改变原本打算固定的函数。





广播是尤其危险的残差错误。把 [B,T,D] 与 [B,1,D] 相加通常合法，但表示把同一增量写给所有位置，而不是逐位置更新。把 [B,D] 直接与 [B,T,D] 相加，在 B 恰好等于 T 时可能意外沿错误轴对齐。使用 \(B\ne T\) 的测试和显式 unsqueeze，比单个整齐的方形张量更能暴露错误。对于变化分辨率的 CNN，也应追踪感受野中心而非只比较输出尺寸。





如果 P 是 \(D_{\rm out}\times D_{\rm in}\) 的线性投影，旁路导数是这个矩形矩阵 P；前面以 I 为基础的方阵界不再直接适用。\(D_{\rm out}<D_{\rm in}\) 时，整个块对输入的局部 Jacobian 秩至多 \(D_{\rm out}\)，不能对所有输入方向保持单射。维度上能相加，只解决了运算合法性，尚未回答表示是否丢失。









## 原地修改与张量别名

张量别名是多个变量引用共享数据的情况，原地操作则直接改写这份数据。残差加法需要保留进入分支前的输入，别名与原地修改可能破坏这个要求。下面把数学中的两条路径与程序中的存储区分开。





Python 中 residual=x 只是给同一 Tensor 增加引用，并未生成独立副本。如果后续对 x 进行原地修改，residual 也可能随之变化，最终加回的就不再是进入分支前的表示。autograd 有时会通过版本检查报错，但不应依赖报错来证明所有原地操作安全。教学实现优先用清晰的非原地表达式，再在掌握依赖后考虑优化。





Dropout 放在分支还是加法之后也会改变旁路是否被随机屏蔽。常见 Pre-Norm 写法是在分支输出上 Dropout 后加回 x；验证和等价性测试应关闭随机性。残差分支若使用 checkpoint 重计算，重算时也必须保持随机状态和模块行为一致。不能为了减少显存把 residual.detach() 当作常规优化：它会切断恒等旁路的梯度，前向一样，训练机制却已经改变。









### detach 不是残差内存优化的等价替换

x.detach()+F(x) 保留前向值，却去掉恒等路径的梯度项。

分别核对前向和输入梯度；对必须保留的旁路使用原张量，若要重计算则采用明确的 checkpoint 机制。

## 残差适配与原有功能

残差适配器是在已有模型中增加一条可训练修正分支，以调整原表示的模块。接近零的初始分支可以减少初始函数扰动，但“原参数未改”不等于整个函数未改。需要分别理解参数冻结、前向修改与能力保持。





给冻结骨干加残差适配器，常从近似零的分支开始，以减小初始输出扰动。但参数不变不等于整个系统能力不变：输入预处理、Attention Mask、Norm 模式、输出模块或条件注入都可能改变计算。适配器也可能逐渐学习很大的增量，从而使表示远离原始分布。是否保持能力，需要在固定的旧任务和新任务上分别评估，不能用“有残差”代替证据。





一个有用的监控量是分支输出与主流表示的范数比，但它只是局部尺度指标。很小的增量也可能改变决策边界，较大的增量也不必然有害；要同时看方向、层位置和目标指标。若使用通道门控，单个总范数可能掩盖少数通道被放大。记录每层统计并做关闭分支的对照，可以区分收益来自适配器、其他可训练模块，还是数据管线变化。









## 受控实验：传播增益与优化行为

前面的推导给出了一般机制和有条件的界，实际非线性网络还受初始化、深度与任务目标影响。要判断观察到的差异来自哪里，比较必须共享分支初值和数据，并把传播探针与任务训练分开。下面的实验据此检验具体配置，不把有限观察提升为架构排名。





代码页构造两组宽度为 12 的网络：普通块 \(h_{\ell+1}=\alpha\tanh(W_\ell h_\ell+b_\ell)\)，残差块 \(h_{\ell+1}=h_\ell+\alpha\tanh(W_\ell h_\ell+b_\ell)\)。每一对模型共享完全相同的初始分支权重、偏置、读出头、输入和目标，只切换是否加入旁路；不同深度还共享同一组前缀层初值。实验分别考察深度 2、8、24，以及 \(\alpha=1\) 与 \(\alpha=L^{-1/2}\)。





传播实验使用同一个单位范数输出方向 g，计算 \(\frac{\partial\langle g,f(x)\rangle}{\partial x}\)，同时记录第一层、最后一层参数的梯度以及隐藏表示的 RMS。这样不会把不同初始预测误差混入 Jacobian 的比较。一个方向的 VJP 范数只是一个探针，不能当作完整 Jacobian 的最大奇异值或所有方向的梯度下界。





优化实验另用同一批固定合成回归数据、同一 AdamW 学习率和 100 次更新，报告训练 MSE 与参数实际位移。它测量的是这套固定配置的可优化性，未对每个架构单独寻找最优超参数，也没有给出真实任务上的泛化排名。缩放模式之间同时改变了分支尺度，因此应先比较相同 \(\alpha\) 内部的普通/残差对，再分析缩放的影响。





本节代码在 CPU、float64 下的一次固定种子运行显示：深度 2、\(\alpha=1\) 时，普通网络的最终训练 MSE 约 0.0585，残差网络约 0.0813；深度 24、\(\alpha=1\) 时，残差网络的输入 VJP 范数约 10.47，仍有明显放大；改用 \(\alpha=1/\sqrt{24}\) 后，这个探针约 1.264，普通网络在同一缩放下约 \(2.22\times10^{-17}\)。它们说明结构、深度与缩放共同决定现象，不支持“残差在任何配置下都更优”。数值尾数可能随环境变化。





最后运行 \(F(x)=-x\) 和 \(F(x)=x\) 的线性反例，分别验证梯度抵消与 12 层放大 \(2^{12}\)。这两项是数学关系的检验；前面的非线性训练表是受控但有限的实验观察。二者应采用不同强度的结论。





残差连接的主线始终是“保留当前表示，再学习更新”。直接路径、分支、加法与后续归一化共同定义这个块；单层和多层梯度分析说明这些连接在什么条件下有助于传播，而非提供无条件保证。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 残差主路径 x | [B,T,D] | 保留现有表示。 |
| 分支 F(x) | [B,T,D] | 与主路径逐元素相加。 |
| FFN 内部 | [B,T,D] → [B,T,4D] → [B,T,D] | 内部可扩维，相加之前必须回到 D。 |

## 完整代码与精读

```python
import copy
import math
import torch
from torch import nn

torch.set_num_threads(1)
torch.manual_seed(41)
dtype = torch.float64
width, batch = 12, 48
x_train = 0.7 * torch.randn(batch, width, dtype=dtype)
teacher = torch.linalg.qr(torch.randn(width, width, dtype=dtype)).Q
y_train = torch.sin(x_train @ teacher)
upstream = torch.randn(batch, width, dtype=dtype)
upstream = upstream / upstream.norm()

class Stack(nn.Module):
    def __init__(self, depth, alpha, skip):
        super().__init__()
        self.layers = nn.ModuleList(nn.Linear(width, width) for _ in range(depth))
        self.readout = nn.Linear(width, width)
        self.alpha, self.skip = alpha, skip
        self.to(dtype)
        for index, layer in enumerate(self.layers):
            generator = torch.Generator().manual_seed(1000 + index)
            with torch.no_grad():
                layer.weight.copy_(torch.randn(width, width, generator=generator, dtype=dtype) / math.sqrt(width))
                layer.bias.zero_()
        generator = torch.Generator().manual_seed(2000)
        with torch.no_grad():
            self.readout.weight.copy_(torch.randn(width, width, generator=generator, dtype=dtype) / math.sqrt(width))
            self.readout.bias.zero_()

    def features(self, x):
        for layer in self.layers:
            update = self.alpha * torch.tanh(layer(x))
            x = x + update if self.skip else update
        return x

    def forward(self, x):
        return self.readout(self.features(x))

def probe(model):
    x = x_train.detach().clone().requires_grad_()
    parameters = (model.layers[0].weight, model.layers[-1].weight)
    # 相同输出方向的 VJP，避免把不同初始预测误差混入 Jacobian 比较。
    gradients = torch.autograd.grad((model(x) * upstream).sum(), (x, *parameters))
    assert all(torch.isfinite(g).all() for g in gradients)
    with torch.no_grad():
        activation_rms = model.features(x_train).square().mean().sqrt().item()
    return [g.norm().item() for g in gradients] + [activation_rms]

def train(model, steps=100):
    # 同一数据、优化器、学习率和更新次数；不对每种结构单独调参。
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.)
    before = model.layers[0].weight.detach().clone()
    with torch.no_grad():
        initial = (model(x_train) - y_train).square().mean().item()
    for _ in range(steps):
        optimizer.zero_grad(set_to_none=True)
        loss = (model(x_train) - y_train).square().mean()
        loss.backward()
        assert torch.isfinite(loss)
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
        optimizer.step()
    with torch.no_grad():
        final = (model(x_train) - y_train).square().mean().item()
        displacement = (model.layers[0].weight - before).norm().item()
    assert math.isfinite(final) and math.isfinite(displacement)
    return initial, final, displacement

print("depth scale model | input_VJP first_W_grad last_W_grad feature_RMS | MSE_before MSE_after first_W_update")
for depth in (2, 8, 24):
    # 不同深度也复用相同前缀随机初始化；每个成对实验只改变 skip 开关。
    template = Stack(depth, alpha=1., skip=False)
    for scale_name, alpha in (("one", 1.), ("sqrt_depth", 1 / math.sqrt(depth))):
        plain, residual = copy.deepcopy(template), copy.deepcopy(template)
        plain.alpha = residual.alpha = alpha
        residual.skip = True
        assert all(torch.equal(a, b) for a, b in zip(plain.parameters(), residual.parameters()))
        for name, model in (("plain", plain), ("residual", residual)):
            diagnostics = probe(model)
            optimization = train(model)
            values = " ".join(f"{v:.5g}" for v in (*diagnostics, *optimization))
            print(depth, scale_name, name, "|", values)

# 恒等项不构成梯度下界：这两个是独立的线性反例，不是上面的 tanh 网络。
z = torch.tensor([1., -2.], dtype=dtype, requires_grad=True)
cancel = z + (-z)
torch.testing.assert_close(torch.autograd.grad(cancel.sum(), z)[0], torch.zeros_like(z))
h = z
for _ in range(12):
    h = h + h
torch.testing.assert_close(torch.autograd.grad(h.sum(), z)[0], torch.full_like(z, 2. ** 12))
print("通过：配对初值、有限训练、抵消反例和 2^12 梯度放大；表内数值仅适用于这个合成实验。")

```

- 第 1–15 行：固定数据、教师函数和单位范数输出探针；使用 float64 与单线程降低小实验的数值噪声。
- 第 16–41 行：不同深度共享逐层种子和相同读出头；同一对模型仅改变是否把输入加回，分支尺度和激活保持相同。
- 第 42–51 行：用统一的线性输出泛函求 VJP，并记录首尾权重梯度及特征 RMS；这与任务损失的梯度比较分开。
- 第 52–70 行：用相同优化器、学习率、样本和步数执行训练，记录真实参数位移；只要求结果有限，不断言某架构必然获胜。
- 第 71–85 行：逐深度和尺度建立独立副本，断言初始参数逐项相同，再打印传播与训练指标。
- 第 86–94 行：独立线性反例验证恒等项仍可被抵消，或者随深度指数放大。

预期观察：输出 12 行对照数据；同一深度、同一 \(\alpha\) 的两个网络初值完全一致。所有训练结果有限，但不保证残差的 MSE 总小于普通网络；两个线性反例严格得到零梯度和 \(2^{12}\) 放大。

## 浏览器 Python 练习

对分支 \(F(x)=x^2\)，实现 residual_value_grad(x, alpha)，返回 \(y=x+\alpha x^2\) 及 \(\frac{dy}{dx}\)。测试还会用有限差分检验导数。

```python
def residual_value_grad(x, alpha):
    # TODO: 返回残差输出和对 x 的导数
    raise NotImplementedError("请实现残差与导数")

```

### 提示

- 对 x 的直接路径求导得到 1。
- 最后一个测试说明残差也可能在某个点产生零梯度。

### 参考实现与解释

```python
def residual_value_grad(x, alpha):
    y = x + alpha * x * x
    grad = 1.0 + 2.0 * alpha * x
    return y, grad

```

残差提供恒等梯度项，但不保证总梯度处处非零。

### 断言测试

```python
y, g = residual_value_grad(2.0, 0.5)
assert y == 4.0 and g == 3.0
assert residual_value_grad(7.0, 0.0) == (7.0, 1.0)
x, a, h = -0.3, 0.2, 1e-5
numerical = (
    residual_value_grad(x+h, a)[0] - residual_value_grad(x-h, a)[0]
) / (2*h)
assert abs(numerical - residual_value_grad(x, a)[1]) < 1e-8
assert residual_value_grad(-1.0, 0.5)[1] == 0.0
print("通过：残差导数、恒等路径和可能的梯度抵消")

```

## 本地 PyTorch 练习

实现 residual_forward。pre_norm=True 时返回 x+branch(norm(x))，否则返回 norm(x+branch(x))；不要原地修改 x。 保留 Norm 统计量和分支的全部梯度路径；测试包含非零线性分支的完整输入 Jacobian。

```python
import torch
from torch import nn

def residual_forward(x, branch, norm, pre_norm=True):
    # TODO: 按两种结构完成前向
    raise NotImplementedError("请实现残差前向")

```

### 提示

- Pre-Norm 的 norm 在分支输入前，Post-Norm 的 norm 在相加后。
- 零分支时分别应返回 x 与 norm(x)；使用 x+...，避免原地修改输入。

### 参考实现与解释

```python
import torch
from torch import nn

def residual_forward(x, branch, norm, pre_norm=True):
    if pre_norm:
        return x + branch(norm(x))
    return norm(x + branch(x))

```

零分支消除了分支函数的影响，让 Norm 的位置成为唯一差别。随后对 Pre-Norm 输出求和，输入梯度应全为一，这直接检验了恒等路径；原输入快照则检验实现没有进行危险的原地修改。 非零分支再检验 \(I+WJ_N\) 与 \(J_N(I+W)\) 的顺序；若把 Norm 放错位置、detach 统计量或漏掉旁路导数，完整 Jacobian 对照会失败。

### 断言测试

```python
torch.manual_seed(12)
x = torch.randn(2, 3, 4, requires_grad=True)
original = x.detach().clone()
norm = nn.LayerNorm(4)
zero_branch = lambda z: z * 0
a = residual_forward(x, zero_branch, norm, True)
b = residual_forward(x, zero_branch, norm, False)
torch.testing.assert_close(a, original)
torch.testing.assert_close(b, norm(original))
torch.testing.assert_close(x, original)
a.sum().backward()
torch.testing.assert_close(x.grad, torch.ones_like(x))
print("通过：两种结构、非原地操作与恒等梯度")

# 非零分支：验证两个复合 Jacobian 的乘法顺序，而不只测置零特例。
v = torch.tensor([0.2, -1.0, 2.0, 0.8], dtype=torch.float64, requires_grad=True)
w = torch.tensor([[0.1, 0.2, 0., -0.1], [-0.2, 0.1, 0.3, 0.],
                  [0., -0.1, 0.2, 0.1], [0.3, 0., -0.2, 0.1]], dtype=v.dtype)
eps = 1e-3
layer_norm = nn.LayerNorm(4, eps=eps, elementwise_affine=False).double()
branch = lambda z: w @ z

def norm_jacobian(z):
    centered = z - z.mean()
    r = (centered.square().mean() + eps).sqrt()
    p = torch.eye(4, dtype=z.dtype) - torch.ones(4, 4, dtype=z.dtype) / 4
    return p / r - torch.outer(centered, centered) / (4 * r ** 3)

for pre in (True, False):
    actual = torch.autograd.functional.jacobian(lambda z: residual_forward(z, branch, layer_norm, pre), v)
    expected = (torch.eye(4, dtype=v.dtype) + w @ norm_jacobian(v) if pre else
                norm_jacobian(v + w @ v) @ (torch.eye(4, dtype=v.dtype) + w))
    torch.testing.assert_close(actual, expected, rtol=1e-9, atol=1e-10)
print("通过：非零分支的 Pre-Norm / Post-Norm 完整 Jacobian")

```

## 练习：推导与分析

### 从 y=x+F(x) 推导输入梯度，为什么残差有助于传播，却不保证梯度永远不为零？

对输入求导得到 \(I+J_F\)，直接路径贡献恒等矩阵，分支贡献自己的 Jacobian。这让梯度不必完全依赖穿过分支的所有连续乘法。

恒等项与分支项仍可能抵消，多层乘积也可能放大或缩小。标量例子 \(F(x)=0.5x^2\) 在 \(x=-1\) 处，导数 1+x 恰好为零，因此不能把残差解释为绝对的稳定性保证。

代码定位：对照 residual_value_grad，并检查实际模块输入和分支输出的梯度范数。

- 给出 \(I+J_F\) 或标量 \(1+F'(x)\)。
- 能举出抵消情形或说明多层尺度仍需监测。

### 新增残差分支的最后一层初始化为零，为什么首步更早层梯度可能为零，而最后一层仍能学习？

最后一层为零时，整个分支输出为零，残差块可以保持初始主路径。反向传播到更早层时会乘以这个零权重矩阵，因此早层梯度可能为零。

最后一层自身的梯度依赖它的输入激活与上游梯度，不必乘自己的权重，所以仍可能非零。完成一次更新后，分支内部的梯度路径可能打开；应检查分层梯度和后续更新，而不是只看首步零梯度。

代码定位：对照 pre.ffn[-1].weight.grad 与 pre.ffn[0].weight.grad，再执行一次实际更新后复查。

- 解释零末层为何保留初始残差行为。
- 区分末层参数梯度与传向更早层的梯度。

### 两层分支范数都很小，或所有残差 Jacobian 的特征值都接近 1，是否足以保证深层梯度稳定？

不足。分支输出值小不代表其局部导数小，例如高频的小幅函数可以有很大导数。梯度由各层 Jacobian 的乘积决定。

取每层 \(A=\begin{bmatrix}1&k\\0&1\end{bmatrix}\)，特征值均为 1，但 Aᴸ 的右上角为 Lk。方向间的耦合会累积，不能仅凭特征值判断放大。

残差范数、分支范数和逐层梯度都是有用观测量，但不能互相代替；Pre-Norm 的恒等项也不是所有方向上的梯度下界。

代码定位：使用 matrix_power 验证 Aᴸ，再比较 Aᴸ 对不同单位向量的放大。

- 区分函数值与导数。
- 解释特征值为 1 的矩阵仍可因方向耦合而累积放大。

### 为什么比较不同模型的 loss.backward() 输入梯度，不能单独证明谁的 Jacobian 传播更稳定？

任务梯度是 \(J^\top g\)，其中 g 还依赖模型当前输出与损失。两个模型的初始预测不同，g 的方向和尺度也可能不同。观测到输入梯度差异时，无法仅凭该值区分来自 J 还是来自上游误差。

本节先固定同一个单位输出方向求 VJP，再单独训练和报告 MSE。即使这样，单个探针也不是对所有奇异方向的证明；它提供受控且可复现的局部证据。

代码定位：完整实现的 probe 与 train 分别记录传播和任务优化。

- 写出 \(J^\top g\) 并区分两个因子。
- 说明共享初值、同一数据、固定 \(\alpha\) 与单方向探针的边界。

## 练习：辨析与纠错

### 把残差当作梯度永不消失的保证

\(F(x)=-x\) 就能抵消恒等项。记录各层梯度和分支/主流尺度，用实际结构解释异常。

### Post-Norm 零分支也要求输出等于 x

外层 Norm 仍然生效。按 y=Norm(x) 构造预期，不要把 Pre-Norm 的测试直接搬过来。

### 为省显存 detach 残差输入

这改变反向图而不是等价优化。前向通过后还须比较输入梯度，尤其要验证恒等通路仍存在。

### 广播掩盖了残差轴错位

用 \(B\ne T\)、各位置不同的测试值，逐元素比较；必要时明确 unsqueeze，避免把样本轴当成时间轴。

### 首步分支内部零梯度就认定断图

零门控或零末端投影可能有意让部分参数第一步不更新。先推导路径，观察门控/末端参数及第二步更新。

## 原始资料

- [Deep Residual Learning for Image Recognition](https://arxiv.org/abs/1512.03385)
- [On Layer Normalization in the Transformer Architecture](https://arxiv.org/abs/2002.04745)
- [PyTorch：TransformerEncoderLayer](https://docs.pytorch.org/docs/stable/generated/torch.nn.TransformerEncoderLayer.html)
- [Identity Mappings in Deep Residual Networks](https://arxiv.org/abs/1603.05027)
