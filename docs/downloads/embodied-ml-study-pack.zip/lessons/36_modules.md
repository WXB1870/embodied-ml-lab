# PyTorch 模块、参数与状态

参数注册、优化器绑定、模式切换与状态保存。

PyTorch 的 nn.Module 是组织神经网络计算与状态的基本组件：它定义前向过程，并管理注册的子模块、参数和 Buffer。Parameter 表示模型参数，Buffer 表示需要随模型管理的非参数状态，优化器与计算图则分别负责更新与求导。本章沿同一个投影模型，先认识这些对象，再追踪注册、设备迁移、训练模式与保存恢复。

## 学习目标

- 检查新加的投影层是否出现在 named_parameters 与优化器中。
- 把归一化统计量注册为 Buffer。
- 理解 state_dict 的引用语义并正确保存训练中的最佳状态。

前置知识：[MLP：表达、梯度与优化](https://wxb1870.github.io/embodied-ml-lab/learn/mlp/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/)

## Module 树与状态注册

Module 树是由模型及其注册子模块组成的层级结构，注册让参数、状态与模式可以被递归管理。它不等于一次前向的计算图。先认识模型“拥有哪些组件”，再讨论这些组件怎样被调用。





构造函数应先调用 super().__init__()，再创建稳定的层对象。重复前向应复用同一批参数，而不是每次临时生成一层。把模块封装成类的价值，是让“本次调用了哪些运算”和“训练系统管理哪些状态”对应起来。后训练增加 Adapter、投影层或分类器时，要将其加入模块树，并验证保存、载入、设备迁移和参数更新都包含新组件，而不只是看 forward 能运行。









### 前向可微与模型注册是两条独立机制

Autograd 沿运算建立图，Module 沿注册关系收集状态，Optimizer 又持有一组具体参数对象。

分别检查 named_modules、named_parameters、实际 grad 与 optimizer.param_groups，不能只检查其中一项。

## Parameter、Buffer 与普通属性

Parameter 是注册为模型参数的张量，Buffer 是注册的非参数状态，普通属性则只是 Python 对象中的字段。它们参与保存、迁移和参数枚举的方式不同。先按职责分类，再决定一个张量应如何加入模型。





需要优化器学习的张量通常注册为 nn.Parameter；影响前向但不通过梯度学习的统计量可注册为 Buffer，例如特征均值、尺度或 BN 运行统计。持久 Buffer 会进入 state_dict，非持久 Buffer 仍参与设备迁移但不写入默认状态字典。普通 Tensor 属性既不会自动成为 Parameter，也通常不受模型递归 to 管理。把一个统计量设成 requires_grad=False 的 Parameter 与 Buffer 在参数枚举等语义上也不同。





Buffer 不是只读常量，可以由前向或其他逻辑更新；因此冻结参数后仍要检查 Buffer 是否变化。to(dtype=...) 通常会转换浮点或复数参数与 Buffer 的 dtype，整数索引 Buffer 需保留其整数性质，不能笼统声称所有状态都变成浮点。分类、条件编码和数据标准化的元信息也可能是字符串或配置对象，不属于 Tensor 状态，需通过配置文件或明确的额外状态机制保存。







### 例：一个带标准化的投影模块

1. mean 与 scale 不应被优化器学习，但影响输出，注册为持久 Buffer。

2. Linear(D,4) 的 weight/bias 是 Parameter，参与优化。

3. 当输入 x=mean 时，标准化结果为零，输出应等于投影 bias；载入快照后这一性质仍应成立。

类型分工可以转化为 named_parameters、named_buffers、state_dict 和前向的四种检查。

## 容器、执行顺序与共享参数

ModuleList 与 ModuleDict 是会注册内部模块的容器，Sequential 还额外定义按顺序执行的前向。参数共享则是多个计算位置复用同一个参数对象。管理组件、执行顺序和共享权重是三件不同的事。





ModuleList 会注册其中的层，但不会替你决定前向顺序；需要在 forward 中迭代或按条件调用。Sequential 则按顺序连接，适合简单串联。ModuleDict 让按名称选择的模块也被管理。普通 list 或 dict 中存放的模块，除非另行注册，一般不会被父模型自动枚举。对于一组独立 Parameter，也有 ParameterList 与 ParameterDict，不要用可训练 Tensor 列表替代这些注册语义。





同一个模块对象被调用多次意味着权重共享，而复制结构并新建对象意味着不同参数；重复写一个变量名不保证共享。共享参数可能从多条运算路径累积梯度，在参数枚举与优化器分组时还要避免无意重复管理。验证时比较对象身份，而不是只比较名称或当前数值：两份权重初始值相同，并不意味着后续更新绑定；同一个对象有多个路径名称，也不是多套独立模型。









## 优化器与参数对象

优化器成员是创建参数组时传入的具体参数对象，不是对模型名称的动态搜索。新增或替换层会改变模型对象关系，却不会自动更新旧优化器。先明确对象身份，再核对它是否真正接受更新。





创建 optimizer(model.parameters()) 时，优化器记录当时传入的 Parameter 对象。之后给模型新增一层，前向能用、梯度能算，但旧优化器不会自动把新参数纳入。可以在明确策略下重建优化器或添加参数组，同时考虑旧动量、学习率和权重衰减的继承。直接把某个 Parameter 替换成新的对象，也可能使优化器仍指向旧对象，即使名字保持不变。





因此通常先完成结构构造、设备放置和冻结配置，再创建优化器。若框架使用特殊的加载、参数分片或 assign 语义，更需核对参数对象是否变化。检查更新不能只看 grad is not None：梯度可能恰好为零、学习率可能为零、该步可能被精度管理跳过。保存更新前后的独立张量副本，结合梯度、参数组和优化器状态解释实际差异，才能判断某层是否按计划学习。









### 新增模块不会自动进入已存在的优化器

优化器持有对象集合，不会每一步重新读取模型树；改对象也可能使旧引用失效。

收集 optimizer.param_groups 内的 id(p)，逐一与计划训练的 named_parameters 对照，再做一次可预测的更新。

## forward 中的状态生命周期

状态生命周期指参数或其他状态在何时创建、复用、改变与销毁。可训练层通常应在构造时建立、在多次前向间复用；临时输入结果则属于一次计算。下面说明混淆这两类生命周期会怎样影响学习。





在 forward 内临时创建 nn.Linear，会每次重新初始化权重，且这批参数通常不在外部优化器中。调用模型多次可能得到不同结果，checkpoint 也无法恢复这些临时层。更隐蔽的情况是以输入 shape 为条件第一次创建参数，此时需要明确的 lazy 初始化流程和优化器时机，不能在训练途中任意变更结构。可变序列长度通常应通过张量运算处理，而不是为每个长度新建权重。





应调用 model(x)，让 Module 的调用机制处理注册的 hooks；直接调用 model.forward(x) 可能绕开相关机制。不要为了记录中间输出而把带计算图 Tensor 永久保存在 self.history 中，这可能长期保留激活。调试日志应保存必要的 detach 结果或标量，而训练所需的返回值仍保留正确梯度。调用顺序、状态更新与缓存也应可解释，避免前一次输入无意影响下一次独立样本。









## 模式、冻结与梯度记录

训练模式选择模块的前向行为，冻结标记选择参数求导范围，梯度记录开关选择是否构建反向图。它们管理的状态不同，不能用一个 eval 或 no_grad 代表全部冻结需求。





train/eval 会递归改变模块的 training 标志，影响 Dropout、BN 等依赖模式的层；requires_grad_ 控制参数是否需要梯度；no_grad 控制该作用域中是否记录普通反向图。三者解决不同问题。eval 下的模型仍然可以训练参数，train 下的冻结模型也可能改变运行统计或产生随机输出。是否应组合使用，要由预期行为而不是习惯决定。





当一个模型同时包含需要 eval 的冻结骨干和需要 train 的适配模块，简单调用外层 model.train() 可能覆盖子模块原先设置。验证后只恢复一个根 training 布尔值，也不一定恢复这种混合模式。应由明确的训练配置重新应用各子模块状态，或保存必要的逐模块状态。把这些要求写进模型封装，可避免训练脚本中多个回调相互覆盖，产生难以复现的性能变化。









## state_dict 与快照别名

state_dict 是注册参数和持久 Buffer 的命名值集合，用于保存与载入模型状态。它不是结构代码或自动生成的独立历史快照。先定义它保存什么，再处理别名、配置和恢复时机。





state_dict 主要记录注册参数与持久 Buffer 的名字和值，不自动保存类的实现、forward 逻辑、训练模式、requires_grad 计划或所有 Python 配置。更换类定义后即使键名匹配，也可能计算出不同函数。strict=True 有助于发现缺失和额外键，但不能证明预处理、标签语义或所有结构参数相同；strict=False 也不应变成忽略所有加载问题的通用补丁。





留在内存中的 best_state=model.state_dict() 通常仍引用当前状态张量，后续原地更新可能改变它。要保留历史快照，应深拷贝或及时序列化。只复制外层字典不能保证底层 Tensor 独立。载入后应在 eval、固定输入和相同配置下比较输出，检查 Buffer 和所有预期键；若继续训练，还需要优化器等其他状态，完整约定见[保存与恢复训练状态](#/learn/checkpoint)。







### 例：浅快照为什么会跟着模型变化

1. 记录 model.state_dict() 后，使用 optimizer.step 原地更新参数。

2. 快照里共享存储的 Tensor 可能也已经变成更新后值，因此不能代表当时最佳模型。

3. 使用 copy.deepcopy 创建独立快照，更新后载入新实例，应还原旧输出。

保存名字和值与保存某一时刻的独立副本是不同操作。

## 参数清单与单步更新

前面的机制最终需要在同一模型上联合成立：参数可枚举、梯度可达、优化器能更新、保存后能恢复。一个小型投影模型足以把这些条件逐项连接起来。验证应比较实际状态与输出，而不能只检查接口调用没有报错。





8 维输入、4 维输出的特征投影示例把输入标准化统计注册为 Buffer，用 ModuleList 管理中间层，并比较更新前快照与恢复后的输出。先打印名字、shape、dtype、device 与 requires_grad，再列出优化器实际参数对象；检查没有遗漏的层、没有被误加入学习的统计量。对输出做确定性标量目标，确认计划更新的参数发生变化，冻结部分保持约定状态。





最后在新实例载入 state_dict，使用同一输入逐元素比较，必要时在不同 dtype 上重复迁移检查。检查的结论是模块注册、状态恢复与更新机制符合本例约定，并不是任务表现已达标。大型训练框架会将这些步骤封装在多个组件中：出现 loss 下降而某组件不更新时，仍可从注册、图、梯度、对象归属、更新前后值这一条路径逐项定位。





在[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)中，同样的注册规则用于 TokenRegressor：head 是唯一可训练模块，x_mean、x_scale、y_mean、y_scale 是随 state_dict 保存的 Buffer。检查它的 named_parameters、named_buffers 与恢复输出，可以将本课的模块机制放回完整训练，而无需再创建一种读出网络。





一个可训练模块既是前向函数，也是具有稳定身份和生命周期的状态集合。注册让训练系统找到这些状态，计算图连接导数，优化器实施更新，保存与恢复再将相同函数带到下一次运行。









### 把封装正确性拆成可观测的状态

参数名称存在、梯度存在和数值改变分别证明不同事情，只有组合起来才能解释训练行为。

保留一个最小 Batch，打印目标参数的更新前值、梯度和更新后值，再比较保存恢复的输出。

## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 输入特征 | [B,D] | 连续特征，不包含序列轴的简化例子。 |
| feature_mean / feature_scale | [D] | 持久 Buffer，与模型一起迁移和保存。 |
| 投影参数 | weight [4,D]，bias [4] | 由 Linear 注册进参数树，输出四个通用特征。 |
| 输出 | [B,4] | 通用四维特征投影，不绑定任何物理坐标含义。 |

## 完整代码与精读

```python
# [1] 统计量作为 Buffer，多个层使用 ModuleList
import copy
import torch
from torch import nn
torch.manual_seed(17)

class FeatureProjector(nn.Module):
    def __init__(self, dim=8):
        super().__init__()
        self.register_buffer("feature_mean", torch.zeros(dim))
        self.register_buffer("feature_scale", torch.ones(dim))
        self.layers = nn.ModuleList([nn.Linear(dim, dim), nn.Linear(dim, dim)])
        self.head = nn.Linear(dim, 4)

    def forward(self, x):
        x = (x - self.feature_mean) / self.feature_scale.clamp_min(1e-6)
        for layer in self.layers:
            x = torch.nn.functional.gelu(layer(x))
        return self.head(x)

# [2] 全部模块构造完毕之后再创建优化器
model = FeatureProjector()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
x = torch.randn(4, 8)
before_output = model(x).detach().clone()
snapshot = copy.deepcopy(model.state_dict())
before_weight = model.head.weight.detach().clone()
assert "layers.0.weight" in snapshot
assert "feature_mean" in snapshot
assert "feature_mean" not in dict(model.named_parameters())

# [3] 更新后，独立快照仍能恢复旧的函数
optimizer.zero_grad(set_to_none=True)
model(x).square().mean().backward()
optimizer.step()
assert not torch.equal(model.head.weight, before_weight)
restored = FeatureProjector()
restored.load_state_dict(snapshot)
torch.testing.assert_close(restored(x), before_output)
print("参数名:", list(dict(model.named_parameters())))
print("Buffer:", list(dict(model.named_buffers())))
print("注册与独立快照检查通过")

```

- 第 1–20 行：ModuleList 注册中间层，Buffer 管理标准化统计，Linear(dim,4) 输出四维通用特征。
- 第 21–31 行：完成模块构造后创建优化器；deepcopy 保存独立状态，clone 保存待比较的参数数值。
- 第 32–42 行：执行一次更新，断言投影权重发生变化；新实例载入旧快照后仍输出更新前结果，证明快照独立。

预期观察：参数名包含 layers 与 head；Buffer 包含 feature_mean 与 feature_scale；投影参数实际更新，新实例从独立快照恢复更新前的四维输出。

## 浏览器 Python 练习

每个规格含 kind、shape、trainable。实现 count_trainable(specs)，只累加 kind='parameter' 且 trainable=True 的形状元素乘积，Buffer 不计入。

```python
def count_trainable(specs):
    # TODO: 按 kind 与 trainable 过滤，再计算元素数
    raise NotImplementedError("请统计可训练参数")

```

### 提示

- 矩阵的元素数是各个维度的乘积；标量 shape=[] 有一个元素。
- 不能只看 trainable 字段，先区分 Parameter 与 Buffer。

### 参考实现与解释

```python
import math

def count_trainable(specs):
    return sum(math.prod(item["shape"]) for item in specs
               if item["kind"] == "parameter" and item["trainable"])

```

项目里的实际检查应基于 named_parameters 和优化器参数组；规格计数练习帮助你明确统计口径。

### 断言测试

```python
specs = [
    {"kind":"parameter", "shape":[4,8], "trainable":True},
    {"kind":"parameter", "shape":[4], "trainable":True},
    {"kind":"parameter", "shape":[8,8], "trainable":False},
    {"kind":"buffer", "shape":[8], "trainable":False},
]
assert count_trainable(specs) == 36
assert count_trainable([]) == 0
assert count_trainable([{"kind":"parameter","shape":[],"trainable":True}]) == 1
assert count_trainable([{"kind":"buffer","shape":[99],"trainable":True}]) == 0
print("通过：冻结过滤、Buffer 排除和标量参数")

```

## 本地 PyTorch 练习

完成 NormalizedProjector。将 mean、scale 注册为持久 Buffer，创建一个 Linear(dim,4) 作为 proj，并在 forward 中标准化输入后投影。

```python
import torch
from torch import nn

class NormalizedProjector(nn.Module):
    def __init__(self, mean, scale):
        super().__init__()
        # TODO: 注册统计量并创建投影层
        raise NotImplementedError("请初始化特征投影模块")

    def forward(self, x):
        # TODO: 使用已注册的状态
        raise NotImplementedError("请完成前向")

```

### 提示

- mean 与 scale 是影响前向但不应被学习的张量，使用 register_buffer，不要包装成 Parameter。
- 先创建 self.proj=nn.Linear(mean.numel(),4)，再在 forward 中引用这个已有层。
- 用 clone 形成自己的统计量状态，scale 用 clamp_min 防止除零。

### 参考实现与解释

```python
import torch
from torch import nn

class NormalizedProjector(nn.Module):
    def __init__(self, mean, scale):
        super().__init__()
        self.register_buffer("mean", mean.clone())
        self.register_buffer("scale", scale.clone())
        self.proj = nn.Linear(mean.numel(), 4)

    def forward(self, x):
        normalized = (x - self.mean) / self.scale.clamp_min(1e-6)
        return self.proj(normalized)

```

测试分别检查 named_buffers、named_parameters、state_dict 和 dtype 迁移，覆盖了注册机制的不同作用。输入取为 mean 时，标准化结果为零，因此最终输出必须等于投影 bias，这一性质检验实际前向是否使用了注册的统计量。

### 断言测试

```python
torch.manual_seed(17)
model = NormalizedProjector(torch.tensor([1.,2.]), torch.tensor([2.,4.]))
assert set(dict(model.named_buffers())) == {"mean", "scale"}
assert set(dict(model.named_parameters())) == {"proj.weight", "proj.bias"}
assert {"mean", "scale"}.issubset(model.state_dict())
model = model.to(dtype=torch.float64)
assert model.mean.dtype == torch.float64 and model.scale.dtype == torch.float64
x = model.mean[None]
assert model(x).shape == (1, 4)
torch.testing.assert_close(model(x), model.proj.bias[None])
print("通过：注册、序列化、dtype 迁移与前向")

```

## 练习：推导与分析

### 一个层能参与前向并得到梯度，是否一定会被 optimizer.step 更新？请给出完整检查顺序。

不一定。层可能放在未注册的普通 Python list 中，或者在优化器创建后才加入，导致优化器没有持有它的参数对象。Autograd 能算梯度并不意味着优化器会自动扫描发现这些参数。

先检查 named_parameters 中是否有目标参数，再看 requires_grad 和实际 grad，接着确认同一参数对象出现在 optimizer.param_groups，最后比较一次更新前后的值。若梯度本来为零，还应结合损失和结构判断，而不是直接断定优化器错误。

代码定位：对比 id(parameter) 与优化器参数组里的对象 ID，保存参数更新前后的独立快照。

- 区分注册、梯度与优化器归属。
- 包含一次实际参数变化检查。

### 为什么 best_state=model.state_dict() 可能不能保留最佳模型？Buffer 是否也需要保存？

state_dict 通常包含引用当前模型张量的值，后续原地参数更新可能使内存里的 best_state 也变化。需要独立快照时使用 deepcopy，或立即序列化，而不是只复制最外层字典。

持久 Buffer 也会影响模型函数，例如归一化统计量或 BatchNorm 运行状态，所以通常需要随权重保存。它们不是优化器学习的参数，但缺失时仍可能让恢复后的输出不同。

代码定位：在保存快照后做一次更新，再加载到新模型并比较更新前的输出。

- 指出浅引用导致快照变化的原因。
- 说明持久 Buffer 对前向与恢复的作用。

## 练习：辨析与纠错

### 用普通 list 装层而没有注册

forward 仍可能运行，但 parameters/to/state_dict 未必能发现这些层。使用 ModuleList/ModuleDict，验证状态键和设备。

### forward 中每次新建 Linear

参数随调用重建，优化器不能按预期复用和更新。把稳定权重放在构造或明确初始化阶段。

### 只看 grad 不检查优化器对象

新增层、替换参数或加载方式可使 optimizer 持有旧集合。对照参数对象 ID，并实际比较一次更新。

### 把统计量直接放普通 Tensor 属性

设备迁移与保存容易遗漏。影响前向且不应学习的 Tensor 可注册为 Buffer，并明确是否持久。

### 用浅 state_dict 引用保留最佳状态

后续更新可能改变底层 Tensor。深拷贝或及时保存，再在新实例中验证旧输出恢复。

## 原始资料

- [PyTorch：Module](https://docs.pytorch.org/docs/stable/generated/torch.nn.Module.html)
- [PyTorch：ModuleList](https://docs.pytorch.org/docs/stable/generated/torch.nn.ModuleList.html)
- [PyTorch：Modules notes](https://docs.pytorch.org/docs/stable/notes/modules.html)
- [PyTorch：Saving and Loading Models，独立最佳状态快照](https://docs.pytorch.org/tutorials/beginner/saving_loading_models.html)
