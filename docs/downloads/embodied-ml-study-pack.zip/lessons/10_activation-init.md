# 激活与初始化

用二阶矩和局部导数解释信号为何放大、衰减或失活。

激活函数是施加在中间响应上的非线性变换，使多层线性映射能够表示更复杂的关系；参数初始化则是在训练开始前为权重和偏置选择起始值。前者改变函数形状与局部导数，后者决定信号最初落在哪些区间，两者共同影响前向和反向的传播尺度。本章先认识常用激活，再解释初始化的尺度与对称性，最后用同一组信号统计检验这些选择。

## 学习目标

- 从函数形状解释 ReLU、GELU 与 SiLU 的梯度行为
- 说明初始化为何需要考虑输入维度和激活函数
- 用激活统计检查小网络是否出现信号塌缩或放大

前置知识：[线性代数与矩阵求导](https://wxb1870.github.io/embodied-ml-lab/learn/matrix-grad/) · [MLP：表达、梯度与优化](https://wxb1870.github.io/embodied-ml-lab/learn/mlp/)

## 激活函数同时决定函数形状与局部导数

激活函数通常是逐元素的非线性函数：接收线性层产生的数值，变换后交给下一层。它在前向中改变可表示的函数，在反向中通过自身导数调节梯度。下面始终从这两个作用认识激活，而非只比较输出曲线。





神经网络前向使用 \(\phi(z)\)，反向使用 \(\phi^{\prime}(z)\)。这两个视角必须一起看：某激活让正负输入都产生非零输出，不代表它在所有区域都有足够大的导数；输出看起来平滑，也不代表梯度传播一定稳定。对深层网络，许多局部导数与权重矩阵连乘，局部尺度的偏差可能沿深度放大或衰减。





激活通常逐元素作用，因此保持输入形状，也不主动混合位置或通道。它依赖前一层形成的特征组合，后一层再将激活后的特征混合。选择激活时应考虑输入分布、初始化、归一化、残差结构和目标精度；单独比较几条函数曲线只能建立直觉，不能替代固定训练配置的实验。





选型先看激活位于哪里。隐藏层负责构造特征，输出层则要匹配目标的数学含义：一般连续回归可直接输出实数，多类分类训练输出 logits，二元概率可在读出时做 Sigmoid。微调已有骨干时，先沿用其激活、初始化与归一化配置，再通过固定数据和预算的对照研究替换。







### 先按网络位置与输出语义选择

| 激活 | 典型位置或场景 | 选择理由 |

|---|---|---|

| Sigmoid | 二元或多标签的概率读出；循环网络的门 | 把数值映射到 0～1，表达概率或保留比例。 |

| tanh | GRU 的候选状态；需要正负对称有界范围的输出 | 输出在 −1～1，零附近保留正负变化。 |

| ReLU | 从零搭建的 CNN、普通 MLP 隐藏层 | 分段线性、计算简单，便于建立训练和手算基线。 |

| Leaky ReLU | 隐藏层需要在负区间继续传递响应和梯度 | 保留小的负半轴斜率，配套选择初始化增益。 |

| GELU | GPT-2 等 Transformer 的前馈隐藏层 | 使用平滑的输入相关调制；适配已有模型时沿用其激活配置。 |

| SiLU | 平滑激活的隐藏层；SwiGLU 的门控分支 | 以输入乘 Sigmoid 做平滑调制；门控结构还包含另一条特征分支。 |



## Sigmoid 与 tanh：饱和为什么带来小梯度

Sigmoid 将实数压到 0 与 1 之间，tanh 将实数压到 −1 与 1 之间；它们都是有界的平滑激活。饱和指输入继续变化时输出已接近边界、局部导数很小的状态。先理解这个机制，再分析多层传播为什么会受影响。

![Sigmoid曲线在零附近较陡，输入绝对值较大时趋于水平并接近0或1。](../assets/figures/sigmoid-d2l.svg)

Sigmoid 将输入压到 0 与 1 之间；零处斜率为 1/4，两端逐渐变平。 图源：[《动手学深度学习》](https://d2l.ai/chapter_multilayer-perceptrons/mlp.html#sigmoid-function)。



Sigmoid 的导数为 \(\sigma(z)(1-\sigma(z))\)，最大值出现在 \(z=0\)，等于 \(\frac14\)；正负两端输出接近常数，导数趋近零。tanh 的导数为 \(1-\tanh^2(z)\)，在零附近较大，在大绝对值处也会饱和。若很多层处于饱和区域，反向传回的梯度可能迅速变小，前层难以调整；仅增加训练步数未必解决尺度问题。

![tanh 激活曲线穿过原点，在输入绝对值较大时分别接近负一与正一。](../assets/figures/tanh-d2l.svg)

tanh 以原点为中心，零附近的斜率为 1，两端逐渐变平。 图源：[《动手学深度学习》](https://d2l.ai/chapter_multilayer-perceptrons/mlp.html#tanh-function)。



典型用法是让 Sigmoid 表达二元概率或门控比例，让 tanh 表达对称有界状态，例如 [GRU 的候选状态](https://docs.pytorch.org/docs/stable/generated/torch.nn.GRU.html)。若用 tanh 输出归一化动作，还要按动作范围恢复单位。二分类训练通常直接将 logits 送入 [BCEWithLogitsLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html)，在需要读取概率时再计算 Sigmoid。





在多层 Sigmoid 网络中，即便每层预激活都接近零，局部导数最大也仅为 \(\frac14\)；实际梯度还乘权重矩阵，因此不能只用激活导数单独断言一定消失。合理判断应看整条 Jacobian 链的增益，这也是残差与归一化结构需要一起讨论的原因。





$$
\sigma(z)=\frac{1}{1+e^{-z}},\quad \sigma^{\prime}(z)=\sigma(z)(1-\sigma(z)),\quad (\tanh z)^{\prime}=1-\tanh^2z
$$



### 例：连续四个小导数的影响

1. 假设一条简化链上四次局部导数都是 0.1，暂不考虑权重因子。

2. 上游梯度 1 经过这条链后变成 \(0.1^4=0.0001\)。

3. 若把每个局部导数变为 0.8，相同链得到 0.4096；微小的逐层差异会被深度累积。

这只是局部链式法则的示意，实际网络还受矩阵谱、分支和归一化影响。

## ReLU：稀疏响应与失活单元

ReLU 是取输入与零之中较大者的分段线性激活：正输入原样通过，负输入输出零。它由此产生稀疏响应，并使负区间的局部梯度为零。持续对训练数据处于负区间的单元，才可能出现这里讨论的失活问题。

![ReLU在负半轴输出零，正半轴保持输入值，在零处形成折点。](../assets/figures/relu-d2l.svg)

ReLU 在负半轴为零、正半轴为直线，两侧斜率分别为 0 和 1。 图源：[《动手学深度学习》](https://d2l.ai/chapter_multilayer-perceptrons/mlp.html#relu-function)。



\(\operatorname{ReLU}(z)=\max(0,z)\)，正区间导数为 1，负区间为 0，零点需采用实现的次梯度约定。它避免正区间的饱和，但如果某单元对训练数据长期处于负区间，其输入权重得不到来自该支路的梯度，这常被称为失活。一个样本上输出为零不等于永久失活，应在多个 Batch 上观察该单元激活与梯度。





典型场景是从零训练 CNN 或普通 MLP 的隐藏层，可配合面向 ReLU 的 Kaiming 初始化建立基线。若希望负区间也持续提供响应，可考虑 Leaky ReLU，并按负斜率选择初始化增益。偏置、输入均值和过大的更新会改变单元落在正负区间的频率，因此判断失活时应同时观察多个 Batch 的响应与梯度。









### 把一次零激活等同于死神经元

局部零响应与对全部训练样本长期无响应是不同现象。

按通道统计多个批次的激活率和梯度，检查输入尺度及学习率变化前后的趋势。

## GELU 与 SiLU：平滑门控不是简单的截断

GELU 和 SiLU 是用依赖输入的平滑系数调节输入幅度的激活函数。前者使用标准正态累积分布函数，后者使用 Sigmoid；它们不像 ReLU 那样直接截掉负区间。下面对“输入乘门控系数”完整求导，说明两条反向路径。

![ReLU 与精确 GELU 曲线对比：ReLU 的负半轴为零，GELU 在负区间平滑下探，正区间逐渐接近直线。](../assets/figures/gelu-relu-commons.svg)

蓝线为 ReLU，绿线为 GELU；重点比较零附近的过渡和负半轴的下探。 图源：[Ringdongdang](https://commons.wikimedia.org/wiki/File:ReLU_and_GELU.svg)。



精确 GELU 可写成 \(z\Phi(z)\)，Φ 是标准正态分布的累积分布函数；SiLU 写成 \(z\sigma(z)\)。它们用与输入相关的平滑权重调节 z，负区间仍可能有非零输出与导数，输出也不一定单调。GELU 的近似实现与精确版本会有细小数值差异，做逐元素等价测试时需要统一 approximation 配置。

![SiLU 曲线在负半轴先下探再返回原点，正半轴逐渐接近恒等映射。](../assets/figures/silu-commons.svg)

横轴是输入 z，纵轴是 SiLU(z)=zσ(z)；负区间保留平滑响应，正区间逐渐贴近 y=z。 图源：[Romain Mondon-Cancel](https://commons.wikimedia.org/wiki/File:Swish.svg)。



SiLU 的导数为 \(\sigma(z)+z\sigma(z)(1-\sigma(z))\)。只把它当成“乘了一个 sigmoid”，却在手写反向中漏掉第二项，会产生错误梯度。GELU 同样包含概率函数与其导数两项。使用自动微分可以避免手写错误，但仍需理解这些梯度来自哪里；否则无法判断初始化和输入范围为什么影响训练。





这里 \(\varphi(z)=\frac1{\sqrt{2\pi}}\exp(-z^2/2)\) 是标准正态密度，与激活函数的通用记号应按上下文区分。由于 \(\Phi^{\prime}=\varphi\)，GELU 的第二项来自对门控概率求导；代码同时验证两个乘积法则，而不是只绘制函数曲线。





在结构中定位时，可以先看两类典型用法：[GPT-2 的前馈层](https://github.com/openai/gpt-2/blob/master/src/model.py)在线性投影后使用 GELU；[LLaMA](https://arxiv.org/abs/2302.13971)采用 SwiGLU，由 SiLU 作用于一条投影分支，再与另一条特征分支逐元素相乘。前者是单路激活，后者还定义了双分支门控，选用时应连同前后投影一起看。





$$
\begin{aligned}\operatorname{SiLU}(z)&=z\sigma(z),\quad \operatorname{SiLU}^{\prime}(z)=\sigma(z)+z\sigma(z)(1-\sigma(z)),\\ \operatorname{GELU}(z)&=z\Phi(z),\quad \operatorname{GELU}^{\prime}(z)=\Phi(z)+z\varphi(z).\end{aligned}
$$



### 例：SiLU 在零点的输出与导数

1. \(z=0\) 时，\(\sigma(0)=0.5\)，因此 \(\operatorname{SiLU}(0)=0\)。

2. 导数第一项为 0.5，第二项包含 \(z=0\) 而为零，所以导数是 0.5。

3. 输出恰好为零，但梯度并不为零；不能用输出值是否为零代替导数判断。

前向数值与反向敏感度必须分别检查。

## 初始化为何要随 fan-in 缩放

参数初始化是为训练选择起始权重与偏置的规则，fan-in 是一个输出单元实际接收的输入连接数。连接越多，加权求和的尺度越容易改变，所以初始化需要随连接数和激活方式调整。接下来从二阶矩推导这项尺度选择。





对 \(z=\sum_i w_i x_i\)，设 fan_in=n，初始化权重独立、零均值、方差 \(\sigma_w^2\)，并与输入独立。若输入各坐标二阶矩均为 q，则在对随机初始化取期望后，交叉项因零均值独立权重消失，\(\mathbb E[z^2]=n\sigma_w^2q\)。这里 \(q=\mathbb E[x^2]\)，不要求 x 自身均值为零；条件说的是随机初始化的统计平均，不是每一个有限宽网络都精确保持尺度。偏置非零时还要计入它的贡献。





若 z 的分布关于 0 对称且没有额外偏置，ReLU 保留正半轴，因此 \(\mathbb E[\operatorname{ReLU}(z)^2]=\frac12\mathbb E[z^2]\)。组合两步得到 \(q_{\mathrm{next}}=\frac{n\sigma_w^2}{2}q\)，让 \(q_{\mathrm{next}}\approx q\) 就得到 \(\sigma_w^2=\frac2n\)。对 Leaky ReLU，负半轴斜率为 a，系数改为 \(\frac{1+a^2}2\)，所以对应方差是 \(\frac2{(1+a^2)n}\)。这是增益与 fan_in 出现的原因。



### 例：fan-in=4 时，把二阶矩逐项算出来

1. 在正文的独立、零均值权重与对称预激活假设下，令 fan-in=4，输入二阶矩 q=1，先取权重方差 \(\sigma_w^2=1/4\)。预激活二阶矩为 \(4\times(1/4)\times1=1\)，经过 ReLU 后变成 1/2。

2. 改为 He 方差 \(\sigma_w^2=2/4=1/2\)，预激活二阶矩变为 2，ReLU 后变回 1。保持的是初始化平均意义下的二阶矩，不是每个有限样本的数值。

3. 此时权重标准差是 \(\sqrt{1/2}\approx0.7071\)，不是 0.5。若再假设预激活是高斯，ReLU 输出均值不为零，其方差也不等于这个二阶矩。

fan-in、权重方差、标准差与输出二阶矩是不同的量；先按声明假设算清它们，再解读初始化实验。

二阶矩不等于方差。进一步假设 \(z\sim\mathcal N(0,v)\)，有 \(\mathbb E[\operatorname{ReLU}(z)]=\sqrt{\frac v{2\pi}}\)、\(\mathbb E[\operatorname{ReLU}(z)^2]=\frac v2\)，因此 \(\operatorname{Var}(\operatorname{ReLU}(z))=v\left(\frac12-\frac1{2\pi}\right)\)，约为 \(0.341v\)，而不是 \(\frac v2\)。ReLU 引入了正均值；把它误当作零均值，会在后续推导里混淆要保持的量。





这个尺度设计只约束平均信号强度，不能保证所有输入方向都传播良好。很大与很小的 Jacobian 奇异值可能在同一层并存，平均二阶矩仍然正常。训练后权重相关性、输入分布偏移、残差分支和归一化也会改变近似条件，因此还要看逐层激活与反向信号，而不是将“用了 He 初始化”当成稳定训练的保证。





$$
q_{\ell+1}=\frac{n\sigma_w^2}{2}q_\ell,\quad \sigma_w^2=\frac{2}{n};\qquad \operatorname{Var}(\operatorname{ReLU}(z))=v\left(\frac12-\frac1{2\pi}\right)\ (z\sim\mathcal N(0,v))
$$





### 初始化公式是一组假设下的尺度设计

He 的前向推导保持的是随机初始化平均下的二阶矩；它不保证输出均值为零，也不约束每个方向的 Jacobian 增益。

初始化后用真实形状的输入测量各层均值、二阶矩与梯度，而不只确认调用了某个 init 函数。

## fan-in、fan-out 与权重朝向

fan-in 计数一个输出收到多少输入，fan-out 计数一个输入送往多少输出。它们分别关联前向与反向求和的尺度；Xavier 等规则在这些要求之间作选择。权重存储朝向决定实现怎样读出这两个数量。





对 Linear(D,H)，存储权重为 [H,D]，fan_in=D、fan_out=H。对普通二维卷积，输入通道数与核面积共同影响 fan_in；分组结构改变每个输出实际连接的输入通道数。使用初始化工具时应核对它按哪种布局解释张量。如果自定义参数 W:[D,H] 并计算 x@W，直接使用按 [H,D] 解释的函数可能选错传播轴。





PyTorch 初始化文档明确以 Linear 使用 x@W.T 的存储方式计算 fan。自定义 x@W 时，可传 W.T 给相应初始化函数。fan_in 模式更关注前向尺度，fan_out 模式更关注反向传播尺度；这不是运行时转置网络，而是初始化时选择统计目标。改变后仍应核对输出方差和训练表现，尤其是门控、多分支和特殊参数共享结构。





记 \(n_{\mathrm{in}}=\mathrm{fan\_in}\)、\(n_{\mathrm{out}}=\mathrm{fan\_out}\)。在类似独立性近似下，反向传播到一个输入坐标时要累加 fan_out 条输出路径，ReLU 导数再贡献约 \(\frac12\)，于是反向二阶矩的倍率约为 \(\frac{n_{\mathrm{out}}\sigma_w^2}{2}\)。前向希望 \(\sigma_w^2=\frac2{n_{\mathrm{in}}}\)，反向希望 \(\sigma_w^2=\frac2{n_{\mathrm{out}}}\)；宽度不相等时，单一标量方差通常无法同时满足两者。fan_in/fan_out 不是两个可以互换的参数名称，而是选择优先保持哪一侧的尺度。





Xavier 初始化讨论了另一个基准：近似线性的、零均值信号传播。在权重独立且与信号及上游梯度近似独立时，前向二阶矩倍率为 \(n_{\mathrm{in}}\sigma_w^2\)，反向为 \(n_{\mathrm{out}}\sigma_w^2\)。前向单独要求 \(\sigma_w^2=\frac1{n_{\mathrm{in}}}\)，反向单独要求 \(\sigma_w^2=\frac1{n_{\mathrm{out}}}\)；只有宽度相等时二者可同时成立。令这两个倍率的算术平均为 1，得到 \(\sigma_w^2=\frac2{n_{\mathrm{in}}+n_{\mathrm{out}}}\)，是一个明确的折中选择，而非能同时精确保持两侧尺度的恒等式。





若权重从 \(\mathcal U[-a,a]\) 采样，其方差为 \(\frac{a^2}3\)，因此 Xavier uniform 的边界为 \(a=\sqrt{\frac6{n_{\mathrm{in}}+n_{\mathrm{out}}}}\)；Xavier normal 则使用标准差 \(\sqrt{\frac2{n_{\mathrm{in}}+n_{\mathrm{out}}}}\)。额外 gain 会进一步改变方差。tanh 在零附近近似线性，进入饱和区后导数减小，这个近似便不足以描述整层。ReLU 的门控二阶矩为另一组推导，不能把 Xavier 与 He 的常数无条件互换。





式中的 q 表示对应前向标量坐标的二阶矩，\(q_g\) 表示梯度坐标的二阶矩；它们并不是同一个随机变量的统计量。真实反向梯度通常与前向激活、权重相关，因此这类均值分析适合解释设计出发点，仍需使用实际网络进行验证。





$$
\begin{aligned}q_{\rm out}&\approx n_{\rm in}\sigma_w^2q_{\rm in},\qquad q_{g,\rm in}\approx n_{\rm out}\sigma_w^2q_{g,\rm out},\\ \tfrac12(n_{\rm in}+n_{\rm out})\sigma_w^2&=1\ \Longrightarrow\ \sigma_w^2=\frac{2}{n_{\rm in}+n_{\rm out}},\qquad a=\sqrt{\frac{6}{n_{\rm in}+n_{\rm out}}}.\end{aligned}
$$





### 只看矩阵两条边的长度，不看实际乘法

同一个 [D,H] 参数可能代表不同数学映射，初始化的 fan 定义由运算约定决定。

写出 x@W 或 x@W.T，并手算每个输出累加了多少独立输入项。

## 初始化对称性、参数共享与零分支

初始化对称性是不同隐藏单元在整个计算与初始参数下可以互换的状态；若梯度更新也保持这种对称，它们就无法分化。随机初始化通常用于破坏它。参数共享和残差末端零初始化则有不同目的，需要分别追踪。





若同一隐藏层两个单元拥有相同入边、偏置，并且出边与其余计算也保持交换这两个单元的对称性，那么同一批数据、确定性梯度更新会对它们产生相同梯度；这种完全对称的状态会持续，新增宽度没有带来独立特征。只让入边相同不够：如果两个单元的出边不同，传回的上游梯度可能不同，之后便会分化。随机初始化是常见的破坏对称性的方法，但应明确究竟是哪一组参数和运算保持对称。





某些残差分支最后一层或门控参数采用零初始化，是为了让网络起始接近恒等映射，这需要结合其前面的非零随机特征与计算图分析。最后一层为零时，更早分支参数第一次反向可能拿不到梯度，但最后一层可先更新，后续再打开通路。这与整个 MLP 所有层都置零不同，必须逐层追踪梯度才能判断设计是否合理。





参数共享和对称性也要区分。共享的 Linear 在多个 token 上复用，是有意规定相同映射；同一隐藏层不同单元拥有完全相同参数，则可能没有足够差异化特征。前者减少自由度并表达归纳偏置，后者可能浪费本来准备提供的隐藏宽度。





把整个无旁路 MLP 的所有权重都置零，还可能让中间层之间的梯度乘积直接变零；这与仅把残差分支的末端投影置零不同。后者先由末端投影学习读取非零随机特征，随后允许更早分支参数更新，具体路径见 [残差的参数梯度与初始化](#/learn/residual)。









## 用信号统计和小实验选择配置

前面的统计推导给出了设计依据，但有限宽网络和训练后的相关性未必满足全部近似条件。受控的小实验需要分别检验解析导数、初始信号与实际训练表现，才能判断某项配置改善了哪一段机制。





固定随机种子并创建同一深度与宽度的模型，比较激活和初始化组合。前向记录每层均值、标准差、绝对值范围以及 ReLU 零值比例；反向记录梯度范数与非有限值；最后确认相同训练预算下的误差与验证表现。只看初始输出尺度接近 1，并不能证明更新后仍稳定，因而还需观测训练早期的演化。





配套代码先把三种激活的解析导数与 Autograd 对照，再用完全相同的标准正态权重方向建立两种初始化尺度。无偏置 ReLU 网络的正齐次性给出精确关系：全部 \(L\) 层权重乘 \(c>0\)，最终输出乘 \(c^L\)。代码同时检验这一关系，并打印均值、二阶矩和标准差，区分精确缩放关系与有限宽随机网络的近似统计。实验没有执行优化，不能由这些初始统计直接推断最终任务性能。





常用配置可作为基线，但预训练模型已有特征尺度和参数分布，微调时不应在缺乏依据的情况下重新初始化骨干。新加入的投影层、适配层或门控模块需要单独检查其初始输出对原模型的扰动，并以固定输入对照修改前后的结果。





若模型包含残差相加，两个分支的相关性决定相加后的方差；简单将每个分支都初始化为单位方差，并不能保证相加后仍是单位方差。应检查完整 block 的输出和残差分支相对幅度，而不是只孤立检查其中一层 Linear。





本章的统计实验保留多层网络，检验近似假设下的传播；若要定位单个激活开关如何影响一次更新，可回到 [MLP 的固定参数案例](#/learn/mlp?tab=theory&anchor=section-activations)。先在同一组输入与权重上只改一个偏置，查看 Z 的符号与第一层梯度；再比较整批的二阶矩。局部计算证据与随机初始化的总体统计不能互相替代。





选择激活与初始化，就是共同决定网络开始时表示什么函数、信号怎样通过它。统计推导提供尺度依据，有限网络的前向、梯度与训练对照再说明这套选择在当前任务中是否合适。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| activation input | [B,H] | 逐元素激活通常保持形状 |
| linear weight | [Hout,Hin] | fan_in=Hin，fan_out=Hout |
| gradient | 与输入相同 | 逐元素局部导数与上游梯度相乘 |

## 完整代码与精读

```python
import math
import torch
from torch.nn import functional as F

torch.manual_seed(19)
torch.set_num_threads(1)
dtype = torch.float64
points = torch.tensor([-3., -1., 0., 1., 3.], dtype=dtype, requires_grad=True)
sigmoid = torch.sigmoid(points)
normal_cdf = (1 + torch.erf(points / math.sqrt(2))) / 2
normal_pdf = torch.exp(-points.square() / 2) / math.sqrt(2 * math.pi)
expected = {
    "ReLU": (points > 0).to(dtype),
    "SiLU": sigmoid + points * sigmoid * (1 - sigmoid),
    "GELU": normal_cdf + points * normal_pdf,
}
for name, fn in (("ReLU", F.relu), ("SiLU", F.silu), ("GELU", F.gelu)):
    derivative = torch.autograd.grad(fn(points).sum(), points)[0]
    torch.testing.assert_close(derivative, expected[name], rtol=1e-12, atol=1e-12)
    print(name, "derivative:", derivative.tolist())

# 两种尺度复用相同的标准正态权重方向；偏置均为零，三层均为 ReLU。
width, depth = 64, 3
directions = torch.randn(depth, width, width, dtype=dtype)
x = torch.randn(256, width, dtype=dtype)
he_std = math.sqrt(2 / width)

def run(std):
    h, statistics = x, []
    for direction in directions:
        h = F.relu(h @ (std * direction).T)
        statistics.append((h.mean().item(), h.square().mean().item(), h.std(correction=0).item()))
    return h, statistics

tiny, tiny_stats = run(0.001)
he, he_stats = run(he_std)
# 对这个无偏置 ReLU 网络，正齐次性给出精确的整体缩放关系。
torch.testing.assert_close(tiny, he * (0.001 / he_std) ** depth, rtol=1e-10, atol=1e-14)
print("per layer (mean, second_moment, std)")
print("tiny:", tiny_stats)
print("He-scale:", he_stats)
print("通过：三种激活导数和匹配方向的尺度关系；二阶矩保持是初始化统计近似。")

```

- 第 1–21 行：明确零点次梯度和精确 GELU，逐元素核对 ReLU、SiLU 与 GELU 的解析导数。
- 第 22–27 行：两种配置复用相同随机方向与输入，偏置为零；只改变共同的权重标准差。
- 第 28–34 行：逐层记录均值、二阶矩和总体标准差，避免把二阶矩保持误写为方差严格保持。
- 第 35–42 行：利用 ReLU 正齐次性验证三层整体缩放关系；打印的随机统计仅代表本次固定种子实验。

预期观察：三种解析导数与 Autograd 一致；两种尺度的最终输出严格满足相应的三次方缩放关系。He 尺度的样本二阶矩在本实验中接近 1，但并不保证任何输入、宽度或训练过程都如此。

## 浏览器 Python 练习

输入一组数，返回 (激活列表, 导数列表)。约定 x=0 时导数为 0。

```python
def relu_and_grad(values):
    # TODO: 计算前向值与逐元素局部导数
    raise NotImplementedError("请实现 relu_and_grad")

```

### 提示

- 导数判断使用 x>0，不是 x>=0。
- 真正反向传播时还要乘以上游梯度，本题先返回局部导数。

### 参考实现与解释

```python
def relu_and_grad(values):
    output = [max(0., x) for x in values]
    derivative = [1. if x > 0 else 0. for x in values]
    return output, derivative

```

局部导数不是整个损失对输入的梯度；它只是链式法则中的一个因子。

### 断言测试

```python
y, g = relu_and_grad([-2., -0.1, 0., 0.1, 2.])
assert y == [0., 0., 0., 0.1, 2.]
assert g == [0., 0., 0., 1., 1.]
assert relu_and_grad([]) == ([], [])
upstream = [2., 2., 2., 2., 2.]
assert [a*b for a, b in zip(g, upstream)] == [0., 0., 0., 2., 2.]
print("通过：前向、零点约定与链式法则。")

```

## 本地 PyTorch 练习

为本题中每个后接 ReLU 的 Linear 使用 Kaiming normal，并将存在的 bias 清零。不要创建新参数或改变 requires_grad。

```python
import torch
from torch import nn

def init_relu_mlp(model):
    # TODO: 遍历注册子模块，初始化 Linear
    raise NotImplementedError("请实现 init_relu_mlp")

```

### 提示

- 遍历 model.modules()，仅处理 nn.Linear，并检查 bias 是否存在。
- 原地初始化权重，而不是把层替换为新对象；Kaiming 的 nonlinearity 与后接 ReLU 对应。

### 参考实现与解释

```python
import torch
from torch import nn

def init_relu_mlp(model):
    for layer in model.modules():
        if isinstance(layer, nn.Linear):
            nn.init.kaiming_normal_(layer.weight, nonlinearity="relu")
            if layer.bias is not None:
                nn.init.zeros_(layer.bias)
    return model

```

Kaiming 初始化用 fan_in 控制 ReLU 网络中的信号尺度。测试检查方差、偏置和参数身份，防止初始化函数创建了优化器未登记的新参数。题目约定每个 Linear 都接 ReLU；真实网络的输出层和预训练层需要分别处理。

### 断言测试

```python
torch.manual_seed(11)
model = nn.Sequential(nn.Linear(1000, 200), nn.ReLU(),
                      nn.Linear(200, 40, bias=False), nn.ReLU())
original_ids = [id(p) for p in model.parameters()]
init_relu_mlp(model)
assert [id(p) for p in model.parameters()] == original_ids
assert torch.equal(model[0].bias, torch.zeros_like(model[0].bias))
variance = model[0].weight.var(unbiased=False).item()
assert abs(variance - 2 / 1000) < 0.0002
assert all(p.requires_grad for p in model.parameters())
assert torch.isfinite(model(torch.randn(2, 1000))).all()
print("PyTorch 测试通过：尺度、偏置及参数身份正确。")

```

## 练习：推导与分析

### ReLU 把方差减半，所以 He 初始化乘 2：这句话错在哪里？

对称分布下恰好减半的是二阶矩 \(\mathbb E[z^2]\)，不是一般的方差。ReLU 后均值为正；对零均值高斯输入，输出方差约为 0.341 倍输入方差。正确推导用 \(\mathbb E[\operatorname{ReLU}(z)^2]=\frac12\mathbb E[z^2]\)，再与线性层的 fan_in 累加组合。

He 初始化的 \(\frac2{n_{\mathrm{in}}}\) 是统计传播条件，不是逐样本的精确守恒。改为不同宽度、非零偏置、门控、多分支或训练后的相关权重时，要重新检查近似条件。只看激活标准差，也看不全平均值和二阶矩各自的变化。

新模块应按自己的激活和权重布局初始化。预训练权重已承载学习结果，不能为了统一初始化规则遍历重置整个已有骨干。

代码定位：演示 run(std) 的逐层均值、二阶矩与标准差；初始化参数的 fan_in/fan_out 与实际乘法布局。

- 能从线性层与 ReLU 两步推导 \(\frac2{n_{\mathrm{in}}}\)。
- 能说明二阶矩守恒为什么不等价于方差守恒或所有方向都稳定。

### 某个 ReLU 对一个 Batch 的梯度为零，是否证明整个神经元永久失效？

不证明。负半轴的局部导数是零，但不同输入、偏置变化或上游参数变化仍可能让预激活进入正区间。应观察多个代表性 Batch 的激活分布，而不是只看一次。

局部导数也不等于损失梯度，它还要乘以上游梯度。演示直接求激活和对输入的导数；排障时要进一步区分真正的零梯度和计算图中根本没有该参数导致的 None。

代码定位：relu_and_grad；演示 torch.autograd.grad(fn(points).sum(), points)。

- 能区分单 Batch 现象与整个数据分布。
- 能区分局部导数、最终梯度和 None。

## 练习：辨析与纠错

### 使用输出值判断是否有梯度

\(\operatorname{SiLU}(0)=0\) 但导数为 0.5，负值输出也可具有非零导数。应检查局部导数或实际 grad，而非只看激活是否为零。

### 所有自定义权重都按默认朝向初始化

fan 的解释依赖实际乘法与权重布局。先确认 x@W 还是 x@W.T，再选择正确转置或初始化参数。

### 所有层都置零以求稳定

这可能保持神经元对称并阻断早层学习。区别整个网络置零与特定残差末层置零，逐层确认初始梯度和第一次更新。

### 一次激活统计正常就认为训练稳定

初始化统计只对应初始参数与当前输入。继续观察早期训练、非有限值、梯度和验证表现；不能以单次方差替代完整诊断。

## 原始资料

- [PyTorch：nn.init](https://docs.pytorch.org/docs/stable/nn.init.html)
- [Delving Deep into Rectifiers](https://arxiv.org/abs/1502.01852)
- [Gaussian Error Linear Units](https://arxiv.org/abs/1606.08415)
- [PyTorch：BCEWithLogitsLoss 与稳定二分类损失](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html)
- [Glorot & Bengio：Initialization and Jacobian singular values](https://proceedings.mlr.press/v9/glorot10a.html)
- [动手学深度学习：本章经典图示](https://d2l.ai/chapter_multilayer-perceptrons/mlp.html)
