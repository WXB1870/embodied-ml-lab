# Diffusion：DDPM、目标参数化与 DDIM

从前向边际和高斯后验推导变分目标、噪声回归权重与反向采样。

扩散模型（Diffusion Model）是一类先规定数据逐步加噪的过程、再学习从噪声反向生成数据的概率模型。DDPM 用离散反向转移生成，DDIM 则构造另一种与噪声预测接口配套的采样过程。网络预测什么与采样器怎样更新是两层选择。本章沿同一个二维双峰分布，先认识加噪与去噪的完整流程，再推导后验、训练目标和不同参数化。

## 学习目标

- 逐项推导前向边际、高斯后验与 epsilon 参数化的反向均值
- 解释变分 KL 如何转成带噪声等级权重的回归目标
- 实现并区分 DDPM 相邻步、DDIM 非相邻步及其边界约定

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [生成建模、潜变量与 VAE](https://wxb1870.github.io/embodied-ml-lab/learn/latent-variable-models/)

## 前向加噪、先验与索引约定

前向加噪是一个预先规定的过程，将干净样本逐步衰减并加入已知随机噪声。噪声等级标记数据被破坏的阶段，而不是机器人执行时刻。先定义这个过程、终端先验和索引，再讨论反向生成。





扩散模型规定一个不含可学习参数的前向过程，逐步衰减干净样本并加入高斯噪声，再学习反向生成。记干净样本为 \(a\in\mathbb R^D\)；它也可以是展开后的图像或动作块 [H,D_action]，网络仍可建模相应空间或时间结构。扩散步 k 表示噪声等级，与图像位置、Token 序号或机器人执行步不同。从[潜变量与 VAE](#/learn/latent-variable-models?tab=theory)的视角看，整条加噪轨迹构成一组潜变量，这里的前向推断过程通常由固定 Gaussian 核给定。

![扩散模型固定的前向链从干净样本 a 走向带噪状态，学习的反向链从高斯先验逐步生成数据。](../assets/figures/diffusion-definition.svg)

先分清方向：上排前向链固定，下排反向链需要学习。训练可以直接抽取一个噪声等级，生成则从高噪声状态出发。依据 [Ho et al., Figure 2](https://arxiv.org/abs/2006.11239) 独立绘制；本文用 a 表示干净样本，x[0] 已经过第一次加噪，与原论文用 x₀ 表示干净样本的记号不同。



贯穿本章代码与后续 Score、Flow Matching 的数据固定为二维条件混合分布：\(Y\mid c\sim\sum_{j=1}^2w_{cj}\mathcal N(\mu_{cj},s_d^2I)\)，\(c\in\{0,1\}\)、\(s_d=0.28\)。条件 0 的两个中心为 \((-1.6,-0.6)\)、\((1.6,0.6)\)，权重为 \((0.35,0.65)\)；条件 1 的中心为 \((-0.6,1.6)\)、\((0.6,-1.6)\)，权重为 \((0.65,0.35)\)。选择有解析密度的同一数据，是为了改变生成机制时仍能独立核对目标，绝不意味着几种方法的中间路径相同。





令 \(\beta_k\) 为每步噪声方差比例，\(\alpha_k=1-\beta_k\)。采用零起始数组索引 \(k=0,\ldots,K-1\)，第一次加噪之后的状态记作 \(x_k\)，原始干净动作仍记 a，避免把代码里的 x[0] 与论文里的干净 \(x_0\) 混淆。\(\beta\) 的范围与顺序必须明确，越界会使平方根或方差失去含义。





反向采样通常从标准高斯出发，因此前向最终分布应足够接近这个起始分布。需要检查最终累计信号系数 \(\bar\alpha_{K-1}\)；若它仍很大，训练末端还包含明显动作信号，推理起点就与训练分布不同。步数、日程和终端信噪比需要一起记录。





$$
q(x_k\mid x_{k-1})=\mathcal N(\sqrt{\alpha_k}x_{k-1},\beta_k I),\qquad \alpha_k=1-\beta_k
$$





### 先固定噪声等级的索引约定

论文常用 1…K，数组常用 0…K−1；二者混用会影响累计乘积、前一系数与最后一步。

列出 \(k=0\)、k=1、k=K−1 对应的 \(\alpha\)、\(\bar\alpha\)、前一 \(\bar\alpha\)，并说明干净端如何表示。

## 为什么可以一步构造任意噪声等级

累计信号系数记录经过多级加噪后仍保留多少原始信号。高斯转移的组合允许直接构造任意等级的带噪样本，无需逐步模拟整个前向链。下面推导这项捷径，再跟踪同一二维探针。





设前一级可写为 \(x_{k-1}=\sqrt{\bar\alpha_{k-1}}\,a+\sqrt{1-\bar\alpha_{k-1}}\,\epsilon'\)，其中 \(\epsilon'\) 为标准高斯。代入 \(x_k=\sqrt{\alpha_k}\,x_{k-1}+\sqrt{\beta_k}\,\xi\)，且 \(\xi\) 与 \(\epsilon'\) 独立，得到信号系数 \(\sqrt{\alpha_k\bar\alpha_{k-1}}\)。两个噪声项的方差相加为 \(\alpha_k(1-\bar\alpha_{k-1})+\beta_k=1-\alpha_k\bar\alpha_{k-1}\)。从干净边界 \(\bar\alpha_{-1}=1\) 归纳，得到 \(\bar\alpha_k=\prod_{j=0}^k\alpha_j\) 以及 \(q(x_k\mid a)=\mathcal N\!\left(\sqrt{\bar\alpha_k}\,a,(1-\bar\alpha_k)I\right)\)。因此训练时可以直接抽一个噪声等级构造 \(x_k\)，无需实际模拟整条前向链。



### 例：同一二维样本经过两级加噪

1. 取 \(\beta_0=\beta_1=0.2\)，则 \(\alpha_0=\alpha_1=0.8\)，累计系数 \(\bar\alpha_1=0.64\)。

2. 从条件 0 的一个分量中心取确定性探针 \(a=(1.6,0.6)\)，噪声取 \(\epsilon=(-1,2)\)。直接构造 \(x_1=\sqrt{0.64}a+\sqrt{0.36}\epsilon=(0.68,1.68)\)。

3. 训练网络读取 \(x_1,k=1,c=0\)，预测这份隐藏噪声 \(\epsilon\)。将单步 \(\alpha_1=0.8\) 误作累计系数，会构造不同的中间分布。

这对固定向量随后用于恢复干净值；训练时仍抽取新的数据、噪声与等级。

对 [B,H,D] 动作块，可以给每个样本采一个 k:[B]，查表得到 \(\bar\alpha\):[B]，再变成 [B,1,1] 广播。若不增加这两个单例轴，在 B 恰好等于 D 时，错误代码可能沿动作维广播而没有报错。需要用 B、H、D 不相等的样例验证，不能只测试形状凑巧相同的方阵。





噪声 \(\epsilon\) 与干净动作 a 的配对、所采等级 k，共同决定训练目标。计算 \(x_k\) 之后重新采一份 \(\epsilon\) 当标签，会破坏同一个前向样本的关系。固定随机三元组并做端点检查，是排查这一类错误的有效方法。\(\bar\alpha=1\) 应还原干净动作，\(\bar\alpha=0\) 应只剩噪声；内部调度器不一定实际包含这两个端点，但测试公式时可以检查。





$$
x_k=\sqrt{\bar\alpha_k}\,a+\sqrt{1-\bar\alpha_k}\,\varepsilon,\qquad \bar\alpha_k=\prod_{j=0}^{k}(1-\beta_j)
$$





## 噪声回归目标与条件的作用

噪声回归是让网络从带噪状态、噪声等级和可用条件，预测构造该状态时加入的噪声。训练端知道这份噪声，所以可以建立监督；推理端再用预测构造反向更新。先认识这个输入输出任务，再解释其概率依据。





常见训练目标是预测构造 \(x_k\) 时用到的 \(\epsilon\)，并最小化预测与真实噪声之间的平方误差。网络输入包括 \(x_k\)、等级 k 及观测条件 c。只给 \(x_k\) 不给 k，会让同一个数值在不同信噪比下需要不同解释；只给 k 不给 c，则无法根据图像、状态或指令选择条件动作分布。





固定 \(x_k\)、k、c 时，可能有多组干净动作与噪声产生同一个中间状态。MSE 最优预测是 \(\mathbb E[\epsilon\mid x_k,k,c]\)，不是逐个记住所有隐藏配对的那一份噪声。因此持续重采样下的损失不一定趋于零，不能看到非零训练误差就认定训练管线有问题。固定有限三元组的最小过拟合测试与真实随机训练目标是两种实验。





原始变分目标可导出不同等级的权重，常用简化噪声 MSE 是具体选择；完整来源在后文[回看训练目标](#/learn/diffusion?section=variational-objective)中推导。改变等级采样分布或时间权重，会改变有限模型更关注的区域；比较实验应记录这些设定。动作有效位、各维尺度与归约方式同样参与目标定义，只报告一个总噪声 MSE 可能掩盖关键动作维或某个噪声区间失效。





在这份混合数据上，`oracle_noise` 可以显式计算 \(\mathbb E[\epsilon\mid x_k,k,c]\)，因此完整训练示例同时报告“网络对采样噪声的误差”和“网络对解析最优预测的误差”。两者分别包含不同误差来源；前者不应被要求降到零。解析计算及与速度场的转换见 [同一二维分布上的两条路径](#/learn/score-sde?tab=theory&section=shared-mixture)。





$$
L_\epsilon=\mathbb E_{a,c,k,\varepsilon}\big[\|\varepsilon_\theta(x_k,k,c)-\varepsilon\|^2\big]
$$





### 把随机噪声回归的残余误差当作必然欠拟合

中间状态可能对应多个隐藏端点配对，条件方差构成不可消除的回归误差。

分别检查固定三元组拟合和重采样验证，并按噪声等级分桶报告误差。

## epsilon、干净动作与 v 预测不能混用

扩散输出参数化规定网络预测的是噪声、干净样本，还是两者的某种线性组合。它们具有相同形状，却要用不同公式进入采样器。下面用同一个带噪点说明怎样恢复数据，以及误读输出会产生什么。





已知当前 \(x_k\) 与预测噪声 \(\hat\epsilon\)，可以解出干净动作估计 \(\hat a=\frac{x_k-\sqrt{1-\bar\alpha_k}\,\hat\epsilon}{\sqrt{\bar\alpha_k}}\)。它是估计值，不是直接执行噪声输出；\(\bar\alpha\) 很小时，这个代数恢复还可能放大噪声预测误差。训练目标、网络输出和采样器的 prediction_type 必须一致，即使三者张量形状相同。



### 例：从同一个带噪点恢复数据，而非直接执行噪声

1. 沿用 \(\bar\alpha=0.64,a=(1.6,0.6),\epsilon=(-1,2)\)，带噪点是 \(x=(0.68,1.68)\)。

2. 若噪声预测恰为 \((-1,2)\)，则 \(\hat a=(x-0.6\hat\epsilon)/0.8=(1.6,0.6)\)。实际网络有预测误差，采样器仍需按声明的转移继续更新。

3. 直接输出 \(\hat\epsilon=(-1,2)\) 或 \(x=(0.68,1.68)\)，虽然同为二维，却没有得到干净样本。若生成变量是动作，之后还要进行对应的反归一化与动作解码。

输出参数化决定数值的含义；恢复关系不等于单步采样已经完成。

有些模型直接预测干净样本，有些使用特定日程定义的 v 参数化。对于常见 VP 记法，\(v=\sqrt{\bar\alpha}\,\epsilon-\sqrt{1-\bar\alpha}\,a\)；它与本网站线性 Flow Matching 路径的速度 \(a-\mathrm{noise}\) 不是同一个量。变量都叫 velocity 并不保证可互换，必须从路径系数与导数重新推导转换。





用已知噪声恢复干净动作，是检查公式的测试夹具：先人为加噪，再使用同一噪声解码，结果应还原原值。这个测试不依赖神经网络预测，检验的是参数化变换与广播是否正确，不能宣称网络已学会去噪。之后还需检查真实预测输出，并用与训练匹配的采样器生成完整动作分布。





$$
\hat a=\frac{x_k-\sqrt{1-\bar\alpha_k}\hat\varepsilon}{\sqrt{\bar\alpha_k}},\qquad v=\sqrt{\bar\alpha_k}\varepsilon-\sqrt{1-\bar\alpha_k}a
$$





## 输出可以换算，损失权重却不会自动相同

VP 的 v 参数化是按当前信号与噪声系数组合噪声和干净数据的预测目标。它不是仅凭名字就等同于任意 Flow 速度。固定等级下可作代数换算，误差权重却会随系数改变；下面分别推导。





在某个固定噪声等级，简写 \(\alpha=\sqrt{\bar\alpha}\)、\(\sigma=\sqrt{1-\bar\alpha}\)，于是 \(x=\alpha a+\sigma\epsilon\)，且 \(\alpha^2+\sigma^2=1\)。VP 的 v 参数化定义为 \(v=\alpha\epsilon-\sigma a\)。把这两式看成一个二维旋转，可以直接反解 \(a=\alpha x-\sigma v\)、\(\epsilon=\sigma x+\alpha v\)，从而得到相应的恢复公式。这里 a 是干净动作，不能与当前噪声状态 x 混用。





可代数转换不等于训练等价。若 \(\hat a\) 与 \(\hat\epsilon\) 用同一个 x 按公式相互转换，则 \(\hat\epsilon-\epsilon=-\frac{\alpha}{\sigma}(\hat a-a)\)。所以固定等级上的噪声平方误差等于 \(\mathrm{SNR}=\frac{\alpha^2}{\sigma^2}\) 倍的干净样本平方误差。类似地，由 \(\hat a=\alpha x-\sigma\hat v\) 得到 \(\lVert\hat v-v\rVert^2=\frac{\lVert\hat a-a\rVert^2}{\sigma^2}\)。对等级均匀采样且都使用无权重 MSE，会给同一干净样本误差不同的时间权重。





当 \(\sigma\) 很小，噪声 MSE 对干净样本误差的等效权重很大；当 \(\alpha\) 很小，从噪声恢复干净值中的除 \(\alpha\) 又会放大预测误差。这些是不同方向的变换，不能笼统说某种输出“更稳定”。上述比值只在分母非零的等级使用，端点应由原始方程或极限处理。





v 的名字还有一个容易混淆的来源。令 \(\alpha=\cos\phi\)、\(\sigma=\sin\phi\)，固定端点时 \(\frac{dx}{d\phi}=-\sin\phi\,a+\cos\phi\,\epsilon=v\)。它是关于角度 \(\phi\) 的导数；若实际时间是 t，则 \(\frac{dx}{dt}=\phi'(t)v\)。线性 FM 的 \(a-\mathrm{noise}\) 来自另一条路径与时间方向，不能直接替换这个 v。





$$
\begin{aligned}a&=\alpha x-\sigma v,&\varepsilon&=\sigma x+\alpha v\\L_\varepsilon&=\frac{\alpha^2}{\sigma^2}L_a,&L_v&=\frac{1}{\sigma^2}L_a\end{aligned}
$$

```python
import math

alpha, sigma = 0.8, 0.6
clean, noise = 2.0, -1.0
x = alpha * clean + sigma * noise
v = alpha * noise - sigma * clean
assert math.isclose(alpha * x - sigma * v, clean)
assert math.isclose(sigma * x + alpha * v, noise)

clean_hat = clean + 0.3
noise_hat = (x - alpha * clean_hat) / sigma
v_hat = (alpha * x - clean_hat) / sigma
loss_clean = (clean_hat - clean) ** 2
loss_noise = (noise_hat - noise) ** 2
loss_v = (v_hat - v) ** 2
assert math.isclose(loss_noise / loss_clean, alpha ** 2 / sigma ** 2)
assert math.isclose(loss_v / loss_clean, 1 / sigma ** 2)
print('x, v:', x, v)
print('clean / noise / v losses:', loss_clean, loss_noise, loss_v)
```

先用真实 a、\(\epsilon\) 验证正反变换，再人为给 \(\hat a\) 一个相同的 0.3 误差。由同一 \(\hat a\) 推出的 \(\hat\epsilon\)、v̂ 描述一致的预测，但三个 MSE 分别为 0.09、0.16、0.25。换到其他噪声等级，比例会再次变化，因此单纯切换 prediction_type 并不保留训练目标。





## 反向一步的均值、方差与最后一步

反向转移是从当前噪声等级采到前一级状态的条件分布，包含预测均值和采样方差。DDPM 的一次生成更新据此组合当前状态、网络预测与新噪声。最后一步的边界也属于这个分布定义。





在 epsilon 参数化的标准 DDPM 形式中，反向均值由当前 \(x_k\) 与预测噪声组成：\(\mu_\theta=\frac{1}{\sqrt{\alpha_k}}\left[x_k-\frac{\beta_k\hat\epsilon}{\sqrt{1-\bar\alpha_k}}\right]\)。若采用前向后验方差，\(\tilde\beta_k=\frac{\beta_k(1-\bar\alpha_{k-1})}{1-\bar\alpha_k}\)。以下采用这一方差选择，其他实现还可能使用不同固定方差或学习方差，不能仅凭“DDPM”名称假设完全相同。 均值与方差的来源将在后文[给定干净样本的高斯后验](#/learn/diffusion?section=posterior-derivation)中推导，先把它们接成一次完整生成更新。





随后从 \(\mu_\theta+\sqrt{\tilde\beta_k}\,z\) 得到下一个状态，其中 z 是新的标准高斯噪声；它不是训练时的那份 \(\epsilon\)，也不是网络输出。对于数组的最后生成一步 \(k=0\)，把前一累计系数视为 1，后验方差为零，直接返回均值，不再添加噪声。若在这一点仍加随机项，得到的是被重新污染的终端输出。





需要同时核对平方根、累计乘积和边界索引。把 \(\tilde\beta\) 当标准差直接乘 z，会把方差缩小一次；读取数组 [-1] 来表示干净端，会错误取到最高噪声端。最后一步应写成明确分支，并用任意巨大 noise 输入验证其结果完全不受影响。





$$
\mu_\theta=\frac1{\sqrt{\alpha_k}}\left(x_k-\frac{\beta_k}{\sqrt{1-\bar\alpha_k}}\hat\varepsilon\right),\quad \tilde\beta_k=\beta_k\frac{1-\bar\alpha_{k-1}}{1-\bar\alpha_k},\quad \bar\alpha_{-1}=1
$$





### 把上一等级的数组索引写成无条件 k−1

\(k=0\) 时 Python 的 −1 是数组尾部，不是理论中的干净边界。

分别测试 \(k=0\) 与 k>0：前者应忽略 noise，后者在给定噪声与系数后应有可手算结果。

## 采样日程不能任意删步

训练噪声日程规定各等级的数据分布，采样网格规定推理选择哪些等级与跨度。跳过中间等级会改变所需转移，不能只删循环而沿用相邻系数。下面先区分这两份日程，再介绍跨等级更新。





推理从最高噪声状态出发，按所选反向日程逐步更新，条件 c 通常在这一动作块的生成期间保持固定。前面给出的一步公式对应特定相邻等级；如果只保留每十个训练等级，却继续使用相邻等级的 \(\beta\) 和 \(\tilde\beta\)，并没有正确实现跳步采样。减少步数需要采用与间隔一致的系数或对应采样算法。





DDIM、不同 ODE/SDE 采样器以及蒸馏模型提供不同速度与误差取舍，它们不是在 for 循环里简单改 range 就等价。比较时除步数外，还需记录网络调用次数、实际延迟、噪声随机性和任务成功率。固定初始噪声只固定了起点；随机 DDPM 的中间噪声也必须固定，才能获得可重复对照。





采样通常使用 eval 和 no_grad，避免 Dropout 或梯度图带来额外变化及内存开销，但两者处理不同问题。模型架构里若含需要模式切换的模块，只有 no_grad 并不能切换其行为。任何采样优化都应先通过公式和数值对照，再到真实条件上评估生成质量。









## 确定性 DDIM 的非相邻步更新

DDIM 是一类与扩散噪声预测配套的采样构造，确定性版本在给定初始噪声后不再每步加入新随机量。它通过干净样本估计重新组合目标等级状态，因此可以明确处理非相邻等级。下面核对两端系数。





确定性 DDIM 对应 \(\eta=0\)。设当前噪声等级为 t，目标等级 s 更接近干净端点；使用累计系数 \(\bar\alpha\)，而不是某个相邻步的 \(\alpha\) 或 \(\beta\)。对常见的前向加噪索引，\(s<t\) 对应 \(\bar\alpha_s>\bar\alpha_t\)。先由当前噪声预测恢复干净动作估计，再用目标累计系数重组这个估计和同一份预测噪声，就可以直接到达一个非相邻等级。





下面公式假设模型输出 \(\epsilon\)，且不对干净动作估计做裁剪、动态阈值或投影，也不注入额外随机噪声。若模型输出干净动作或 v，需要先按前文关系转换，不能直接代入 \(\epsilon\) 的位置。\(\bar\alpha_t\) 必须大于零；\(\bar\alpha_s=1\) 是干净端点，此时返回干净动作估计。相同累计系数对应恒等更新，可以用于检查实现。





对 \(0<\bar\alpha_t\le\bar\alpha_s\le1\) 且 \(\bar\alpha_t<1\) 的带噪起点，更一般的 DDIM 更新可加入标准差 \(\rho_{t\to s}=\eta\sqrt{\frac{1-\bar\alpha_s}{1-\bar\alpha_t}}\sqrt{1-\frac{\bar\alpha_t}{\bar\alpha_s}}\)：\(x_s=\sqrt{\bar\alpha_s}\,\hat a+\sqrt{1-\bar\alpha_s-\rho^2}\,\hat\epsilon+\rho z\)，其中 z 是新抽的单位高斯，\(0\le\eta\le1\)。\(\eta=0\) 恢复下面的确定性公式；\(\eta=1\) 且 s 是相邻前一等级时，\(\rho^2\) 等于前向后验方差，均值也可化简成相应 DDPM 均值。这种联系依赖同一累计系数、epsilon 参数化和未额外裁剪的设置。





采样时要在所选日程的每个当前等级重新计算模型输出，再使用该步的两个累计系数更新。固定初始噪声、条件和确定性的模型计算后，\(\eta=0\) 的过程是确定的；减少步数仍可能放大模型预测误差。它不能被解释为把相邻 DDPM 公式中的索引直接跳过，也不保证任意少的步数具有相同的生成质量。





代码用已知干净动作和噪声构造一个 oracle：只要 \(\epsilon\) 预测准确，跨步结果就应落在由这两者定义的目标噪声等级。它验证公式、方向及端点约定，不验证神经网络是否学会了正确的条件分布。实际调度器若启用了裁剪等选项，还需要检查其噪声重计算约定。





$$
\hat a=\frac{x_t-\sqrt{1-\bar\alpha_t}\,\hat\epsilon_\theta(x_t,t,c)}{\sqrt{\bar\alpha_t}},\qquad x_s=\sqrt{\bar\alpha_s}\,\hat a+\sqrt{1-\bar\alpha_s}\,\hat\epsilon_\theta(x_t,t,c),\qquad 0<\bar\alpha_t\le\bar\alpha_s\le1\quad(\eta=0).
$$

```python
import math
import torch


def ddim_step(x_t, eps_hat, alpha_bar_t, alpha_bar_s):
    """eta=0；epsilon 参数化；累计系数是标量；不做裁剪或额外加噪。"""
    if x_t.shape != eps_hat.shape:
        raise ValueError("x_t and eps_hat must have the same shape")
    if not x_t.is_floating_point() or x_t.dtype != eps_hat.dtype or x_t.device != eps_hat.device:
        raise ValueError("inputs must share a floating dtype and device")
    at, as_ = float(alpha_bar_t), float(alpha_bar_s)
    if not (math.isfinite(at) and math.isfinite(as_) and 0.0 < at <= as_ <= 1.0):
        raise ValueError("require 0 < alpha_bar_t <= alpha_bar_s <= 1")
    # sqrt 使用同一设备和精度；alpha_bar_t=0 不允许除法恢复干净动作。
    at = x_t.new_tensor(at)
    as_ = x_t.new_tensor(as_)
    clean_hat = (x_t - (1 - at).sqrt() * eps_hat) / at.sqrt()
    return as_.sqrt() * clean_hat + (1 - as_).sqrt() * eps_hat


# Oracle 验证：已知干净动作与噪声，检查跨步公式能否恢复同一条路径。
clean = torch.tensor([[-0.8, 0.2], [0.5, 1.1]], dtype=torch.float64)
noise = torch.tensor([[0.3, -0.7], [1.2, -0.4]], dtype=torch.float64)
at, as_ = 0.16, 0.64
x_t = math.sqrt(at) * clean + math.sqrt(1 - at) * noise
expected_s = math.sqrt(as_) * clean + math.sqrt(1 - as_) * noise
x_s = ddim_step(x_t, noise, at, as_)
torch.testing.assert_close(x_s, expected_s, rtol=1e-12, atol=1e-12)
# 干净端点 alpha_bar_s=1；相同系数对应恒等更新。
torch.testing.assert_close(ddim_step(x_t, noise, at, 1.0), clean, rtol=1e-12, atol=1e-12)
torch.testing.assert_close(ddim_step(x_t, noise, at, at), x_t, rtol=1e-12, atol=1e-12)
for bad_at, bad_as in [(0.0, 0.64), (0.64, 0.16), (0.16, 1.1)]:
    try:
        ddim_step(x_t, noise, bad_at, bad_as)
        raise AssertionError("invalid coefficients were accepted")
    except ValueError:
        pass
print("DDIM checks passed; max error:", (x_s - expected_s).abs().max().item())

```

ddim_step 只负责 \(\eta=0\) 的单步代数更新，输入的 alpha_bar_t 与 alpha_bar_s 是累计系数。Oracle 检查跨越非相邻噪声等级、到达干净端点、恒等更新及非法系数；容差采用 float64 精度。真实采样循环中，eps_hat 应由模型使用当前 \(x_t\)、当前时间与条件重新预测。





## 回看反向一步：给定干净样本的高斯后验

前面已经按给定均值和方差完成了反向更新，现在回头推导这两个量的来源。这里的条件后验是已知当前带噪状态与干净训练样本时，前一级状态的分布。它是训练中可计算的比较对象，与生成时没有干净答案的反向模型不同。





反向生成需要 \(p_\theta(x_{k-1}\mid x_k,c)\)，但真实反向分布要对未知干净数据积分，通常不易直接计算。训练时已经知道 a，因此可计算 \(q(x_{k-1}\mid x_k,a)\)。前向 Markov 性给出 \(q(y\mid x_k,a)\propto q(x_k\mid y)q(y\mid a)\)，其中 \(y=x_{k-1}\)。这两个分布都是高斯，关于 y 的指数是二次函数。





下面先限制 \(k\ge1\)，使 \(1-\bar\alpha_{k-1}>0\)。将两个平方展开，\(y^\top y\) 的系数给出精度 \(\Lambda=\frac{\alpha_k}{\beta_k}+\frac{1}{1-\bar\alpha_{k-1}}\)；线性项给出自然均值参数 \(\eta=\frac{\sqrt{\alpha_k}\,x_k}{\beta_k}+\frac{\sqrt{\bar\alpha_{k-1}}\,a}{1-\bar\alpha_{k-1}}\)。高斯配方因此得到协方差 \(\Lambda^{-1}I\)、均值 \(\Lambda^{-1}\eta\)。





利用 \(\bar\alpha_k=\alpha_k\bar\alpha_{k-1}\) 化简，得到后验方差 \(\tilde\beta_k=\frac{\beta_k(1-\bar\alpha_{k-1})}{1-\bar\alpha_k}\)，以及下式的干净样本项与当前噪声状态项。这个后验使用了训练时的 a；部署网络不能把 a 当作已知输入，因此还需学习能从 \(x_k,k,c\) 提供相关信息的预测器。





由 \(x_k=\sqrt{\bar\alpha_k}\,a+\sqrt{1-\bar\alpha_k}\,\epsilon\) 解出 a，并代入后验均值，可得 \(\frac{1}{\sqrt{\alpha_k}}\left[x_k-\frac{\beta_k\epsilon}{\sqrt{1-\bar\alpha_k}}\right]\)。这一步说明 epsilon 参数化的均值形式从何而来。训练样本中的 \(\epsilon\) 是一个隐藏端点配对的噪声，网络对给定 \(x_k\) 的 MSE 最优预测仍是其条件均值。





\(k=0\) 对应从第一个噪声状态返回干净 a，给定 a 的后验退化为点质量，不能把含 \(\log\tilde\beta_0\) 的普通高斯 KL 公式直接使用。变分目标在这里单独使用解码似然项；教学采样代码最后返回均值，是输出规则，不是已经计算了这个解码似然。





$$
\begin{aligned}
\log q(y\mid x_k,a)&=C-\frac{\|x_k-\sqrt{\alpha_k}y\|^2}{2\beta_k}
-\frac{\|y-\sqrt{\bar\alpha_{k-1}}a\|^2}{2(1-\bar\alpha_{k-1})}\\
\tilde\beta_k&=\frac{\beta_k(1-\bar\alpha_{k-1})}{1-\bar\alpha_k},\\
\tilde\mu_k&=\frac{\sqrt{\bar\alpha_{k-1}}\beta_k}{1-\bar\alpha_k}a+
\frac{\sqrt{\alpha_k}(1-\bar\alpha_{k-1})}{1-\bar\alpha_k}x_k,\qquad k\ge1 .
\end{aligned}
$$

```python
import math
import torch

torch.set_default_dtype(torch.float64)
beta = torch.tensor(0.12)
alpha = 1 - beta
alpha_bar_previous = torch.tensor(0.72)
alpha_bar = alpha_bar_previous * alpha
clean = torch.tensor([[-0.7, 1.2], [0.4, -1.1]])
noise = torch.tensor([[0.3, -0.2], [1.3, 0.6]])
noisy = alpha_bar.sqrt()*clean + (1-alpha_bar).sqrt()*noise

# Complete the square in the product q(x_k|y) q(y|clean).
precision = alpha/beta + 1/(1-alpha_bar_previous)
natural_mean = alpha.sqrt()*noisy/beta + alpha_bar_previous.sqrt()*clean/(1-alpha_bar_previous)
posterior_variance = beta*(1-alpha_bar_previous)/(1-alpha_bar)
posterior_mean = (
    alpha_bar_previous.sqrt()*beta/(1-alpha_bar)*clean
    + alpha.sqrt()*(1-alpha_bar_previous)/(1-alpha_bar)*noisy)
torch.testing.assert_close(precision.reciprocal(), posterior_variance)
torch.testing.assert_close(natural_mean/precision, posterior_mean)

# The same mean can be parameterized by the sampled forward noise.
epsilon_form = (noisy-beta/(1-alpha_bar).sqrt()*noise)/alpha.sqrt()
torch.testing.assert_close(epsilon_form, posterior_mean)
print("posterior variance:", posterior_variance.item())
print("max mean difference:", (natural_mean/precision-posterior_mean).abs().max().item())

# This posterior is non-degenerate only for k>=1 in the zero-based convention.
clean_boundary_variance = beta * (1-1) / (1-alpha)
assert clean_boundary_variance == 0
print("passed: Gaussian product, epsilon mean and clean-boundary variance")

```

先按自然参数计算两个 Gaussian 核的乘积，再与化简后的后验均值/方差对照；最后代入已知前向噪声验证 epsilon 形式。这个 oracle 不使用学习网络，能够把公式错误与模型预测误差分开。





## 回看训练目标：从轨迹 ELBO 到噪声回归

前面用噪声 MSE 训练了回归器，下面再问它与数据似然是什么关系。轨迹 ELBO 把整条加噪过程看作潜变量，将全局生成目标分解为若干反向分布的局部比较，由此导出带时间权重的噪声回归。这个推导也说明简化目标省去了哪些权重。





固定一个训练样本 \((a,c)\)，把整条噪声轨迹 \(x_{0:K-1}\) 视为潜变量。生成联合分布为 \(p_\theta(a,x_{0:K-1}\mid c)=p(x_{K-1})p_\theta(a\mid x_0,c)\prod_{k=1}^{K-1}p_\theta(x_{k-1}\mid x_k,c)\)。以前向链 \(q(x_{0:K-1}\mid a)\) 作为变分分布，[VAE 的 ELBO](#/learn/latent-variable-models?tab=theory&section=elbo-derivation) 给出负对数似然的上界：





\[L_{\rm VLB}=\mathbb E_q\!\left[\log q(x_{0:K-1}\mid a)-\log p_\theta(a,x_{0:K-1}\mid c)\right]\ge-\log p_\theta(a\mid c).\]





要把这个整条轨迹的比值变成局部比较，关键是对同一个前向联合分布采用反向链式分解。固定 \(a\) 后，Markov 链的反向条件只需当前 \(x_k\) 与 \(a\)，因此 \(q(x_{0:K-1}\mid a)=q(x_{K-1}\mid a)\prod_{k=1}^{K-1}q(x_{k-1}\mid x_k,a)\)。这里是在重写已知分布，不是声明训练时已经学到了反向模型。





将这两个乘积放入对数比，逐项得到终端项 \(\log[q(x_{K-1}\mid a)/p(x_{K-1})]\)、各级项 \(\log[q(x_{k-1}\mid x_k,a)/p_\theta(x_{k-1}\mid x_k,c)]\)，以及 \(-\log p_\theta(a\mid x_0,c)\)。对各级项先按 \(q(x_{k-1}\mid x_k,a)\) 求期望，它就成为一个 KL；再按 \(q(x_k\mid a)\) 求期望。这个全期望步骤解释了为什么最终出现“局部 KL 的平均”。





具体地，负 ELBO 为 \[L_{\rm prior}+\sum_{k=1}^{K-1}\mathbb E_{q(x_k\mid a)}\!\left[D_{\rm KL}\!\left(q(x_{k-1}\mid x_k,a)\,\Vert\,p_\theta(x_{k-1}\mid x_k,c)\right)\right]+L_{\rm recon}\]\(L_{\rm prior}=D_{\rm KL}\!\left(q(x_{K-1}\mid a)\,\Vert\,p(x_{K-1})\right)\)；当前向日程和先验固定时，它不参与 \(\theta\) 的梯度。\(L_{\rm recon}=\mathbb E_{q(x_0\mid a)}[-\log p_\theta(a\mid x_0,c)]\)。这一分解把困难的整条轨迹比值转为可计算的局部 Gaussian 比较。





设反向模型使用固定协方差 \(\rho_k^2 I\)，而均值采用 epsilon 参数化。两个 Gaussian 的 KL 中，只有均值平方差依赖这个预测网络；协方差比值、对数行列式等合并成 \(C_k\)。用上一节的均值形式相减，差值恰好是 \(-\frac{\beta_k(\epsilon_\theta-\epsilon)}{\sqrt{\alpha_k}\sqrt{1-\bar\alpha_k}}\)。因此相应 \(\theta\) 目标等于 \(\lambda_k\lVert\epsilon_\theta-\epsilon\rVert^2\)，\(\lambda_k=\frac{\beta_k^2}{2\rho_k^2\alpha_k(1-\bar\alpha_k)}\)。





若反向方差也由网络学习，则协方差项一般依赖 \(\theta\)，不能继续删除 \(C_k\) 或只训练这个简单 MSE。\(k=0\) 的重建项、先验项和离散数据的解码约定也需要单独处理；因此“DDPM loss 就是任意 mean MSE”并不准确。





常用 \(L_{\rm simple}\) 对噪声等级均匀采样并使用无权重 epsilon MSE，是对原始变分目标的重新加权。若以非均匀概率 \(r(k)>0\) 抽样，却仍想估计某个指定的求和目标 \(\sum_k\lambda_k L_k\)，应使用 \(\lambda_k/r(k)\) 的重要性权重；若目标是等级平均，还要包含相应的总数因子。有限模型容量下，改变权重会改变优化关注的噪声区间。





下面代码故意选择与真实后验不同的固定反向方差，验证 KL=加权 MSE+常数，并比较两者对 \(\epsilon_\theta\) 的 Autograd 梯度。它检验的是给定固定方差与索引条件下的恒等式，不比较不同训练目标在真实数据上的最终性能。





$$
\begin{aligned}
L_{\mathrm{VLB}}&=L_{\mathrm{prior}}+
\sum_{k=1}^{K-1}\mathbb E\,D_{\mathrm{KL}}\!\left(q(x_{k-1}\mid x_k,a)\Vert p_\theta(x_{k-1}\mid x_k,c)\right)+L_{\mathrm{recon}},\\
D_{\mathrm{KL}}&=\frac{\|\tilde\mu_k-\mu_\theta\|^2}{2\rho_k^2}+C_k\\
&=\underbrace{\frac{\beta_k^2}{2\rho_k^2\alpha_k(1-\bar\alpha_k)}}_{\lambda_k}
\|\epsilon_\theta(x_k,k,c)-\epsilon\|^2+C_k .
\end{aligned}
$$

```python
import torch

torch.set_default_dtype(torch.float64)
beta = torch.tensor(0.12)
alpha = 1-beta
ab_previous = torch.tensor(0.72)
ab = alpha*ab_previous
posterior_variance = beta*(1-ab_previous)/(1-ab)
reverse_variance = beta  # Fixed, intentionally different from the posterior.
clean = torch.tensor([[-0.7,1.2],[0.4,-1.1]])
noise = torch.tensor([[0.3,-0.2],[1.3,0.6]])
noisy = ab.sqrt()*clean + (1-ab).sqrt()*noise
epsilon_hat = (noise + torch.tensor([[0.2,-0.3],[0.1,0.4]])).requires_grad_()
posterior_mean = (noisy-beta/(1-ab).sqrt()*noise)/alpha.sqrt()
model_mean = (noisy-beta/(1-ab).sqrt()*epsilon_hat)/alpha.sqrt()
q = torch.distributions.Independent(
    torch.distributions.Normal(posterior_mean, posterior_variance.sqrt()), 1)
p = torch.distributions.Independent(
    torch.distributions.Normal(model_mean, reverse_variance.sqrt()), 1)
kl = torch.distributions.kl_divergence(q,p)
weight = beta.square()/(2*reverse_variance*alpha*(1-ab))
weighted_noise_error = weight*(epsilon_hat-noise).square().sum(-1)
dimension = clean.shape[-1]
constant = 0.5*dimension*(
    posterior_variance/reverse_variance-1
    + torch.log(reverse_variance/posterior_variance))
torch.testing.assert_close(kl, weighted_noise_error+constant)
g_kl = torch.autograd.grad(kl.mean(),epsilon_hat,retain_graph=True)[0]
g_mse = torch.autograd.grad(weighted_noise_error.mean(),epsilon_hat)[0]
torch.testing.assert_close(g_kl,g_mse)
print("time weight:", weight.item(), "fixed covariance constant:", constant.item())
print("passed: KL equals weighted epsilon MSE plus a theta-independent constant")

```

Independent(Normal(...),1) 把动作向量作为一个联合事件，对维度求和后计算 KL。协方差常数与网络均值无关，故删除后保留相同的期望梯度；若使用逐元素 mean，必须同时追踪额外的维度因子。





## DDPM、LDM、DiT 与采样器分别改变什么

生成空间、网络架构、训练目标和采样器是扩散系统的不同组成。LDM 改变扩散发生的表示空间，DiT 采用 Transformer 去噪骨干，DDPM/DDIM 则涉及生成过程与采样构造。先定位层次，再理解哪些设计可以组合。





以图像为例，[Latent Diffusion Models（LDM）](https://arxiv.org/abs/2112.10752) 先学习图像编码器与解码器，再在压缩后的表示上训练扩散模型。计算主要转移到较小的空间网格，条件可通过 Cross-Attention 注入。这里改变的是生成空间：最终图像还要经过解码，重建质量与压缩保留的信息成为额外边界。机器人动作本身通常已是低维向量，因此是否再学习潜空间，应由动作结构和表示需求决定，不能照搬图像方案。





[DiT](https://arxiv.org/abs/2212.09748) 将潜表示切为 patch，并用 Transformer 代替常见的 U-Net 去噪骨干；其原始工作研究类别条件图像生成，使用包含 AdaLN-Zero 的条件注入设计。DiT 首先描述骨干选择，不自动规定采用 Flow Matching、文本条件或自回归输出。图像 DiT、时间轴上的动作 Transformer 和 VLA 的动作专家可以共享组件，但输入轴、条件路径和输出目标仍要逐一辨认。条件缩放与门控见[条件融合](#/learn/conditioning-fusion)。





[DPM-Solver](https://arxiv.org/abs/2206.00927) 属于采样算法：它利用扩散 ODE 的半线性结构，解析处理线性部分，并近似涉及网络预测的积分。它不需要把原去噪模型重新训练为一个新的骨干；实际使用仍需与噪声日程、输出参数化及时间变量匹配。高阶收敛描述的是相应条件下的数值误差，不是对任意模型、任意少步数的生成质量保证。通用 Euler、Heun 与专用扩散求解器的差别，可接续[Score 与概率流 ODE](#/learn/score-sde)。





因此，一个模型可以同时是潜空间生成模型、采用 Transformer 骨干，并使用特定 ODE 采样器。阅读配置时分别确认“生成变量、路径与训练目标、骨干、采样更新”；比较实验也应固定其余选择。图像中的名称迁移到[动作策略](#/learn/generative-policy)后，仍须检查动作单位、时间轴和闭环执行协议。







### 代表工作与模型中的位置

| 工作 | 主要特点 | 在实现中定位 |

|---|---|---|

| [DDPM](https://arxiv.org/abs/2006.11239) | 离散前向 Gaussian 链与学习到的反向转移，常用噪声回归训练。 | 加噪分布、训练损失及反向更新；本章前半部分逐项推导。 |

| [DDIM](https://arxiv.org/abs/2010.02502) | 与相同前向边际及训练目标兼容的另一类生成过程，可使用非相邻等级；零随机项时采样确定。 | 主要在采样更新中体现；不能仅删除 DDPM 循环中的若干索引。 |

| LDM（2022） | 先编码，再在压缩表示中生成，最后解码。 | 改变建模空间；额外检查编码尺度、压缩误差与解码器。 |

| DiT（2022/2023） | 以 patch Transformer 构建去噪骨干；原论文研究潜空间类别条件生成。 | 在网络结构中定位，不据此推断训练目标或采样器。 |

| DPM-Solver（2022） | 利用扩散 ODE 特殊结构的高阶数值求解。 | 在 sampler / scheduler 中定位；核对预测类型、时间与日程。 |



## 动作块中的尺度、约束与监督边界

扩散动作块是将一段未来命令作为联合生成变量的策略表示。噪声与回归发生在模型采用的坐标中，执行却需要恢复物理单位与动作含义。下面把前面的概率过程接回有效监督、归一化和控制接口。





连续动作通常先按训练统计量归一化，再进入扩散空间。平移、旋转和夹爪等分量若尺度相差很大，噪声日程对它们的相对破坏程度也不同。采样完成后按固定顺序反变换为控制接口；不能把标准高斯噪声的数值范围直接当成机器人动作范围。





动作 Padding 与无效维要在训练损失中明确排除，模型输入也需对应有效性协议。直接在每个去噪步把无效位置置零，改变了这些坐标的实际过程；这可能是某个设计的一部分，但必须与训练一致。若采用动作前缀条件或 inpainting，还需定义已知部分如何随等级加噪与固定，不能把原始动作强塞进任意噪声层。





欧氏噪声不自动保持旋转流形、关节限位或接触约束。最终裁剪限制了数值，同时也改变生成分布；去噪误差无法代替动作表示、控制后处理和闭环效果的检验。









## 定位生成失败

生成失败可能来自加噪、网络学习、采样器或动作解码，单个训练损失无法区分这些原因。有效诊断应逐步替换未知环节，用已知噪声与固定样本建立参照。每一步只恢复一类不确定性，才能把观察结果对应到具体机制。





按四个边界逐项核对：原始动作如何标准化，训练怎样构造 \(x_k\) 和 \(\epsilon\)，网络预测是什么，采样器怎样恢复与执行。先跳过网络使用已知噪声验证参数化；再检查固定三元组的梯度与拟合；最后恢复随机训练并检查按等级、条件和动作维分组的误差。这样能够区分公式错误、学习失败与动作接口问题。





完整示例使用与 FM 相同的二维条件混合分布，输出独立探针误差、解析最优噪声预测误差与生成样本。有限训练、离散采样和末端分布近似都会影响生成误差。固定网络比较步进配置，可以观察数值求解的影响；同时改变日程、优化器与尺度，则很难解释误差来自哪一项。





排错时给 eps_hat、alpha_bar、mean 和 noise 标出随机变量、形状与等级。错误版本也提供明确反例：把累计系数换成单步系数、反向日程升序、最后一步加噪，分别破坏不同计算关系。





有关噪声预测与边际 score 的精确关系，以及 DDPM 连续极限、反向 SDE 和概率流 ODE 的区别，见[Score、SDE 与概率流 ODE](#/learn/score-sde?tab=theory)。这些联系解释了为何“Diffusion 随机、Flow 确定”不足以区分方法。





本章 DDPM 和 [Flow Matching 的多峰训练](#/learn/flow-matching?tab=code&anchor=demo-conditional-mixture)采用相同的数据参数和条件含义，分别训练噪声与速度预测器。比较时应固定数据、模型预算和评价口径，再分别记录采样随机性与网络调用次数；两份训练 MSE 不是同一度量。本次用途是追踪数据如何进入不同目标与采样步骤，不据一次合成训练宣称算法优劣。





扩散生成的主线是固定加噪过程、从可计算噪声建立监督、再以匹配的反向规则采样。参数化、损失权重与求解日程各有定义；生成动作时还要完成单位与执行语义的还原。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| clean / noisy / noise prediction | [B,H,D] | 动作块、带噪动作块和噪声预测同形状；演示简化成 [B,1] |
| noise index | [B] | 每个样本的噪声等级，独立于 H 个控制时刻 |
| cumulative alpha | [B,1,1] | 选取当前等级后广播到动作块 |

## 完整代码与精读

```python
"""Conditional DDPM on the same 2D mixture used by the Flow Matching course."""
import json
from pathlib import Path
import torch
from torch import nn

SEED = 20261106
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


def sample_data(condition, generator=None):
    first = torch.rand(len(condition), generator=generator) < WEIGHTS[condition, 0]
    component = (~first).long()
    return MEANS[condition, component] + DATA_STD * torch.randn(
        len(condition), 2, generator=generator)


class NoisePredictor(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, k, condition, levels):
        tau = k.to(x.dtype)[:, None] / (levels - 1)
        clock = torch.cat((tau, torch.sin(torch.pi*tau), torch.cos(torch.pi*tau)), -1)
        context = nn.functional.one_hot(condition, 2).to(x.dtype)
        return self.net(torch.cat((x, clock, context), -1))  # [B,7] -> [B,2]


def oracle_noise(x, alpha_bar, condition):
    alpha, sigma = alpha_bar.sqrt(), (1-alpha_bar).sqrt()  # [B,1]
    q = alpha.square()*DATA_STD**2 + sigma.square()
    residual = x[:, None, :] - alpha[:, :, None]*MEANS.to(x)[condition]
    logits = WEIGHTS.to(x)[condition].log() - residual.square().sum(-1)/(2*q)
    posterior = logits.softmax(-1)  # p(component | x,k,c)
    return (posterior[:, :, None]*(sigma/q)[:, :, None]*residual).sum(1)


def run(output="ddpm_mixture_results.json", train_steps=1800):
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    levels = 64
    beta = torch.linspace(0.001, 0.2, levels)
    alpha = 1-beta
    alpha_bar = alpha.cumprod(0)
    previous = torch.cat((torch.ones(1), alpha_bar[:-1]))
    posterior_variance = beta*(1-previous)/(1-alpha_bar)
    assert posterior_variance[0] == 0
    assert torch.all((beta > 0) & (beta < 1))
    model = NoisePredictor()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.002)

    def batch(size, generator=None):
        condition = torch.randint(2, (size,), generator=generator)
        clean = sample_data(condition, generator)
        k = torch.randint(levels, (size,), generator=generator)
        noise = torch.randn(size, 2, generator=generator)
        ab = alpha_bar[k, None]  # coefficients broadcast across D=2, not B
        noisy = ab.sqrt()*clean + (1-ab).sqrt()*noise
        return noisy, k, condition, noise

    probe = batch(4096, torch.Generator().manual_seed(SEED+1))
    with torch.no_grad():
        before = (model(*probe[:3], levels)-probe[3]).square().mean().item()
    for _ in range(train_steps):
        noisy, k, condition, noise = batch(256)
        loss = (model(noisy, k, condition, levels)-noise).square().mean()
        assert torch.isfinite(loss)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()

    model.eval()
    with torch.no_grad():
        estimate = model(*probe[:3], levels)
        oracle = oracle_noise(probe[0], alpha_bar[probe[1], None], probe[2])
        after = (estimate-probe[3]).square().mean().item()
        oracle_target_mse = (oracle-probe[3]).square().mean().item()
        model_oracle_mse = (estimate-oracle).square().mean().item()
        assert after < before  # this fixed experiment; not a general convergence theorem
        generator = torch.Generator().manual_seed(SEED+2)
        condition = torch.arange(1024) % 2
        initial = torch.randn(1024, 2, generator=generator)
        target = sample_data(condition, generator)
        x = initial.clone()
        for k in reversed(range(levels)):
            index = torch.full((len(x),), k, dtype=torch.long)
            eps_hat = model(x, index, condition, levels)
            mean = (x-beta[k]/(1-alpha_bar[k]).sqrt()*eps_hat)/alpha[k].sqrt()
            # No fresh noise at k=0; the terminal clean estimate is the mean.
            x = mean if k == 0 else mean + posterior_variance[k].sqrt()*torch.randn(
                x.shape, generator=generator)
        assert x.shape == (1024, 2) and torch.isfinite(x).all()

    result = {"seed": SEED, "torch": torch.__version__, "device": "cpu",
              "dtype": "float32", "levels": levels, "train_steps": train_steps,
              "terminal_alpha_bar": alpha_bar[-1].item(),
              "probe": {"before_mse": before, "after_mse": after,
                        "oracle_target_mse": oracle_target_mse,
                        "learned_to_oracle_mse": model_oracle_mse},
              "data_std": DATA_STD, "means": MEANS.tolist(), "weights": WEIGHTS.tolist(),
              "conditions": [],
              "limits": ["One fixed-seed teaching experiment, not a policy benchmark.",
                         "The finite schedule has a small, nonzero terminal signal.",
                         "DDPM's finite Gaussian reverse steps are approximations.",
                         "Noise and velocity MSE have different units and time weights."]}
    for c in (0, 1):
        select = condition == c
        nearest = (x[select, None, :]-MEANS[c]).square().sum(-1).argmin(-1)
        result["conditions"].append({"id": c, "noise": initial[select][:200].tolist(),
                                     "data": target[select][:200].tolist(),
                                     "generated": x[select][:200].tolist(),
                                     "nearest_mode_fractions": torch.bincount(
                                         nearest, minlength=2).div(select.sum()).tolist()})
    Path(output).write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"probe": result["probe"], "generated_shape": list(x.shape),
                      "terminal_alpha_bar": result["terminal_alpha_bar"]}, indent=2))
    return result


if __name__ == "__main__":
    run()

```

- 第 7–18 行：两个条件各包含两个 Gaussian 模式，与 Flow Matching 的 conditional-mixture 使用相同均值、混合比例和标准差；每次重新抽取分量与局部噪声。
- 第 21–40 行：网络接收 [B,2] 带噪样本、三维时间编码和二维 one-hot 条件。oracle_noise 用混合分量的后验权重计算 E[ε|x,k,c]，不是将本次采样标签交给网络。
- 第 43–64 行：保留零起始 DDPM 索引；用累计 alpha 一步生成训练样本。固定独立探针用于区分训练批次波动与实际探针误差。
- 第 66–86 行：训练噪声回归网络，再分别测预测到采样标签和解析条件均值的误差；总体平方误差分解不意味着有限探针的两项会精确相加。
- 第 87–101 行：从标准 Gaussian 开始反向迭代，k=0 不添加新噪声。有限日程的末端仍有很小信号，先验近似和 Gaussian 反向一步近似都明确保留。
- 第 100–123 行：导出实际参数与样本。最近模式比例仅作诊断；噪声 MSE 与 FM 速度 MSE 的单位和时间权重不同，不能据大小排序算法。

预期观察：固定种子的本次 CPU 实验中，独立探针噪声 MSE 从 1.01124 降到 0.22395，解析最优预测对同一探针标签的 MSE 为 0.21076；输出 [1024,2] 样本与 ddpm_mixture_results.json。终端累计 alpha 约 0.000994，因此从标准 Gaussian 开始仍是一项近似。这些是合成实验观察，不是普遍收敛或机器人表现的保证。

## 浏览器 Python 练习

实现 add_noise(clean, noise, alpha_bar)，返回同长度列表。alpha_bar 必须位于 [0,1]；长度不一致要报错。端点分别应该恢复 clean 和 noise。

```python
import math

def add_noise(clean, noise, alpha_bar):
    # TODO: 使用累计 alpha，而不是直接用 beta
    raise NotImplementedError

```

### 提示

- 系数是 alpha_bar 的平方根与 1−alpha_bar 的平方根。
- 先验证两列表长度，避免 zip 静默截断。

### 参考实现与解释

```python
import math

def add_noise(clean, noise, alpha_bar):
    if not 0 <= alpha_bar <= 1 or len(clean) != len(noise):
        raise ValueError('invalid coefficient or shape')
    a, b = math.sqrt(alpha_bar), math.sqrt(1-alpha_bar)
    return [a*x + b*z for x,z in zip(clean,noise)]

```

当 alpha_bar 接近 1，样本保留更多原始动作；接近 0 时更接近高斯噪声。实际日程的最后一步是否足够接近 0，需要直接检查。

### 断言测试

```python
assert add_noise([2.,-1.],[0.5,0.2],1.) == [2.,-1.]
assert add_noise([2.,-1.],[0.5,0.2],0.) == [0.5,0.2]
y = add_noise([2.],[0.],0.25)
assert abs(y[0]-1.) < 1e-12
try:
    add_noise([1.],[0.],1.1)
    raise AssertionError('非法系数应报错')
except ValueError:
    pass
print('加噪公式及两个端点检查通过。')

```

## 本地 PyTorch 练习

实现 ddpm_reverse_step(x, eps_hat, k, betas, noise)。采用后验方差 beta_tilde，\(k=0\) 返回均值且忽略 noise。x、eps_hat、noise 形状相同，k 是 Python 整数。

```python
import torch

def ddpm_reverse_step(x, eps_hat, k, betas, noise):
    # TODO: 累计系数、反向均值、后验方差和边界
    raise NotImplementedError

```

### 提示

- 先对 1−betas 做 cumprod，反向均值同时使用当前 alpha 和累计 alpha。
- \(k=0\) 应在添加随机噪声前返回；k>0 的方差使用 alpha_bar[k−1]。

### 参考实现与解释

```python
import torch

def ddpm_reverse_step(x, eps_hat, k, betas, noise):
    if not 0 <= k < len(betas) or not ((betas > 0) & (betas < 1)).all():
        raise ValueError('invalid step or schedule')
    alphas = 1-betas
    abar = torch.cumprod(alphas, dim=0)
    mean = (x-betas[k]/(1-abar[k]).sqrt()*eps_hat) / alphas[k].sqrt()
    if k == 0:
        return mean
    variance = betas[k]*(1-abar[k-1])/(1-abar[k])
    return mean + variance.sqrt()*noise

```

DDPM 的当前噪声系数 alpha、累计系数 alpha_bar 和反向后验方差承担不同作用。均值中的 epsilon 预测需要按 beta/sqrt(1−alpha_bar) 换算，不能直接减去网络输出。对于相邻反向步，posterior variance=beta*(1−alpha_bar_previous)/(1−alpha_bar)。\(k=0\) 最后一步仍更新均值，但不注入新噪声。本练习只适用于给定相邻步日程。

### 断言测试

```python
betas = torch.tensor([0.1,0.2])
x = torch.tensor([[1.,2.]])
eps = torch.zeros_like(x)
one = torch.ones_like(x)
a = ddpm_reverse_step(x,eps,0,betas,one)
b = ddpm_reverse_step(x,eps,0,betas,-one)
torch.testing.assert_close(a,b)
torch.testing.assert_close(a,x/torch.tensor(0.9).sqrt())
c = ddpm_reverse_step(x,eps,1,betas,one)
expected = x/torch.tensor(0.8).sqrt() + torch.tensor(0.2*0.1/0.28).sqrt()
torch.testing.assert_close(c,expected)

# 非零 eps_hat：最后一步应精确反演已知的单步加噪
clean = torch.tensor([[0.4, -0.6]])
known_eps = torch.tensor([[0.7, -1.2]])
alpha0 = 1 - betas[0]
noisy0 = alpha0.sqrt() * clean + (1 - alpha0).sqrt() * known_eps
recovered = ddpm_reverse_step(noisy0, known_eps, 0, betas, one)
torch.testing.assert_close(recovered, clean, atol=1e-6, rtol=1e-5)
# k=1 也必须使用噪声预测，系数中的累计 alpha 是 0.9*0.8=0.72
nonzero_eps = torch.tensor([[0.5, -0.25]])
expected_nonzero = (x - (0.2 / (0.28 ** 0.5)) * nonzero_eps) / (0.8 ** 0.5)
expected_nonzero = expected_nonzero + (0.2 * 0.1 / 0.28) ** 0.5 * one
actual_nonzero = ddpm_reverse_step(x, nonzero_eps, 1, betas, one)
torch.testing.assert_close(actual_nonzero, expected_nonzero, atol=1e-6, rtol=1e-5)

print('DDPM 后验方差和最后一步检查通过。')

```

## 练习：推导与分析

### 同一个网络输出 [B,H,D]，为什么 epsilon 预测、干净动作预测和 Flow Matching 速度不能直接互换？

形状相同只说明元素数量一致，没有说明数值代表什么。epsilon 模型监督的是此次加噪使用的标准高斯噪声；干净动作模型监督动作本身；Flow Matching 的速度目标由所选概率路径及时间方向定义。它们的量纲、时间依赖和换算公式不同。

应从训练 loss 的 target 追到模型输出，再核对采样器如何使用该输出。用已知干净动作和固定噪声构造一个可手算样本，检查一次更新及端点。仅修改配置字段而不匹配训练参数化，可能不会触发 shape 错误，却会破坏采样。

代码定位：NoisePredictor 的噪声 MSE、oracle_noise 的条件均值与 ddpm_reverse_step 的反向均值公式。

- 分别说明三种输出语义。
- 提出固定噪声的单步一致性检查。

### 将训练日程从 1000 步改成 20 步，并保留原 beta 区间后，从高斯噪声采样为什么可能失配？

累计 alpha 是所有 1−beta 的乘积。大幅减少步数但保留很小的 beta 时，终端仍可能包含大量干净动作信号，而推理却从标准高斯开始；此时训练终端分布和推理初值不一致。应该直接计算并查看终端 alpha_bar，而不是只比较步数。

推理减步还涉及如何选择训练日程中的时间点和对应采样公式。可使用有明确推导的调度器，但不能随意跳过相邻 DDPM 步。模型是否足够好、采样离散误差和动作后处理是否一致，应分别检查。

代码定位：alpha_bar[-1]、训练 timestep 采样和推理 scheduler 的步进序列。

- 解释累计乘积与终端分布的关系。
- 区分改变训练日程与减少推理采样步数。

### \(\epsilon\)、a、v 能互相换算，为什么三个无权重 MSE 仍会训练出不同模型？

在固定等级且预测一致时，\(L_\epsilon=\frac{\alpha^2}{\sigma^2}L_a\)，\(L_v=\frac{L_a}{\sigma^2}\)。比例依赖等级，均匀采样等级后并不是对整个目标乘同一个常数；有限容量模型因此分配不同拟合重点。

若要保持某个指定目标，需一起转换损失权重与时间采样分布。端点除零、输出裁剪及不同网络参数化还可能破坏简单代数等价，不能只修改采样器配置。

代码定位：用 \(\alpha\)=0.8、\(\sigma\)=0.6 和相同干净动作误差，计算三个损失。

- 推导 SNR 权重。
- 区分输出换算与总体优化目标一致。

### “把 U-Net 换成 DiT，再用 DPM-Solver 采样，就变成了 Flow Matching。”这个判断错在哪里？

DiT 改变网络骨干，DPM-Solver 改变相应扩散 ODE 的数值积分；二者都不能单独说明训练概率路径或监督目标发生了变化。若仍按原日程训练噪声回归，模型的训练目标并未因此自动变成 Flow Matching。

应分别读出加噪公式、网络输出含义、损失权重及采样方程。若想在相同 Gaussian 路径下转换 noise、score 与 velocity，还需使用匹配的系数和时间方向；损失权重也不能忽略。是否在潜空间中生成，又是独立的表示选择。

代码定位：对照本章 noise schedule、eps_hat 与 ddim_step 的接口，再在 DiT 官方仓库分别定位 models.py、train.py 与 sample.py。

- 区分表示空间、骨干、训练目标和采样器四个层次。
- 说明替换组件后需要核对的数学接口，不以模型名字代替目标定义。

## 练习：辨析与纠错

### 用每步 alpha 代替累计 alpha_bar

两者控制不同噪声量。将两个 \(\beta\) 的累计乘积手算后，与查表及广播后的张量核对。

### 输出形状相同就共用采样器

epsilon、sample 与特定 v 参数化需要不同恢复公式。检查训练 target、模型配置及调度器的声明是否一致。

### 采样步数减少但仍套相邻一步公式

跳步的系数必须匹配真实等级间隔。使用实现明确支持的日程，并做固定模型、固定随机性的数值对照。

### 最后一步仍加入噪声

采用上述后验方差时，\(k=0\) 直接返回均值。用不同 noise 输入检查最后输出不变。

### 扩散 loss 下降就意味着动作可执行

损失发生在生成空间，几何与控制约束另有含义。核对反归一化、动作接口并进行闭环评估。

## 原始资料

- [DDPM 原论文](https://arxiv.org/abs/2006.11239)
- [Diffusion Policy 原论文与代码](https://diffusion-policy.cs.columbia.edu/)
- [PyTorch cumprod 官方文档](https://docs.pytorch.org/docs/stable/generated/torch.cumprod.html)
- [Diffusers · DDPM 调度器、方差与输出参数化](https://huggingface.co/docs/diffusers/en/api/schedulers/ddpm)
- [Salimans & Ho · Progressive Distillation：v 参数化与时间权重](https://arxiv.org/abs/2202.00512)
- [DDIM 原论文 · 非相邻采样与 \(\eta=0\) 的确定性更新](https://arxiv.org/abs/2010.02502)
- [Kingma & Welling · Auto-Encoding Variational Bayes（轨迹变分界的基础）](https://arxiv.org/abs/1312.6114)
- [Song et al. · Score-Based Generative Modeling through SDEs](https://arxiv.org/abs/2011.13456)
- [Rombach et al. · Latent Diffusion Models：压缩表示中的生成](https://arxiv.org/abs/2112.10752)
- [Peebles & Xie · DiT：潜空间 Transformer 去噪骨干](https://arxiv.org/abs/2212.09748)
- [DiT 官方实现：模型、训练与采样入口](https://github.com/facebookresearch/DiT)
- [Lu et al. · DPM-Solver：利用扩散 ODE 结构的高阶求解](https://arxiv.org/abs/2206.00927)
