# 微调与 LoRA

可训练参数、梯度路径、低秩更新与能力保持。

微调是以已有模型参数为起点，用新任务数据继续训练，使其适应新的目标或输入分布。参数高效微调（PEFT）限制需要学习的参数数量，LoRA 则通过给线性权重增加可训练低秩增量实现一种 PEFT。它们规定更新方式，并不自行规定监督目标。本章先定义训练什么与更新什么，再推导 LoRA、初始化和合并，最后检验迁移与能力保持。

## 学习目标

- 区分全量微调、冻结骨干、读出头和 LoRA 的参数更新范围
- 实现低秩线性层并检查初始化、梯度与合并等价性
- 设计同时覆盖新任务与保留能力的微调评估

前置知识：[PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [梯度下降、动量与 AdamW](https://wxb1870.github.io/embodied-ml-lab/learn/optimization/) · [Transformer：注意力、残差与序列建模](https://wxb1870.github.io/embodied-ml-lab/learn/transformer/)

## SFT、行为克隆与 PEFT 分别改变什么

监督微调（SFT）是用输入—目标对继续训练已有模型，行为克隆是从示范学习动作策略，PEFT 是限制可训练参数的一类方法。它们分别描述训练阶段、监督问题与更新形式，可以在同一训练中同时成立。





监督微调 SFT 描述用成对输入和目标继续训练已有模型的阶段；行为克隆描述从示范条件学习动作策略的监督问题。二者可以同时成立。LoRA 或其他参数高效微调方法 PEFT 则约束哪些参数可更新、增量怎样表达，并没有自行指定监督目标。使用 LoRA 的策略仍需根据动作生成方式选用正确的损失与采样接口。





离散动作 token 模型通常使用对齐后的交叉熵；固定方差高斯动作回归对应按尺度加权的 MSE；Diffusion 使用其噪声、数据或 velocity 参数化对应的目标；Flow Matching 回归条件速度。后两者的回归损失不能直接当成一段动作的 log π(a|c)，也不能因为都写作 MSE 就互换 target 或用于 PPO 概率比。生成目标详见 [生成式动作策略](#/learn/generative-policy)，策略密度与梯度问题见 [策略梯度](#/learn/policy-gradient)。





全量微调让指定模型全部参数可更新；部分层解冻、LoRA、可训练提示向量或新增适配层限制了不同的函数空间。PEFT 是这些参数效率方案的上位概念，不等同于 LoRA，也不承诺某个固定的显存降低比例。先明确目标域与需要改变的表示，再选更新范围，最后用参数实际变化、有效梯度、保存恢复及验证集行为检查选择是否成立。





下式用 \(\theta_0\) 表示已有模型参数，φ 表示本次可训练参数，c 与 y 分别为条件输入和监督目标，𝒟 为训练分布。具体更新规则可以是冻结 \(\theta_0\) 只学习适配参数，也可以将所选原始权重纳入 φ；损失 ℓ 的定义与这一参数化选择相互独立。





$$
\min_{\phi}\ \mathbb E_{(c,y)\sim\mathcal D}\bigl[\ell(f_{\theta_0,\phi}(c),y)\bigr],\qquad \ell\ \text{defines the target},\quad\phi\ \text{defines trainable parameters}
$$





## 微调范围由实际更新路径决定

微调范围是实际允许更新的参数集合：全量微调更新全部选定模型参数，部分解冻只更新其中一部分，冻结骨干则可只训练新增模块。计算图和优化器还需要与这份范围一致，意图才会成为真实更新。





全量微调更新骨干及任务模块；冻结骨干只训练新增层；部分解冻只更新指定参数集合。名称描述的是意图，真正行为要由 requires_grad、前向计算图、优化器参数组与 step 前后参数差值共同确认。参数有梯度但没进优化器不会更新，进了优化器却与 loss 无关也不会学到目标。





冻结参数与禁用计算图不等价。如果一个可训练模块位于冻结模块之前，梯度还需要穿过冻结模块回传给前面的参数；把整个冻结模块放进 no_grad，会切断这条路径。只有上游没有需要优化的输入或参数、且该输出作为固定特征使用时，才可按设计关闭这一段记录。





train/eval 控制 Dropout、BatchNorm 等模块行为，与参数是否训练是另一个维度。冻结权重后 BatchNorm 的运行统计量仍可能在 train 模式变化，Dropout 仍可能产生随机输出。应明确模型中哪些状态可以改变，并检查保存时是否包含这些状态；仅比较某个 weight 张量不足以证明“骨干完全固定”。









### 冻结骨干就把整段 forward 放进 no_grad

这可能切断前置 Adapter、可训练输入或其他上游模块所需的梯度。

构造一个前置可训练层，确认它在冻结骨干之后仍收到非零有限梯度；再分别检查参数与运行统计量。

## LoRA 的形状、参数量与低秩约束

LoRA 是在冻结的线性权重旁增加两个小矩阵，其乘积构成低秩权重增量的方法。它用较少可训练参数限制增量的表达方式。下面先定义两因子形状，再计算前向和参数量。

![LoRA 输入并行通过冻结的基座权重 W0 与可训练的 A、B 低秩分支，缩放后逐元素相加。](../assets/figures/lora-definition.svg)

先看两路相加：蓝色基座权重保持冻结，橙色 A、B 学习低秩增量。图中按本文 PyTorch 行向量约定标出转置，参数形状与源码一致。依据 [Hu et al., Figure 1 与 §4.1](https://arxiv.org/abs/2106.09685) 独立绘制。



线性层权重 \(W_0\) 的形状为 [out_dim,in_dim]。LoRA 将增量写成 BA，其中 A:[r,in_dim]、B:[out_dim,r]，并按 \(\alpha/r\) 缩放。前向可以先算 \(xA^\top\)，再乘 \(B^\top\)，与直接使用 \(W_0+\frac{\alpha}{r}BA\) 等价。不要因为 Linear 的输入乘法写法是 \(xW^\top\)，就把参数存储的朝向也转反。





不含低秩分支偏置时，可训练参数为 \(r(d_{\rm in}+d_{\rm out})\)，冻结原层仍保存 \(d_{\rm out}d_{\rm in}\) 个权重以及可能的偏置。小 r 限制单个更新矩阵的秩，不代表整个深层网络只增加 r 个自由度，也不代表所有任务所需变化都能被当前目标层与秩表达。目标层选择与 r 都应由实验验证。



### 例：手算一个低秩分支的参数量

1. in_dim=5、out_dim=2、rank=2，原层带偏置并全部冻结。

2. 冻结参数为 5×2+2=12；A 有 2×5=10 个数，B 有 2×2=4 个数。

3. 低秩分支可训练参数合计 14，这个很小的例子甚至多于原层；优势取决于实际尺寸和秩。

4. 再只比较一个 4096→4096 层的权重：基座有 \(4096^2=16{,}777{,}216\) 个数，rank=8 的两因子只有 \(8(4096+4096)=65{,}536\) 个，为前者的 1/256。这里不计偏置，用于对照大矩阵、小秩时的参数节省。

LoRA 参数节省是相对于大矩阵与较小秩而言，不能对任意尺寸默认成立。

LoRA 常被注入注意力或前馈投影，但并不要求所有线性层都使用同一秩和缩放。实际实现还可能包含 bias、额外保存模块或特定初始化变体，参数计数必须以模型的真实 named_parameters 为准。以下使用 \(\alpha/r\) 缩放；改变初始化或缩放时，需要重新验证相应性质。





$$
W=W_0+\frac\alpha rBA,\qquad y=xW_0^\top+b+\frac\alpha r(xA^\top)B^\top
$$





## 为什么常见初始化只让一个因子为零

LoRA 的零增量初始化让新增分支最初不改变原线性层输出。通常只将一个因子置零，使另一个因子仍提供首步学习所需的方向。下面推导两因子梯度，解释它与同时置零的区别。





设基础矩阵 \(W_0\in\mathbb R^{d_{\rm out}\times d_{\rm in}}\)，低秩因子 \(A\in\mathbb R^{r\times d_{\rm in}}\)、\(B\in\mathbb R^{d_{\rm out}\times r}\)，\(W=W_0+sBA\)、\(s=\alpha/r\)。令 \(G=\partial L/\partial W\)，则 \(dW=s[(dB)A+B(dA)]\)，并且标量损失的微分为 \(dL=\operatorname{tr}(G^\top dW)\)。





利用迹的循环性质，\(\operatorname{tr}(G^\top(dB)A)=\operatorname{tr}((GA^\top)^\top dB)\)，\(\operatorname{tr}(G^\top B(dA))=\operatorname{tr}((B^\top G)^\top dA)\)。与 \(dL=\operatorname{tr}((\nabla_B L)^\top dB)+\operatorname{tr}((\nabla_A L)^\top dA)\) 比较，便得到下方梯度。两个结果的形状分别与 \(B\)、\(A\) 完全相同。





为在训练开始时保持基础层的前向结果，常用初始化令 \(A\) 随机、\(B=0\)，于是 \(BA=0\)。此时 \(\nabla_A L=sB^\top G=0\)，但 \(\nabla_B L=sGA^\top\) 一般可以非零；B 更新后 A 才可能开始学习。因而首步 A 的零梯度是该初始化的预期行为，并不单独说明梯度链断开。这里讨论的是数据损失的反向梯度，优化器的权重衰减或已有状态可能另外影响参数。



### 例：首步零梯度的两种含义

1. A 随机、\(B=0\) 时，初始输出与基础层一致。

2. \(\frac{\partial L}{\partial A}\) 中包含 B，因此 A 的首步梯度为零；\(\frac{\partial L}{\partial B}\) 可以非零。

3. 若 \(A=B=0\)，则两式都为零；若第一步 B 更新后 A 仍长期没有梯度，应继续检查路径和优化器。

初始化预期、首步行为与后续更新需要分开判断。

若 A 与 B 同时初始化为零，两者梯度都包含另一个零因子，基础参数化会无法从这一点通过普通一阶更新起步。相反，如果 A、B 都随机，低秩分支开始时就改变了原模型行为。选择哪种初始化需要与“起始功能是否保持”的目标对应，不能只检查梯度张量是否存在。





alpha/r 的缩放会影响输出增量与参数梯度的尺度。改变 r 时，即使 alpha 不变，也同时改变容量与缩放；这会使单纯把效果归因于“秩更大”不充分。实验记录应包含实际缩放、目标模块、初始化与学习率；若使用 rank-stabilized 等变体，应按其定义单独分析。





$$
\frac{\partial L}{\partial A}=\frac\alpha rB^\top G,\qquad \frac{\partial L}{\partial B}=\frac\alpha rGA^\top\quad(G=\partial L/\partial W)
$$





### 一看到 A 首步零梯度就判断 LoRA 坏了

基础零 B 初始化本就使 A 的首步梯度为零，真正异常是可更新路径长期没有变化。

分别记录 A/B 的首步和第二步梯度、参数差值，并确认初始输出与原层相同。

## 合并权重的等价性有前提

权重合并是把训练后的线性低秩增量加到基座矩阵中，使推理不必显式计算独立分支的操作。等价性依赖相同参数、缩放与确定性设置；量化和浮点计算还会带来额外约定。





固定 A、B 与缩放后，线性低秩分支可合并为 \(W_{\rm merge}=W_0+\frac{\alpha}{r}BA\)，推理不再显式计算两个小矩阵。验证时先关闭随机层，使用同一输入比较合并前后输出；误差容限需要考虑浮点精度与计算顺序，不应要求低精度运算逐位完全相同。





LoRA 分支若包含训练期 Dropout，合并等价应在确定性的推理模式下讨论。量化基础权重的解量化与重新量化也可能引入差异，不能把 FP32 代数等价直接解释成量化部署的逐值相等。需要明确合并流程使用的精度、原模型身份，以及是否另外保留了未合并适配器。





重复合并同一增量会把它加两次；合并后的模型若又加载同一适配器并启用分支，也会重复计算。保存格式应标明合并状态，并保留基础模型版本。使用固定输入的等价测试和结构检查，比依赖文件名带 merged 更可靠。恢复继续训练时还要说明是训练合并权重，还是恢复原低秩参数化。









## 参数高效与显存高效不是同一比例

可训练参数成本包括梯度和优化器状态，模型总内存还包括基座权重、激活和临时量。LoRA 主要直接减少前一类，所以参数效率不等于同比例的显存效率。下面按对象分开建立账目。





LoRA 减少了需要保存梯度与优化器状态的参数数量，但基础权重仍需存放，反向传播还可能需要经过大量中间激活。长视觉语言序列的显存常由激活、注意力及输入长度主导，因此可训练参数减少一个数量级，不代表总训练显存也减少相同比例。





冻结参数能避免它们的参数梯度与优化器状态，但不一定允许丢弃其所有中间计算：为了给其他可训练路径求导，仍可能需要激活。激活重计算、混合精度、序列裁剪与低秩适配分别针对不同开销，叠加之前应测量各部分瓶颈，避免把所有显存下降都归因于 LoRA。





量化基础模型还会改变权重存储、数值误差、可用算子与反向路径。实际峰值显存、吞吐、可训练参数量和任务表现需要分别测量，不能只由 trainable ratio 推算资源需求。









## LoRA、QLoRA 与实现框架：分别减少哪一项成本

LoRA 定义低秩更新形式，QLoRA 将量化的冻结基座与这类可训练增量结合，框架则提供配置和执行这些方法的工具。它们分别作用于更新、存储与实现，不能仅凭一个框架名称判断实际训练成本。





[LoRA](https://arxiv.org/abs/2106.09685) 的核心是冻结原权重并学习低秩增量，本身不规定基座必须采用哪一种存储精度。[QLoRA](https://arxiv.org/abs/2305.14314) 则把冻结的 4 bit 基座与可训练 LoRA 结合，进一步减少基座存储。原论文围绕语言模型开展实验；把同一思路用于 VLA 时，仍需单独验证视觉编码器、条件投影与动作头的精度敏感性，不能把语言任务结果直接当作闭环策略性能保证。





QLoRA 中三项设计解决不同开销。NF4 依据正态分布构造非均匀的 16 个量化表示值，以块内缩放配合 4 bit 编码；这一分布假设不表示任意层都能无误差压缩。双重量化进一步量化块缩放常数，减少量化元数据，而非把每个权重连续压缩两次。分页优化器利用统一内存机制，在显存紧张时将优化器状态分页到 CPU 内存，缓解瞬时峰值；它既不消除激活，也不保证分页没有传输成本。三者的定义与组合见原论文第 3 节。





4 bit 描述存储编码，不等于整次矩阵计算、激活或梯度都采用 4 bit。QLoRA 原论文在使用权重时反量化到 BF16 进行计算；实际实现还区分量化格式、计算 dtype 与未量化模块的 dtype，见 [bitsandbytes 集成文档](https://huggingface.co/docs/transformers/quantization/bitsandbytes#compute-data-type)。因此完整显存仍包括量化元数据、适配器、梯度、优化器状态、激活与临时工作空间。长序列的激活若已占主导，只压缩基座并不会按同样比例降低峰值。





令 \(Q_4\) 表示包含编码与缩放元数据的量化操作，\(\mathcal D\) 表示反量化，得到 \(\widehat W_0=\mathcal D(Q_4(W_0))\)。沿用前面的权重方向，\(X\in\mathbb R^{m\times d_{\rm in}}\) 是 m 个输入向量，\(W_0,\widehat W_0\in\mathbb R^{d_{\rm out}\times d_{\rm in}}\)，\(A\in\mathbb R^{r\times d_{\rm in}}\)、\(B\in\mathbb R^{d_{\rm out}\times r}\)，\(s=\alpha/r\)。忽略偏置时，输出仍是基座路径与低秩路径之和。置 \(B=0\) 后，初始输出等于量化后的基座；它与原始基座的差为 \(X(\widehat W_0-W_0)^\top\)，一般不为零。前面“零初始化保持基座函数”的结论仍成立，但必须说明用哪一个基座作为参照。





训练时量化编码保持冻结，梯度通过使用 \(\widehat W_0\) 的运算传向适配器及其他允许训练的模块。冻结权重并不使输入导数消失，也不能直接用 no_grad 包住需要向上游传梯度的整段骨干。前文的 PEFT 指参数高效微调这一类方法；[Hugging Face PEFT](https://huggingface.co/docs/peft/index) 同时是实现适配器注入、配置与保存的框架名称。[bitsandbytes](https://huggingface.co/docs/bitsandbytes/reference/nn/linear4bit) 提供量化线性层等底层实现。框架、算子库与 LoRA 算法处在不同层次，安装其中一个并不能证明模块选择、冻结范围和优化器参数组已经正确。





部署时，浮点形式的 \(\widehat W_0+sBA\) 可表达当前量化基座加适配器的有效权重，但若再量化合并结果，就再次引入近似；改用原始 \(W_0+sBA\) 也换了基座。具体后端是否支持合并、如何恢复量化状态，应核对所用版本的 [PEFT 量化说明](https://huggingface.co/docs/peft/developer_guides/quantization)。固定输入，在相同评估模式下对比适配前后、保存恢复后与部署合并后的输出，可以区分训练变化、恢复错误和再量化误差。





选择时先定位瓶颈：仅希望保存小型任务增量，可从 LoRA 理解更新空间；冻结基座的存储已构成约束时，再评价量化适配。对照应固定基础 checkpoint、目标模块、数据、输入长度与评估协议，并分别记录峰值显存、吞吐和新旧任务指标。本章下面的 CPU 实验验证浮点 LoRA 与迁移机制，不验证 NF4 内核、分页行为或 QLoRA 的设备性能；这些结论需要在目标硬件和完整模型上另做测量。





$$
\begin{aligned}\widehat W_0&=\mathcal D(Q_4(W_0)),\\Y_{\rm QLoRA}&=X\widehat W_0^\top+s(XA^\top)B^\top,\\Y_{B=0}-XW_0^\top&=X(\widehat W_0-W_0)^\top.\end{aligned}
$$





## 保留能力需要数据与评价证据

能力保持是适配后模型在原有任务上仍满足既定性能要求的性质。冻结基座只保证一组参数不变，新增增量仍会改变完整函数。判断保持与迁移收益，需要在各自目标分布上评价。





只更新少量参数也能显著改变输出分布，尤其当增量加在影响范围很大的层。冻结基础权重只说明 \(W_0\) 没变，不说明加上适配器后的系统仍保留原行为；新模块、归一化、动作解码与条件分布改变也可能造成退化。因此新任务与原有能力应使用各自明确的保留评估。





可比较全量微调、部分解冻、LoRA 与固定特征基线，但要说明数据量、训练步数、有效样本、调参预算和可训练范围是否一致。不同方法的最优学习率可能不同，严格相同超参数并不总是公平；应固定可解释的搜索预算，并避免让某个方法获得额外测试集反馈。





混合保留数据或加入约束项可以表达能力保持目标，但权重会改变最终优化问题。观察新旧任务的分组指标及梯度，而不是仅看总 loss。若原能力测试条件已参与反复调参，它们成为开发证据，需要另留独立条件评估最终结果。容量更小或更新矩阵低秩都不是免除这些验证的理由。









### 分别回答适应与保持两个问题

新任务损失下降只能说明对该训练目标更合适，无法量化旧任务是否受损。

同时保留新任务与原能力测试，报告分组变化，并记录数据混合与选模规则。

## 迁移优化的目标与源域损失变化

迁移学习是在新任务或新分布中复用已有模型信息，源域风险与目标域风险分别衡量它在两份分布上的误差。一次目标域更新可能改变二者。下面用同一参数空间的梯度分析局部变化，再做独立评价。





迁移学习首先要说明复用什么，以及在哪个分布上衡量收益。令标量回归模型为 \(f_\theta(x)=w^\top h_\psi(x)+b\)，\(h_\psi(x)\in\mathbb R^d\) 是骨干特征，\(w\in\mathbb R^d\)、\(b\in\mathbb R\) 是线性读出。源域与目标域分别记为 S、T，预训练得到 \(\theta_0\)。适配时用 φ 表示本次可训练变量：冻结骨干时 \(\phi=(w,b)\)，全量更新时 \(\phi=(\psi,w,b)\)，LoRA 则用各层 A、B 和允许训练的读出参数表示 φ。相同的监督目标经过不同参数化，允许采用的函数变化方向并不相同。





设目标训练集有 \(n_T\) 个样本，残差 \(e_i=f_{\theta_0,\phi}(x_i)-y_i\)，经验目标是这些残差平方的平均。先对读出和骨干求导：\(\nabla_w\) 是残差加权的特征平均；\(\nabla_\psi\) 还要经过特征对骨干参数的 Jacobian \(J_{h,\psi}(x)\in\mathbb R^{d\times P_\psi}\)，其中 Pψ 是骨干参数数目。冻结 ψ 后这条参数更新路径消失，但 w、b 的改变仍会作用于所有输入，包括旧域样本。LoRA 保留原始矩阵 \(W_0\)，却通过 BA 改变中间特征；低秩约束既不是增量范数约束，也不是旧输出相等约束。前面的初始化与合并推导给出这条梯度路径的具体形式。





记 \(R_S(\phi)\) 为固定参数化下的源域平方风险，\(g_S=\nabla_\phi R_S\)，\(H_S\) 为对 φ 的 Hessian，Δφ 是优化器真正执行的参数位移。对二次可微目标，沿这一步做 Taylor 展开，会得到线性项 \(g_S^\top\Delta\phi\) 和曲率项。式中的 \(\xi\in(0,1)\) 表示更新线段上的某个位置；只有步长足够小、曲率影响可忽略时，线性项才主导损失变化。实际计算用固定独立源探针上的均值近似 \(R_S\)，因而结论还受有限探针的覆盖范围限制。





对无动量、无其他更新项的 SGD，\(\Delta\phi=-\eta g_T\)，因此源风险的一阶变化为 \(-\eta g_S^\top g_T\)：梯度夹角为钝角时，一阶预测为源风险增加。这是梯度冲突的局部解释，相关约束见 GEM 原论文第 3 节；本文没有实现 GEM。Adam 的位移还取决于矩估计、逐坐标缩放与 ε，不能直接替换成 \(-\eta g_T\)。下面保存实际更新前后的 φ，再计算 \(g_S^\top\Delta\phi\)，并与真实源损失变化对照。即便线性预测为负，较大的曲率项仍可能使这次有限更新增加源风险。





只训练线性读出时，可以进一步得到无需忽略高阶项的检查。固定源探针有 m 个输入，把每个 \([h_\psi(x_j)^\top,1]\) 堆成设计矩阵 \(\Phi_S\in\mathbb R^{m\times(d+1)}\)，\(\phi=(w,b)\)。此时模型对 φ 线性，平方风险对 φ 严格二次，精确变化等于 \(g_S^\top\Delta\phi+\frac{\lVert\Phi_S\Delta\phi\rVert^2}{m}\)。代码用前后输出差直接计算第二项，并断言两项之和等于观测到的源 MSE 变化。这个等式具体说明了：骨干完全不动，读出的一个更新也可以损害旧域表现。





若目标域收益必须伴随一定的旧域保持，可以把保持数据混入训练，或声明 \(R_T+\lambda R_S\) 之类的联合目标；这会改变目标函数，而不只是更换微调名称。实际项目应使用独立的目标验证集，并按事先约定的源域保持限制选择 checkpoint 或超参数，最后用未参与选择的测试集报告结果。下面固定适配 600 步，不依据探针早停或调参，以隔离预训练、更新空间与小样本拟合的影响。评估口径与选模纪律见 [策略评估](#/learn/evaluation)。





$$
\begin{aligned}\widehat R_T^{\,y}(\phi)&=\frac1{n_T}\sum_{i=1}^{n_T}e_i^2,\qquad e_i=f_{\theta_0,\phi}(x_i)-y_i\\\nabla_w\widehat R_T^{\,y}&=\frac2{n_T}\sum_i e_i h_\psi(x_i),\quad \nabla_\psi\widehat R_T^{\,y}=\frac2{n_T}\sum_i e_i J_{h,\psi}(x_i)^\top w\\R_S(\phi+\Delta\phi)-R_S(\phi)&=g_S^\top\Delta\phi+\frac12\Delta\phi^\top H_S(\phi+\xi\Delta\phi)\Delta\phi,\quad 0<\xi<1\\\Delta\widehat R_S\ \text{(fixed features)}&=g_S^\top\Delta\phi+\frac1m\lVert\Phi_S\Delta\phi\rVert_2^2\end{aligned}
$$





## 受控迁移实验：从零、冻结、LoRA 与全量适配

上一节的风险变化关系需要一个能够控制变量的实验来核对。这里固定数据生成函数与预训练起点，只改变目标域上的更新范围。保留未适配基座作为参照，可以同时检验迁移收益、过拟合与旧域退化，而不是只比较几个训练后的损失。





下面构造可完整复现的两域回归。输入 \(x\in\mathbb R^2\)，源域为 \(\mathcal N(0,I_2)\)，目标域为 \(\mathcal N((1.5,-1)^\top,0.6^2I_2)\)。两个域共用同一个真函数 \(f^*(x)=\sin(1.5x_1)+0.4x_2^2+0.3x_1x_2\)；训练标签均为 \(y=f^*(x)+\epsilon\)，ε 独立服从 \(\mathcal N(0,0.05^2)\)。因此改变的是输入分布，不是给同一输入强行指定相互冲突的任务标签。这里 \(x_1\)、\(x_2\) 分别对应代码 x[:,0]、x[:,1]。





模型为 2→32→32 的 Tanh 骨干和 32→1 的线性读出，不使用 BatchNorm 或 Dropout，以免混入批次统计与随机模式差异。固定 512 个源训练样本、48 个目标训练样本以及每域 2,048 个独立探针。探针标签使用无噪真函数，测量对条件均值的预测误差；对于训练完的固定模型和重新抽取的独立标签噪声，带噪总体 MSE 比这个风险多常数 \(0.05^2\)。训练集与探针 MSE 的数值不能直接解释为同一批数据上的泛化间隙。





先从固定随机初始化进行 900 次源域 Adam 全批次更新。冻结、LoRA 和全量路线都复制这一份完整 checkpoint，保留同一个已有读出；LoRA 令 A 随机、\(B=0\)，断言三条路线适配前输出完全一致。所有目标优化器重新建立，不继承源域动量。从零路线则复制预训练之前的随机 checkpoint：它与后三条起始函数不同，这是比较预训练作用时有意设置的变量，不能声称四条路线的初始权重完全一样。





每条路线使用同一份目标数据、600 次全批次 Adam 更新、学习率 0.01、零权重衰减，且不混入源训练数据。全量与从零可训练参数均为 \(96+1056+33=1185\)；冻结路线仅训练读出的 33 个数；LoRA 在两个骨干矩阵上分别增加 1×(2+32) 和 1×(32+32) 个参数，再加读出，共 131 个。LoRA 总共存储 1283 个参数；冻结基座仍要占存储。首层权重是 [32,2]，这里使用 r=1 才对其增量施加严格的低秩限制。





表格来自下面代码的真实 CPU、FP32、单线程运行，固定种子 20261106。此协议并未按不同方法搜索最优学习率；相同目标更新次数也不代表相同 FLOPs、显存或总训练成本，预训练路线还额外使用了源数据和 900 步计算。它是机制对照，不是方法性能排行榜。代码输出每 100 步的训练与探针曲线，且用 JSON 保留完整数值、梯度检查和首步位移诊断。





这次运行中，三个预训练适配方案的目标探针误差都低于从零路线，但未适配基座的目标误差更低。目标训练 MSE 从共同的 0.005174 降到 0.003457、0.001770、0.001772，并没有转化为独立目标探针的收益。保留基座参照才会暴露这一点：预训练已经提供了有用迁移，继续拟合这 48 条含噪标签并不自动更好。这组观测与小样本过拟合、更新约束及当前优化设置有关，不能单凭一个种子分离其因果贡献。





源探针中，冻结、LoRA、全量适配的误差都高于基座。冻结路线的骨干逐张量完全不变；LoRA 的基座权重与偏置完全不变，两层增量的数值秩均为 1，但启用适配器后的完整系统仍发生源域退化。此处保持指标包括读出变化，不能把全部退化都归因于骨干表示。关闭 LoRA 再评价会换成另一预测函数，不是同一个适配系统的保持结果。从零路线没有先学过源任务，因此只报告其源域误差，不给它定义遗忘增量。





首步诊断还提供了一个可手算的核对：冻结骨干路线的 \(g_S^\top\Delta\phi\) 约为 −0.002319，但固定特征二次项约为 0.031836，因此源 MSE 实际增加约 0.029517；代码断言这条精确二次等式。全量路线也出现一阶预测为负而真实变化为正，此时非线性和有限位移的高阶影响不能忽略。不要只看两个梯度的夹角，就宣称 Adam 的一次真实更新必然保持旧域。





将这一实验迁移到真实后训练工作时，应把标量回归替换为实际策略目标，重新约定观测和动作表示、数据划分、源能力集合与目标验证协议。当前结果只覆盖一个合成函数、一次分布偏移和一个固定种子，不构成跨机器人迁移、VLA 泛化或闭环成功率证据，也不支持“冻结必然最好”或“LoRA 比全量更容易遗忘”的一般结论。





```python
"""CPU transfer experiment; no external data and no probe-based model selection."""
import argparse
import copy
import json
import math
import time
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F

SEED = 20261106
PRETRAIN_STEPS, ADAPT_STEPS = 900, 600
LEARNING_RATE, NOISE_STD = 0.01, 0.05
RANK = 1


def generator(seed):
    return torch.Generator(device="cpu").manual_seed(seed)


def truth(x):
    # Same conditional mean in both domains: no task-label conflict.
    return (torch.sin(1.5 * x[:, 0]) + 0.4 * x[:, 1].square()
            + 0.3 * x[:, 0] * x[:, 1])[:, None]


def dataset(n, mean, std, seed, noisy):
    rng = generator(seed)
    x = std * torch.randn(n, 2, generator=rng) + torch.tensor(mean)
    y = truth(x)
    if noisy:
        y = y + NOISE_STD * torch.randn(n, 1, generator=rng)
    return x, y


class Regressor(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = nn.Sequential(nn.Linear(2, 32), nn.Tanh(),
                                      nn.Linear(32, 32), nn.Tanh())
        self.head = nn.Linear(32, 1)

    def forward(self, x):
        return self.head(self.backbone(x))


class LowRankLinear(nn.Module):
    def __init__(self, layer, rng):
        super().__init__()
        self.base = copy.deepcopy(layer).requires_grad_(False)
        self.A = nn.Parameter(0.05 * torch.randn(RANK, layer.in_features,
                                                generator=rng))
        self.B = nn.Parameter(torch.zeros(layer.out_features, RANK))
        self.scale = 1.0  # alpha/r = 1; alpha = rank = 1 in this experiment.

    def forward(self, x):
        return self.base(x) + self.scale * F.linear(F.linear(x, self.A), self.B)


def build_variant(name, initial, pretrained):
    model = copy.deepcopy(initial if name == "scratch" else pretrained)
    model.zero_grad(set_to_none=True)
    if name == "frozen":
        model.backbone.requires_grad_(False)
    if name == "lora":
        rng = generator(SEED + 20)
        for i in (0, 2):
            model.backbone[i] = LowRankLinear(model.backbone[i], rng)
    return model


@torch.no_grad()
def mse(model, data):
    return F.mse_loss(model(data[0]), data[1]).item()


def scalar_norm(tensors):
    return math.sqrt(sum(t.square().sum().item() for t in tensors))


def run():
    started = time.perf_counter()
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    # Fixed independent splits. Both observed training distributions use noise SD .05.
    source_train = dataset(512, [0., 0.], 1.0, SEED + 1, True)
    target_train = dataset(48, [1.5, -1.], 0.6, SEED + 2, True)
    source_probe = dataset(2048, [0., 0.], 1.0, SEED + 3, False)
    target_probe = dataset(2048, [1.5, -1.], 0.6, SEED + 4, False)
    initial = Regressor()
    pretrained = copy.deepcopy(initial)
    pre_optimizer = torch.optim.Adam(pretrained.parameters(), lr=LEARNING_RATE)
    for _ in range(PRETRAIN_STEPS):
        pre_optimizer.zero_grad(set_to_none=True)
        loss = F.mse_loss(pretrained(source_train[0]), source_train[1])
        loss.backward()
        pre_optimizer.step()
    pretrained.zero_grad(set_to_none=True)
    base_source = mse(pretrained, source_probe)
    base_target = mse(pretrained, target_probe)
    result = {
        "seed": SEED, "torch": torch.__version__, "device": "cpu", "dtype": "float32",
        "config": {"source_n": 512, "target_n": 48, "probe_n_each": 2048,
                   "pretrain_steps": PRETRAIN_STEPS, "adapt_steps": ADAPT_STEPS,
                   "optimizer": "Adam; fresh state for every target run",
                   "lr": LEARNING_RATE, "weight_decay": 0., "batching": "full batch",
                   "source_mean": [0., 0.], "source_std": 1.0,
                   "target_mean": [1.5, -1.], "target_std": 0.6,
                   "label_noise_std": NOISE_STD, "probe_labels": "clean conditional mean",
                   "rank": RANK, "lora_scale": 1.0},
        "pretrained": {"source_probe_mse": base_source, "target_probe_mse": base_target,
                       "source_train_noisy_mse": mse(pretrained, source_train)},
        "methods": [],
    }
    for name in ("scratch", "frozen", "lora", "full"):
        model = build_variant(name, initial, pretrained)
        trainable = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
        parameters = [p for _, p in trainable]
        frozen = {n: p.detach().clone() for n, p in model.named_parameters()
                  if not p.requires_grad}
        before = {n: p.detach().clone() for n, p in trainable}
        start_s, start_t = mse(model, source_probe), mse(model, target_probe)
        start_training = mse(model, target_train)
        with torch.no_grad():
            difference = (model(target_probe[0]) - pretrained(target_probe[0])).abs().max().item()
        if name != "scratch":
            assert difference == 0., "Pretrained adaptation routes must start identically"
        opt = torch.optim.Adam(parameters, lr=LEARNING_RATE)
        curve = [{"step": 0, "source_mse": start_s, "target_mse": start_t,
                  "target_train_noisy_mse": start_training}]
        # Probe derivatives diagnose an update; never used by the optimizer or stopping rule.
        source_grad = torch.autograd.grad(
            F.mse_loss(model(source_probe[0]), source_probe[1]), parameters)
        first_before = [p.detach().clone() for p in parameters]
        with torch.no_grad():
            source_output_before = model(source_probe[0]).clone()
        first_step, lora_gradients = {}, {}
        for step in range(1, ADAPT_STEPS + 1):
            opt.zero_grad(set_to_none=True)
            loss = F.mse_loss(model(target_train[0]), target_train[1])
            assert torch.isfinite(loss)
            loss.backward()
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in parameters)
            if name == "lora" and step in (1, 2):
                for suffix in ("A", "B"):
                    value = scalar_norm([p.grad for n, p in trainable if n.endswith("." + suffix)])
                    lora_gradients[f"step_{step}_{suffix}_norm"] = value
            opt.step()
            if step == 1:
                delta = [p.detach() - old for p, old in zip(parameters, first_before)]
                linear_prediction = sum((g * d).sum().item() for g, d in zip(source_grad, delta))
                actual_change = mse(model, source_probe) - start_s
                first_step = {"source_gradient_norm": scalar_norm(source_grad),
                              "parameter_step_norm": scalar_norm(delta),
                              "linear_source_change": linear_prediction,
                              "actual_source_change": actual_change,
                              "taylor_remainder": actual_change - linear_prediction}
                if name == "frozen":
                    # Fixed features + a linear head make the source MSE exactly quadratic.
                    with torch.no_grad():
                        quadratic_term = (model(source_probe[0]) - source_output_before).square().mean().item()
                    assert abs(actual_change - linear_prediction - quadratic_term) < 2e-7
                    first_step["exact_head_quadratic_term"] = quadratic_term
            if step % 100 == 0:
                curve.append({"step": step, "source_mse": mse(model, source_probe),
                              "target_mse": mse(model, target_probe),
                              "target_train_noisy_mse": mse(model, target_train)})
        frozen_equal = all(torch.equal(dict(model.named_parameters())[n], v)
                           for n, v in frozen.items())
        frozen_no_grad = all(dict(model.named_parameters())[n].grad is None for n in frozen)
        assert frozen_equal and frozen_no_grad
        low_rank_checks = []
        if name == "lora":
            assert lora_gradients["step_1_A_norm"] == 0.
            assert lora_gradients["step_1_B_norm"] > 0. and lora_gradients["step_2_A_norm"] > 0.
            for i in (0, 2):
                layer = model.backbone[i]
                delta = (layer.scale * (layer.B @ layer.A)).detach()
                observed_rank = int(torch.linalg.matrix_rank(delta))
                assert observed_rank <= RANK and delta.norm().item() > 0.
                low_rank_checks.append({"layer": i, "shape": list(delta.shape),
                                        "rank": observed_rank, "frobenius_norm": delta.norm().item()})
        parameter_change = scalar_norm([p.detach() - before[n] for n, p in trainable])
        assert parameter_change > 0.
        final_s, final_t = mse(model, source_probe), mse(model, target_probe)
        result["methods"].append({
            "method": name, "trainable_parameters": sum(p.numel() for p in parameters),
            "stored_parameters": sum(p.numel() for p in model.parameters()),
            "initial_source_mse": start_s, "initial_target_mse": start_t,
            "initial_target_train_noisy_mse": start_training,
            "final_source_mse": final_s, "final_target_mse": final_t,
            "target_train_noisy_mse": mse(model, target_train),
            "source_change_from_pretrained": None if name == "scratch" else final_s - base_source,
            "initial_pretrained_output_maxdiff": None if name == "scratch" else difference,
            "frozen_parameters_exactly_equal": frozen_equal,
            "frozen_parameters_have_no_grad": frozen_no_grad,
            "trainable_parameter_change_norm": parameter_change,
            "first_step": first_step, "lora_gradients": lora_gradients,
            "low_rank_checks": low_rank_checks, "curve": curve,
        })
    result["seconds_in_process"] = time.perf_counter() - started
    result["checks_passed"] = True
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="transfer_results.json")
    args = parser.parse_args()
    results = run()
    Path(args.output).write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    for row in results["methods"]:
        print(row["method"], "trainable", row["trainable_parameters"],
              "target", round(row["final_target_mse"], 6),
              "source", round(row["final_source_mse"], 6))
    print("seconds", round(results["seconds_in_process"], 3), "checks passed")

```

保存为 transfer_controlled.py，运行 python transfer_controlled.py；仅依赖 PyTorch 和标准库。默认写出 transfer_results.json，可用 --output 指定路径。build_variant 明确初始化和可训练范围；source_grad 只用于解释首步，优化器只接收目标训练 loss。测试覆盖预训练路线初始输出相等、冻结参数与梯度、LoRA 第一/第二步梯度、增量秩，以及固定特征源风险变化的精确二次等式。常数步数在看探针前已固定，没有早停或择优报告。代码统计的是机制与误差，不测试某一种方法必胜。



### 一次固定种子运行：训练拟合、目标泛化与源域保持分别报告

| 路线 | 适配可训练参数 | 目标训练 MSE（含噪） | 目标探针 MSE（干净） | 源探针 MSE（干净） | 源 MSE 相对基座变化 |

|---|---|---|---|---|---|

| 预训练基座，不适配 | 0 | 0.005174 | 0.001519 | 0.012809 | 0 |

| 从零训练 | 1185 | 0.001715 | 0.008821 | 0.562597 | —，未先学习源域 |

| 冻结骨干，仅训练读出 | 33 | 0.003457 | 0.001861 | 0.022338 | +0.009529 |

| LoRA r=1 + 读出 | 131 | 0.001770 | 0.003059 | 0.078981 | +0.066172 |

| 全量适配 | 1185 | 0.001772 | 0.003689 | 0.042288 | +0.029479 |



## 用更新与恢复测试闭合微调流程

数学上的参数化正确，还需要通过保存、加载与部署保持相同计算。一次实际更新和一次独立恢复分别验证训练链路与交付链路。将这些检查与前面的初始化、梯度和合并性质组合，才能判断微调流程是否闭合。





在开始长训练前，列出所有可训练参数名、形状与参数组；对一小批输入运行前后向，检查预计训练的参数具有有限梯度，预计冻结的参数保持不变。某些参数在特定样本上梯度为零可能合理，因此用多个有辨别力的输入和明确初始化预期，避免把一次检查当作永久证明。





然后比较 step 前后的实际数值，检查优化器是否持有当前模型的参数对象。有时替换模块后优化器仍引用旧层，loss.backward 正常、梯度正常，但新模块不会更新。保存后在新进程重新构造基础模型与适配器，加载状态并验证固定输入输出一致，才闭合训练到部署的链路。





初始等价、A/B 梯度、冻结基础权重、可训练参数量与合并等价，是互不替代的性质。迁移到实际模型时，额外模块、预处理统计和任务配置也属于检查范围；可训练参数占比只覆盖其中一项。





微调需要共同定义监督目标、可更新参数与增量形式。LoRA 回答怎样限制参数更新，源域与目标域评价回答更新是否有效；初始化、合并和恢复则保证这份方法在实际程序中仍是同一个函数。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| base weight W0 | [D_out,D_in] | 冻结的原始线性层权重 |
| A / B | [r,D_in] / [D_out,r] | 可训练低秩更新因子 |
| input / output | [...,D_in] / [...,D_out] | 支持 Batch 与 token 维的线性投影 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(7)
torch.set_num_threads(1)

# STEP 1: 冻结原层，A 随机、B 为零
class LoRALinear(nn.Module):
    def __init__(self, in_dim, out_dim, rank=2, alpha=2.):
        super().__init__()
        self.base = nn.Linear(in_dim,out_dim)
        self.base.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(rank,in_dim)*0.1)
        self.B = nn.Parameter(torch.zeros(out_dim,rank))
        self.scale = alpha/rank
    def forward(self,x):
        return self.base(x) + self.scale*F.linear(F.linear(x,self.A),self.B)

layer = LoRALinear(4,3)
x = torch.randn(32,4)
target = torch.randn(32,3)
frozen_weight = layer.base.weight.detach().clone()
torch.testing.assert_close(layer(x),layer.base(x))

# STEP 2: 检查第一步梯度，区分零梯度与没有梯度
optimizer = torch.optim.AdamW([p for p in layer.parameters() if p.requires_grad],lr=0.03)
loss = (layer(x)-target).square().mean()
loss.backward()
print('first A/B grad norms:', layer.A.grad.norm().item(), layer.B.grad.norm().item())
assert layer.A.grad is not None and layer.B.grad is not None
assert layer.base.weight.grad is None
optimizer.step()

# STEP 3: 小型监督训练，只更新适配器
for _ in range(60):
    loss = (layer(x)-target).square().mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()
torch.testing.assert_close(layer.base.weight, frozen_weight)

# STEP 4: 合并后线性层应与适配器前向等价
with torch.no_grad():
    merged = layer.base.weight + layer.scale*(layer.B @ layer.A)
    merged_output = F.linear(x,merged,layer.base.bias)
    torch.testing.assert_close(merged_output,layer(x),atol=1e-6,rtol=1e-5)
print('trainable parameters:', sum(p.numel() for p in layer.parameters() if p.requires_grad))
print('frozen weight unchanged; merge check passed')

```

- 第 8–25 行：低秩分支与原层相加；由于 B 为零，模型初始行为与冻结原层完全相同。
- 第 26–34 行：第一次 A 的梯度可为零，B 的梯度可非零。冻结原权重的 grad 应是 None；这些状态代表不同原因。
- 第 35–42 行：只把可训练参数送进优化器，并检查原权重未变。这个合成回归任务只用于验证训练路径。
- 第 43–49 行：合并公式是 W0+scale·B@A。比较合并前后输出，可直接发现矩阵方向或缩放错误。

预期观察：首步 A 梯度范数为零，B 梯度通常非零；可训练参数数目为 14；冻结权重和 LoRA 合并检查通过。

## 浏览器 Python 练习

实现 parameter_counts(in_dim,out_dim,rank)。返回包含 frozen 与 trainable 的字典。原层含偏置且全部冻结；低秩 A/B 不含偏置。维度与 rank 都必须是正整数。

```python
def parameter_counts(in_dim, out_dim, rank):
    # TODO: 分别统计原层和两个低秩矩阵
    raise NotImplementedError

```

### 提示

- A 有 rank×in_dim 个参数，B 有 out_dim×rank 个。
- 原层的偏置有 out_dim 个元素，本题约定它也被冻结。

### 参考实现与解释

```python
def parameter_counts(in_dim, out_dim, rank):
    if any(not isinstance(x,int) or x <= 0 for x in (in_dim,out_dim,rank)):
        raise ValueError('dimensions must be positive integers')
    return {'frozen':in_dim*out_dim+out_dim, 'trainable':rank*(in_dim+out_dim)}

```

当层本身很小或 rank 很大时，低秩参数总数可能超过原层。实际显存还包含激活、梯度和优化器状态，不能只根据这一计数推断完整训练显存。

### 断言测试

```python
assert parameter_counts(8,6,2) == {'frozen':54,'trainable':28}
assert parameter_counts(4,3,2) == {'frozen':15,'trainable':14}
assert parameter_counts(4,4,4) == {'frozen':20,'trainable':32}
try:
    parameter_counts(8,6,0)
    raise AssertionError('零秩应报错')
except ValueError:
    pass
print('参数量检查通过：较大的 rank 不保证参数更少。')

```

## 本地 PyTorch 练习

实现 lora_forward(x,W,b,A,B,alpha)。按 \(\alpha/r\) 缩放低秩分支，支持 x 的任意前导维度。函数只实现前向；哪些输入需要梯度由调用者设置。

```python
import torch
from torch.nn import functional as F

def lora_forward(x,W,b,A,B,alpha):
    # TODO: 原线性层 + 低秩更新
    raise NotImplementedError

```

### 提示

- F.linear 的权重形状是 [out,in]，先过 A 再过 B。
- 缩放量 alpha/r 只作用于低秩增量，不作用于原层输出。

### 参考实现与解释

```python
import torch
from torch.nn import functional as F

def lora_forward(x,W,b,A,B,alpha):
    rank = A.shape[0]
    if rank <= 0 or B.shape != (W.shape[0],rank) or A.shape[1] != W.shape[1]:
        raise ValueError('invalid LoRA shape')
    return F.linear(x,W,b) + (alpha/rank)*F.linear(F.linear(x,A),B)

```

A 将输入投到 r 维，B 再投到输出维，因此增量权重是 B@A。用 F.linear(F.linear(x,A),B) 可以保留任意前导 Batch/token 维。与 F.linear(x,W+(alpha/r)*B@A,b) 比较能验证方向与缩放。此函数只定义计算，不负责冻结 W；调用方必须设置 requires_grad、优化器参数组和保存范围。

### 断言测试

```python
torch.manual_seed(3)
x = torch.randn(2,5,4)
W = torch.randn(3,4)
b = torch.randn(3)
A = torch.randn(2,4,requires_grad=True)
B = torch.randn(3,2,requires_grad=True)
y = lora_forward(x,W,b,A,B,4.)
merged = F.linear(x,W+2*(B@A),b)
torch.testing.assert_close(y,merged)
torch.testing.assert_close(lora_forward(x,W,b,A,torch.zeros_like(B),4.),F.linear(x,W,b))
y.square().mean().backward()
assert A.grad is not None and B.grad is not None and W.grad is None
print('LoRA 前向、合并等价性与梯度检查通过。')

```

## 练习：推导与分析

### 首步 A.grad 全零、B.grad 非零，而冻结原权重 grad=None，这三种状态分别说明什么？

B 初始化为零时，监督损失传向 A 的路径会被 B 乘成零，所以 A 的梯度张量可能存在但全零。B 的梯度可通过非零的 A 和输入得到。冻结原权重则不需要计算该参数梯度，通常显示 None，含义与“参与计算但导数为零”不同。

确认优化器更新 B 后，检查后续 A 的监督梯度。还需区分梯度与实际参数变化：某些优化器的权重衰减或历史动量也可能改变零当前梯度的参数。用参数前后差值、梯度和优化器配置三者联合判断。

代码定位：LoRALinear 初始化、first A/B grad norms 与 optimizer.step() 前后参数快照。

- 区分 None、零梯度和非零梯度。
- 说明必须检查参数更新而不只看梯度。

### 骨干完全冻结，为什么仍需要评估语言跟随和旧任务？

完整系统包含骨干之外的投影器、适配器、读出头、预处理与动作解码。骨干权重固定仅说明这些参数没有被更新，不保证新模块仍正确利用已有表征。新头也可能偏向视觉捷径，或通过错误归一化改变输出含义。

保留独立旧任务集与同图不同指令的配对检查。比较新任务成功率、旧任务保留和语言条件敏感性，固定评估条件。另做梯度与权重差值检查，确认所谓冻结在实现中真实成立；实现检查和能力评估回答不同问题。

代码定位：base.requires_grad_(False)、参数组筛选及旧任务/指令干预评估入口。

- 解释参数不变与系统行为不变的差异。
- 给出旧任务和语言条件两类独立评估。

### 量化基座上的 LoRA 令 B=0，却与原始浮点模型输出不同，是否说明初始化代码有错？应如何定位？

不能仅据此判断。B=0 只消除低秩分支，保留的是反量化后的基座权重。先在相同输入、模式与计算 dtype 下对比量化基座和启用零增量适配器的输出；再单独比较量化基座与原始浮点基座。后一差异可以来自量化，不能归到 LoRA 初始化。

对于本节忽略偏置的单层，量化前后的输出差恰为 \(X(\widehat W_0-W_0)^\top\)。完整网络还会传播这些局部误差，因此不能把某层的误差直接等同最终策略误差。保存恢复与合并再量化需要各自的对照输入，最终还应评价新旧任务行为。

代码定位：在已有 LoRALinear 初始化与合并检查中区分原始基座、量化基座和带适配器的模型；现有示例未实现真实量化后端。

- 给出正确的初始等价参照。
- 将量化误差、低秩增量与恢复/合并误差分别定位。

## 练习：辨析与纠错

### 冻结权重后把所有相关计算都 detach

冻结与梯度通路不同。检查可训练模块的位置，并验证上游所需梯度没有被 no_grad 截断。

### A 与 B 同时零初始化

基础 LoRA 的两个因子会相互阻断起步梯度。按初始化设计检查初始输出与两步梯度。

### 用参数比例直接预测显存比例

基础权重、激活、注意力和优化器状态是不同开销。测量真实峰值显存并定位主导部分。

### 保存适配器但不保存基础模型身份

同形基础模型可能来自不同权重或结构，加载后行为会改变。绑定配置与基础版本，进行新进程恢复对照。

### LoRA 自动避免遗忘

低秩增量仍能显著改变行为。保留独立旧能力评估并记录新旧目标的权重。

## 原始资料

- [LoRA 原论文](https://arxiv.org/abs/2106.09685)
- [Hugging Face PEFT：LoRA 概念与参数](https://huggingface.co/docs/peft/main/en/conceptual_guides/lora)
- [PyTorch：自动微分与冻结参数](https://docs.pytorch.org/docs/stable/notes/autograd.html)
- [PEFT 官方文档：方法范围与配置](https://huggingface.co/docs/peft/main/en/index)
- [GEM 原论文：旧任务风险、梯度约束与局部近似](https://arxiv.org/abs/1706.08840)
- [QLoRA 原论文：NF4、双重量化、分页优化器与计算精度](https://arxiv.org/abs/2305.14314)
- [PEFT 官方文档：量化模型上的适配训练](https://huggingface.co/docs/peft/developer_guides/quantization)
- [Transformers / bitsandbytes：存储格式与计算 dtype](https://huggingface.co/docs/transformers/quantization/bitsandbytes)
- [bitsandbytes 官方参考：4 bit 线性层](https://huggingface.co/docs/bitsandbytes/reference/nn/linear4bit)
