# 视觉与图文预训练：DINO、CLIP 与 SigLIP

从视觉自蒸馏、图文匹配到可复用的编码器。

视觉预训练为下游任务学习可复用的图像特征。DINO 与 DINOv2 通过同一图像不同视图间的自监督学习视觉表示；CLIP 与 SigLIP 通过图文配对学习跨模态匹配。它们规定训练信号，ResNet 或 ViT 则规定网络结构。本章先比较两条路线，再推导图文相似度、损失与梯度，最后讨论全局向量和空间特征怎样用于下游任务。

## 学习目标

- 区分视觉自蒸馏与图文配对监督，并按下游任务选择全局或空间特征。
- 构建图像—文本相似度矩阵和正确的配对标签。
- 实现对称对比交叉熵，区分 Sigmoid 成对目标。
- 解释温度、假负例及全局语义表征对精确读出的限制。

前置知识：[概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [视觉编码器与多模态融合](https://wxb1870.github.io/embodied-ml-lab/learn/multimodal/)

## 配对关系与监督目标

正配对是数据中被声明相符的图像与文本，负配对是目标要求区分的不匹配关系。图文预训练将识别这些关系转化为学习信号，使两个编码器的表示可以比较。监督定义了何种对应被奖励，却未覆盖所有视觉属性。

![CLIP 完整流程：图文分别编码形成配对相似度矩阵进行对比预训练；类别文本编码为分类器，与新图像特征比较完成零样本预测。](../assets/figures/clip-overview-original.png)

左侧：图文分别编码，再用相似度矩阵学习配对关系。右侧：把类别文字编码成候选，与新图像比较，得到零样本分类结果。图源：[OpenAI CLIP](https://github.com/openai/CLIP)。



图文对比学习从配对样本出发：图像编码器和文本编码器各输出一个向量，希望匹配对在相似度矩阵中更容易被识别。训练目标规定哪些对应关系被奖励，却不会自动告诉模型所有物理属性。描述中常出现的对象和属性可能被强调，未被描述的精细几何或操作状态可能缺少直接监督。理解特征为何可迁移，要从目标与数据覆盖开始，而不是只看骨干规模。





将一个 Batch 的 B 张图像与 B 条文本两两比较，得到 [B,B] 分数矩阵，通常对角线是本批给定的匹配关系。这个对角结构依赖数据保持顺序：独立 shuffle 文本后仍使用 arange(B) 作标签，会训练错误配对。不同数据可能一图多描述、一文本多图，原始的一一对角假设需要扩展，不能把所有非对角关系都无条件当成语义上互斥的负例。









### 先验证配对，再讨论温度或网络结构

相似度和交叉熵都能正常计算，但标签排列错误会优化完全不同的任务。

打印图像 ID 与文本源 ID，做已知匹配/打乱配对对照，确认标签矩阵符合数据关系。

## DINO 与 DINOv2：没有配对文本时，视觉特征怎样学习

DINO 是“无标签自蒸馏”：让学生网络从一幅图的不同增强视图中，对齐教师网络给出的预测分布。DINOv2 在这一思路上构建大规模视觉预训练方法与可直接复用的 ViT 编码器。先认识训练信号，再选择下游读取的特征。

![DINO 自蒸馏训练：同一图像的不同视图进入学生和教师，学生对齐教师分布，教师通过学生参数的指数移动平均更新。](../assets/figures/dino-self-distillation.svg)

同一图像的不同视图进入学生和教师；交叉熵更新学生，EMA 更新教师。图源：[DINO 论文图 2](https://arxiv.org/html/2104.14294v2#S1.F2)。



同一幅图经过不同裁剪和增强，分别进入学生与教师。学生的预测分布对齐教师目标，损失更新学生；教师参数由学生参数的指数移动平均更新，目标支路停止梯度。教师看全局裁剪，学生还学习从局部裁剪理解同一图像。教师输出的中心化与温度调整也是原方法训练设计的一部分。





DINOv2 扩展了数据组织、模型规模与训练方法，同时利用图像级自蒸馏和被遮挡 Patch 位置的教师目标来学习表示。使用发布权重时，可以读取汇总图像的 CLS 向量，也可以读取保留网格位置的 Patch 向量；这两类接口的下游用途不同。具体的空间特征示例见[视觉编码器](#/learn/multimodal?section=4)。





有大量图像、缺少可靠图文配对时，这类方法提供一条视觉预训练路线。使用现成编码器时，可先冻结骨干，用全局特征训练分类或检索读出，或用 Patch 特征训练分割、深度等空间读出。需要由文字定义类别、做图文检索时，则应考虑下一部分的图文对齐表示，并明确文字分支怎样接入。









## 相似度单位化、温度与梯度

向量单位化把特征缩放到单位长度，使点积只比较方向；温度或尺度再调节相似度差异进入损失时的强弱。前者约束表示，后者改变候选竞争或成对分类的数值尺度。下面分别追踪其梯度。





常见做法先将图像与文本向量按 L2 范数单位化，点积于是等于余弦相似度，再乘正尺度 \(s=\exp(\alpha)\)，或除以温度 \(\tau\)。单位化减少模型仅靠放大向量范数提高分数的自由度，温度控制候选之间的区分强度。这里 \(\alpha\) 若是可学习参数，应明确是否实际优化其指数，并防止不合理尺度；不能把 logit_scale 本身和 `exp(logit_scale)` 混为一谈。





小温度使 Softmax 更尖锐，也会放大梯度尺度及对困难配对的关注；它不增加冻结特征中原本没有的可区分信息。若所有候选方向相同，单纯提高尺度不会让正确配对变得唯一。F.normalize 的 \(\varepsilon\) 与零向量处理也应纳入数值检查。相似度分数并不能直接解释为可跨数据集比较的置信概率，候选集合与温度改变都会改变 Softmax 概率。





单位化的导数可以直接由微分建立。令 \(r=\sqrt{v^\top v}>0\)，则 \(dr=v^\top dv/r=u^\top dv\)；对 \(u=v/r\) 求导得到 \(du=dv/r-v\,dr/r^2=(I-uu^\top)dv/r\)。括号内删除沿 \(u\) 的分量，剩余变化位于单位球面的切空间。此处不经过零范数或实现中的截断区域，因此结论不能直接替代那个区域的具体数值约定。





对非零向量 v，令 \(u=\frac v{\lVert v\rVert_2}\)，并假定范数大于实现的 \(\varepsilon\) 截断阈值。Jacobian 为 \(\frac{I-uu^\top}{\lVert v\rVert_2}\)，所以单位化前的梯度与 v 正交：损失主要推动方向改变，径向变化不会一阶改变余弦分数。但范数仍出现在分母中，同样的上游梯度会因原向量范数不同而产生不同的参数更新幅度；前向对正比例缩放不敏感，不等于 SGD 训练过程对缩放完全不敏感。





$$
\hat v_i=\frac{v_i}{\|v_i\|},\quad\hat t_j=\frac{t_j}{\|t_j\|},\quad S_{ij}=e^{\alpha}\hat v_i^T\hat t_j
$$





## 双向交叉熵与尺度参数梯度

双向对比交叉熵分别把“由图找文”和“由文找图”作为候选分类任务，再合并两项损失。它们使用同一相似度矩阵，却沿不同轴归一化。先定义两个检索方向，再推导特征和尺度的更新。





图像到文本方向把 S 的每一行当成 B 类 logits，目标是同索引文本；文本到图像方向对 S 的转置做同样计算。两方向的平均要求每张图能找到其文本、每条文本也能找到其图像。虽然它们使用同一矩阵，但归一化分母分别沿行和列，不能只把某一个方向乘 2 当作对称目标。实现时 cross_entropy 接收原始 logits，不需要再先做 Softmax。



### 例：行分类与列分类确实是两项不同损失

1. 取匹配分数矩阵 \(S=\begin{bmatrix}2&0\\1&3\end{bmatrix}\)，两个对角位置为正例。两行的正确分数均领先 2，因此图像到文本平均损失为 \(\log(1+e^{-2})\)。

2. 第一列的正确分数领先 1，第二列领先 3，因此文本到图像损失为 \(\tfrac12[\log(1+e^{-1})+\log(1+e^{-3})]\)。

3. 对称目标再取两者平均；候选分数没有改变，变化的是每次归一化所使用的集合。

共享一个相似度矩阵不意味着两个方向的交叉熵相等。

对一行分类损失，分数梯度为 \(p_j-\mathbf1[j=i]\)，因此正确项被拉高，其他项按当前预测概率被压低。温度又通过链式法则影响特征梯度。可以把这看成在当前候选集合中区分匹配，而不是要求所有负图文在绝对意义上毫不相似。Batch 组成会改变分母与负例难度，报告损失时要记录 Batch 及采样约定，不能跨完全不同设置直接比较数值大小。





令一行余弦相似度为 \(c_j\)，正例为 \(c_+\)，\(\mathrm{logits}_j=e^\alpha c_j\)。由交叉熵可得 \(\frac{\partial L}{\partial\alpha}=e^\alpha\left(\sum_jp_jc_j-c_+\right)\)。若正例高于当前概率加权平均，梯度下降倾向增大尺度，让分布更尖；若最高分主要来自错误匹配，继续增大尺度反而加重损失。所有 \(c_j\)相同时，这个导数为零，调温度无法打破并列。这个式子只针对固定候选的一行，完整对称目标还要汇总所有行与列。





$$
L=\frac12\left[-\frac1B\sum_i\log\frac{e^{S_{ii}}}{\sum_j e^{S_{ij}}}-\frac1B\sum_i\log\frac{e^{S_{ii}}}{\sum_j e^{S_{ji}}}\right]
$$





## 批内负例与候选集合

批内负例是利用同一批次其他样本构造的不匹配候选。候选集合决定模型当前需要区分谁，也决定 Softmax 的归一化分母。批次大小、重复描述和语义重合都会改变这个学习问题。





每个 Batch 给出 B 个正对和 \(B(B-1)\) 个非对角关系。更大的 Batch 通常引入更多候选，却不保证每个新增负例都有价值；重复描述和相近场景还可能产生假负例。\(B=1\) 时，对角 Softmax 的分母只有自己，交叉熵恒为零，这个目标无法提供区分配对的训练信号。单样本 loss 为零不能当作模型已经学会匹配。





多卡训练常汇聚不同 rank 的图文特征构造更大候选池，需要正确的全局标签偏移和梯度通信。简单把远端特征 detach 后拼接，是否得到想要的目标梯度取决于整体实现，不能只验证分数矩阵大小。教学代码的本地 \(B\times B\) 数值验证不等同于完整分布式实现验证。若队列或历史特征被用作负例，还应说明它们对应旧参数，和当前同批特征的更新机制不同。









### B=1 的零损失不是学习成功

单候选 Softmax 概率固定为 1，梯度消失；这由目标结构决定。

至少用两个不同配对构造可区分测试，并检查错配损失、梯度及全局标签偏移。

## Sigmoid 成对目标与归约分母

Sigmoid 成对目标将每个图文组合视为匹配与否的二分类，而不强制一行候选共享总概率。它与 Softmax 对比目标的归一化关系不同。下面先定义正负标签，再分析损失稳定形式与归约。





SigLIP 式目标可对每个图文对做二分类，正对符号 \(z=+1\)、负对 \(z=-1\)，用 \(\operatorname{softplus}(-z\,\mathrm{logit})\) 稳定计算负对数似然。它不要求每一行概率总和为 1；某图与多条文本的预测可同时较高。通常还需分数尺度与偏置，偏置有助于处理匹配对比例。不能只将 CLIP 的 Softmax 换成 sigmoid 而保持所有其他假设不变。





归约方式必须明确。若对 \(B^2\) 个配对求和后除以 B，与直接 mean 除以 \(B^2\) 相差 B 倍，梯度尺度不同；当 B 改变时，这个差异不是固定常数。负例采样、正负权重和偏置初始化也会影响目标。当前教学示例按 B 归约，用已知正负关系验证稳定计算，不试图复刻任意公开训练系统的全部配置。比较方法时应先统一实际优化的目标与计算预算。





若目标是从一行候选中找出对应项，CLIP 式 Softmax 直接建立候选之间的竞争；若希望以图文对为基本单元定义“匹配 / 不匹配”，可考虑 SigLIP 式目标，并同时设计正负配对抽样、权重与偏置。两种选择都应从数据中真实可用的配对关系开始，而非仅替换一个函数名。





$$
L_{pair}=\frac1B\sum_{i,j}\operatorname{softplus}(-z_{ij}S_{ij}),\quad z_{ii}=1,\ z_{ij}=-1\ (i\ne j)
$$



### 例：两种归约为什么差一倍

1. \(B=2\) 时有 4 个配对损失，假设它们总和为 8。

2. 按 B 归约得到 4；对全部配对 mean 得到 2。

3. \(B=4\) 时同一差异比例变为 4，而不是仍为 2。

分母是算法约定的一部分，不能把 loss 的数值缩放当成无关显示细节。

## 假负例与两种多正例目标

假负例是语义上也相符、却被一一配对标签当成负例的组合；多正例目标允许一个查询对应多个正确候选。它们涉及监督关系的重新定义，而非只调整温度。下面比较两种多正例目标如何分配概率。





若两张图都符合“红色杯子”的描述，标准一一匹配目标仍可能把交叉配对当成负例，这是数据语义与监督标签之间的冲突。可考虑更清晰描述、多正例目标或过滤/权重策略，但这些都改变了训练问题，应明确比较。把标签简单全改为正例又会失去区分能力，不能作为通用修复。需要先理解数据中的等价关系与希望保留的细粒度差异。





“使用多正例”也不是唯一目标。设正例集合为 P、所有候选概率为 \(p_j\)。\(-\log\!\left(\sum_{j\in P}p_j\right)\) 只要求总概率进入正例集合，一个正例吸收几乎全部质量也可得到低损失；\(-\frac1{|P|}\sum_{j\in P}\log p_j\) 则要求每个正例都分到概率。两个正例时，\(p=(0.99,0.01)\) 的前者为 0，后者约 2.31；\(p=(0.5,0.5)\) 的前者仍为 0，后者约 0.693。前者表达“任一个正确答案即可”，后者更接近“每个标注正例都应被检索到”；应由任务语义选择。





评估检索或迁移时，重复图像、相邻帧、同一原始样本的裁剪和描述变体可能跨集合泄漏。模型记住来源特征也能得到看似良好的配对指标，却未必学会任务所需概念。应按原始来源、场景或轨迹划分，并设计与目标泛化匹配的测试。图文匹配训练的成功还可能依赖水印、背景和固定模板，需要用内容替换、背景变化等对照判断捷径。









### 非对角不必然意味着语义错误

Batch 对角标签是一种数据假设；重复或等价描述会引入假负例。

抽查高损失非对角对是否实际上匹配，保留原始来源 ID，按任务定义处理多正例关系。

## 全局检索与下游表示

全局图文表示是把整幅图或整段文字汇总后的向量，适合比较整体匹配。局部动作任务还可能需要空间位置与细节。全局目标支持的能力，不能自动当成对每个 Patch 或控制变量的监督。





全局对比向量适合检索和某些分类，但动作模型可能需要局部位置、对象关系、历史状态或接触信息。将整图压成一个向量可能丢失细粒度结构；某层 patch 表征则可能保留更丰富空间线索，却没有被全局目标逐项验证。选择特征层、池化和条件接口需要下游对照，不能认为“来自强视觉编码器”就自动解决所有机器人观测建模。





线性探针、非线性适配、冻结或微调都是检查表示可用性的不同方式。小数据上适配失败，可能是信息不足，也可能是优化、尺度、标签或划分问题；成功则只证明在该评价设置下可用。后训练应同时检查新任务表现与既有图文能力，记录条件是否真正影响输出。对比 Loss 下降、检索提升和闭环成功率是不同指标，需分别给出证据。









## 代表工作：自监督视觉与图文对齐

预训练可通过图像视图间的一致性或图文对应关系产生学习信号。DINO 系列强调视觉表征，CLIP 与 SigLIP 建立图文比较接口。将训练目标与编码器结构分开，才能选择合适的下游用法。





CLIP 和 SigLIP 采用双编码器：图像与文本分别编码，经过各自的汇聚与投影后，在共同特征空间比较全局向量。它们不是把图像和文本一起送入同一个融合 Transformer。视觉骨干与训练方法也是两个层次：原始 CLIP 同时研究了修改后的 ResNet 和 ViT，因此“使用 ViT”并不意味着“使用 CLIP 预训练”。





实际使用有两条路径。训练或适配图文检索模型时，保留图像塔、文本塔和匹配目标，数据要有可靠的配对关系；构建 VLM 或动作策略时，则可以只取预训练视觉塔，把未汇聚的视觉 Token 交给投影器和条件模型，再用问答、描述或动作监督适配。后一种做法不要求机器人数据重新附带 CLIP 式批内负例，也不等于从头训练图文编码器。是否冻结视觉塔，应作为下游训练方案的一部分验证。





例如，将“a photo of a red cup”和“a photo of a blue bowl”编码成两个候选向量，就能与一张图像的全局向量比较，形成零样本分类。这里的零样本指没有为这组下游类别另行训练分类头。CLIP 的候选 Softmax 会随候选集合变化；SigLIP 的逐对 Sigmoid 不要求这些分数和为 1，但其数值也受训练中的负例比例和偏置影响，不能直接解释成机器人任务成功概率。





接代码时还要核对返回值的处理阶段。[OpenAI CLIP 实现](https://github.com/openai/CLIP/blob/main/clip/model.py)的 `encode_image` / `encode_text` 返回投影后的特征，L2 单位化发生在计算匹配分数的 `forward` 中；自行缓存特征再算余弦相似度时仍需单位化。用于检索的全局向量与用于空间任务的视觉 Token 也不是同一输出，具体选择接续[视觉与语言融合](#/learn/multimodal?tab=theory)和[视觉预处理](#/learn/vision-preprocessing?tab=theory&section=0)。本章代码验证双向交叉熵和逐对 Sigmoid 的核心计算，不声称复现这些工作的完整预训练。







### 代表工作的监督信号与使用方式

| 工作 | 核心设计 | 典型用途与使用边界 |

|---|---|---|

| [DINO（2021）](https://arxiv.org/abs/2104.14294) | 同一图像的多视图自蒸馏；学生匹配 EMA 教师的预测分布。 | 没有配对文本的视觉自监督；学习的骨干可用于图像分类、检索或下游视觉表示初始化。 |

| [DINOv2（2023）](https://arxiv.org/abs/2304.07193v2) | 大规模视觉自监督，结合图像级与 Patch 级训练目标，发布多种 ViT 编码器。 | CLS 用于全局图像读出，Patch 特征用于空间预测；可先用冻结骨干与轻量任务头建立基线。 |

| [CLIP（2021）](https://arxiv.org/abs/2103.00020v1) | 双编码器通过双向 Softmax 对比目标学习图文对应；文本可用来构造下游类别的比较向量。 | 图文检索、文本定义的零样本分类，以及视觉塔初始化。完整模型输出匹配分数，并不自行生成图像描述或动作。 |

| [SigLIP（2023）](https://arxiv.org/abs/2303.15343v4) | 将图文匹配写成含尺度与偏置的逐对二分类；归一化不依赖整行候选的 Softmax 分母，便于分块计算配对损失。 | 仍可用于图文匹配和视觉表征迁移。逐对目标仍需要正负例；若枚举全部组合，配对数仍为批大小的平方，不能据此宣称没有负例成本。 |

| [SigLIP 2（2025）](https://arxiv.org/abs/2502.14786v1) | 在 SigLIP 基础上加入描述/定位相关的解码器监督、多语言数据，并在标准分支加入自蒸馏与掩码预测；部分小模型还采用主动数据筛选。 | 同时关注全局语义与局部表征，发布固定分辨率及 NaFlex 变体。论文 v1 的 NaFlex 分支未加入上述自蒸馏与掩码预测；训练用描述解码器也不包含在发布编码器中。下游效果需按任务验证。 |



## 数值、梯度与语义对照

前面的定义把错误来源分成了配对关系、数值计算与表征学习三层。验证应按这个顺序推进，使每次实验只回答一个问题，再把局部计算的正确性与真实语义能力区分开。





第一层核对图文配对与矩阵轴；第二层检查单位范数、温度、logits 范围与稳定损失；第三层检查图像编码、文本编码和尺度参数的梯度；第四层做正误配对、重复描述和内容替换对照。纯合成相近向量应让正确配对损失低于打乱配对，但这种性质只验证实现，不代表真实图像与文字已经对齐。切勿把合成数据的高检索率作为预训练效果。





若训练不稳，先分别固定特征只优化尺度、固定尺度只优化编码器、缩小到可手算矩阵，定位问题来自目标还是表示。数值检查应覆盖零向量、极端分数和不同 B 的归约差异。将批次定义、正负例策略、分母、温度参数化与评价划分写入实验记录，才能让“CLIP 式”或“SigLIP 式”的名称对应到可复查的实际计算。





图文预训练先定义匹配关系，再通过编码、相似度与损失学习可比较的表示。候选竞争与成对分类是不同目标，全局匹配与局部控制也需要不同证据；这几层区别决定了怎样选择与使用预训练特征。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 图像 / 文本向量 | [B,D] / [B,D] | 投影到同一比较空间。 |
| 相似度矩阵 | [B,B] | 行是图像，列是文本。 |
| 配对标签 | [B]，整数 \(0,\ldots,B-1\) | 一一匹配假设下的对角正例。 |
| SigLIP 正负标记 | [B,B]，\(\pm1\) | 逐对定义正负，不做行 Softmax。 |

## 完整代码与精读

```python
# [1] 构造带小扰动的匹配向量，作为可验证教学数据
import torch
from torch.nn import functional as F
torch.manual_seed(36)
B, D = 4, 8
image_raw = torch.randn(B, D, requires_grad=True)
text_raw = (image_raw.detach() + 0.03*torch.randn(B, D)).requires_grad_()
logit_scale = torch.tensor(1.5, requires_grad=True)
image = F.normalize(image_raw, dim=-1)
text = F.normalize(text_raw, dim=-1)

# [2] 每行和每列各做一次正确配对分类
scores = logit_scale.exp() * (image @ text.T)
labels = torch.arange(B)
clip_loss = (F.cross_entropy(scores, labels)
             + F.cross_entropy(scores.T, labels)) / 2
shuffled_scores = logit_scale.exp() * (image @ text.roll(1, 0).T)
shuffled_loss = (F.cross_entropy(shuffled_scores, labels)
                 + F.cross_entropy(shuffled_scores.T, labels)) / 2
assert shuffled_loss > clip_loss
torch.testing.assert_close(image.norm(dim=-1), torch.ones(B))

# [3] SigLIP 式逐对目标：正例 +1、负例 -1，按 B 归约
pair_logits = 4.0 * (image @ text.T) - 2.0
sign = 2.0 * torch.eye(B) - 1.0
sigmoid_loss = F.softplus(-sign * pair_logits).sum() / B
assert torch.isfinite(sigmoid_loss)

# [4] 验证两路特征和尺度都连接到对比目标
clip_loss.backward()
assert image_raw.grad is not None and text_raw.grad is not None
assert logit_scale.grad is not None
assert torch.isfinite(image_raw.grad).all()
print("匹配 / 错配 CLIP loss:", round(clip_loss.item(), 4), round(shuffled_loss.item(), 4))
print("成对 Sigmoid loss:", round(sigmoid_loss.item(), 4))
print("配对、单位化与梯度检查通过")

```

- 第 1–11 行：合成匹配用于测试目标函数，不代表经过预训练的视觉或语言编码器。
- 第 12–22 行：矩阵转置交换图像检索文本与文本检索图像两个方向；错配测试能发现标签或排列错误。
- 第 23–28 行：softplus(-sign×logit) 是稳定的负对数 Sigmoid 写法；这里使用 sum()/B。对于 \(B\times B\) 的成对损失，mean() 等于 sum()/\(B^2\)，因此本例归约是 mean() 的 B 倍。
- 第 29–36 行：反向检查涵盖两路特征和 logit_scale，避免某一路被意外 detach。

预期观察：匹配对的 CLIP loss 低于错配；特征范数为 1；两路特征和尺度均获得有限梯度。不同目标的数值不用于直接排名。

## 浏览器 Python 练习

实现 symmetric_pair_ce(scores)。输入为非空方阵，正例在主对角线。分别计算行方向和列方向交叉熵后取平均，使用稳定的 log-sum-exp。

```python
def symmetric_pair_ce(scores):
    # TODO: 正确配对为对角线，计算两个方向
    raise NotImplementedError("请实现图文配对损失")

```

### 提示

- 行方向是每张图像选择文本；列方向需要真的取出每一列。
- 减最大值再求指数，最后把最大值加回 log-sum-exp。

### 参考实现与解释

```python
import math

def symmetric_pair_ce(scores):
    n = len(scores)
    if n == 0 or any(len(row) != n for row in scores):
        raise ValueError("需要非空方阵")
    def lse(values):
        m = max(values)
        return m + math.log(sum(math.exp(x-m) for x in values))
    row_loss = sum(lse(row)-row[i] for i, row in enumerate(scores))
    col_loss = 0.0
    for i in range(n):
        column = [scores[j][i] for j in range(n)]
        col_loss += lse(column)-scores[i][i]
    return (row_loss+col_loss)/(2*n)

```

非对称矩阵测试会识别把同一个行损失算两遍的错误。温度已包含在输入分数中，本函数只负责配对监督。

### 断言测试

```python
import math
assert abs(symmetric_pair_ce([[2.,0.],[0.,2.]])-math.log1p(math.exp(-2))) < 1e-12
assert abs(symmetric_pair_ce([[0.,0.],[0.,0.]])-math.log(2)) < 1e-12
expected = (2*math.log1p(math.exp(-2)) + math.log1p(math.exp(-1))
            + math.log1p(math.exp(-3))) / 4
assert abs(symmetric_pair_ce([[2.,0.],[1.,3.]])-expected) < 1e-12
assert symmetric_pair_ce([[1000.]]) == 0
print("通过：双向目标、非对称矩阵与稳定归约")

```

## 本地 PyTorch 练习

实现 clip_pair_loss(image_raw,text_raw,logit_scale)。沿最后一维单位化，使用 `exp(logit_scale)` 缩放，并返回两个方向平均 CE。保持所有输入的梯度连接。

```python
import torch
from torch.nn import functional as F

def clip_pair_loss(image_raw, text_raw, logit_scale):
    # TODO: 单位化、相似度、正确标签与双向损失
    raise NotImplementedError("请实现 CLIP 式损失")

```

### 提示

- labels 是 torch.arange(B)，而不是所有样本都指向第一个文本。
- 对转置分数再次计算 CE；不要对分数提前 Softmax 后再传给 cross_entropy。

### 参考实现与解释

```python
import torch
from torch.nn import functional as F

def clip_pair_loss(image_raw, text_raw, logit_scale):
    image = F.normalize(image_raw, dim=-1)
    text = F.normalize(text_raw, dim=-1)
    scores = logit_scale.exp() * (image @ text.transpose(-1, -2))
    labels = torch.arange(scores.shape[0], device=scores.device)
    return (F.cross_entropy(scores, labels)
            + F.cross_entropy(scores.T, labels)) / 2

```

同时重排图像和文本不会改变配对损失，只重排一路则破坏对应关系。正比例缩放原特征不改变单位化方向，这项测试能发现遗漏归一化。 非对称固定配对让两个方向的损失不同，约为 0.2544 与 0.3785；正确答案必须返回均值约 0.3165，不能只算一个检索方向。

### 断言测试

```python
torch.manual_seed(36)
a = torch.randn(3, 5, requires_grad=True)
b = (a.detach()+0.02*torch.randn(3, 5)).requires_grad_()
scale = torch.tensor(1.0, requires_grad=True)
loss = clip_pair_loss(a, b, scale)
torch.testing.assert_close(loss, clip_pair_loss(7*a, 2*b, scale))
order = torch.tensor([2, 0, 1])
torch.testing.assert_close(loss, clip_pair_loss(a[order], b[order], scale))
assert clip_pair_loss(a, b.roll(1,0), scale) > loss
loss.backward()
assert all(x.grad is not None and torch.isfinite(x.grad).all() for x in (a,b,scale))
# 非对称配对：两个检索方向的 CE 确实不同。
a_fixed = torch.tensor([[1., 0.], [0., 1.]])
b_fixed = torch.tensor([[1., 0.], [1., 1.]])
fixed_scale = torch.tensor(1.)
scores = fixed_scale.exp() * (F.normalize(a_fixed, dim=-1) @ F.normalize(b_fixed, dim=-1).T)
labels = torch.arange(2)
expected = (F.cross_entropy(scores, labels) + F.cross_entropy(scores.T, labels)) / 2
torch.testing.assert_close(clip_pair_loss(a_fixed, b_fixed, fixed_scale), expected)
assert not torch.isclose(expected, F.cross_entropy(scores, labels))
print("通过：单位化、配对顺序、非对称双向目标和梯度")

```

## 练习：推导与分析

### 一个 Batch 中两张图像都是同一只红杯，文本也都写“红杯”。为什么只把对角线当正例可能有问题？

非对角配对可能同样正确，却被单正例对比目标当作负例。模型会同时收到把语义接近的内容拉近与推远的信号；这不是简单的学习率问题。

应先核对配对语义与数据重复情况，再决定去重、组织 Batch 或使用多正例目标。不能因为两张图像像素不同就认定它们在当前文本任务中必须互为负例。

代码定位：检查 scores 的正例矩阵是否真的等于单位矩阵，尤其关注多相机同场景和重复描述。

- 指出假负例来自标签假设，而不是矩阵维度。
- 提出至少一种与数据语义一致的处理方式。

### 把相似度乘以更大的 `exp(logit_scale)` 会怎样？能否因此让冻结特征获得新的几何信息？

尺度增大会改变 Softmax 的尖锐程度以及损失对相似度的梯度。它必须与特征单位化、正负例分布和训练稳定性一起考虑；过尖的分布也可能出现饱和或过度确信。

仅修改分数尺度不会给冻结特征增加原本没有编码的信息。它可能改善当前配对目标的数值行为，但不能替代下游监督、空间结构或任务能力检验。

代码定位：比较 scores、行概率和 logit_scale.grad；同时区分评分校准与表征内容变化。

- 说清尺度是温度倒数方向：越大越尖锐。
- 说明分数缩放不等价于增加可读出的几何信息。

### 所有候选余弦分数相同，提高 logit_scale 能让正例更容易被选中吗？如果存在多个正例，只优化它们的总概率是否要求每个正例都得高分？

不能。共同乘正尺度后 logits 仍相同，Softmax 仍均匀，且 \(\frac{\partial L}{\partial\alpha}=e^\alpha\left(\sum_jp_jc_j-c_+\right)=0\)。要区分候选必须改变表示或候选信息。

只优化 \(-\log\!\left(\sum_{j\in P}p_j\right)\) 不要求正例之间均衡。两个正例的概率为 (0.99,0.01) 或 (0.5,0.5)，总质量都为 1，损失都为 0。平均正例交叉熵则分别约为 2.31 与 0.693，体现不同目标。

代码定位：固定余弦矩阵只对 \(\alpha\) 求导，再手算两个多正例归约。

- 说明温度不能增加候选的可区分信息。
- 区分“任一正例”与“每个正例”的概率要求。

## 练习：辨析与纠错

### 传入已经 Softmax 的分数给 cross_entropy

该接口需要 logits，重复归一化改变目标。用 2×2 手算矩阵核对交叉熵。

### 图文独立打乱后仍使用对角标签

损失能下降但学习了错误配对。携带原始 ID，核对每一行的正确候选索引。

### 把所有非对角项都解释为真正负例

重复描述与等价场景可能是多正例。检查高损失对并按任务定义处理，避免无意识地制造监督冲突。

### Sigmoid 目标的 sum/B 与 mean 随意替换

二者相差 Batch 大小倍数，改变 B 时梯度尺度也不同。明确配对数、正负权重与归约口径。

### 靠增大 logit_scale 修复冻结特征信息不足

尺度只改变已有相似度的区分强度。用内容干预和下游验证判断表示是否包含需要的信息。

## 原始资料

- [CLIP：Learning Transferable Visual Models From Natural Language Supervision（v1, 2021）](https://arxiv.org/abs/2103.00020v1)
- [Sigmoid Loss for Language Image Pre-Training（v4, 2023）](https://arxiv.org/abs/2303.15343v4)
- [PaliGemma 官方文档](https://huggingface.co/docs/transformers/en/model_doc/paligemma)
- [OpenAI CLIP 官方实现：归一化与 logit_scale](https://github.com/openai/CLIP/blob/main/clip/model.py)
- [PyTorch：CrossEntropyLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html)
- [SigLIP 2：训练配方与模型变体（v1, 2025）](https://arxiv.org/abs/2502.14786v1)
- [Big Vision：SigLIP 官方训练器](https://github.com/google-research/big_vision/blob/main/big_vision/trainers/proj/image_text/siglip.py)
- [Big Vision：SigLIP 2 官方模型与使用入口](https://github.com/google-research/big_vision/blob/main/big_vision/configs/proj/image_text/README_siglip2.md)
- [DINO：Emerging Properties in Self-Supervised Vision Transformers（2021）](https://arxiv.org/abs/2104.14294)
- [DINOv2：Learning Robust Visual Features without Supervision（2023）](https://arxiv.org/abs/2304.07193v2)
- [DINOv2 官方模型卡：CLS、Patch 与 Register 输出](https://github.com/facebookresearch/dinov2/blob/main/MODEL_CARD.md)
