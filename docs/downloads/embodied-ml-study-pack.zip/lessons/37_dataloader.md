# 数据采样与批处理

采样分布、变长批次、随机性与数据吞吐。

数据加载管线将存储中的记录变成训练批次：Dataset 定义如何读取一条样本，Sampler 决定抽取哪些索引，collate 将样本组织成 Batch，DataLoader 协调这些步骤及可选的并行读取。它同时影响训练分布、有效监督与吞吐。本章先认识这条流程，再定义变长填充、轨迹窗口、随机性和进程分片。

## 学习目标

- 区分 Dataset、Sampler 与 collate_fn 的责任。
- 构建变长动作序列和有效位 Mask。
- 检查多进程加载、随机增强与轨迹采样的重复或偏置。

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/)

## 采样、读取与批次组装

Dataset 表达一条数据如何被读取，Sampler 表达样本怎样被选择，collate 表达多个样本如何合成一批。DataLoader 组织这些职责，不自行规定每条记录的语义。先定义样本边界，再组合这些组件。





一个样本应有明确的语义边界，例如单张图文对、某条轨迹的观测窗口及对应动作片段。返回字典时保留必要的轨迹 ID、时间索引、有效长度和任务标签，有助于追踪它如何进入损失。Dataset 不应在每次读取时隐式改变标签约定，也不应把验证集统计混入训练预处理。先用 num_workers=0 打印少量样本，确认单条记录正确，再开启 Batch 和多进程。









### 沿样本 ID 追踪整条数据路径

读取成功不代表输入与标签仍对应。采样、增强、拼接和排序都可能改变排列。

让每个样本携带唯一 ID，打印 Dataset 输出、collate 后顺序、模型输出与标签对应关系。

## 采样概率与损失权重

采样概率决定一条记录进入训练的频率，损失权重决定它出现后对目标贡献多大。两者共同定义期望训练风险。下面从等权经验目标出发，分析均衡或重采样实际改变了什么。





对有限数据集均匀采样，随机梯度估计的是这些样本等权的经验损失。若改为类别均衡、任务重采样或轨迹均衡，就改变了不同样本被看到的概率，通常也改变了被优化的风险。长轨迹拥有更多窗口，按窗口均匀采样会使长轨迹占更大权重；按轨迹均匀再选时间点则是另一种分布。二者哪种合适取决于任务，而非 DataLoader 能否运行。





若目标分布为 \(p_i\)、实际独立采样分布为 \(q_i\)，且 \(p_i>0\) 时 \(q_i\)也大于零，则样本权重 \(p_i/q_i\) 满足 \(\mathbb E_{i\sim q}\!\left[\frac{p_i}{q_i}\ell_i\right]=\sum_i p_i\ell_i\)。对固定采样分布，这给出原目标损失及梯度的无偏估计，但极小 \(q_i\) 会带来大权重和高方差。类别均衡与轨迹均衡也可以有意定义一个新目标，此时不必强行改回原分布；关键是说明希望优化哪个风险。





不要把无偏公式换成“乘权重后除以当前 Batch 的权重和”而仍声称完全相同。后者是随机分子除以随机分母，一般存在有限 Batch 偏差。例：\(p=(0.5,0.5)\)，\(q=(0.9,0.1)\)，损失为 (1,9)，目标均值为 5；不加权的期望只有 1.8。权重是 (5/9,5)，按 Batch 大小取均值可还原期望 5；Batch=1 时若再除以权重和，权重被完全抵消，期望又回到 1.8。





$$
R=\sum_i p_i\ell_i=\mathbb E_{i\sim q}\!\left[\frac{p_i}{q_i}\ell_i\right],\qquad \widehat R=\frac1B\sum_{b=1}^{B}\frac{p_{i_b}}{q_{i_b}}\ell_{i_b}
$$



### 例：长轨迹为什么占更多训练权重

1. 轨迹 A 有 100 个可用窗口，B 有 10 个；按窗口均匀采样时，A 的概率为 100/110。

2. 先等概率选轨迹、再选窗口时，两条轨迹各占 1/2，但 B 中每个窗口被采到的概率更高。

3. 若另外给 B 的损失乘 10，又进一步扩大了它的作用。

采样单位和损失权重需要放在一起定义，而不是分别凭经验设置。

## 变长序列与有效长度

变长批处理是把长度不同的序列组织为可一起计算的批次。填充、截断与分桶是不同方法，有效长度则保留哪些位置是真实数据。需要分别定义输入内容与监督集合，再计算损失。





默认 collate 通常能堆叠同形 Tensor，但不同长度序列需要明确 Padding、截断或分桶策略。将长度为 \(L_i\) 的序列补到最大 H 后，应保留 valid[b,h] 或 lengths，约定哪些观测、动作和维度真实存在。零值可以是真实动作，不能用 value!=0 判断 Padding。若输入和标签需要排序，同一个排列必须作用于全部关联字段，恢复顺序也要有依据。





对 [B,H,D] 的逐标量 MSE，时间有效位 [B,H,1] 会广播到 D 维，分母也应计入 D 个有效标量。假如每个机器人可用维度不同，还要与维度 Mask 组合后再统计。空监督样本与全空 Batch 要明确处理策略。Padding 数值若是 NaN，先乘零再求误差仍可能产生 NaN；应在计算不合法运算前安全选择有效数据。Attention 的输入有效位也不能被最终 Loss Mask 替代。





$$
L=\frac{\sum_{b,h,d}m_{bhd}(\hat a_{bhd}-a_{bhd})^2}{\sum_{b,h,d}m_{bhd}}
$$



### 例：长度为 3、1、4 的动作序列

1. 补齐到 4 步后张量为 [3,4,D]，真实有效时间步总数为 8。

2. 若 D=3 且所有动作维度都有效，逐标量平均的分母是 8×3=24，不是 12 或 8。

3. 加入未使用维度时，必须按最终展开的有效位重新计数。

Padding 统一存储形状；损失分母必须保留原来的监督语义。

### 补齐后的 shape 不能代表有效样本数

Padding 是占位，不是额外监督；时间 Mask 广播后分母也要匹配逐标量口径。

构造不等长序列和合法零动作，手算误差和与有效分母，改变 Padding 值后有效损失应不变。

## 轨迹窗口与时间边界

轨迹窗口是从同一回合中、相对一个参考时刻截取的观测与动作片段。回合边界和时间戳限制哪些元素可以组合。它是有时间语义的样本，不只是长数组的一次连续切片。





一个训练窗口可能包含历史观测和未来动作，需要先约定参考时间。观测窗口不能跨越 episode 边界拼入上一条轨迹，动作窗口的终止处要标记有效长度；图像、状态与动作采样率不同，还要按时间戳对齐。把“第 k 帧”机械对应“第 k 个动作”可能在延迟、丢帧或频率变化时制造错误监督。索引合法不代表物理时间一致。





数据划分应先按轨迹、场景或目标泛化单位进行，再生成窗口。若先把相邻窗口随机切到训练和验证，重叠图像和动作可能使验证结果过于乐观。相同原始轨迹的增强副本也不能成为独立验证证据。使用轨迹 ID 检查交集，抽样查看边界窗口，并记录观测截止时间与动作起始时间，才能将离线损失解释为所声明的学习任务。









## Worker 与数据分片

DataLoader Worker 是并行读取和处理数据的进程，分片规则规定每个副本负责哪些记录。索引式与迭代式数据集的调度方式不同。先分清副本怎样分工，再检查遗漏与重复。





Map-style DataLoader 的主进程通常管理索引调度，Worker 读取与处理分配的样本。IterableDataset 则由各 Worker 执行自己的迭代逻辑；如果每个副本都从相同数据流起点开始，会重复产出同一批记录，需要显式按 Worker 和分布式 rank 分片。增加 num_workers 不能修复数据重复，甚至可能把重复数量放大。也不要假设流式 loader 的 len 一定精确反映真正输出的 Batch 数。





Worker 有自己的进程状态、随机数与资源生命周期。persistent_workers 可以减少反复创建成本，但也意味着某些 Dataset 状态会跨 epoch 保留；主进程里改一个普通属性不一定自动同步到已启动 Worker。某些平台使用 spawn，需要 Dataset、collate 和初始化函数可被正确序列化并在模块级定义。调试优先回到单进程暴露原始堆栈，再逐步恢复并行，而不是仅捕获异常跳过大量样本。









## 随机增强与可复现性

可复现的数据随机性包括索引顺序、窗口选择和增强参数等不同随机序列。种子给出起点，生成器状态记录运行进度。下面分别管理这些来源，避免把固定一个种子当成完整复现。





采样顺序、图像增强、随机窗口与模型随机性可能来自不同生成器。固定 torch.manual_seed 不一定覆盖 Python random、NumPy、各 Worker 和分布式 rank。DataLoader 可使用显式 generator 管理采样与 Worker 基础 seed，并在 worker_init_fn 中按其 seed 初始化其他库。目标是让一次实验的随机规则可解释，而不是让每个 Worker 使用完全相同 seed 从而产生重复增强。





即使 seeds 相同，改变 Worker 数量、预取顺序或软件环境也可能改变样本访问与数值路径。严格断点续训还涉及 sampler 游标、预取但未消费的 Batch 和增强状态，不应只保存 epoch 就声称逐步等价。对于调试，可以先关闭随机增强、固定窗口和顺序，建立确定性小样本；确认管线后再逐项恢复随机性，并记录每次变化对指标和可复查性的影响。









### 所有 Worker 同一个 seed 可能制造相同增强

可复查需要可区分的 Worker 随机流，并明确采样与增强各由谁控制。

记录样本 ID、Worker ID 与增强参数，检查不同 Worker 未重复处理同一流，重启后按既定配置能重现探针。

## 数据吞吐与传输开销

数据吞吐是单位时间交付给训练的有效数据量，端到端加载时间则包含读取、解码、增强、组批与传输。Worker、预取和固定页内存各优化其中某些阶段。先定位瓶颈，再选择对应机制。





CPU 解码、磁盘读取、增强、collate、主机到设备传输都可能形成瓶颈。增加 Worker、预取或 pinned memory 分别作用于不同阶段，过多 Worker 还可能争抢 CPU、内存或存储带宽。pin_memory 与 non_blocking 传输可以在合适硬件和执行安排下减少等待，但不保证任意配置都更快；应测量端到端迭代时间和 GPU 等待，而不是只看某个开关是否开启。





按长度分桶可减少 Padding 计算，但也改变 Batch 内样本的组合与顺序，可能影响 BN 统计或任务混合。缓存解码结果、预处理特征或固定增强会减少成本，也可能减少训练多样性，必须说明缓存发生在哪个阶段。吞吐提升后仍检查样本覆盖、类别比例、异常跳过率和有效 token 数，避免系统跑得更快，却遗漏困难样本或仅重复读取少量数据。









## 数据覆盖与边界验证

数据管线的测试需要同时回答每条记录是否正确，以及完整迭代是否覆盖了预期集合。单个随机 Batch 无法证明边界窗口、缺失模态或多进程分片正确。由可手算的小样本扩展到完整覆盖统计，能够为后续损失曲线建立可信的数据基础。





数据检查可以覆盖短序列、完整序列、合法零动作和缺失模态。检查 dtype、device、shape、时间戳、ID、有效位和标签对应。用手算损失对照 collate 输出，验证只改变 Padding 不影响有效监督。随后遍历一个小数据集，统计每条记录被读取次数、总有效元素、类别与轨迹覆盖，确认 drop_last 和采样策略的影响符合预期。





最后开启 Worker 和分布式分片后重复覆盖检查，监控读失败、重试、重复与缺失记录。测试应覆盖真正的边界，而不是对实现中的 reshape 原样再写一次期望。训练出现异常时，保留出错 Batch 的可复查索引和必要元信息，回到确定性读取路径重建它。模型、优化器与数据读取是同一个实验系统，只有数据流可信，损失曲线才值得进一步解释。





继续到[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)的 `ToyEpisodes`、`collate_episodes` 与 `make_loader`，同一批数据会进入真实优化。每条记录保留 id；每轮排序后的已消费 id 必须恰为 0…31，有效输出标量数为 190。Padding 故意填 NaN，以确认输入和标签都在危险算术之前被隔离。这里 num_workers=0 且只在 epoch 结束恢复，明确避开尚未保存的 Worker 状态与预取游标。





数据加载的完整过程是选择记录、读取样本、保持时间与标签对应、组装带有效位的批次，再送入模型。性能配置应建立在这条语义正确的流程上；采样分布和归约权重也要共同匹配目标。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 单个动作序列 | [Ti,A] | 每条样本长度可不同。 |
| 补齐动作 Batch | [B,Tmax,A] | 用零补齐只是存储约定。 |
| valid | [B,Tmax]，bool | True 表示真实监督位置。 |
| 状态 / 文本 | [B,S] / [B,Lmax] | 不同字段可以拥有不同的补齐长度与 Mask。 |

## 完整代码与精读

```python
# [1] 样本在初始化时生成，避免每次读取悄悄改变监督
import torch
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
torch.manual_seed(18)

class ToyEpisodes(Dataset):
    def __init__(self):
        self.items = []
        for i, length in enumerate([3, 1, 4]):
            self.items.append({
                "state": torch.randn(4),
                "actions": torch.randn(length, 3),
                "text": torch.tensor([1, 2+i], dtype=torch.long),
            })

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        return self.items[index]

# [2] 显式组批，长度决定 Mask，而不是判断数值是否为零
def collate(samples):
    actions = pad_sequence([x["actions"] for x in samples], batch_first=True)
    lengths = torch.tensor([len(x["actions"]) for x in samples])
    valid = torch.arange(actions.shape[1])[None, :] < lengths[:, None]
    return {
        "state": torch.stack([x["state"] for x in samples]),
        "actions": actions,
        "valid": valid,
        "text": pad_sequence([x["text"] for x in samples], batch_first=True),
    }

# [3] 先用单进程确认结构，再考虑加载性能
loader = DataLoader(ToyEpisodes(), batch_size=3, shuffle=False,
                    collate_fn=collate, num_workers=0)
batch = next(iter(loader))
assert batch["actions"].shape == (3, 4, 3)
assert batch["valid"].sum().item() == 8
assert (batch["actions"][~batch["valid"]] == 0).all()
print({key: tuple(value.shape) for key, value in batch.items()})
print("有效步数:", batch["valid"].sum().item())
print("逐元素损失的有效分母:", batch["valid"].sum().item() * 3)

```

- 第 1–22 行：Dataset 返回一个有明确字段的样本。这里是合成数据，只演示组批规则。
- 第 23–34 行：用真实长度构造 valid，避免把真实的零动作误认为 Padding。
- 第 35–44 行：Batch 中 3+1+4=8 个有效步，每步 3 维，因此逐元素损失的有效分母是 24。

预期观察：动作 [3,4,3]，valid [3,4]，状态 [3,4]，文本 [3,2]；有效步数 8，有效动作元素数 24。

## 浏览器 Python 练习

实现 pad_and_mask(sequences,pad_value=0)，返回补齐后的二维列表和同形状布尔 Mask。允许某条序列为空，但整个 Batch 不能为空；不修改输入。

```python
def pad_and_mask(sequences, pad_value=0):
    # TODO: 最长长度、补齐、有效位
    raise NotImplementedError("请完成变长组批")

```

### 提示

- 有效位来自原始长度，不来自 value!=0。
- 用 list(seq) 拷贝每一行，避免原地 extend 修改原数据。

### 参考实现与解释

```python
def pad_and_mask(sequences, pad_value=0):
    if not sequences:
        raise ValueError("Batch 不能为空")
    longest = max(len(seq) for seq in sequences)
    padded = [list(seq) + [pad_value] * (longest-len(seq))
              for seq in sequences]
    valid = [[j < len(seq) for j in range(longest)] for seq in sequences]
    return padded, valid

```

这个练习特意含有真实的零值，防止把数值零与 Padding 混为一谈。

### 断言测试

```python
items = [[0, 2], [3], []]
padded, valid = pad_and_mask(items)
assert padded == [[0,2], [3,0], [0,0]]
assert valid == [[True,True], [True,False], [False,False]]
assert sum(sum(row) for row in valid) == 3
assert items == [[0,2], [3], []]
assert pad_and_mask([[], []]) == ([[], []], [[], []])
try:
    pad_and_mask([])
    raise AssertionError("空 Batch 应被拒绝")
except ValueError:
    pass
print("通过：真实零值、变长序列、空序列和不修改输入")

```

## 本地 PyTorch 练习

实现 collate_actions。输入为非空列表，每个 Tensor 是非空 [Ti,A]，且 A 相同；返回补齐动作和 bool 有效位。使用 pad_sequence。

```python
import torch
from torch.nn.utils.rnn import pad_sequence

def collate_actions(sequences):
    # TODO: 验证输入，补齐动作，构造有效位
    raise NotImplementedError("请完成动作组批")

```

### 提示

- pad_sequence(...,batch_first=True) 产生 [B,Tmax,A]，原始长度单独收集。
- 用 arange(Tmax)<lengths[:,None] 构造 bool Mask，而不是比较动作值是否非零。
- 输入动作宽度 A 必须一致；示例约定每条序列非空。

### 参考实现与解释

```python
import torch
from torch.nn.utils.rnn import pad_sequence

def collate_actions(sequences):
    if not sequences or any(x.ndim != 2 or len(x) == 0 for x in sequences):
        raise ValueError("需要非空二维动作序列")
    if len({x.shape[1] for x in sequences}) != 1:
        raise ValueError("动作维度必须一致")
    padded = pad_sequence(sequences, batch_first=True)
    lengths = torch.tensor([len(x) for x in sequences], device=padded.device)
    valid = torch.arange(padded.shape[1], device=padded.device)[None] < lengths[:, None]
    return padded, valid

```

参考解把填充数据与有效性分别表达。测试包含真实全零动作，因此按数值判断 Padding 的实现会失败；不同长度 2、1、4 对应七个有效步，明确检验了长度和 Mask 的对应关系。

### 断言测试

```python
seqs = [torch.zeros(2, 3), torch.ones(1, 3), torch.full((4, 3), 2.)]
actions, valid = collate_actions(seqs)
assert actions.shape == (3, 4, 3) and valid.dtype == torch.bool
assert valid.sum().item() == 7
assert valid[0, 0] and torch.equal(actions[0, 0], torch.zeros(3))
assert not valid[1, 1]
assert (actions[~valid] == 0).all()
print("通过：形状、长度、真实零动作与 Padding")

```

## 练习：推导与分析

### Dataset、Sampler、collate_fn 分别负责什么？如果要改任务采样比例与变长补齐，分别优先检查哪里？

Dataset 定义给定索引时读取和返回的一条样本；Sampler 决定抽取哪些索引以及顺序；collate_fn 将样本列表组合成一个 Batch。DataLoader 负责协调这些工作及并行加载。

任务采样比例通常从样本索引、权重与 Sampler 检查；变长补齐与组批 Mask 从 collate_fn 检查。两者也会通过轨迹长度影响实际数据分布，所以修改后要记录真正被读取的任务与帧比例。

代码定位：先单独调用 dataset[index]，再检查采样索引和 collate 后的各字段形状。

- 明确三者职责。
- 把采样比例与补齐逻辑定位到合适组件。

### 有效长度为 3、1、4 的三个动作序列，每步 3 维，补齐到 4 步后，逐元素 MSE 的有效分母是多少？为什么不能用动作非零判断？

共有 3+1+4=8 个有效时间步，每步三维都有效时，分母是 24。如果还存在动作维度 Mask，则要进一步按真正有效的标量元素计数，不能仍使用固定的 24。

动作恰好为零可能是真实示教，例如保持某关节不动。Padding 与合法零动作具有不同的数据含义，应由原始长度或显式 valid 元数据区分，而不是靠数值是否为零。

代码定位：检查 valid.sum()、动作维度 Mask 和损失分母是否对应同一集合。

- 得到 24 并说明三维均有效的前提。
- 解释合法零动作不能被当成 Padding。

### 按类别重采样后，乘重要性权重并除以当前 Batch 权重之和，为什么未必精确保持原来的经验风险？

无偏估计使用 \(\frac1B\sum_i\frac{p_i}{q_i}\ell_i\)，要求采样覆盖目标支持集。把分母改为 \(\sum_i p_i/q_i\) 得到比值估计，期望不能一般地把分子分母分别求期望后相除。

Batch=1 就是反例：加权损失除以其唯一权重，完全等于未加权损失。对 \(p=(0.5,0.5)\)、\(q=(0.9,0.1)\)、ℓ=(1,9)，期望为 1.8，而目标是 5。

自归一化权重在某些情况下可以降低波动，但这属于偏差与方差的取舍。应按想优化的分布选择，不能同时把它称为原风险的有限样本无偏估计。

代码定位：用两种样本的精确期望手算，不依赖随机抽样的近似结果。

- 写明目标分布 p 与实际分布 q。
- 用 Batch=1 解释随机分母造成的差别。

## 练习：辨析与纠错

### 用动作是否非零判断有效位

零动作是合法标签，必须从长度或显式有效标记构造 Mask。加入真实零动作的边界测试。

### IterableDataset 每个 Worker 读取同一数据流

每个副本都从头读会重复样本。按 Worker/rank 分片，并统计一个 epoch 的样本 ID 覆盖。

### 相邻窗口随机分到训练和验证

重叠信息造成泄漏。先按轨迹或场景划分，再切窗口，检查源轨迹 ID 无交集。

### 只固定主进程 seed 就认为所有增强固定

其他随机库和 Worker 状态仍可能变化。明确 generator 与初始化策略，保存探针及配置。

### 只按 Batch 数报告训练数据量

变长与 drop_last 使有效监督量不同。记录样本数、有效 token/动作标量数和采样分布。

## 原始资料

- [PyTorch：torch.utils.data](https://docs.pytorch.org/docs/stable/data.html)
- [PyTorch：pad_sequence](https://docs.pytorch.org/docs/stable/generated/torch.nn.utils.rnn.pad_sequence.html)
- [PyTorch：Reproducibility](https://docs.pytorch.org/docs/stable/notes/randomness.html)
