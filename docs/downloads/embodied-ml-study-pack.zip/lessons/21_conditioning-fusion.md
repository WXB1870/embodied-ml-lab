# 条件注入：拼接、FiLM 与 AdaLN

条件交互、动态调制与零门控的梯度路径。

条件注入是让模型的计算依赖额外已知信息的方法，例如用图像、语言或生成时间改变动作预测。拼接直接提供条件特征，Cross-Attention 从条件序列读取内容，FiLM 和 AdaLN 则用条件调制特征通道。它们建立不同形式的交互。本章先定义条件的信息路径，再比较这些机制，最后检验条件怎样影响前向、梯度与缓存。

## 学习目标

- 区分特征拼接、token 拼接、Cross-Attention 与逐通道调制。
- 实现条件生成的缩放和平移，并检查广播轴。
- 解释零门控初始化时的梯度现象与语义验证边界。

前置知识：[归一化：统计轴、梯度与不变性](https://wxb1870.github.io/embodied-ml-lab/learn/normalization/) · [残差连接与深层优化](https://wxb1870.github.io/embodied-ml-lab/learn/residual/) · [注意力：匹配、聚合与梯度](https://wxb1870.github.io/embodied-ml-lab/learn/attention/)

## 条件依赖与信息路径

条件模型在当前待处理对象之外，还以已知信息 c 决定输出。条件路径是这些信息进入运算并影响预测的依赖关系。输入接口有某个字段，只证明数据被传入，尚未证明计算或训练实际使用了它。

![FiLM 的双分支网络：左侧条件生成器产生调制参数，送入右侧主网络的两个 FiLM 层，改变主输入的处理。](../assets/figures/film-overview-distill.svg)

以 FiLM 为例：左侧条件分支生成缩放与偏移参数，调制右侧处理主输入的网络。先看清两条信息路径，再展开各层运算。图源：[Dumoulin 等，Distill](https://distill.pub/2018/feature-wise-transformations/)。



条件模型写成 \(f_\theta(x,c)\)：x 是当前处理的状态或 token，c 是语言、视觉、状态或生成时间等条件。输入字典里出现 c，不代表输出实际使用了它：未读取的分支、遮住条件的 Mask 或学得的权重都可能使前向忽略条件。detach 则是另一件事，它保留本次前向数值及其随条件变化的关系，切断的是通向条件上游的梯度。先分别画出前向依赖与反向路径，再判断融合是否有效。





不同条件具有不同结构。一个生成时间标量可以编码成向量，一条语言指令含有词序，多张图像包含空间位置。把所有条件都平均成一个向量会降低接口成本，也会丢失局部检索能力；保留全部 token 增加灵活性，同时增加注意力开销。接口选择应对应任务所需信息，而不只是为了拼接时 shape 匹配。





还要区分条件的时间含义：序列位置描述“第几个 token”，动作时间描述“预测哪个执行时刻”，生成时间描述“当前噪声或流状态”。三者可能同时进入一个模型。把它们统一称为 t 而不注明尺度和来源，容易造成训练和采样使用不同条件的错误。







### 条件的结构与读取方式决定融合起点

| 方式 | 适合从什么需求出发 | 主要计算特点 |

|---|---|---|

| 特征拼接 | 维数较小的状态、目标或任务向量，先建立简单基线 | 沿特征轴并排输入，由后续网络组合。 |

| Token 拼接 | 图像、语言和动作需要在同一序列中交互 | 统一特征宽度，用位置、来源与 Mask 规定交互。 |

| Cross-Attention | 不同查询需要从多个词或 Patch 中分别读取条件 | 查询数控制输出长度，保留对条件位置的选择。 |

| FiLM | 全局条件需要逐通道调节已有特征 | 用条件产生缩放和平移，控制响应与阈值。 |

| AdaLN | Transformer 或生成网络中，需要在归一化后注入时间、类别等条件 | 将 LayerNorm 与条件仿射组合，按所选参数化初始化。 |



## 特征拼接与 token 拼接

特征拼接沿通道轴并排提供不同信息，Token 拼接沿位置轴增加可被读取的序列项。二者分别改变一个位置的内容与整组候选位置。下面先看连接后由什么算子完成交互。





特征拼接将 \(x\in\mathbb R^D\) 与 \(c\in\mathbb R^C\) 合成 \([x;c]\)，单个线性层给出 \(W_x x+W_c c+b\)。对每个 token 复制同一个 c 时，条件相当于样本相关偏置；输入与条件的混合二阶导数为零，条件不能改变该层对 x 的线性斜率。随后加入非线性或更深结构可以产生交互，因此这个限制属于“拼接后只有一个线性层”，不是对所有拼接网络的限制。





Token 拼接沿序列轴加入条件，通常需要先将宽度投影到共同 D，并补上位置或来源信息。要让动作 token 读取条件，Mask 必须开放相应方向；若条件放在因果序列的未来，较早的动作位置无法看到它们。即使开放了一层，也要检查其他层或池化操作是否保留了这条路径。





条件 token 与动作 token 一起进行自注意力，可能让条件表示也反向读取动作。这个设计可以有用，但会影响固定前缀缓存是否成立。选择融合方式时，应同时考虑表示能力、可见性、计算量和后续推理复用，而不只比较 API 调用是否简短。









## Cross-Attention 与单个条件 token

Cross-Attention 让待更新位置发出 Query，读取条件序列提供的 Key/Value。多个条件位置允许按内容选择；若只剩一个有效条件位置，Softmax 权重恒为一。这个边界决定条件压缩后还剩什么交互。





Cross-Attention 用需要更新的 token 生成 Q，用条件序列生成 K/V。每个查询获得不同权重，因此多个动作位置可以关注不同词或图像 patch；输出长度由查询数决定，不由条件长度决定。若条件仅压缩成一个 token，则每个头对唯一有效键的 softmax 权重为一，无法再在多个条件位置之间选择。





只有一个有效 Key 且无注意力 Dropout 时，\(\operatorname{softmax}([s])=[1]\)，读出就是 V，完全不依赖 Q 或 K。这条注意力分支对 Q/K 的梯度为零；Value、输出投影仍可学习，若外面有残差，整个块仍可依赖查询输入。把整幅图先压成一个 token 后，不能再期待 Cross-Attention 根据不同查询从图内不同位置进行选择。





条件键的 padding 或缺失视角要被正确遮罩。给每个查询增加相同条件向量，与让每个查询根据内容读取一组条件 token，表达方式不同；后者仍可能忽略条件，因此结构选择不能代替任务验证。可检查交叉注意力输出、条件扰动和最终损失的变化，但不要把漂亮的权重热图直接解释成因果证据。





条件宽度与动作宽度可以不同，通过各自投影进入同一每头维度即可。多头 attention 的头数、条件序列长度、query 长度也不是同一个概念。阅读代码时先给 Q/K/V 标注 [B,H,Tq,d]、[B,H,Tc,d]，再检查 Mask 在哪条轴上表示有效条件。









### 先画可见性，再决定是否能缓存条件

条件 token 是否读取动作会影响它在迭代中是否变化；只要输出 shape 相同，双向与单向信息流都能运行，却有不同语义。

固定 c、改变 x，比较各层拟缓存条件 K/V；同时验证动作查询确实能读取有效条件，不能读取 padding。

## FiLM 的乘法交互与通道限制

FiLM 是由条件生成逐通道缩放与平移、再作用于中间特征的调制方法。缩放引入条件与特征的乘法关系，平移改变响应的偏移。它不直接在不同位置之间检索内容，表达机制与注意力不同。





FiLM 用一个条件网络生成 \(\gamma(c)\)、\(\beta(c)\)，再做 \(\gamma\odot h+\beta\)。它显式引入条件与特征的乘法：条件可以放大、压低或翻转某个通道，平移则改变非线性前的阈值。这里的参数通常是逐通道向量，不是整层共享的一个数；也不能把 \(\gamma\) 固定看作概率，因为它不必位于零到一。



### 例：两个通道如何被条件分别控制

1. 取一个样本两行特征 \(h=\begin{bmatrix}1&2\\3&4\end{bmatrix}\)，条件生成 \(\gamma=[2,0]\)、\(\beta=[-1,5]\)。

2. 第一行输出 \([2\times1-1,0\times2+5]=[1,5]\)，第二行输出 \([2\times3-1,0\times4+5]=[5,5]\)。

3. 第二通道不再依赖原特征，因为 \(\gamma_2=0\)；对 h 的局部梯度在该通道也为零，但 \(\beta_2\) 仍可接收梯度。

逐通道缩放同时改变前向信息与反向梯度，零梯度有时来自有意的乘法结构。

若 \(\gamma(c)=Ac+b\)，则 \(y_i=(A_ic+b_i)h_i+\beta_i(c)\)，有 \(\frac{\partial^2 y_i}{\partial h_i\,\partial c_j}=A_{ij}\)。条件直接改变输入通道的局部斜率，这就是它与单层线性拼接的机制差别。不过对固定条件，FiLM 对 h 的矩阵仍是 \(\operatorname{diag}(\gamma(c))\)，不能单独实现任意通道旋转；前后线性层可以提供通道混合，不应把逐通道门控描述成任意条件线性变换。





对于 h=[B,T,D]，每样本条件给出 [B,D]，需要变为 [B,1,D] 才能沿时间轴广播。直接相乘时 PyTorch 从右侧对齐维度；若恰好 \(B=T\)，错误表达式甚至可能静默把样本条件当作时间条件。用 \(B\ne T\) 和逐样本干预，才能暴露这个错位。





FiLM 不要求必须先归一化，但应用位置会改变行为：在线性层前后、激活前后调制不是同一函数。若条件本身是逐 token 的，调制也可以是 [B,T,D]，此时无需跨 T 共享。实现时应明确调制粒度，而不是见到两个相同维度就自动加广播。





$$
\mathrm{FiLM}(h,c)=\gamma(c)\odot h+\beta(c)
$$





### 把 [B,D] 直接乘 [B,T,D]

广播按维度位置而非变量名对齐。当 \(B=T\) 时，错误代码可能成功运行并产生跨样本条件污染。

使用 \(B=2\)、\(T=3\)；显式写 `scale[:,None,:]`。只改变条件第 0 个样本，其他样本输出必须保持不变。

## AdaLN 与条件仿射

自适应 LayerNorm（AdaLN）在 LayerNorm 之后使用条件生成的缩放和平移。它先调整特征统计，再依据条件调制通道，因而不同于固定仿射参数的 LayerNorm。下面比较其初始化与广播关系。





AdaLN 在 LayerNorm 之后施加条件生成的缩放和平移，常写为 \((1+s(c))\odot\operatorname{LN}(x)+b(c)\)。加一是参数化选择：\(s=b=0\) 时得到 LN(x)，便于把“无调制”作为初始化点。若使用直接 \(\gamma\) 参数化，则无调制对应 \(\gamma=1\)、\(\beta=0\)；不能从一种公式复制零初始化到另一种公式。





常见实现关闭 LayerNorm 自带的 elementwise_affine，让动态调制负责仿射，避免额外共享 \(\gamma\)、\(\beta\) 混淆解释；保留共享仿射也可以，但那是另一种参数组合。LayerNorm 的统计轴仍是最后的通道 D，条件不应该让不同样本混在一起求均值方差。





FiLM 与 AdaLN 的关键区别不是名字，而是被调制的特征是否先归一化及如何参数化。LN 去掉部分均值/尺度信息，条件仿射再引入样本相关的变化。若任务需要原始幅度或绝对统计，可以由残差路径或独立条件保留，不能期待归一化后的表示无条件保存所有原信息。





$$
\mathrm{AdaLN}(x,c)=(1+s(c))\odot\mathrm{LN}(x)+b(c)
$$





## 零门控残差与首步梯度

零门控残差在变换分支外乘一个初始为零的门控，使整个块初始返回输入。门控、调制参数和分支参数可能在首步获得不同梯度。先看完整连接，才能判断“初始不改变输出”究竟限制了谁的学习。





在调制分支外再乘 gate，可以得到 \(y=x+g(c)\odot F\!\left(\operatorname{AdaLN}(x,c)\right)\)。\(g=0\) 时整个残差块输出等于 x，尽管内部 F 的输出不为零。这与 \(s=b=0\) 只保证 AdaLN 等于 LN(x) 不同：无调制不等于整个块恒等，恒等需要残差分支的总体贡献为零。



### 例：用标量残差手算零门控的两条梯度

1. 取 \(y=x+gwx\)，\(x=3\)、\(w=2\)、\(g=0\)，并令上游 \(\frac{\partial L}{\partial y}=1\)，则前向 \(y=3\)。

2. \(\frac{\partial L}{\partial w}=gx=0\)；\(\frac{\partial L}{\partial g}=wx=6\)。内部 w 首步不更新，门控却可以离开零点。

3. 如果再令 \(w=0\)，则门控梯度也为零；若 \(g=ac\) 且 \(a=0\)，条件 c 的梯度同样为零，但 a 的梯度还可能非零。

检查结构预期、门控参数和更新后梯度，比要求所有参数首步非零更准确。

由链式法则，分支内部参数梯度含 g 因子，因此首步 \(g=0\) 时通常为零；门控梯度则含 F 的当前输出，可以非零。如果生成所有调制参数的最后线性层权重为零，条件输入的梯度也可能为零，即使门控偏置正在学习。不能把这些预期零值误判为 detach。





也要避免把所有相关项都同时清零而造成死分支。例如 F 输出和门控都为零时，门控梯度与 F 内部梯度都可能为零，需要检查实际初始化。DiT 的 AdaLN-Zero 是具体的结构与初始化设计，不是“任何层全部设零都会更稳定”的通用规则。









### 无调制、恒等块与条件有梯度是三件事

\(s=b=0\) 只还原 LN；\(g=0\) 才让残差贡献为零。零门控或零调制权重会让部分梯度暂时为零，不能统一视为断图。

先核对初始输出等于谁，再打印 gate 参数梯度；完成一次有效更新后重新检查分支与条件输入的梯度。

## 时间编码与多条件组合

时间编码将生成阶段转换为网络可使用的特征，多条件组合则规定时间、观测与其他信息在哪些位置共同影响计算。它们需要各自明确取值与语义，再决定拼接、读取还是调制。





生成时间可先经多频正弦/余弦映射，再由 MLP 生成调制向量，使网络能够在不同频率上表示随时间变化的规律。训练用 [0,1] 而推理输入 [0,1000]，即使维度一致也会让编码处于不同区域；方向、范围与端点定义需要和噪声或 Flow Matching 的路径约定一致。





多个条件可以先各自编码到同一宽度后求和，也可以拼接再投影。求和成本低，但两路的尺度和识别方式需要学习；拼接保留显式槽位，增加后续参数。任一种方式都需要考虑缺失条件的表示，不能把“无指令”临时替换为不曾训练过的随机向量。





条件丢弃是在训练的一部分样本上，将选定条件替换为预先约定的空条件表示，让同一网络同时学习有条件与空条件预测。多条件输入要明确丢弃整组还是部分来源；若保留观测、仅丢弃文本，空条件分支就仍以观测为条件。推理沿用训练过的空表示，才能调用这条分支。





无分类器引导（Classifier-Free Guidance，CFG）在采样时组合这两份预测，无需额外分类器，用于调节生成结果对条件的服从程度。对同一状态 \(x_t\) 和时间 \(t\)，记空条件预测为 \(f_\varnothing\)、条件预测为 \(f_c\)。下式中的两者须采用相同输出参数化，例如都预测噪声、都预测 Score 或都预测速度。





这里 \(s=0\) 使用空条件预测，\(s=1\) 使用普通条件预测，\(s>1\) 沿两者之差外推。该记号对应[原论文](https://arxiv.org/abs/2207.12598)的 \(s=1+w\)。CFG 需要已学到空条件分支，通常每个采样步计算两份预测，可合并为一个 Batch；按条件服从度、生成多样性和延迟选择强度。





$$
f_{\mathrm{guided}}(x_t,t)=f_\varnothing(x_t,t)+s\bigl[f_c(x_t,t)-f_\varnothing(x_t,t)\bigr]
$$





## 条件干预与语义评估

输出随着条件变化，只说明存在依赖，尚不能说明模型理解了条件的语义。验证需要从形状和梯度推进到受控干预，最终检查输出是否朝任务要求的方向改变。





第一层验证结构：断言调制参数形状、归一化轴、广播方向和残差初始行为，检查有效条件确实有路径到输出。第二层验证数值：在 eval 下固定输入和随机噪声，只改变一条样本的一个条件，检查对应输出变化以及其他样本不变，并按初始化预期检查梯度。





第三层验证语义：同一场景配两条要求不同结果的指令，评价输出是否朝正确目标改变，而不只是某个数不同。打乱语言与样本配对、移除条件或替换为无关条件，可以帮助判断模型是否依赖它；这些消融的性能差异还需结合数据相关性解释，不能把任意下降都归为良好语言理解。





示例在零门控初始化后手动赋予非零参数，用于观察计算路径与样本隔离；语言理解仍需任务指标检验。真实训练中应观察门控分布、条件梯度、行为指标及不同条件组合的泛化。结构教学和能力结论分开，才能避免从一个通过 assert 的小例子推导过大的结论。





这些局部算子怎样在完整动作模型中组合，见 [VLA 模型架构](#/learn/vla-architecture?tab=theory)：图像、语言与状态如何进入 token，Action Expert 如何读取条件，以及冻结与缓存如何改变梯度。该课分别标明具体 OpenPI 版本和教学实现，避免将单一融合方式视作所有 VLA 的共同结构。





条件注入的关键是能够指出“条件在何处改变了哪项计算”。拼接、检索与调制分别提供不同交互；只有同时核对前向依赖和反向路径，才能把结构接入、条件敏感性与语义利用区分开。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 动作特征 | [B,T,D] | 每样本多个动作位置。 |
| 条件 | [B,C] | 可来自语言、状态、生成时间等编码。 |
| scale / shift / gate | [B,D] → [B,1,D] | 按通道调制，在同一样本内沿 T 广播。 |
| 调制输出 | [B,T,D] | 可进入 FFN、注意力或残差分支。 |

## 完整代码与精读

```python
# [1] 条件参数在每个样本内广播，B 与 T 特意不同
import torch
from torch import nn
torch.manual_seed(40)

class ConditionalBlock(nn.Module):
    def __init__(self, dim=4, condition_dim=2):
        super().__init__()
        self.norm = nn.LayerNorm(dim,elementwise_affine=False)
        self.modulate = nn.Sequential(nn.SiLU(),nn.Linear(condition_dim,3*dim))
        self.ffn = nn.Sequential(nn.Linear(dim,8),nn.SiLU(),nn.Linear(8,dim))
        nn.init.zeros_(self.modulate[-1].weight)
        nn.init.zeros_(self.modulate[-1].bias)

    def forward(self,x,condition):
        scale,shift,gate = self.modulate(condition).chunk(3,dim=-1)
        normalized = self.norm(x)
        h = normalized*(1+scale[:,None,:])+shift[:,None,:]
        return x + gate[:,None,:]*self.ffn(h)

# [2] 零门控保持恒等；先检查门控层而不是要求所有梯度非零
model = ConditionalBlock()
x = torch.randn(2,3,4)
condition = torch.randn(2,2,requires_grad=True)
initial = model(x,condition)
torch.testing.assert_close(initial,x)
initial.square().mean().backward()
assert model.modulate[-1].bias.grad[-4:].norm() > 0
torch.testing.assert_close(condition.grad,torch.zeros_like(condition))
print("初始恒等与门控梯度正确")

# [3] 打开条件分支后，只改变第一个样本的条件
with torch.no_grad():
    nn.init.normal_(model.modulate[-1].weight,std=0.1)
    model.modulate[-1].bias[-4:].fill_(0.2)
changed = condition.detach().clone()
changed[0,0] += 1.0
before,after = model(x,condition),model(x,changed)
torch.testing.assert_close(before[1],after[1])
assert not torch.allclose(before[0],after[0])
model.zero_grad(set_to_none=True)
condition.grad = None
model(x,condition).square().mean().backward()
assert condition.grad is not None and condition.grad.norm() > 0
print("条件只影响相应样本，打开分支后梯度能够回到条件")

```

- 第 1–20 行：每个条件生成 3D 个数，分别用作 scale、shift、gate。零初始化用于验证残差起始行为。
- 第 21–31 行：`gate=0` 时输出等于 x；门控偏置可以有梯度，但零权重会使条件输入首步梯度为零。
- 第 32–45 行：这里手动设置非零参数用于结构演示；不是声称完成训练。逐样本干预能发现广播造成的跨样本污染。

预期观察：初始化输出与 x 一致，门控偏置有梯度；打开分支后仅被修改条件的样本输出改变，条件梯度非零。

## 浏览器 Python 练习

实现 film_batch(features,gamma,beta)。features 为 [B,T,D] 的嵌套列表，gamma/beta 为 [B,D]；返回逐元素 `gamma[b][d] * features[b][t][d] + beta[b][d]`，不修改输入。

```python
def film_batch(features, gamma, beta):
    # TODO: 条件只在同一样本的时间位置之间共享
    raise NotImplementedError("请实现 FiLM")

```

### 提示

- 索引顺序是 batch、time、channel；gamma/beta 没有 time 轴。
- 同一 batch 的每行使用同一组条件，但不同 batch 不能混用。

### 参考实现与解释

```python
def film_batch(features, gamma, beta):
    if len(features) != len(gamma) or len(features) != len(beta):
        raise ValueError("Batch 大小不一致")
    result = []
    for batch,row_list in enumerate(features):
        if len(gamma[batch]) != len(beta[batch]):
            raise ValueError("条件通道不一致")
        rows = []
        for row in row_list:
            if len(row) != len(gamma[batch]):
                raise ValueError("特征通道不一致")
            rows.append([gamma[batch][d]*value+beta[batch][d]
                         for d,value in enumerate(row)])
        result.append(rows)
    return result

```

第二个样本的第二通道 gamma 为零，所以输出始终等于 beta=4。改变第一个样本的条件不应影响第二个样本。

### 断言测试

```python
x = [[[1,2],[3,4]],[[5,6],[7,8]]]
gamma,beta = [[2,1],[1,0]],[[0,-1],[3,4]]
y = film_batch(x,gamma,beta)
assert y == [[[2,1],[6,3]],[[8,4],[10,4]]]
changed = film_batch(x,[[4,1],[1,0]],beta)
assert changed[1] == y[1] and changed[0] != y[0]
assert x == [[[1,2],[3,4]],[[5,6],[7,8]]]
assert film_batch([[]],[[1,1]],[[0,0]]) == [[]]
print("通过：逐通道调制、样本隔离和不修改输入")

```

## 本地 PyTorch 练习

实现 adaptive_layer_norm(x,condition,modulator)。x=[B,T,D]，modulator(condition)=[B,2D]，前 D 是 scale，后 D 是 shift。使用无固定仿射的 LayerNorm，再做 `(1 + scale) * LN(x) + shift`。

```python
import torch
from torch.nn import functional as F

def adaptive_layer_norm(x, condition, modulator, eps=1e-5):
    # TODO: 生成逐样本条件，正确广播并调制
    raise NotImplementedError("请实现 AdaLN")

```

### 提示

- `scale=0` 时要保留 LN(x)，所以公式使用 `1+scale`。
- 对 [B,D] 使用 [:,None,:]，新增的是时间轴；直接乘到 [B,T,D] 会错误或失败。

### 参考实现与解释

```python
import torch
from torch.nn import functional as F

def adaptive_layer_norm(x, condition, modulator, eps=1e-5):
    scale,shift = modulator(condition).chunk(2,dim=-1)
    normalized = F.layer_norm(x,(x.shape[-1],),eps=eps)
    return normalized*(1+scale[:,None,:])+shift[:,None,:]

```

零调制测试识别遗漏加一的问题；\(B=2\)、\(T=3\) 的测试避免轴大小恰好相等掩盖广播错误。逐样本干预与梯度检查分别验证前向依赖和反向连接。

### 断言测试

```python
torch.manual_seed(40)
x = torch.randn(2,3,4,requires_grad=True)
condition = torch.randn(2,2,requires_grad=True)
modulator = torch.nn.Linear(2,8)
torch.nn.init.zeros_(modulator.weight)
torch.nn.init.zeros_(modulator.bias)
torch.testing.assert_close(adaptive_layer_norm(x,condition,modulator),
                           F.layer_norm(x,(4,),eps=1e-5))
torch.nn.init.normal_(modulator.weight,std=0.1)
before = adaptive_layer_norm(x,condition,modulator)
changed = condition.detach().clone()
changed[0] += 1
after = adaptive_layer_norm(x,changed,modulator)
torch.testing.assert_close(before[1],after[1])
assert not torch.allclose(before[0],after[0])
before.square().mean().backward()
assert condition.grad is not None and torch.isfinite(condition.grad).all()
assert modulator.weight.grad is not None
print("通过：零调制、广播隔离与条件梯度")

```

## 练习：推导与分析

### LayerNorm 自带的 gamma/beta 与 FiLM 或 AdaLN 由条件生成的参数有什么区别？为什么 [B,D] 要变成 [B,1,D]？

标准 LayerNorm 的可学习仿射参数通常跨样本和位置共享；FiLM/AdaLN 的调制参数由当前样本的条件产生，因此不同指令、状态或生成时间可以得到不同的缩放与平移。二者在计算中承担不同角色。

输入是 [B,T,D] 时，在中间增加长度一的轴，让条件只沿该样本的 T 个位置广播。不能用维度碰巧相等来判断正确性，应该选择 B 与 T 不同的例子，并只改变一个样本的条件检查隔离。

代码定位：检查 modulator 输出的分块顺序，以及 `scale[:,None,:]` 和 `shift[:,None,:]` 的轴。

- 区分共享的固定参数与样本条件产生的动态参数。
- 解释时间轴广播并给出样本隔离检查。

### 残差门控初始化为零时，条件输入或分支内部梯度为零，一定表示代码断图吗？输出随指令改变是否已经证明语言跟随正确？

不一定。`y = x + gate * F(...)` 的乘法结构使 `gate=0` 时部分分支梯度为零，但门控生成层仍可能获得梯度。应检查门控参数的梯度、完成更新后再观察分支，而不是要求首步所有参数都有非零梯度。

输出随指令变化只证明计算路径对条件敏感。它也可能是无意义的数值变化；需要固定场景和其他条件，使用明确的指令—目标对照评估，检查动作是否按语义改变以及错误率如何变化。

代码定位：同时观察 gate 相关参数梯度、更新后的条件梯度，以及任务层面的指令干预结果。

- 能用乘法路径解释首步零梯度。
- 明确区分条件敏感性与正确语言跟随。

### 单层“拼接后 Linear”和 FiLM 都输出相同形状，为什么它们对输入—条件交互的表达不同？

拼接后 Linear 为 \(W_x x+W_c c+b\)，对 x 的 Jacobian 恒为 \(W_x\)，与 c 无关；混合二阶导数为零。条件只能改变偏置项。

FiLM 为 \(\gamma(c)\odot x+\beta(c)\)，对 x 的 Jacobian 是 \(\operatorname{diag}(\gamma(c))\)，会随条件变化。若 \(\gamma(c)=Ac+b\)，混合二阶导数直接给出 A 的元素。

FiLM 本身仍仅逐通道缩放，并非任意动态矩阵。带非线性的拼接网络也能学习交互，不能把单层反例推广成拼接永远不如 FiLM。

代码定位：固定条件后比较输出对 x 的 Jacobian，再改变条件观察这个 Jacobian 是否变化。

- 给出两种结构的 Jacobian。
- 明确结论只针对所讨论的层及其非线性假设。

## 练习：辨析与纠错

### 有条件输入就认为模型使用了条件

Mask、池化、detach 或数据捷径都可能让条件失效。分别检查计算路径、条件干预和任务级语义指标。

### 直接 γ 与 1+scale 的初始化混用

直接 \(\gamma=0\) 会抹掉特征，`1+scale` 在 `scale=0` 时才保留特征。根据公式设置初始化并明确无调制参考。

### 只用 B=T 的张量测广播

相同维度可能让错误轴静默对齐。用不同 Batch 和时间长度，并确认改单个样本条件不会影响其他样本。

### 将首步零梯度一概归为断图

乘法门控与零初始化能够产生预期零梯度。先检查门控梯度及一次更新后的路径，再决定是否存在 detach。

### 用随机输出变化证明语言理解

变化只能说明数值敏感，不能说明方向正确。固定场景和噪声，设计目标明确的指令对照并评价任务结果。

## 原始资料

- [FiLM：Visual Reasoning with a General Conditioning Layer](https://arxiv.org/abs/1709.07871)
- [Scalable Diffusion Models with Transformers](https://arxiv.org/abs/2212.09748)
- [OpenPI：条件注入与动作专家](https://github.com/Physical-Intelligence/openpi/blob/main/src/openpi/models_pytorch/pi0_pytorch.py)
- [PyTorch：LayerNorm 统计与仿射参数](https://docs.pytorch.org/docs/stable/generated/torch.nn.LayerNorm.html)
- [Ho & Salimans：Classifier-Free Diffusion Guidance（2022，§3.2）](https://arxiv.org/abs/2207.12598)
