# 示教数据与采样

轨迹划分、时间对齐、有效样本与混合分布。

示教数据集是记录观测、动作及其任务和时间关系的经验样本集合；数据质量指这些记录是否足够准确、一致并覆盖目标训练问题。采样策略再决定各条记录以多大概率进入学习，因此数据处理也在定义优化分布。本章先认识记录、轨迹与独立样本的层次，再分析切分、时间语义、标准化统计与任务混合。

## 学习目标

- 按评估目标选择轨迹、采集会话或对象级别的切分
- 让训练集独占统计量拟合并检查数据有效性
- 根据目标任务比例计算逐样本采样权重

前置知识：[数据采样与批处理](https://wxb1870.github.io/embodied-ml-lab/learn/dataloader/) · [时间对齐与动作块](https://wxb1870.github.io/embodied-ml-lab/learn/action-chunk/) · [数值精度与标准化](https://wxb1870.github.io/embodied-ml-lab/learn/numerical/) · [泛化与验证](https://wxb1870.github.io/embodied-ml-lab/learn/generalization/)

## 先定义一条数据与一个独立样本

记录是存储的一帧或一个窗口，轨迹是同一回合内的连续行为，独立样本单位则用于判断统计证据。相邻记录可能高度相关，所以文件数不等于独立信息量。先定义这些层次，再选择采样与评价单位。





同样的采样方式会隐含不同权重。按帧均匀抽样使长轨迹贡献更多；先均匀抽轨迹再抽帧则给每条轨迹相同总概率；按任务再抽轨迹又给任务指定权重。哪一种符合目标，取决于部署任务分布和想优化的行为，而不是 DataLoader 默认采用哪种迭代顺序。





因此数据清单应保留 episode、session、task、对象/场景身份和原始时间戳。记录被裁剪、重采样或窗口化以后，还要能够追溯到原始组。丢掉这些元数据会使训练测试隔离、重复样本检测和故障归因都变困难，后面再用随机种子也无法恢复这种信息。









### 先决定采样与统计的单位

帧、轨迹和任务的均匀分布不同，评价中的独立单位也可能比训练样本更大。

打印每任务轨迹数、帧数、有效动作数与实际抽样比例，检查长轨迹是否无意中获得更高权重。

## Open X-Embodiment、DROID 与数据格式

数据集规定样本来自哪些机器人、任务和采集过程，数据格式规定这些记录如何存储与读取。标准化格式可以统一接口，却不自动统一单位、动作语义或数据分布。下面据此认识代表性数据来源。





[Open X-Embodiment](https://robotics-transformer-x.github.io/) 汇集不同机构、机器人和任务的示教数据，并提供标准化数据形式，用于研究跨机器人训练。它的特点是来源和具身形态多样；统一字段便于加载，却不会自动统一关节顺序、末端坐标、动作单位或控制频率。混合之前仍要建立每个来源的转换，并保留来源身份，接续本章后面的采样风险分析。





[DROID](https://droid-dataset.github.io/) 采用统一的 Franka 采集平台，将机器人带到不同场景中采集示教。它适合用来理解“同一平台上的环境、物体、视角多样性”，这一覆盖轴与跨不同机器人混合并不相同。官方同时提供 RLDS 与原始数据入口；语言标注、相机标定和数据导出版本也应固定，避免把版本差异混入训练对照。





[RLDS](https://github.com/google-research/rlds) 把数据组织为 episode 和其中的 steps，并显式记录边界。`is_last` 表示回合记录结束，`is_terminal` 表示环境终止，两者不可互换；例如截断可以是 last 而不是 terminal。按 RLDS 的规范，最后一条观测后没有有效后续动作，不能仅因 `action` 字段仍存在就将它作为行为克隆标签。具体数据转换器还需核对是否遵循该规范。





[LeRobotDataset v3](https://huggingface.co/docs/lerobot/en/lerobot-dataset-v3) 的典型存储由 Parquet 状态/动作、MP4 视频和轨迹元数据组成，加载器向 PyTorch 提供张量与时间窗口。v3 的一个文件可包含多个 episode，边界通过元数据恢复，不能把文件边界当作轨迹边界；这与 v2 常见的逐轨迹文件布局不同。格式版本、特征名、FPS、视频时间与动作含义要一并核对。





将 RLDS 数据转换成 LeRobot 格式，并不会改变原始示教的覆盖范围，也不会自动消除延迟或统一动作表示。转换后应核对同一 episode 的首尾、时间戳、动作有效位与采样窗口，再做[时间对齐](#/learn/action-chunk)和[批处理](#/learn/dataloader)。本章后续的组级切分和训练统计量约束，对这几种资源与格式同样适用。







### 资源覆盖与读取协议分别判断

| 项目 | 主要特点 | 用于训练前要确认 |

|---|---|---|

| Open X-Embodiment | 跨来源、跨机器人数据集合，研究多具身形态迁移。 | 每个来源的动作语义、转换、采样比例与评价划分。 |

| DROID | 统一采集平台上的多场景、多视角示教。 | 场景/会话隔离、相机标定、语言与数据版本。 |

| RLDS | 以 episode / step 为核心的记录规范与处理工具。 | 首尾与终止标记、无效末步动作、时间和字段语义。 |

| LeRobotDataset v3 | 面向 PyTorch 的数据接口；常见布局为 Parquet、视频与元数据。 | 由元数据恢复边界；按版本读取窗口、有效位和特征。 |



## 数据切分要回答明确的泛化问题

数据切分是将来源记录分配到训练、验证和测试集合的过程。分组单位应对应要检验的新轨迹、场景或物体变化。先明确泛化主张，再选择隔离层级，才能避免相关片段泄漏。





如果问题是新轨迹上的表现，按完整轨迹隔离至少能避免相邻帧泄漏；如果问题是新物品、新场景或新采集会话，还需要按对应组隔离。把同一物体的不同视角分到训练和测试，只能支持对已见物体的新视角结论，不能宣称新物体泛化。切分单位应由实验主张反向确定。





先切分，再拟合统计量、选择数据清洗阈值或进行模型选择。若先在全数据上估计均值与标准差，测试分布已经参与处理；若先用全数据挑出“难例”再决定分组，可能也引入选择偏差。任何基于数值内容学习的转换，都应说明它在哪个子集上拟合。





重复片段、重命名文件和同一采集结果的不同导出版本还会跨组泄漏。哈希可识别完全相同记录，但轻微压缩或裁剪后相同场景可能具有不同哈希，因此还需原始来源与组级元数据。随机划分可复现不等于划分合理；固定种子只固定了某个可能错误的协议。







### 例：帧级切分为什么看起来特别容易

1. 一条长轨迹中，t 与 t+1 的画面几乎一样，动作也高度相关。

2. 若 t 在训练集、t+1 在测试集，模型可能主要是在复现已见轨迹附近的状态。

3. 把整条轨迹或整次采集会话整体留出，才会去掉这一类近邻泄漏；仍需按新物体等目标进一步隔离。

验证分数只能解释为当前切分所支持的泛化类型。

### 轨迹 ID 不交叉就认为所有泄漏都消失

对象、会话、场景、预处理统计以及反复选模都可能共享信息。

先写实验要外推的轴，再检查每个轴的组隔离和所有拟合步骤使用的数据来源。

## 质量检查沿时间与语义展开

数据完整性检查字段、维度与数值是否可读可用，语义一致性检查时间、单位和观测—动作对应是否符合任务。两者属于不同层面的质量。下面沿同一条轨迹同时追踪它们。





基础完整性包括图像能解码、关节与动作维度符合接口、数值有限、时间单调、回合边界明确。进一步检查相机源时间是否滞后、重复帧是否过多、动作是否超出记录约定，以及观测与命令的延迟是否稳定。合法的 shape 不会揭示这些语义错误，需要结合元数据和可视化片段。





缺失观测要有独立有效位。零图像可能表示真正黑暗，也可能表示丢帧；动作零值可能是停住，也可能是填充。用数值等于零判断有效性，会混淆这些情况。对关键事件，应检查事件前后的观测和动作是否完整，而不是只保留事件发生的一帧作为全部因果证据。





清洗规则还应尊重任务阶段。高速度可能是坏数据，也可能是合法恢复动作；低速度可能是重复停顿，也可能是接触保持。仅按全局分位数删除离群值，会系统性删除稀有但重要的状态。先检查物理含义、采集错误类型与任务分组，再记录过滤前后各组分布，保留能够追溯的删除原因。









## 监督冲突不一定等于数据损坏

监督冲突是相同可观测条件对应不同标签的现象，来源可能是标注错误、隐藏信息或真实多种方案。它不等同于数据损坏。先判断差异是否能被可用条件解释，再决定筛选、补条件或建模分布。





同一可观测条件对应不同动作，可能来自操作者风格、隐藏状态或真正多种可行方案。简单把这些标签平均，未必得到有效策略；只保留最常见动作也可能丢掉必要覆盖。应先判断输入是否缺少历史、任务阶段或目标信息，再决定修正条件、使用分布模型或规范示教。





延迟错位、单位错误和关节顺序错误则是另一类问题，它们应该在数据接口层修复。可以比较动作与状态差分的时延关系，但峰值相关不自动证明因果对齐，尤其闭环控制中命令与反馈互相作用。抽取已知事件，核对发送、接纳和实测时间，往往更有解释力。





成功轨迹并不意味着每一帧都是最优标签，失败轨迹也可能包含有价值的正常或恢复行为。是否保留失败片段，要结合标签质量、目标条件和训练方法；不能把失败标签直接当成功专家动作。记录采集策略版本与人工介入信息，有助于解释同一状态附近为什么存在不一致监督。









## 训练统计量怎样拟合与使用

训练统计量是仅从训练数据有效部分估计的均值、尺度等预处理参数。它们随后成为模型输入输出函数的一部分，需要固定并保存。Padding 与缺失字段不应作为真实观测混入估计。





对动作或状态做标准化时，应只在训练集的有效元素上估计统计量。回合末尾 Padding、异构机器人填充维与缺失字段不应混入均值和方差；否则统计量会随补齐长度或数据组合变化。按维度检查有效数量，对从未出现有效值的维度采用明确协议，不能静默除以零。





标准差下界可以防止常量维数值爆炸，但不替代单位检查和有效性声明。全数据统一统计、每机器人统计和每任务统计对应不同生成空间；若推理不知道任务身份，就不能依赖只有训练时才有的任务专属转换。统计量文件需绑定动作顺序、估计方法与版本。





在线推理应使用保存的统计量，而不是根据当前小批观测重新计算。后者会使同一动作值的编码依赖同时出现的其他样本，破坏训练的语义。对验证集仅执行 transform，不执行 fit；training_statistics 练习通过改变非训练行而保持统计量不变，直接检查这一边界。









## 从目标任务概率得到逐记录采样权重

逐记录采样权重是为实现目标任务概率分配给每条记录的抽样质量。任务中记录越多，单条权重与任务总权重的关系越要分清。下面由期望任务比例推导，而不是凭样本数直接设定。





假设任务 k 有 \(n_k\) 条可采记录，希望抽到该任务的总概率是 \(p_k\)。给其中每条记录权重 \(w_i=p_k/n_k\)，则任务内权重相加为 \(p_k\)，所有任务合计为 1。WeightedRandomSampler 接收的是逐记录权重，不是任务类别权重；权重可以不预先归一化，但相对比例必须正确。





如果直接把 \(p_k\) 赋给任务内每帧，该任务总权重会变成 \(n_k p_k\)，数据更多的任务仍占优势。若希望任务内再按轨迹均衡，应先分配任务概率给轨迹，再分到帧，不能只使用全任务帧数。窗口化以后，\(n_k\) 应与真正采样的窗口数量对应，而不是原始视频帧数。





replacement=True 允许重复抽到稀少任务样本；replacement=False 则会在一个有限抽样过程中逐渐耗尽某些记录，整轮比例与每次独立抽样不同。提升稀少任务比例增加的是训练曝光，不会创造新场景。还应检查多进程中的采样划分与种子，避免不同工作进程重复同一序列而误判为有效多样性。





$$
w_i=\frac{p_{k(i)}}{n_{k(i)}},\qquad \sum_{i:k(i)=k}w_i=p_k
$$



### 例：10 帧与 2 帧的两个任务，各占一半

1. 任务 A 有 10 帧，B 有 2 帧，目标 \(p_A=p_B=0.5\)。

2. A 的每帧权重为 0.05，B 的每帧权重为 0.25，两任务总权重都是 0.5。

3. 若每帧都赋 0.5，则 A 总权重 5、B 总权重 1，归一化后仍是 5:1。

目标任务比例必须经过该任务记录数量换算，不能直接复制到所有样本。

### 把过采样次数当成更多独立数据

稀少样本反复出现可以改变训练目标权重，也会增加记忆这些样本的风险。

比较实际抽样频率与唯一轨迹/场景覆盖；对稀少任务单独报告训练和保留集表现。

## 混合采样改变了优化的分布

混合数据分布是按任务概率组合多个任务内分布得到的总体分布。采样比例改变模型看见的任务频率，损失权重又可进一步重加权。两者一起定义训练期望，需要共同解释。





设任务索引为 \(k=1,\ldots,M\)，任务内数据分布为 \(D_k\)，希望优化的任务权重为 \(p_k\ge0\)、\(\sum_kp_k=1\)。目标风险是 \(R_p(\theta)=\sum_k p_k\,\mathbb E_{D_k}[\ell_\theta]\)。实际采样先以概率 \(q_k\) 选任务，再从 \(D_k\) 选记录；若对应损失还乘 \(\lambda_k\)，平均更新就来自 \(\sum_k q_k\lambda_k\,\mathbb E_{D_k}[\ell_\theta]\)。





当目标权重非零的任务都有 \(q_k>0\)，且希望只改变采样方式、不改变这个目标时，取 \(\lambda_k=p_k/q_k\) 才能逐项恢复 \(R_p\)。这依赖任务内采样仍为 \(D_k\)；若任务内也按难度筛选，还需处理那部分概率。重要性校正不保证方差更小，极小的 \(q_k\) 反而可能带来很大的权重。



### 例：同一组任务损失，采样和加权怎样改变目标

1. 设两任务的目标概率为 (0.8,0.2)，当前任务内平均损失分别为 (1,4)。目标风险是 0.8×1+0.2×4=1.6。

2. 若改成各占一半地抽任务，且不作损失校正，期望损失变成 0.5×1+0.5×4=2.5。

3. 若仍想优化原目标，应分别乘上 p/q=(1.6,0.4)：0.5×1.6×1+0.5×0.4×4=1.6。

改变曝光频率和改变目标权重是两个选择；是否校正应由想优化的任务分布决定。

若均匀抽样本来就是为了加强第二个任务，则不应抵消它，而应明确采用了新的目标分布。过采样再叠加额外类别权重，也必须按乘积解释。





评估应使用事先定义的任务分布，并同时报告按任务等权与按实际试验数汇总等指标。训练采样比例无需与评价完全相同，但差异要明确，否则一个总分的改善可能只反映评价组份变化。清洗与重采样的消融也要固定其余数据身份及预算，才能判断具体规则的作用。





数据报告可以集中记录组交叉、缺失率、时间偏移、每维有效数、过滤原因与抽样分布。规则变更应绑定数据版本与对照结果，使训练差异能够追溯到经验分布的具体变化。





可用的数据集需要同时满足记录语义正确、划分支持目标结论、统计量只拟合合法训练元素、采样权重对应期望任务分布。整理数据的最终产物是一份明确的学习问题，而不仅是能被读取的文件集合。





$$
\begin{aligned}R_p(\theta)&=\sum_k p_k\,\mathbb E_{D_k}[\ell_\theta],\\\mathbb E_{K\sim q,D_K}[\lambda_K\ell_\theta]&=\sum_kq_k\lambda_k\,\mathbb E_{D_k}[\ell_\theta],\\\lambda_k&=p_k/q_k\quad\text{when }q_k>0\text{ on the target support}.\end{aligned}
$$

```python
import torch

torch.set_default_dtype(torch.float64)
p = torch.tensor([0.8, 0.2])
q = torch.tensor([0.5, 0.5])
loss_by_task = torch.tensor([1., 4.], requires_grad=True)
target = p @ loss_by_task
uncorrected = q @ loss_by_task
corrected = q @ ((p/q)*loss_by_task)
torch.testing.assert_close(target, torch.tensor(1.6))
torch.testing.assert_close(uncorrected, torch.tensor(2.5))
torch.testing.assert_close(corrected, target)
g_target, = torch.autograd.grad(target, loss_by_task, retain_graph=True)
g_corrected, = torch.autograd.grad(corrected, loss_by_task)
torch.testing.assert_close(g_target, g_corrected)
torch.testing.assert_close(g_corrected, p)
print("target, uncorrected, corrected:",
      target.item(), uncorrected.item(), corrected.item())
print("effective task coefficients:", g_corrected.tolist())

```

用两任务的精确有限和替代随机采样，直接验证期望权重，不让抽样噪声掩盖目标差异。对每任务损失求梯度得到其系数；再乘该任务损失对模型参数的梯度，就是链式法则下的参数更新贡献。真实数据中还要检查 q 是否确实等于采样器实现的任务概率。





## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| episode_id / task_id | [N] | 用于组切分与任务采样的元数据 |
| sample weights | [N_train] | 训练记录逐项采样权重 |
| normalization statistics | [D] | 仅由训练记录拟合的动作统计量 |

## 完整代码与精读

```python
from collections import Counter
import torch
from torch.utils.data import WeightedRandomSampler

torch.manual_seed(7)

# STEP 1: 每条记录保留 episode 和 task，而不仅保存动作
records = []
for episode, task_name, length in [(0,'reach',6),(1,'grasp',2),(2,'reach',4),(3,'grasp',3)]:
    for t in range(length):
        records.append({'episode':episode,'task':task_name,
                        'action':torch.tensor([episode*0.1, t*0.01])})
train_episodes, validation_episodes = {0,1,2}, {3}
assert train_episodes.isdisjoint(validation_episodes)
train = [r for r in records if r['episode'] in train_episodes]
validation = [r for r in records if r['episode'] in validation_episodes]

# STEP 2: 先做有限值检查，统计量只在训练数据上拟合
train_actions = torch.stack([r['action'] for r in train])
assert torch.isfinite(train_actions).all()
mean = train_actions.mean(dim=0)
std = train_actions.std(dim=0,unbiased=False).clamp_min(1e-6)
validation_actions = torch.stack([r['action'] for r in validation])
validation_normalized = (validation_actions-mean)/std

# STEP 3: p_k/n_k 才能让两种任务各占期望 50%
counts = Counter(r['task'] for r in train)
desired = {'reach':0.5,'grasp':0.5}
weights = torch.tensor([desired[r['task']]/counts[r['task']] for r in train],dtype=torch.double)
generator = torch.Generator().manual_seed(7)
sampler = WeightedRandomSampler(weights,10000,replacement=True,generator=generator)
selected = list(sampler)
observed = Counter(train[i]['task'] for i in selected)

# STEP 4: 报告真实抽样，而不是仅报告配置中的目标比例
print('training frame counts:', dict(counts))
print('observed sample fractions:', {k:round(observed[k]/len(selected),3) for k in desired})
print('training mean/std:', mean.tolist(), std.tolist())
print('validation uses training statistics:', tuple(validation_normalized.shape))
assert abs(observed['reach']/len(selected)-0.5) < 0.04

```

- 第 7–17 行：轨迹 ID 用于阻止同一轨迹跨集合。演示的验证轨迹只说明隔离机制，真实评估还需要覆盖你声称的任务分布。
- 第 18–25 行：统计量只由训练记录拟合；验证记录使用相同变换。先检查 NaN/Inf，防止异常污染整份统计量。
- 第 26–34 行：reach 有十帧、grasp 只有两帧。每帧用目标概率除以该任务帧数，才能消除数量差异对任务比例的影响。
- 第 35–40 行：放回采样允许重复，实际比例围绕期望波动。采样配置与实际日志都应随实验保留。

预期观察：训练帧数 reach=10、grasp=2；一万次加权采样后两任务比例接近各 50%。验证统计量没有参与拟合。

## 浏览器 Python 练习

实现 sample_weights(tasks, desired)。tasks 是记录的任务标签列表，desired 是总和为 1 的非负目标概率。返回每条记录的权重；缺失但有正目标概率的任务、未知标签或空数据要报错。

```python
import math
from collections import Counter

def sample_weights(tasks, desired):
    # TODO: 每条记录应获得其任务概率除以该任务样本数
    raise NotImplementedError

```

### 提示

- 先用 Counter 统计每种任务有多少条记录。
- 验证一个任务内所有记录的权重和，是否等于 desired 中的概率。

### 参考实现与解释

```python
import math
from collections import Counter

def sample_weights(tasks, desired):
    if not tasks or not desired:
        raise ValueError('empty data or distribution')
    if any(not math.isfinite(p) or p < 0 for p in desired.values()) or not math.isclose(sum(desired.values()),1.0):
        raise ValueError('invalid distribution')
    counts = Counter(tasks)
    if any(t not in desired for t in counts):
        raise ValueError('unknown task')
    if any(p > 0 and counts[t] == 0 for t,p in desired.items()):
        raise ValueError('positive probability without data')
    return [desired[t]/counts[t] for t in tasks]

```

任务概率是该任务全部记录的权重之和。把 0.5 直接赋给每条 reach 记录，会让三条 reach 总权重达到 1.5，改变预期比例。

### 断言测试

```python
tasks = ['reach','reach','reach','grasp']
w = sample_weights(tasks,{'reach':0.5,'grasp':0.5})
assert abs(sum(w[:3])-0.5) < 1e-12
assert abs(w[3]-0.5) < 1e-12
assert abs(sum(w)-1.0) < 1e-12
assert sample_weights(['a','a'],{'a':1.0}) == [0.5,0.5]
try:
    sample_weights(['reach'],{'reach':0.5,'grasp':0.5})
    raise AssertionError('缺失目标任务应报错')
except ValueError:
    pass
print('逐样本权重与任务总概率检查通过。')

```

## 本地 PyTorch 练习

实现 training_statistics(x, train_mask)。x 为 [N,D]，train_mask 为 [N] 布尔值。仅用训练行计算均值和总体标准差，标准差下界 1e-6；训练行非有限或没有训练行时拒绝计算。

```python
import torch

def training_statistics(x, train_mask):
    # TODO: 先筛选训练行，再检查并计算统计量
    raise NotImplementedError

```

### 提示

- 必须先用 train_mask 选行，再计算任何统计量。
- 使用总体标准差 unbiased=False；训练集为空或包含非有限值时应报错。

### 参考实现与解释

```python
import torch

def training_statistics(x, train_mask):
    if x.ndim != 2 or train_mask.shape != (len(x),) or train_mask.dtype != torch.bool:
        raise ValueError('invalid shape or mask')
    train = x[train_mask]
    if len(train) == 0 or not torch.isfinite(train).all():
        raise ValueError('invalid training data')
    return train.mean(dim=0),train.std(dim=0,unbiased=False).clamp_min(1e-6)

```

函数只允许训练记录影响均值和标准差，保留集即使有极端值也不能改变结果。训练数据要先检查有限性，避免一个 NaN 污染全部维度；验证数据自身的质量检查属于另一条流程。标准差下界避免常量维除零。此处使用总体标准差，是明确的变换约定，推理必须复用同一份结果。

### 断言测试

```python
x = torch.tensor([[1.,2.],[3.,6.],[999.,1000.]])
m = torch.tensor([True,True,False])
mean,std = training_statistics(x,m)
torch.testing.assert_close(mean,torch.tensor([2.,4.]))
torch.testing.assert_close(std,torch.tensor([1.,2.]))
x[-1] = torch.tensor([float('nan'),-100000.])
mean2,std2 = training_statistics(x,m)
torch.testing.assert_close(mean,mean2)
torch.testing.assert_close(std,std2)
print('训练统计量未受保留集数据影响。')

```

## 练习：推导与分析

### 按 episode 切分后验证很好，换物品明显失败，是否说明评估代码错了？

不一定。不同 episode 仍可能包含同一物品、同一摆位和同一采集会话，因此原验证测量的是这个分布内的新轨迹表现。若结论要涉及新物品，就需按物品身份保留独立测试组；新会话、新背景和新操作者也是不同泛化轴。

先检查划分元数据和重复/近重复记录，再明确每份测试集的目标。标准化和任何数据驱动预处理只能由训练部分拟合。若用测试失败样例做了补采或调参，就应把它转为开发数据，并保留新的最终测试集。

代码定位：episode_id/task_id 分组、train_episodes 与统计量拟合边界。

- 区分 episode 隔离与对象/会话隔离。
- 说明测试集进入迭代后的角色变化。

### 两个任务数据量是 10:1，把它们每条记录的权重都设成 0.5，能得到任务各 50% 吗？

不能。采样器看到的是逐记录权重，一个任务有十倍记录就会积累十倍总权重。若任务目标概率为 \(p_k\)、记录数为 \(n_k\)，应给每条记录 \(p_k/n_k\)，使同任务的权重和等于 \(p_k\)。

还要说明记录单位是帧、窗口还是轨迹，以及采样是否放回。目标比例是期望，不保证每个 Batch 恰好一致。记录实际抽样任务频率，并在比较模型时控制总样本数和训练预算；没有数据的正概率任务应明确报错或重设目标。

代码定位：sample_weights 中 Counter、逐任务归一化及 WeightedRandomSampler 日志。

- 能推导 \(p_k/n_k\)。
- 区分配置概率、实际采样频率和每批平衡。

### 将 RLDS 转成 LeRobotDataset v3 后，为什么不能仅凭文件边界决定训练/验证划分，也不能把每行 action 都计入监督？

v3 的一个 Parquet 或视频文件可以包含多个 episode，episode 也依赖元数据中的范围定位。切分与构造时间窗口应先确认原始 episode/session/场景身份。只有预先证明文件分片与所需独立分组一致时，文件才可作为该划分的实现单位；文件格式转换本身不提供新的统计独立性。

RLDS 规范中的最后观测没有有效后续动作；字段存在不等于有效标签，is_last 与 is_terminal 也有不同含义。转换时应保留或重建对应有效位，并检查动作和观测的时间约定。Padding、末步和缺失字段应分别处理，不能用动作是否为零推断。

代码定位：对照数据样本的 episode 标识、窗口索引与 action_valid，检查跨 episode 的窗口及最后观测是否进入损失分母。

- 区分文件分片、episode 与评估独立单位。
- 说明 last、terminal 与有效动作监督的关系。

## 练习：辨析与纠错

### 先标准化全数据再划分训练测试

测试分布会参与统计拟合。先按正确组切分，所有学习型预处理仅 fit 训练集。

### 把任务概率直接作为每帧权重

总概率还会乘以任务的帧数。按 \(p_k/n_k\) 分配，并检查实际采样直方图。

### 按零值或全局分位数直接删数据

合法停顿、稀有恢复与缺失记录可能混在一起。结合有效位、任务阶段和物理含义记录清洗规则。

### 把长轨迹的帧数当独立示教数

时序与窗口重叠会形成相关性。分别报告帧、轨迹、会话与场景覆盖，并据此选择评价单位。

### 测试集失败后补采又继续称它为独立测试

这些条件已经参与模型开发。将它们归入开发集，另外保留未使用的最终评价条件。

## 原始资料

- [scikit-learn：数据泄漏与预处理常见问题](https://scikit-learn.org/stable/common_pitfalls.html)
- [PyTorch WeightedRandomSampler](https://docs.pytorch.org/docs/stable/data.html#torch.utils.data.WeightedRandomSampler)
- [OpenPI：训练数据归一化](https://github.com/Physical-Intelligence/openpi/blob/main/docs/norm_stats.md)
- [Open X-Embodiment：跨机器人数据集合与研究背景](https://robotics-transformer-x.github.io/)
- [DROID：统一平台、多场景采集与官方数据入口](https://droid-dataset.github.io/)
- [DROID 官方数据说明：RLDS 与原始数据](https://github.com/droid-dataset/droid/blob/main/docs/the-droid-dataset.md)
- [RLDS 官方规范：episode、is_last 与 is_terminal](https://github.com/google-research/rlds)
- [LeRobotDataset v3：文件分片、元数据与时间窗口](https://huggingface.co/docs/lerobot/en/lerobot-dataset-v3)
