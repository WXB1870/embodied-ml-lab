# 梯度累积

让不同长度的微批次，真正等价于同一个训练目标。

梯度累积是把一次有效批次拆成多个微批次、分别前向与反向，将梯度累加后只更新一次参数的方法。它降低同时保存的激活量，但是否等价于大批次取决于目标分母、参数保持不变及前向是否受分块影响。本章先认识一个完整累积周期，再定义变长计数、尾批、裁剪、精度缩放与进程同步的边界。

## 学习目标

- 推导不等长微批次对应的全局平均损失与梯度。
- 写出清零、累积、裁剪、更新和调度的正确边界。
- 用完整批次作为数值参照，验证参数更新等价性。

前置知识：[PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/) · [梯度下降、动量与 AdamW](https://wxb1870.github.io/embodied-ml-lab/learn/optimization/)

## 梯度可加的前提：同一参数点、同一目标

梯度可加性是同一参数点处，加权目标之和的导数等于各目标导数之和的性质。梯度累积利用它分开计算一个有效批次。先固定参数与每项系数，才能把累积和多次小步更新区分开。





设本次更新共有 N 个有效元素，第 k 个微批次的未归约损失和为 \(S_k\)，则完整目标为 \(L=\frac{\sum_k S_k}{N}\)。微分的线性性允许把样本分成多个微批次，分别计算它们对同一组参数的梯度，再相加。这里关键是所有微批次前向都使用相同参数，且每项损失带有与完整目标一致的系数。若每个微批次都 optimizer.step，后面的梯度是在另一参数点计算，已经变成多次小批更新，不再是同一次大批梯度。



### 例：相同两个样本，更新顺序可以改变结果

1. 令 \(L_1(\theta)=\frac12(\theta-1)^2\)、\(L_2(\theta)=\frac12(\theta+1)^2\)，从 \(\theta=0\) 开始。两项在同一点的梯度分别为 −1 和 +1，平均梯度为 0，因此一次累积更新仍为 0。

2. 若改成两个 SGD 小步，每步学习率 0.1，先用 \(L_1\) 得到 \(\theta=0.1\)，再用 \(L_2\) 的当前梯度 1.1 得到 \(\theta=-0.01\)。

3. 把顺序反过来，结果为 +0.01。即使把每个小步学习率改为 0.05，仍分别得到 −0.0025 或 +0.0025，而累积更新仍为 0。

逐微批 step 会在新的参数点重新求梯度；把学习率按微批数缩小，也不能普遍恢复一次大批更新。

梯度累积主要减少同时驻留的激活，不会按同样比例减少参数、梯度和优化器状态。一个微批次反向完成后，它的图可以释放，叶子参数上的 .grad 保留数值供后续相加。通常无需 retain_graph=True，因为每个微批次都是新的前向图。把所有微批 loss 保留到最后一次 backward，可能仍然保留全部激活，失去预期的内存优势。





理解累积时先写出完整目标，再设计分块过程；不要先套 loss/K 模板再解释它平均了什么。样本数、有效 token 数、动作维度与权重都可能影响分母，尤其是机器人轨迹长短不同的情况。





$$
\nabla_\theta\frac{\sum_k S_k(\theta)}{N}=\sum_k\nabla_\theta\frac{S_k(\theta)}{N}
$$





## 为什么 loss 除以累积次数只在特定条件下成立

有效元素数是当前目标真正平均的监督标量数量，微批局部均值则只平均该微批。仅在相应计数相等时，平均局部均值才等于总体均值。下面由完整目标推导每次反向应使用的系数。





若每个微批次都有相同的有效元素数 n，且其局部损失 \(L_k\) 都是这些元素的平均，完整目标为 \(\frac1K\sum_k L_k\)，因此每次反向前除 K 正确。若 \(n_k\) 不同，正确目标则为 \(\frac{\sum_k n_kL_k}{\sum_k n_k}\)。把局部均值直接平均，等于让微批次等权，而不是让元素等权；最后一个不足大小的批次尤其容易触发这个错误。





一种直接实现是先知道本次更新所有微批次的总有效数 N，将每个未归约误差和 \(S_k\) 除 N 后 backward。若目标分母只依赖数据而不依赖参数，也可先累计误差和对应的梯度，再在更新前按同一 N 缩放梯度。后一种方式与 AMP、DDP 和裁剪组合时必须明确顺序，不能先裁剪局部梯度再期望恢复完整目标。







### 例：不等长微批次不能简单二等分

1. 微批次 A 有 2 个有效元素，平均梯度为 10；B 有 6 个有效元素，平均梯度为 2。

2. 完整有效元素平均梯度为 \(\frac{2\times10+6\times2}{8}=4\)。

3. 两个局部均值各除 2 再相加得到 6，方向可能相同但更新幅度和任务权重已经错误。

有效元素不等时，用真实计数加权，而不是固定累积次数。

### 有效 Batch 大小只按样本条数估算

不同轨迹包含的有效监督数量可以相差很大；样本 Batch 与元素 Batch 不一定等价。

同时记录每次更新的样本数、有效时间步和有效标量数，并手算两块不等长输入。

## 清零、反向、更新与尾批的边界

累积周期是多次微批反向共同组成一次参数更新的范围。周期开始清空旧梯度，内部保持参数固定，末端统一更新。尾批长度不足时也需按实际监督量定义，而非默认补足完整周期。





一个累积周期开始前清零梯度；周期内多次 forward/backward；周期结束执行一次更新；再为下一个周期清零。若在每个微批次开头 zero_grad，前面的累积会被丢掉。若周期结束忘记清零，旧梯度会混入下一次更新。最好用显式的 optimizer_step 和 micro_step 计数，避免把这些边界隐藏在复杂循环条件里。





数据迭代结束时可能剩下不足 K 个微批次。可以按实际有效数完成这一更新，或者按预先声明的协议丢弃；不能仍固定除 K，却宣称与当前剩余数据的均值等价。空监督微批次可以对分子和计数贡献零，但整个更新全无效时必须明确跳过策略。日志、scheduler 和 checkpoint 的保存位置也要对应这个更新边界。





如果中途恢复训练，需要知道是否允许在累积周期内部保存。只保存模型和优化器而不保存已累计梯度、计数与数据位置，会丢失半个更新。更简单的协议是在完整 step 边界保存，并在文档中明确这一点。









## 裁剪是非线性操作，应在完整梯度形成后进行

梯度裁剪是对已经形成的梯度作幅度限制，它通常是非线性操作。先分别裁剪微批再相加，通常不等于对总梯度裁剪。若要保持同一批次更新，应先完成累积再执行裁剪。





全局范数裁剪将最终梯度按同一比例缩放。一般有 \(\operatorname{clip}(g_1)+\operatorname{clip}(g_2)\ne\operatorname{clip}(g_1+g_2)\)，所以逐微批次裁剪再累积，会改变更新方向与大小。正确顺序通常是完成全部反向、还原 AMP 缩放、必要的全局归约，再对完整参数集合裁剪一次，最后 step。



### 例：局部裁剪会改变结果

1. 一维微梯度为 \(g_1=2\)、\(g_2=-1\)，阈值为 0.5。

2. 分别裁剪后为 0.5 和 -0.5，相加得到 0。

3. 先求和得到 1，再裁剪得到 0.5。

一次完整更新与逐块裁剪是两个不同算法。

裁剪参数集合也应一致。若只裁剪某一小头，却把总梯度范数当作整个模型统计，会误判训练稳定性。对于分片优化器或特殊分布式结构，全局范数如何得到需要对应实现；这里的公式以同一进程可访问全部目标梯度为基础。检测到 NaN/Inf 时，应定位来源，而不是让 max_norm 成为掩盖非法数值的手段。









### 记录裁剪前范数与真实参数位移

裁剪是否频繁触发、是否压制了正常信号，需要实际统计。

在固定累积周期内比较裁剪前后梯度，并确认只在周期末调用一次。

## AMP 累积必须保持同一个缩放因子

梯度缩放使反向梯度带上同一正比例因子，unscale 才将它恢复到原目标的单位。累积周期内各项必须使用一致因子，否则无法用一次还原得到正确总梯度。下面将缩放边界接到更新边界。





使用 GradScaler 时，整个有效批次的梯度要在同一缩放因子下累加。如果第一个微批次后就 unscale，再累加第二个缩放后的梯度，两者单位不同，无法得到正确总梯度。类似地，在周期中途 update 改变缩放因子，会让不同微批次乘上不同倍数。缩放检查、跳步和尺度更新应与完整有效批次对齐。





通常每个微批次用同一个 scaler.scale(loss_part).backward，在周期末 unscale_ 一次，裁剪后 scaler.step，再 scaler.update。每个 optimizer 的 unscale_ 不能在一次更新之间重复调用。若一个周期出现非有限梯度，跳过的是这次完整更新；scheduler 是否前进应遵守实际更新计数协议，并记录跳步事件。





梯度缩放只处理数值范围，不会自动修复错误的 loss_part 分母。应先在 FP32 下证明累积等价，再引入 AMP 并用合理容差比较；否则数学归约错误与低精度差异会混在一起。









### 在微批次末尾调用 scaler.update

这样可能使同一 .grad 中混入不同单位的梯度。

把 unscale、clip、step、update 与清零放到同一个明确的更新边界。

## DDP 累积还多了进程维度

分布式累积同时包含微批维度和进程维度：本地先累加，进程间再按同步协议组合。默认 DDP 的平均行为并不自动补齐不同有效计数。需要先定义全局目标，再推导各 rank 的贡献。





普通 DDP 会在进程间平均梯度。若各 rank 和微批次有效数不同，平均本地均值不等于全局有效元素均值。应先得到全局有效数 N，并按 DDP 的平均行为对本地误差和缩放；在默认平均梯度协议下，本地反向目标可写为 \(\frac{\mathrm{world\_size}\,S_{\mathrm{local}}}{N}\)，使平均后回到全局目标。自定义通信 hook 或不同归约方式需要重新推导。





为了减少通信，可在前几个微批次使用 no_sync，并在最后一次前向与反向恢复同步。no_sync 的上下文需要包含 forward，不能只包 backward。所有 rank 必须以一致的顺序参与所需集合通信；某个进程没有本地有效元素，也不能无协调地跳过同步。这里应先追求正确更新，再考虑通信优化。









## 大批次与累积为何可能仍不完全相同

大批次等价要求分块不改变每个样本对应的前向函数与目标。训练态 BatchNorm、批内对比或随机操作可能不满足这个条件。梯度加法恒等式本身不能消除这些前向差异。





数学上的梯度加法等价假定每个样本的前向行为不随分块变化。训练态 BatchNorm 使用微批统计，分块后统计不同，因此不一定等价于一次大批前向。Dropout 随机 Mask、数据增强、批内对比负样本和其他跨样本运算也会改变目标。把损失分母修正正确，是必要条件，但并非所有模型的大批等价充分条件。





浮点累加顺序还会带来小数值差异。验证可先选择没有跨样本状态和随机性的模型，使用 float64，关闭或固定随机因素，比较 loss、逐参数梯度与更新后的参数；确认基础目标一致后，再逐项加入真实结构。若差异来自有意的微批统计，应记录这一边界，而不是不断放宽容差掩盖原因。









## 用一次完整更新做端到端对照

各项等价条件最终需要在一次完整更新中同时成立。复制同一模型和优化器状态，逐项比较整批与分块的梯度及参数，比只观察两条相似损失曲线更直接，也能发现计数边界上的错误。





示例用不等长、带 Mask 的微批次复现完整批次更新。首先复制同一初始模型和优化器状态，随后分别走整批与分块路径，最终逐元素比较参数。只比较最终 loss 太弱：两个错误实现也可能得到接近的标量；比较梯度更直接，而参数对照还能发现 step 次数和优化器状态边界错误。





扩展检查时覆盖最后不足 K 的尾批、某一微批次全无效、不同动作维数以及权重不等的样本。日志同时报告误差和、有效数、微批次数、同步次数与优化步数。确认这些计数和目标定义一致后，再调节累积次数以适应显存或吞吐，而不是把更大的名义 Batch 直接当作更好的训练方案。





保存实验配置时明确哪些操作在微批级、哪些在更新级：增强与前向通常在微批级，裁剪、optimizer.step、按步学习率与 scaler.update 通常在更新级。这样才能让后续改动、断点恢复和分布式扩展保持可解释。





本章的局部梯度对照继续保留；完整组批后的验证统一在[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)的 `verify_accumulation`。同一个 TokenRegressor 和七条 episode 分成有效数 10、30 的两批，正确反传是 S₁/40 与 S₂/40；控制组故意对局部 mean 再平均。除了所有梯度，还对照一次 SGD 后的参数。这一等价不含 BN、Dropout 或批间随机交互，不能推广为任意网络逐比特相同。





梯度累积保留的应是一次明确更新：相同参数、相同监督权重、完整总梯度和统一更新边界。节省激活内存是实现效果，与大批次等价则是带条件的数学关系，需要分别检查。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 微批次输入 | [bₖ, D] | bₖ 可以不同；参数在累积窗口内不变。 |
| 误差与有效位 | [bₖ, A] | 本例按有效动作标量平均，不按微批次数平均。 |
| 全部梯度 | [P]（概念上展平） | 全局范数横跨所有被裁剪参数。 |

## 完整代码与精读

```python
import copy
import torch
from torch import nn

torch.manual_seed(29)
# STEP 1: 固定模型和数据，两个模型从相同参数开始
model = nn.Linear(3, 2).double()
reference = copy.deepcopy(model)
x = torch.randn(7, 3, dtype=torch.float64)
y = torch.randn(7, 2, dtype=torch.float64)
valid = torch.tensor([[1,1],[1,0],[0,1],[1,1],[0,0],[1,0],[1,1]], dtype=torch.bool)
total = int(valid.sum())
windows = [slice(0, 3), slice(3, 5), slice(5, 7)]
opt = torch.optim.SGD(model.parameters(), lr=0.1)
ref_opt = torch.optim.SGD(reference.parameters(), lr=0.1)

# STEP 2: 每个微批次都除以整个窗口的有效元素总数
ref_opt.zero_grad(set_to_none=True)
full_loss = (reference(x) - y).square()[valid].sum() / total
full_loss.backward()
opt.zero_grad(set_to_none=True)
for part in windows:
    errors = (model(x[part]) - y[part]).square()
    local_loss = errors[valid[part]].sum() / total
    local_loss.backward()
for p, q in zip(model.parameters(), reference.parameters()):
    torch.testing.assert_close(p.grad, q.grad, atol=1e-12, rtol=1e-12)

# STEP 3: 累积结束再裁剪和更新，比较最终参数
norm = nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.3)
ref_norm = nn.utils.clip_grad_norm_(reference.parameters(), max_norm=0.3)
torch.testing.assert_close(norm, ref_norm)
opt.step()
ref_opt.step()
for p, q in zip(model.parameters(), reference.parameters()):
    torch.testing.assert_close(p, q, atol=1e-12, rtol=1e-12)
print('各微批次有效元素:', [int(valid[s].sum()) for s in windows])
print('总有效元素:', total, '裁剪前范数:', round(norm.item(), 6))
print('通过：累积梯度和更新后的参数均与完整批次一致')

```

- 第 1–16 行：使用 float64 降低求和次序带来的误差，且不引入 BatchNorm、Dropout。三个微批次的有效元素数分别是 4、2、3。
- 第 17–28 行：完整批次和每个微批次共用分母 total=9。zero_grad 只在窗口开始调用；逐参数核对尚未裁剪的梯度。
- 第 29–39 行：clip_grad_norm_ 返回裁剪前范数。两个模型都只更新一次，再检查所有参数相等；这验证了训练行为而不只是损失数字。

预期观察：输出有效元素 [4, 2, 3]、总数 9；梯度及一次 SGD 更新的等价性断言全部通过。

## 浏览器 Python 练习

grads[k] 是第 k 个微批次已经按有效元素平均的梯度向量，counts[k] 是其有效元素数。实现 weighted_gradient，返回全局有效元素等权的梯度。counts 为非负整数；总数为零或输入长度、向量宽度不一致时抛出 ValueError。

```python
def weighted_gradient(grads, counts):
     # TODO: 恢复各微批次梯度总和，再按全局有效数平均
     raise NotImplementedError('请实现 weighted_gradient')

```

### 提示

- 先乘 counts，恢复每组梯度的有效元素总和。
- 分母是 sum(counts)，不是 len(grads)；零计数组不贡献梯度。

### 参考实现与解释

```python
def weighted_gradient(grads, counts):
     if not grads or len(grads) != len(counts):
         raise ValueError('长度不一致或无微批次')
     width = len(grads[0])
     if width == 0 or any(len(g) != width for g in grads):
         raise ValueError('梯度宽度不一致')
     if any(not isinstance(n, int) or n < 0 for n in counts):
         raise ValueError('计数应为非负整数')
     total = sum(counts)
     if total == 0:
         raise ValueError('没有有效元素')
     return [sum(g[d] * n for g, n in zip(grads, counts)) / total
             for d in range(width)]

```

梯度可按求和线性组合，但不同微批次 mean 的权重由其真实分母决定。本题将梯度视为已给定的有限向量，只练习统计权重；真实训练需保证这些梯度在同一组参数上计算。

### 断言测试

```python
assert weighted_gradient([[2, 4], [8, -2]], [3, 1]) == [3.5, 2.5]
assert weighted_gradient([[999, 999], [4, -6]], [0, 2]) == [4, -6]
assert weighted_gradient([[1], [7], [4]], [2, 1, 3]) == [3.5]
for gs, ns in [([[1]], [0]), ([[1], [2, 3]], [1, 1]), ([[1]], [-1]), ([[1]], [])]:
    try:
        weighted_gradient(gs, ns)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝无效计数或形状')
print('通过：不等计数、零权重和输入边界')

```

## 本地 PyTorch 练习

实现 accumulate_gradients(model, microbatches)。microbatches 是非空列表，每项为 (x, y, valid)，其中 y 和布尔 valid 同形状且数值有限。仅在 valid 为 True 的标量上计算全局 MSE，累积到 model 参数 .grad，返回总有效数；不更新参数。即使某一微批次没有有效元素也要正确处理；总有效数为零时抛出 ValueError。

```python
import torch

def accumulate_gradients(model, microbatches):
    # TODO: 窗口开始清零，各微批次 sum 除以全局有效数
    raise NotImplementedError('请实现 accumulate_gradients')

```

### 提示

- 先遍历列表得到全部 valid.sum()，再开始反传。
- 对空索引结果做 sum 仍可得到带计算图的零损失；不能在每个循环里清零。

### 参考实现与解释

```python
import torch

def accumulate_gradients(model, microbatches):
    total = sum(int(valid.sum()) for _, _, valid in microbatches)
    if total == 0:
        raise ValueError('没有有效元素')
    model.zero_grad(set_to_none=True)
    for x, y, valid in microbatches:
        error = (model(x) - y).square()
        (error[valid].sum() / total).backward()
    return total

```

测试故意包含有效数为 1、0、3 的微批次，能识别平均每组 mean 或最后一组覆盖前面梯度的错误。函数只写梯度，参数更新和裁剪由调用方在窗口结束后执行；输入中的 NaN 仍需在进入误差运算前处理。

### 断言测试

```python
import copy
torch.manual_seed(290)
model = torch.nn.Linear(2, 1).double()
reference = copy.deepcopy(model)
x = torch.randn(6, 2, dtype=torch.float64)
y = torch.randn(6, 1, dtype=torch.float64)
valid = torch.tensor([[1], [0], [0], [1], [1], [1]], dtype=torch.bool)
parts = [slice(0, 1), slice(1, 3), slice(3, 6)]
batches = [(x[s], y[s], valid[s]) for s in parts]
before = [p.detach().clone() for p in model.parameters()]
assert accumulate_gradients(model, batches) == 4
((reference(x) - y).square()[valid].mean()).backward()
for p, q, old in zip(model.parameters(), reference.parameters(), before):
    torch.testing.assert_close(p.grad, q.grad, atol=1e-12, rtol=1e-12)
    torch.testing.assert_close(p, old)
try:
    accumulate_gradients(model, [(x, y, torch.zeros_like(valid))])
except ValueError:
    pass
else:
    raise AssertionError('应拒绝全无效窗口')
print('PyTorch 通过：不等微批次与零有效微批次的累积')

```

## 练习：推导与分析

### 为什么 loss / accumulation_steps 有时仍然算错？

该写法默认窗口内各微批次 mean 的统计分母相同。如果有效动作数分别为 4、2、3，直接平均三个 mean 会让第二组的单个元素权重更大。

演示每个微批次使用 errors[valid].sum()/total，且 total=9。检查完整批次梯度能定位权重问题；存在 BatchNorm 或不同随机前向时，还要区分数学平均错误和模型本身的批次依赖。

还需保持窗口内参数不变。\(L_1=\frac12(\theta-1)^2\) 与 \(L_2=\frac12(\theta+1)^2\) 在 \(\theta=0\) 的平均梯度为零，逐微批更新却会产生与顺序有关的非零结果。对 BatchNorm、对比学习中跨样本目标或随机前向，还要分别检查是否真的对应同一个完整批次函数。

代码定位：演示 STEP 2；accumulate_gradients 的 total 与 backward。

- 能为不等有效数写出正确分母。
- 能指出累积与完整批次等价所需的参数、模型条件。

### 为什么必须在累积完成后裁剪？能否把裁剪阈值当作参数位移上限？

裁剪函数不是线性的，\(\operatorname{clip}(g_1)+\operatorname{clip}(g_2)\) 通常不等于 \(\operatorname{clip}(g_1+g_2)\)。先汇总才能根据本次训练目标的完整梯度决定统一缩放比例。

演示在两个模型的全部梯度核对后才调用 clip_grad_norm_。对于无额外项的普通 SGD，位移与学习率乘裁剪后梯度相关；Adam 的预条件、动量或权重衰减会改变这个关系，阈值不能直接解释为最终参数位移。

代码定位：演示 STEP 3；clip_grad_norm_ 的返回值是裁剪前范数。

- 能说明逐微批次裁剪为何改变结果。
- 能区分梯度范数和优化器实际参数位移。

## 练习：辨析与纠错

### 每次 backward 前都 zero_grad

这只保留最后一个微批梯度。明确一个周期的起止，周期前清零、周期末一次更新。

### 不等有效长度仍固定 loss/K

这会让微批等权而非有效元素等权。累计真实有效数，以完整目标分母缩放每一块。

### 逐微批裁剪或提前 unscale

裁剪非线性，提前还原还会混合不同梯度单位。全部累积完成后，再统一还原和裁剪。

### 只比较 loss 就宣称等价

需对照逐参数梯度、一次更新和优化器状态；同时排除 BatchNorm、随机采样和批内交互的差异。

## 原始资料

- [PyTorch：AMP 梯度累积与裁剪](https://docs.pytorch.org/docs/stable/notes/amp_examples.html)
- [PyTorch：clip_grad_norm_](https://docs.pytorch.org/docs/stable/generated/torch.nn.utils.clip_grad_norm_.html)
