# 训练循环与指标归约

梯度更新、有效分母、混合精度与评估统计。

训练循环是反复用一批数据计算预测与损失、求出梯度并更新参数的过程。参数定义当前模型，梯度提供本轮更新信息，优化器保存历史更新状态；验证与日志另行衡量结果。本章沿同一个 4→2 回归项目认识这一完整流程，再加入变长数据、累积、混合精度和 checkpoint，检验组合后是否仍优化同一个目标。

## 学习目标

- 独立实现清零、前向、反向和更新的完整循环。
- 按正确分母汇总训练与验证误差。
- 检查参数实际更新、梯度有限和验证模式是否正确。

前置知识：[PyTorch 模块、参数与状态](https://wxb1870.github.io/embodied-ml-lab/learn/modules/) · [数据采样与批处理](https://wxb1870.github.io/embodied-ml-lab/learn/dataloader/) · [梯度下降、动量与 AdamW](https://wxb1870.github.io/embodied-ml-lab/learn/optimization/) · [损失、掩码与归约](https://wxb1870.github.io/embodied-ml-lab/learn/losses/)

## 参数、梯度与优化器状态

模型参数是当前函数的可学习数值，梯度是损失对它们的局部变化率，优化器状态是更新规则保存的历史信息。一次训练步先计算前两者的关系，再使用后者改变参数。把这些对象分开，才能追踪更新顺序。





训练模式是另一类状态：model.train() 影响 Dropout、BN 等模块，不等于开启梯度开关；eval 下也可以构建图。普通每 Batch 更新一次时，应在该更新的梯度累积开始前 zero_grad。清零可以放在上一轮更新后或当前轮反向前，只要边界一致；但把 zero_grad 放在 backward 与 step 之间会直接擦掉这次更新所需的梯度。





后面保留原有短训练循环，并在代码页提供一个贯穿多课的[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)。模型仍是 Linear(4,2)，任务仍是双输出合成回归；新增的只是变长记录、有效位与状态管理。只在训练集拟合输入和目标统计，参数与统计共同定义模型函数。数据集有 44 条独立生成的序列，前 32 条训练、后 12 条验证，每条长度为 1…5；它用于排除工程错误，不代表机器人数据的时间相关性或闭环难度。





![共同训练项目中样本、有效误差、累积窗口、参数更新和 epoch 边界恢复的状态时间线](../assets/figures/training-state-lifecycle.svg)

原创数据与状态图，函数名对应同一份 shared-training-project。两个微批次的有效标量数为 10 和 30，因此每一项反向都使用共同分母 40；保存点在完整 epoch 结束，恢复校验覆盖下一整轮。



### 先说明一次 step 对应哪些数据

梯度清零、归约分母、累积窗口和学习率调度的单位都应与一次实际参数更新对应。

记录 update_step、微批次数、有效元素数与学习率，用一个可手算的小模型核对两次更新。

## 损失分子、分母与样本权重

损失归约将各有效预测的误差合成标量，分子计入误差贡献，分母定义等权单位。样本平均与元素平均通常是不同目标。下面在同一变长项目中从这份定义推到日志和反向。





逐元素 MSE 可以先得到误差张量，再把有效平方误差和除以有效标量数。这里的平均不是仅用于日志的格式，而是实际缩放梯度；改分母相当于改变优化力度或样本权重。不同样本长度不一时，先算每个样本的均值再平均，会让短样本与长样本等权；直接对全体有效元素平均，则每个元素等权。两种目标都可有用途，但不能在不知情时混用。





令样本 \(b\) 的有效标量数为 \(n_b>0\)、有效平方误差和为 \(S_b\)。样本等权目标为 \(B^{-1}\sum_b S_b/n_b\)，元素等权目标为 \(\sum_bS_b/\sum_bn_b\)。若一条样本只有一个有效元素、误差和为 9，另一条有三个有效元素、误差和为 3，两种损失分别是 \((9+1)/2=5\) 与 \(12/4=3\)。第一种目标中，短样本每个平方误差项的系数是长样本的三倍；反传到残差时还要乘该元素残差的二倍。第二种目标对四个平方误差项使用相同系数。分母选择表达了任务偏好，不能仅凭哪一个损失数值更小决定。





对固定有效分母，梯度可按微批次误差和累积后整体缩放；若每个微批次先局部 mean，再除以固定累积次数，只在相应分母相等时等价。空监督批次、最后一个较短窗口、多进程平均都会影响这一点。不要只把日志改成全局平均，而反向仍优化各微批次等权目标。先写出数学目标，再把 reduction、mask.sum 与更新边界逐行对应。





在共同项目的七条样本中，有效长度为 1、4、2、5、3、1、4，每步两个输出，共 40 个有效标量。前两条组成第一个微批次，分母为 10；余下五条的分母为 30。项目使用 \((S_1+S_2)/40\)，其中 \(S_i\) 是该微批次的有效平方误差和。若误写成 \((S_1/10+S_2/30)/2\)，第一组每个误差项的系数为 1/20，第二组为 1/60；目标已经变成微批次等权，而非有效元素等权。`verify_accumulation` 比较全部参数梯度与更新结果。





$$
L(\theta)=\frac{\sum_i\ell_i(\theta)}{N_{\mathrm{valid}}},\qquad \nabla_\theta L=\frac{\sum_i\nabla_\theta\ell_i}{N_{\mathrm{valid}}}
$$





## 连续更新与梯度累积

梯度清零移除上次留下的求导结果，梯度累积则有意将多次反向合成一次更新。两者都操作 .grad，却服务于不同更新边界。下面先跟踪连续两步，再区分有意累积与意外残留。





只有一次参数更新的测试不够：初始 .grad 为空，即使漏掉清零，第一步仍可能完全正确。第二次调用时旧梯度会参与累加，才暴露与预期不符的更新。对线性 \(y=wx\)、单点 \(x=1\)、目标 2 的 MSE，梯度为 \(2(w-2)\)，使用无动量 SGD 可以直接算出每一步。这样的测试既能验证 backward/step 顺序，也能区分返回的是更新前还是更新后的损失。





记录参数快照时要 clone，保存的梯度也要避免被后续原地清零覆盖。把 loss.item() 或 float(loss.detach()) 用于日志，原始 loss Tensor 仍用于 backward；若先把训练目标转成 Python 数字再包装成新 Tensor，图已断开。set_to_none=True 与将 grad 填零在某些优化器行为和内存上并不完全相同，故测试应关注预期更新而不只检查 grad 的外观。







### 例：w=0 开始的两次 SGD

1. 第一次 \(L=(0-2)^2=4\)，梯度 −4，学习率 0.1 后 w=0.4。

2. 第二次清零后梯度为 2×(0.4−2)=−3.2，更新为 w=0.72，更新前 loss=2.56。

3. 若忘记清零，第二步使用 −4−3.2=−7.2，w 会变成 1.12。

第二步才能排除“首次碰巧正确”的实现。

## 有限性、裁剪与混合精度

有限性检查判断数值能否继续作为合法更新，裁剪限制梯度幅度，混合精度与损失缩放控制数值表示。这些步骤共同作用于一次更新，但不能互相修复所有问题。先定义各自对象，再安排执行顺序。





梯度裁剪按总体范数缩放梯度，常用于限制异常大的一步，而不是修复已经产生的 NaN。应先找到非有限 loss 或梯度出现的位置，检查输入、目标、归约和数值范围。clip_grad_norm_ 返回裁剪前的总范数，可用于记录；若所有梯度都被严重裁剪，可能是目标尺度、学习率或上游结构问题，不能仅因训练没有崩溃就认为配置合理。





使用 FP16 GradScaler 时，先对缩放后的 loss 反向，完成当前累积窗口后 unscale，再裁剪真实梯度，最后 scaler.step 和 update。若在 unscale 前裁剪，阈值作用于被人为放大的梯度，实际更新不再符合预期。溢出可能使参数更新被跳过，此时调度器和日志应区分尝试的 Batch 与真正完成的 update。普通精度教学循环与 AMP 路径的状态不同，迁移时必须重新核对顺序。





共同项目中的 `verify_cpu_amp` 从相同初值、相同输入和同一有效目标出发，只将 Linear 的计算切换为 CPU BF16 autocast。模型参数与 .grad 保持 FP32，先选择有效预测，再转为 FP32，随后计算平方误差与归约；随后真正执行一次混合精度更新。这里没有 FP16 GradScaler 的缩放路径，也没有 GPU 性能测量；CUDA FP16 的动态缩放顺序仍应按[混合精度](#/learn/mixed-precision)的接口另行验证。









### 裁剪缩放梯度会改变实际阈值

GradScaler 的比例只是数值管理工具，不应进入期望的梯度范数约束。

先核对 unscale→clip→step 顺序，并分别记录原始有限性、真实梯度范数及本步是否实际更新。

## 验证模式与指标聚合

验证是在不用于当前参数更新的保留数据上估计模型表现。评估模式决定前向行为，梯度开关决定是否记录图，指标聚合决定统计对象。三者都需要与声明的验证问题一致。





验证通常需要 eval 与 no_grad：前者切换随机/统计行为，后者避免构建不需要的反向图。运行结束后恢复正确模式；若模型有冻结 eval 骨干与训练态新模块，恢复一个根布尔值不一定足够，应重设混合模式配置。验证集不能参与参数更新、标准化统计拟合或阈值反复调优后仍被当作最终独立测试；评价的角色要事先定义。





多个 Batch 的均值不能直接再平均，除非它们包含相同权重的有效元素。正确做法通常累计误差和、有效数，最后相除；多进程时对分子分母分别汇总。最后一个小 Batch、变长序列和缺失监督都会让这个差异变大。训练日志也应注明是更新前当前模型的批次目标，还是固定模型在整套数据上的重算指标，二者不能直接当作完全相同的统计量比较。





项目的 32 条训练序列合计 95 个有效时间步、190 个输出标量。batch_size=5 且 drop_last=False 得到 7 个微批次，最后一批只有 2 条样本；两个微批次一组累积，形成 4 次 optimizer update。训练日志的分子来自各次更新前的模型，验证则将模型固定后遍历独立数据。两者都使用有效分母，但并不是同一组参数点上的相同风险，不能仅比较两个数字大小来断言出现过拟合。







### 例：两个不等长 Batch 的整体 MSE

1. Batch A 有 9 个有效元素，MSE=1，平方误差和为 9。

2. Batch B 有 1 个元素，MSE=9，平方误差和为 9。

3. 整体 MSE=(9+9)/(9+1)=1.8；直接平均两项 mean 会得到 5。

指标聚合也属于目标定义，不能只图代码简短。

## 调度器与更新计数

调度器按训练进度改变学习率，更新计数记录参数实际改变的次数。微批、数据批次、epoch 与优化更新不总是一一对应。先固定进度单位，再定义调度调用和恢复位置。





学习率计划可能按 epoch、Batch、token 数或 optimizer update 变化，调用频率必须与定义一致。启用梯度累积后仍每个微批次调用按 update 设计的 scheduler，会让计划提前走完。恢复训练时若只载入权重而步数归零，也会重新经历另一段学习率过程。使用依赖验证指标的调度器时，输入应是相同口径的指标，而不是任意一次训练 Batch loss。





日志长期持有带图 Tensor 会保留激活并增加显存；累计量应 detach 或转换成普通数值，但反向目标要保留图。每次 .item() 也可能触发设备同步，实际大训练需权衡日志频率而非在每个中间量都同步。保存 checkpoint 应选明确的更新边界，记录是否已完成 scheduler、scaler 和数据进度更新，避免恢复后重复或跳过一个阶段。工程细节会影响可复现的数学过程。









## 小样本过拟合与管线检查

固定小批次过拟合是反复拟合少量已知样本、检查训练链路是否具备基本学习能力的诊断实验。它用简单可控任务排查实现，不评价未见数据泛化。下面说明通过和失败分别支持什么结论。





固定少量数据、随机种子、增强与目标，模型应有机会拟合一个设计合理的简单任务。若完全拟合不了，依次检查目标与输入对齐、参数是否属于优化器、梯度是否有限、输出参数化是否允许目标、以及归一化与损失尺度。这个实验可迅速发现断图、错误标签或恒定输出，但不能直接证明真实任务数据足够、模型选择正确或部署会成功。





训练损失降低而验证不变，可能来自过拟合、划分差异、分布变化或指标不匹配；损失与任务成功率的关系也依赖输出后处理和闭环执行。记录按维度、任务、长度和时间段分组的误差，比只看总 loss 更有诊断价值。建立固定预算和只改变一个因素的对照，先明确希望证伪哪个假设，再决定是否扩大模型、增加数据或调整学习率。





先运行共同项目的 `verify_masks`：把无效输入改成零或 NaN，预测与有效 loss 应保持不变，Padding 的输入梯度严格为零；把有效标签改成 NaN，则必须被拒绝。再运行 `verify_optimizer_diagnosis`，只把 bias 从优化器移除，bias 仍有非零梯度但实际位移为零。它把“图连接成立”和“参数由优化器更新”分成两种证据。更广泛的推理式排查见[训练诊断](#/learn/training-diagnostics)，不在每个训练脚本中另造一个网络。









### 训练曲线是结果，诊断需要可分辨的假设

多个错误都能产生“loss 不降”或“验证变差”。单看曲线不能判断原因。

保留固定探针，依次检验标签对齐、梯度、参数变化、模型模式和分组指标，每次只改变一个因素。

## 共同项目中的函数与更新顺序

完整更新顺序是将数据、求导、同步、参数变化与状态保存排列在同一时间线上的协议。共同项目把这些职责放在可追踪的函数中，使局部 API 能被放回一个训练过程理解。





框架可能把 autocast、反向、梯度同步、裁剪、优化器、调度器和保存拆到不同回调。阅读时按一次真正的参数更新重建时间线，标出哪里清零、哪里累积、哪里同步、哪里改变状态。若修改一个 Hook，确认它在多个 Worker、rank 或累积步中的调用次数。将配置文件中的“batch size”换算成实际有效监督量，才能理解学习率和训练预算。





合成回归示例检查普通精度训练循环，以及最后一个 Batch 较小时的指标聚合。输入、预测、标量损失、梯度和参数更新构成完整的一步；框架增加分布式与回调后，这些状态的更新顺序仍须与数学目标一致。





阅读[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)时，可先执行 main，再沿下表回看函数。原有独立短例和练习继续隔离单项机制；共同项目负责验证这些机制组合后仍一致。其 checkpoint 在第 3 个 epoch 结束、第 12 次 optimizer update 后保存，下一 epoch 到第 16 次更新；恢复分支不只检查载入权重，还逐项对照下一整轮的样本顺序、统计量、模型、优化器及调度器。





训练循环把数据、函数、目标、导数和更新连接起来。累积、精度、调度与恢复都是这条过程的具体组织；每项加入以后，都应仍能说明参数因哪份数据、按哪个目标发生了一次什么更新。







### 一份实现连接多门训练工程课程

| 函数或状态 | 解决的问题 | 对应课程 |

|---|---|---|

| ToyEpisodes / collate_episodes | 样本边界、NaN Padding 与 valid | Dataset 与 DataLoader |

| fit_statistics / TokenRegressor | 训练统计、参数注册与 Buffer | 数值稳定性 / 模块管理 |

| masked_error_sum | 先选有效值；误差和与有效标量数 | Loss 与 Mask |

| train_window / verify_accumulation | 共同分母、只裁剪一次、短尾窗 | 梯度累积 |

| verify_cpu_amp | 同初值下的 dtype、梯度误差和真实更新 | 混合精度 |

| verify_masks / verify_optimizer_diagnosis | 从数据有效性到 optimizer 成员定位 | 训练诊断 |

| save_training / main 恢复分支 | epoch 边界、数据生成器和全部优化状态 | 保存与恢复训练状态 |



## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 输入 Batch | [B,4] | 合成状态特征。 |
| 预测 / 目标 | [B,2] | 两个通用连续输出，按标量元素汇总均方误差。 |
| 损失 | [] | 用于 backward 的标量。 |
| 日志累计量 | 误差和、元素数 | 保持分母一致，兼容最后一个小 Batch。 |

## 完整代码与精读

```python
# [1] 独立的合成训练集与验证集
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
torch.manual_seed(19)
true_weight = torch.randn(4, 2)
x = torch.randn(173, 4)
y = x @ true_weight + 0.2 + 0.01 * torch.randn(173, 2)
train_loader = DataLoader(TensorDataset(x[:128], y[:128]),
                          batch_size=24, shuffle=True, num_workers=0)
val_loader = DataLoader(TensorDataset(x[128:], y[128:]),
                        batch_size=16, shuffle=False, num_workers=0)
model = nn.Linear(4, 2)
optimizer = torch.optim.AdamW(model.parameters(), lr=0.03, weight_decay=0)

# [2] 按元素总数汇总，保存并恢复模型原来的模式
def evaluate(model, loader):
    was_training = model.training
    model.eval()
    error_sum, count = 0.0, 0
    with torch.no_grad():
        for inputs, targets in loader:
            errors = (model(inputs) - targets).square()
            error_sum += errors.sum().item()
            count += errors.numel()
    model.train(was_training)
    return error_sum / count

# [3] 清零、前向、反向、有限性检查、裁剪、更新
for epoch in range(80):
    model.train()
    train_sum, train_count = 0.0, 0
    for inputs, targets in train_loader:
        optimizer.zero_grad(set_to_none=True)
        errors = (model(inputs) - targets).square()
        loss = errors.mean()
        assert torch.isfinite(loss), "发现非有限 loss"
        loss.backward()
        grad_norm = nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
        assert torch.isfinite(grad_norm), "发现非有限梯度"
        optimizer.step()
        train_sum += errors.detach().sum().item()
        train_count += errors.numel()
    if epoch in (0, 19, 79):
        print(epoch, "train MSE", round(train_sum/train_count, 6),
              "val MSE", round(evaluate(model, val_loader), 6))
assert evaluate(model, val_loader) < 0.01
print("训练循环与验证检查通过")

```

- 第 1–15 行：学习四个输入特征到两个连续输出的合成映射；训练与验证样本独立，最后一个 Batch 故意较小，用来暴露错误平均口径。
- 第 16–28 行：eval 与 no_grad 分别控制模块行为和图记录。本例仅有 Linear，恢复根模式即可；混合冻结子模块时还需恢复各自模式。
- 第 29–48 行：clip_grad_norm_ 返回裁剪前的范数。这个教学循环采用普通精度，每个 Batch 更新一次。

预期观察：训练与验证 MSE 逐步降低；最终验证 MSE 小于 0.01，并打印通过。确切小数可能随 PyTorch 版本略有差异。

### 共同训练项目：从有效样本到累积、精度与完整恢复

复用本课 4→2 线性回归，将 Dataset、DataLoader、有效 Loss、梯度累积、CPU BF16、诊断和 checkpoint 放进一个可执行程序；其他工程课程链接这里的同一函数。

[完整可运行代码](../demos/training-loop/shared-training-project.py)

- 第 1–18 行：仅需 PyTorch，固定 CPU 单线程；数据生成、模型初始化、采样使用明确种子。此项目学习工程状态，不作为机器人策略。
- 第 19–60 行：Dataset 保存完整的变长 episode；collate 用真实长度构造 Mask 并填 NaN。归一化统计仅在 32 条训练 episode 上拟合，验证切分不参与。
- 第 61–96 行：仍是主例的 Linear(4,2)。统计注册为 Buffer；先清理无效输入，再做线性变换；对有效标签先选择后运算，归约返回分子与真实标量分母。
- 第 97–156 行：一个累积窗口先得到总分母，全部微批次反向后才裁剪和 step。DataLoader 的最后两个样本保留，最后单微批窗口仍更新。验证使用误差和/有效数，而非批均值的均值。
- 第 157–187 行：完整七条样本与 2+5 条样本组成的两个微批次，从相同初值比较梯度及 SGD 更新。错误控制组局部取 mean，展示有效长度不等时如何改变梯度。
- 第 188–214 行：只切换 CPU BF16 autocast；检查输出、参数、梯度和损失 dtype，测量相对差异，并实际执行 AMP 参数更新。不包含 CUDA FP16 运行证据。
- 第 215–254 行：验证无效 NaN 输入的梯度为零、有效 NaN 标签被拒绝；故意遗漏 bias 的优化器控制组有梯度但零位移，用同一模型定位不同故障。
- 第 255–279 行：将模型、优化器、调度器、CPU RNG 与 DataLoader generator 序列化成独立快照。保存点限定为 epoch 结束；递归对照下一轮的指标与样本顺序，以及模型、优化器和调度器状态。
- 第 280–350 行：同一数据和模型依次完成验证、三轮训练、保存、下一整轮恢复对照及继续训练。固定合成验证误差降低只证明本例优化链路，不证明真实策略泛化。

预期观察：所有断言通过：微批有效分母为 10 与 30，正确累积与 full batch 的梯度及 SGD 更新在 float64 容差内一致；局部 mean 控制组产生不同梯度。CPU BF16 输出、FP32 参数/梯度和 FP32 归约得到核验，并实际更新参数。epoch 边界恢复后的下一整轮样本顺序、指标、模型和优化状态完全一致。程序打印本次环境与误差；CUDA AMP 未运行，真实 DDP 仍标为 environment_blocked。

## 浏览器 Python 练习

输入 batch_stats 中每项为 (平方误差总和, 有效元素数)。实现 aggregate_mse；总有效元素数为零时抛出 ValueError。

```python
def aggregate_mse(batch_stats):
    # TODO: 汇总分子与分母，最后再相除
    raise NotImplementedError("请实现 MSE 汇总")

```

### 提示

- 不要先算每个 Batch 的平均再取普通平均。
- 最后一个 Batch 可能更小；用真实有效元素数作为权重。

### 参考实现与解释

```python
def aggregate_mse(batch_stats):
    error_sum = sum(item[0] for item in batch_stats)
    count = sum(item[1] for item in batch_stats)
    if count <= 0:
        raise ValueError("没有有效元素")
    return error_sum / count

```

第二个测试的正确结果为 18/10=1.8。两个 Batch 均值的简单平均会得到错误的 5.0。

### 断言测试

```python
assert aggregate_mse([(4.0, 2), (0.0, 2)]) == 1.0
assert abs(aggregate_mse([(9.0, 9), (9.0, 1)])-1.8) < 1e-12
assert aggregate_mse([(0.0, 0), (6.0, 3)]) == 2.0
try:
    aggregate_mse([(0.0, 0)])
    raise AssertionError("没有有效元素时不能给出正常指标")
except ValueError:
    pass
print("通过：按有效元素加权，避免 Batch 均值再平均")

```

## 本地 PyTorch 练习

实现 train_step：切换训练模式、清零梯度、计算 MSE、反向、更新，并返回更新前 loss 的 Python float。不使用梯度累积。

```python
import torch

def train_step(model, optimizer, x, y):
    # TODO: 完成一次普通精度参数更新
    raise NotImplementedError("请实现训练步骤")

```

### 提示

- 先 model.train() 和 zero_grad，再计算当前 MSE，随后 backward 与 step。
- 返回的是更新前计算的 loss 数值，使用 detach 转成 float，避免返回带图的历史日志。
- 第二次调用必须清理上次梯度，否则权重不会从 0.4 更新到 0.72。

### 参考实现与解释

```python
import torch

def train_step(model, optimizer, x, y):
    model.train()
    optimizer.zero_grad(set_to_none=True)
    loss = (model(x) - y).square().mean()
    loss.backward()
    optimizer.step()
    return float(loss.detach())

```

单参数线性例子可以手算：初始 w=0、目标2，梯度−4，学习率0.1 后 w=0.4；下一次梯度−3.2，得到 w=0.72。这个两步检查同时检验清零、反向和更新顺序，避免仅凭第一次运行产生变化就判断实现正确。

### 断言测试

```python
model = torch.nn.Linear(1, 1, bias=False)
with torch.no_grad():
    model.weight.zero_()
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
model.eval()
x, y = torch.tensor([[1.]]), torch.tensor([[2.]])
first = train_step(model, optimizer, x, y)
assert abs(first-4.0) < 1e-6 and model.training
torch.testing.assert_close(model.weight, torch.tensor([[0.4]]))
second = train_step(model, optimizer, x, y)
assert abs(second-2.56) < 1e-5
torch.testing.assert_close(model.weight, torch.tensor([[0.72]]))
print("通过：反向、参数更新、清零梯度与训练模式")

```

## 练习：推导与分析

### zero_grad、backward 和 step 分别改变什么？为什么连续两次调用的测试比只测试一次更能发现错误？

zero_grad 清理参数梯度，backward 沿当前计算图计算并累积梯度，step 使用优化器规则和内部状态更新参数。三者负责不同状态，不能互相替代。

第一次调用前梯度可能本来为空，即使漏掉清零也看不出来。第二次会把旧梯度一起带入，导致更新幅度错误。用可手算的单参数例子比较两步结果，可以明确定位梯度累积是否符合设计。

代码定位：检查第二次更新前 grad 是否被清理，并对照 w=0→0.4→0.72。

- 区分梯度状态与参数状态。
- 说明两步测试如何暴露意外累积。

### 训练与验证时分别怎样处理模型模式和日志？为什么不应把所有 batch loss Tensor 长期相加？

训练使用适当的 train 模式，验证通常同时使用 eval 与 no_grad，完成后恢复原模式；冻结骨干若需要固定行为，还应检查递归模式切换。指标应累计误差和与真实有效分母。

带计算图的 loss Tensor 若持续被历史容器引用，可能保留不再需要的图。日志应转成 detach 后的数值，同时保留当前用于 backward 的原始 loss，不能为了日志简单把训练目标本身提前切断。

代码定位：查看 evaluate 的模式恢复与 train_sum 中 errors.detach().sum().item() 的位置。

- 区分 eval 与 no_grad。
- 说明日志 detach 与训练目标梯度的边界。

## 练习：辨析与纠错

### backward 后立刻 zero_grad 再 step

这会擦掉当前更新所需的梯度。按更新边界安排清零，并用两步 SGD 例子检查数值。

### 直接平均不同 Batch 的均值

不同有效分母使整体指标失真。累计误差和及有效元素数，最终一次相除。

### 为记录 loss 提前将训练目标转成普通数字

会切断原计算图。用于 backward 的 loss 保持 Tensor，日志另取 detach 后的数值。

### 验证后只恢复根模式，忽略冻结子模块

混合 train/eval 配置可能被递归覆盖。用明确的模块策略恢复，而不是假设一个布尔值代表全部状态。

### 按微批次推进按 update 设计的学习率计划

梯度累积后计数单位改变。记录实际 optimizer update，并核对 scheduler 与保存恢复步数。

## 原始资料

- [PyTorch：Optimizing Model Parameters](https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html)
- [PyTorch：Autograd mechanics](https://docs.pytorch.org/docs/stable/notes/autograd.html)
- [PyTorch：clip_grad_norm_](https://docs.pytorch.org/docs/stable/generated/torch.nn.utils.clip_grad_norm_.html)
- [PyTorch：Automatic Mixed Precision examples，反缩放与裁剪](https://docs.pytorch.org/docs/stable/notes/amp_examples.html)
- [PyTorch：CPU autocast 与算子精度](https://docs.pytorch.org/docs/stable/amp.html)
- [PyTorch：DataLoader 与显式 generator](https://docs.pytorch.org/docs/stable/data.html)
- [PyTorch：复现范围与数据加载随机性](https://docs.pytorch.org/docs/stable/notes/randomness.html)
