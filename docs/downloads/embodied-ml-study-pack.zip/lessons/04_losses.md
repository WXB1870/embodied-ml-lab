# 损失、掩码与归约

把“模型应该关注什么”写成可核对的分子和分母。

损失函数是将预测结果与目标之间的偏差变成数值代价的函数，训练通过降低它来调整参数。实际优化的标量还由有效位置、样本权重和归约规则共同组成，因此“使用 MSE”并未完整定义训练目标。本章从单个误差的代价出发，逐步构造带掩码和权重的标量，再将它连接到反向梯度和日志统计。

## 学习目标

- 根据目标与异常值特征选择基础损失
- 正确处理 Padding、无效动作维度和加权归约
- 检查不同长度、不同单位的数据对训练的贡献

前置知识：[张量与广播](https://wxb1870.github.io/embodied-ml-lab/learn/tensor/) · [线性代数与矩阵求导](https://wxb1870.github.io/embodied-ml-lab/learn/matrix-grad/) · [概率、统计与训练目标](https://wxb1870.github.io/embodied-ml-lab/learn/probability/)

## 损失函数定义了模型优先减少哪一种错误

损失函数规定一种预测错误应付出多少代价；它的导数决定这份错误怎样推动参数更新。平方损失、绝对值损失等会对大小误差作不同处理。先定义什么误差有意义，再比较这些函数的前向代价与反向作用。





一个训练目标不仅包括误差公式，还包括数据采样、有效位、权重与归约。先考虑一维欧氏残差 \(e=\hat y-y\)：平方损失 \(e^2\) 的导数为 \(2e\)，因此误差越大，单个观测的局部作用越大；绝对值损失 \(|e|\) 在非零处的导数为 \(\operatorname{sign}(e)\)，幅度恰为 1。在零点，绝对值不可微，需要使用次梯度约定。不同损失对应不同的优化对象，不能仅比较显示数值大小。





Huber 损失希望在零附近保留平滑二次结构，同时限制大残差的局部斜率。取阈值 \(\delta>0\)，小误差区使用 \(\tfrac12e^2\)；在 \(e=\delta\) 处，函数值为 \(\tfrac12\delta^2\)，斜率为 \(\delta\)。将大误差区接成具有同一值和斜率的直线，就得到 \(\delta(|e|-\tfrac12\delta)\)。其导数为 \(e\)（\(|e|\le\delta\)）或 \(\delta\operatorname{sign}(e)\)（\(|e|>\delta\)），边界两侧一致。所谓降低离群点作用，指这个残差导数不再随绝对误差无限增长，并非保证任何数据上都更准确。



### 例：同一阈值下，小误差与大误差如何影响梯度

1. 取 \(\delta=1\)，残差 \(e=0.5\) 位于二次区，损失为 \(0.5\times0.5^2=0.125\)，导数为 0.5。

2. 残差 \(e=2\) 位于线性区，损失为 \(2-0.5=1.5\)，导数为 1。

3. 若使用 \(e^2\)，这两个位置的导数分别为 1 和 4；改变的是相对影响与整体尺度，不只是损失名称。

损失的形状必须通过导数与训练作用连接起来，阈值还要与残差单位一致。

选择损失前还应定义误差空间。连续标量、类别、方向、角度和旋转并不共享同一种几何。对周期角直接做普通减法，接近负 π 与正 π 的两个等价方向可能被算成巨大误差；对离散开关用连续回归，也需要说明后处理阈值。这里讨论欧氏回归与分类的基础形式，其他表示应先定义合法误差再选择归约。





Huber 的 \(\delta\) 具有残差单位。把目标数值扩大 1000 倍，却保持同一个阈值，会让更多误差进入线性区，从而改变鲁棒目标。PyTorch 的 SmoothL1Loss 与 HuberLoss 在一般阈值下还差一个整体比例；更换 API 时应核对函数及导数，而不能只依据“平滑 L1”的名称判断二者相同。





$$
\ell_\delta(e)=\begin{cases}\tfrac12e^2,&|e|\le\delta,\\ \delta(|e|-\tfrac12\delta),&|e|>\delta,\end{cases}\qquad \ell_\delta^{\prime}(e)=\begin{cases}e,&|e|\le\delta,\\ \delta\operatorname{sign}(e),&|e|>\delta.\end{cases}
$$

```python
import torch
import torch.nn.functional as F

e = torch.tensor([-3., -1., -0.25, 0., 0.5, 1., 3.],
                 dtype=torch.float64, requires_grad=True)
delta = 1.0
manual = torch.where(e.abs() <= delta, 0.5 * e.square(),
                     delta * (e.abs() - 0.5 * delta))
official = F.huber_loss(e, torch.zeros_like(e), reduction="none", delta=delta)
torch.testing.assert_close(manual, official)
derivative = torch.autograd.grad(manual.sum(), e)[0]
torch.testing.assert_close(derivative, e.detach().clamp(-delta, delta))
print("残差:", e.detach().tolist())
print("Huber 导数:", derivative.tolist())

```

逐元素损失求和后再求导，能同时核对每个独立残差的斜率。测试包含零点、两个转折点和大残差，验证的是分段公式及边界连接；真实模型的参数梯度还要乘预测对参数的 Jacobian。





## 逐元素损失与最终标量必须分开理解

逐元素损失给每个预测位置一项代价，归约把这些代价合成训练所需的标量。按样本、时间步或标量元素平均，会给数据不同权重。下面从未归约张量出发明确等权单位，再计算最终分母。





先得到未归约误差 e:[B,H,D]，再明确是按有效标量、按时间步还是按样本等权。全有效 MSE 的 mean 对 \(BHD\) 个元素平均；先在 D 上求和、再对 B,H 求均值会大 D 倍。两者都可作为目标，但对应的学习率、多任务权重和日志解释不同，不能在中途无说明切换。





若长度不同，逐样本平均再求 Batch 平均，会给短序列中每个标量更大的权重；直接对全部有效标量平均，则长序列贡献更大。没有一种归约对所有任务都天然正确。需要用任务目的选择，并把同一约定贯穿训练、累积、分布式和验证指标。减小显示出来的 loss，不一定意味着每个样本的预测更好。





对固定且与参数无关的权重，\(L=\frac{\sum_i w_i e_i^2}{\sum_i w_i}\) 的预测梯度为 \(\frac{2w_i e_i}{\sum_j w_j}\)。由此可以构造直接的单元测试：无效或零权重位置梯度应为零，有效位置的梯度比例应符合权重与分母。若权重本身可学习，分母也可能产生梯度，固定权重的推导不再直接适用。





$$
L_{\rm element}=\frac{\sum_i n_iL_i}{\sum_i n_i},\qquad L_{\rm sample}=\frac1B\sum_iL_i
$$



### 例：两条不等长序列的平均

1. 序列 A 有 1 个有效标量，平方误差为 9；序列 B 有 3 个有效标量，误差都为 1。

2. 按样本等权得到 \(\frac{9+1}{2}=5\)。

3. 按有效标量等权得到 \(\frac{9+1+1+1}{4}=3\)。

两个结果分别优化不同的样本权重，必须先选目标再写 mean。

### 先保留 reduction="none" 看误差形状

逐元素误差是选择 Mask 和权重的基础；过早求 mean 会丢失重新归约所需信息。

打印一个极小 Batch 的误差、Mask、分子与分母，手算最终标量。

## Mask 的广播必须同时作用于分子与分母

有效位 Mask 是标记哪些标签应参与监督的布尔数组，不是一个新的误差函数。它选择损失分子中的项，也决定分母中计数的对象。广播会重复使用有效位，因此计数必须与实际参与的误差一致。





若有效时间 Mask 为 [B,H,1]，在乘 [B,H,D] 的误差时会广播 D 次。分子因此包含每个有效时间步的 D 个误差，分母也必须计数这 D 个标量。直接使用原 Mask.sum() 会只数时间步，使 loss 放大 D 倍。若每个机器人只有部分动作维度有效，则还要把时间 Mask 与维度 Mask 组合成实际有效集合。





零动作可以是正确标签，不能用 target!=0 推断有效性。Mask 应来自轨迹长度、标签可用性或任务协议，并与模型输入 Mask 区分。Loss Mask 只决定哪些输出受监督；无效输入仍可能通过注意力影响有效输出。因此“无效位置梯度为零”的局部损失性质，不等于整个跨位置模型已经对 Padding 不敏感。





$$
L=\frac{\sum_{bhd}m_{bhd}(\hat y_{bhd}-y_{bhd})^2}{\sum_{bhd}m_{bhd}}
$$



### 例：时间 Mask 不能直接作为标量分母

1. 有效时间步总数为 3，每步动作维数 D=2，各有效标量平方误差都为 1。

2. 广播后的分子为 6；正确分母为 6，loss=1。

3. 只用 [B,H,1] Mask 的 sum 得到分母 3，loss=2，所有有效输出梯度也放大 2 倍。

分母错误不仅影响日志，还改变实际参数更新。

### 广播后数了更多误差，却仍用广播前的计数

隐式广播不会替你更新手写分母。

将 Mask 显式 expand_as(error)，核对非零有效元素数及梯度的比例。

## 无效标签含 NaN 时，先安全选择再计算

NaN 表示未定义或无效的浮点结果，不是可以用零权重自动忽略的普通数。缺失标签应先用有效位选择，再进入减法和平方。这里说明为何事后掩码仍可能污染前向或反向，以及怎样先构造合法计算。





把无效位置的平方误差乘零不一定安全：如果 target 为 NaN，减法和平方已经产生 NaN，NaN×0 仍为 NaN。即使最后用 where 选掉这个输出，反向也可能经过无效局部导数。更稳妥的实现是在差值与平方之前，将无效预测和目标替换为有限值，或只选取有效元素计算，再保持所需的梯度路径。





整个批次没有有效监督时，应按训练协议明确拒绝或协调跳过。给分母加一个很小的 epsilon 产生零 loss，并不自动意味着“等价于没训练”：如果仍调用 step，动量、权重衰减和调度器可能继续变化。多进程下更不能单独让某个 rank 退出集合通信；要区分全局无监督与本地无监督，并按统一边界处理。









### epsilon 把空监督伪装成正常训练

空集合没有可用平均目标，优化器是否更新需要明确决定。

构造全 False Mask，检查返回策略、参数位移、step 计数与分布式同步约定。

## 样本权重、维度权重与归一化分母

损失权重是各误差项在总目标中的系数，用来表达样本、时间或维度的相对贡献。加权和与加权平均对整体尺度的处理不同；先声明权重的含义和归一化分母，才能解释它们怎样改变梯度。





加权平均常写为 \(\frac{\sum_i w_i\ell_i}{\sum_i w_i}\)，其中 \(w_i\ge0\)；另一种写法为 \(\frac1N\sum_i w_i\ell_i\)，它会让整体权重缩放改变目标大小。前者关心相对贡献，后者允许权重同时控制绝对梯度尺度。将所有权重乘 10 时两种目标行为不同，手写函数必须在题设里明确采用哪一种。权重为零不应让无效 NaN 进入前面的计算。





动作维度具有不同单位时，原始 MSE 不会自动公平。把一个量从米改成毫米，残差增大 1000 倍，平方项增大一百万倍。目标标准化可改善尺度，但等价于在原坐标下给各维不同权重；因此应同时报告标准化训练目标与物理单位误差。权重表达任务偏好之前，先检查单位、尺度和分母是否已经一致。





全体正权重同乘常数时，正规化加权平均应不变；只将某类样本权重增大时则应改变相对作用。这两组对照可以验证权重用于调整相对贡献，还是同时改变了整体梯度尺度。权重与有效位分开存储，也便于分清标签缺失和人为偏好。





上述权重通常被视为数据给定的常量。若 \(w_i=w_i(\theta)\) 由模型学习，分母 \(Z=\sum_i w_i\) 也依赖参数，商法则会多出一项：\(\nabla L=\sum_i\frac{w_i}{Z}\nabla\ell_i+\sum_i\frac{\ell_i-L}{Z}\nabla w_i\)。第二项允许模型降低高于当前平均损失的样本权重、提高较容易样本的权重；目标下降可能来自“重新挑样本”，而非原任务误差变小。若这不是希望学习的机制，应明确固定权重、分离更新或加入相应约束。





只对分母 detach 并不是单纯的数值优化：它删除商法则的一部分，把本来应相互抵消的归一化梯度改掉。对分子、分母或所有权重停止梯度都代表不同算法。检查时可固定两项损失为 1 和 9，让两个权重由 logits 的指数给出：等权处损失为 5，对两个权重 logits 的梯度为 −2 和 +2；梯度下降会增加容易项的权重，降低困难项的权重。





$$
L=\frac{\sum_i w_i\ell_i}{Z},\quad Z=\sum_iw_i>0;\qquad \nabla L=\sum_i\frac{w_i}{Z}\nabla\ell_i+\sum_i\frac{\ell_i-L}{Z}\nabla w_i
$$





### 分母是否参与求导，取决于它是否依赖参数

有效元素计数通常是常量，模型预测的软权重和其归一化分母则可能可微。形状相同，不代表梯度相同。

写出权重来源与依赖关系，对权重分支做有限差分；对分母停止梯度需要有明确的目标定义，不能仅以梯度数值更平稳为依据。

## 分类与序列监督的有效位置

监督位置是模型输出中有标签、且被选入损失的那些位置。自回归训练的标签移位决定每个位置预测谁，Loss Mask 决定哪些预测被计入；注意力可见性又决定预测时能读取什么。这三项共同定义序列任务。





分类交叉熵在每个有效位置形成一个损失，Padding、提示区或无标签位置可能需要忽略。对于自回归序列，标签移位决定“当前位置预测谁”，Loss Mask 决定“哪些预测计入目标”，二者不能互相替代。形状正确但目标错移一位，会训练完全不同的问题；把输入 token 直接当同位置标签还可能产生信息泄漏。





ignore_index、类别权重和标签平滑会影响不同输入形式下的归约规则。不能先假定某个内置 mean 等价于有效 token 平均，再额外除一次长度。一个稳妥的调试路径是先取 reduction="none"，按明确的有效计数手工计算一个批次，再核对所用 API 的最终结果。软标签也应满足题设的概率含义，不能将任意浮点向量视为有效概率目标。









## 多项损失加权后，真正相加的是共享梯度

多项损失的加权目标，是用若干监督信号共同更新一组参数的方法。相加的是这些目标在共享参数上的梯度，而非可以直接比较意义的日志数值。下面用梯度分解说明任务怎样相互作用。





总目标 \(L=L_1+\lambda L_2\) 对共享参数的梯度为 \(g_1+\lambda g_2\)。某项 loss 很大，可能含常数偏置或使用不同单位，不足以证明它主导训练；需要比较同一组共享参数上的梯度范数、方向与实际更新。两个任务独立输出头的参数不属于共享干扰的同一坐标，应分开记录。





先分别验证每个子目标能在最小例子上学习，再组合并固定基线权重。记录各任务原始指标、有效数量、加权前后损失及共享梯度统计。动态加权或梯度修正算法可以进一步研究，但不能修复错误标签、错误分母或断图。总 loss 下降也可能掩盖主任务退化，因此验证必须保留各任务独立评价。





多任务权重若由可学习网络预测，还需检查权重是否能通过趋近零降低困难目标的贡献。可学习权重的目标、约束和梯度不一定满足固定常数 \(\lambda\) 推导的前提。









## 梯度与日志要优化同一个统计对象

指标汇总是在多个批次之间合成误差统计，梯度归约则决定实际优化的权重。两者应对应同一个总体平均，不能都靠“平均各批的平均值”代替。保存分子与有效计数，可以让变长批次仍有明确的统计含义。





训练循环经常对每个 Batch 的 mean 再做简单平均，遇到最后一个小 Batch 或变长序列时，就不是全体有效元素的平均。验证时保存误差和 S 与有效数 N，最终计算 \(\frac{\sum S}{\sum N}\)，能使统计对象明确。梯度累积也必须用相同的目标分母；仅修正日志不能挽救之前按错误局部均值产生的参数更新。





配套代码将正确加权 Mask MSE 与直接 mean 对照。测试应覆盖不等长、有效零值、不同 D、全无效输入和无效 NaN，并检查有效位置梯度与无效位置梯度。一个只检查 loss 是有限数的测试太弱：错误归约通常仍然有限，甚至看起来收敛更快。可用复制某条样本或整体缩放权重的实验，验证目标是否遵守预期的不变性。





最后记录训练目标的完整定义：误差空间、采样单位、有效位、权重、归约范围与空集合策略。保存这几个选择，才能解释两个实验的 loss 是否可比较，也才能让恢复训练和部署后分析沿用同一语义。





贯穿训练工程的[共同训练项目](#/learn/training-loop?tab=code&anchor=demo-shared-training-project)以 `masked_error_sum` 作为唯一有效误差实现。它先选择有效标签、返回误差和与有效标量数，再由普通训练、累积与验证决定如何汇总。`verify_masks` 同时检查前向不受无效 NaN 影响、无效输入梯度为零，以及有效 NaN 被拒绝。完整程序不把 Mask 只当作日志筛选条件。





一个完整损失应能回答四件事：怎样衡量偏差、哪些位置有效、每项权重多大、最终除以什么。把这四件事用于同一套梯度与日志，数值下降才有明确的目标解释。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| prediction / target | [B,T,D] | 每条轨迹每个时间步的动作向量 |
| valid | [B,T] | 哪些时间步有真实监督 |
| dim_weight | [D] | 不同动作维度的非负权重 |
| effective_weight | [B,T,D] | 时间有效性与维度权重共同决定的权重 |

## 完整代码与精读

```python
import torch

torch.manual_seed(0)
pred = torch.tensor([[[1., 2.], [3., 4.], [float("nan"), float("nan")]],
                     [[2., 1.], [float("nan"), float("nan")],
                      [float("nan"), float("nan")]]], requires_grad=True)
valid = torch.tensor([[True, True, False], [True, False, False]])
target = torch.where(valid[..., None], torch.zeros_like(pred),
                     torch.full_like(pred, float("nan")))
dim_weight = torch.tensor([1., 2.])

# STEP 1: 先构造实际有效集合，再做差与平方。
weight = valid.unsqueeze(-1).to(pred.dtype) * dim_weight
active = weight > 0
denominator = weight.sum()
if denominator <= 0:
    raise ValueError("没有正权重的有效监督")
safe_pred = torch.where(active, pred, torch.zeros_like(pred))
safe_target = torch.where(active, target, torch.zeros_like(target))
error = safe_pred - safe_target
loss = (error.square() * weight).sum() / denominator
assert torch.allclose(loss, torch.tensor(56. / 9.))

# STEP 2: 两种错误独立验证：先计算 NaN 再乘零；使用 Padding 分母。
unsafe_loss = ((pred - target).square() * weight).sum() / denominator
assert torch.isnan(unsafe_loss)
wrong_mean = (error.square() * weight).mean()
assert torch.allclose(wrong_mean, torch.tensor(56. / 12.))

# STEP 3: 直接按解析式核对全部预测梯度。
loss.backward()
expected_grad = 2 * error.detach() * weight / denominator
torch.testing.assert_close(pred.grad, expected_grad)
assert torch.isfinite(pred.grad).all()
assert torch.equal(pred.grad[~active], torch.zeros_like(pred.grad[~active]))
print("正确损失:", loss.item(), "错误 Padding mean:", wrong_mean.item())
print("有效标量数:", int(active.sum()), "加权分母:", denominator.item())

```

- 第 4–10 行：只有已声明无效的输入位置含 NaN；有效标签中保留零，说明不能用标签值推断 Mask。
- 第 12–22 行：先将无效预测与标签替换为有限值，再做减法与平方。分子与分母使用同一个广播后的权重集合。
- 第 24–28 行：分别构造数值定义域错误与归约错误：前者产生 NaN，后者虽然有限却改变梯度尺度。
- 第 30–37 行：解析梯度为 \(2w_i e_i/\sum_jw_j\)。对全部位置逐元素核对，并确认无效位置为有限的零梯度。

预期观察：安全损失为 \(56/9\approx6.222222\)，以全部 12 个位置为分母的错误 mean 为 \(56/12\approx4.666667\)；先对无效 NaN 计算误差再乘零会得到 NaN。有效标量数为 6，加权分母为 9，全部预测梯度与解析式一致。

## 浏览器 Python 练习

errors 是 [T,D] 的误差列表，valid 标记有效时刻，weights 是非负维度权重。返回有效权重归一化后的平方误差；分母为零时抛出 ValueError。

```python
def masked_weighted_error(errors, valid, weights):
    # TODO: 使用相同的有效权重计算分子和分母
    raise NotImplementedError("请实现 masked_weighted_error")

```

### 提示

- 一个有效时间步对分母的贡献是所有维度权重之和。
- 先求平方误差，再按权重加权；不要把权重也平方。

### 参考实现与解释

```python
def masked_weighted_error(errors, valid, weights):
    numerator = 0.
    denominator = 0.
    for row, keep in zip(errors, valid):
        if keep:
            for error, weight in zip(row, weights):
                numerator += weight * error * error
                denominator += weight
    if denominator <= 0:
        raise ValueError("没有有效权重")
    return numerator / denominator

```

在变长 Batch 中，明确分母会让不同补齐长度下的目标保持一致。是否让每条轨迹等权，需要另行设计。

### 断言测试

```python
e = [[1., 2.], [3., 4.], [100., 100.]]
assert abs(masked_weighted_error(e, [True, True, False], [1., 2.]) - 50/6) < 1e-12
assert masked_weighted_error(e, [True, True, False], [1., 0.]) == 5.
assert masked_weighted_error([[2.]], [True], [1.]) == 4.
for mask, weights in [([False, False, False], [1., 2.]), ([True]*3, [0., 0.])]:
    try:
        masked_weighted_error(e, mask, weights)
    except ValueError:
        pass
    else:
        raise AssertionError("零分母应显式处理")
print("通过：加权、Padding 排除和零分母处理。")

```

## 本地 PyTorch 练习

实现 prediction/target 为 [B,T,D] 的加权 Mask MSE。valid 为布尔 [B,T]，dim_weight 为有限非负 [D]；输入位于同一设备，预测、标签和权重使用同一浮点类型。有效集合同时要求 valid=True 且维度权重大于零：只有集合外的位置允许 NaN。先安全选择再计算误差，分母为有效权重之和；形状不符、非法权重、有效位置非有限或没有正权重监督时抛出 ValueError。权重是数据给定常量，目标不是学习如何挑选样本。

```python
import torch

def masked_weighted_mse(prediction, target, valid, dim_weight):
    # TODO: 检查契约；先建立有效集合，再做安全差值和加权归约。
    raise NotImplementedError("请实现 masked_weighted_mse")

```

### 提示

- 先检查形状与权重，再由 valid 和正权重形成真正参与损失的标量集合。
- 对预测和目标分别使用 torch.where，在做差与平方之前把集合外位置替换为有限值。
- 分子和分母使用同一权重；整体乘一个正常数应保持损失不变，无效位置的预测梯度应为零。

### 参考实现与解释

```python
import torch

def masked_weighted_mse(prediction, target, valid, dim_weight):
    if (prediction.ndim != 3 or prediction.shape != target.shape
            or valid.shape != prediction.shape[:2]
            or dim_weight.shape != prediction.shape[2:]
            or valid.dtype != torch.bool):
        raise ValueError("形状或 Mask 类型不符合约定")
    if not torch.isfinite(dim_weight).all() or (dim_weight < 0).any():
        raise ValueError("维度权重应有限且非负")
    weight = valid.to(prediction.dtype).unsqueeze(-1) * dim_weight
    active = weight > 0
    denominator = weight.sum()
    if denominator <= 0:
        raise ValueError("没有有效权重")
    if (not torch.isfinite(prediction[active]).all()
            or not torch.isfinite(target[active]).all()):
        raise ValueError("有效监督中含有非有限值")
    safe_prediction = torch.where(active, prediction, torch.zeros_like(prediction))
    safe_target = torch.where(active, target, torch.zeros_like(target))
    return ((safe_prediction - safe_target).square() * weight).sum() / denominator

```

安全选择删除的是已声明无效位置的求导路径，而不是掩盖有效标签中的异常。按标量循环构造的独立参照检查值与梯度，NaN、零权重维及整体权重缩放则检验实现是否保留了目标的有效集合与不变量。当前目标按有效标量加权；若要求每条轨迹等权，需要明确定义另一种归约。

### 断言测试

```python
torch.manual_seed(3)
p = torch.randn(2, 3, 2, dtype=torch.float64, requires_grad=True)
y = torch.zeros_like(p)
m = torch.tensor([[True, True, False], [True, False, False]])
w = torch.tensor([1., 2.], dtype=p.dtype)
loss = masked_weighted_mse(p, y, m, w)
# 独立标量索引参照：只读取真正有效的值，不复用被测的广播实现。
expected = sum((p[b,t,d] - y[b,t,d]) ** 2 * w[d]
               for b in range(2) for t in range(3) if m[b,t]
               for d in range(2)) / 9
torch.testing.assert_close(loss, expected)
actual_grad = torch.autograd.grad(loss, p)[0]
reference_grad = torch.autograd.grad(expected, p)[0]
torch.testing.assert_close(actual_grad, reference_grad)
assert torch.equal(actual_grad[~m], torch.zeros_like(actual_grad[~m]))

# 无效位置含 NaN，也应保持相同损失和有限的零梯度。
pn = p.detach().clone()
yn = y.detach().clone()
pn[~m] = float("nan")
yn[~m] = float("nan")
pn.requires_grad_()
safe = masked_weighted_mse(pn, yn, m, w)
torch.testing.assert_close(safe, loss.detach())
safe.backward()
torch.testing.assert_close(pn.grad, reference_grad)
torch.testing.assert_close(masked_weighted_mse(pn, yn, m, 7 * w), safe.detach())

# 零权重维也在有效集合外；有效零标签仍必须参与。
one_dim = torch.tensor([1., 0.], dtype=p.dtype)
pd = p.detach().clone()
yd = y.detach().clone()
pd[..., 1] = float("nan")
yd[..., 1] = float("nan")
pd.requires_grad_()
dim_loss = masked_weighted_mse(pd, yd, m, one_dim)
torch.testing.assert_close(dim_loss, p.detach()[..., 0][m].square().mean())
dim_loss.backward()
assert torch.equal(pd.grad[..., 1], torch.zeros_like(pd.grad[..., 1]))
assert torch.isfinite(pd.grad).all()

def expect_value_error(pred, target, valid, weights):
    try:
        masked_weighted_mse(pred, target, valid, weights)
    except ValueError:
        return
    raise AssertionError("应拒绝不符合约定的输入")

expect_value_error(p, y, torch.zeros_like(m), w)
expect_value_error(p, y, m, torch.zeros_like(w))
expect_value_error(p, y, m, torch.tensor([-1., 2.], dtype=p.dtype))
expect_value_error(p, y, m, torch.tensor([float("inf"), 2.], dtype=p.dtype))
expect_value_error(p, y, m.float(), w)
expect_value_error(p, y[:, :1], m, w)
bad = p.detach().clone()
bad[0, 0, 0] = float("nan")
expect_value_error(bad, y, m, w)
print("PyTorch 测试通过：有效集合、值域、分母和全部预测梯度正确。")

```

## 练习：推导与分析

### 按有效动作元素平均与先按每条轨迹平均再平均，有什么不同？

前者给每个有效元素相同权重，较长轨迹总贡献更大；后者先消除轨迹长度差异，再让每条轨迹等权。两者优化的是不同经验目标，都不能仅凭名称判断谁一定正确。

代码中的 weight.sum() 定义了分母。若只把 Padding 乘零后直接 mean，则分母包含补齐位置，得到的是第三种受补齐长度影响的目标。

代码定位：masked_weighted_mse 的分子与 denominator；演示 correct/wrong_loss。

- 能用长短两条轨迹举例说明两种权重。
- 能明确指出 Padding 应否进入分母。

### 为什么 NaN 位置已经有 Mask=0，损失仍可能是 NaN？

NaN×0 仍然是 NaN；对所有位置先做差和平方，再乘 Mask，并没有阻止非法数值进入计算。反向也可能经过这些局部导数，因此只替换最后的 loss 不够。

参考实现先构造由有效时间和正维度权重共同决定的集合，再将集合外的预测与标签替换为零。有效集合内部的非有限值仍拒绝处理，因为它代表待诊断异常；零权重维和 Padding 的 NaN 则按题设排除。

可以用两个对照检验：给有效标签恰好为零的位置保留监督；把无效位置替换为 NaN 后，损失及有效位置梯度应与有限填充版本一致。这样同时验证了统计含义和数值路径。

代码定位：代码页的 safe_pred / safe_target 与 unsafe_loss 对照；PyTorch 练习中的 active 集合和独立标量梯度参照。

- 能解释为什么零 Mask 不是数值清洗。
- 能提出在危险运算前处理无效值的办法，而非只替换最终 loss。

## 练习：辨析与纠错

### 对变长样本先 mean 再平均

这会给每条样本相同总权重，而不是给每个有效元素相同权重。按目标选择一种定义，并贯穿训练、累积和验证。

### 用非零标签推断有效性

零可以是正确动作或回归值。使用独立有效标记，并加入“有效标签恰为零”的测试。

### Mask 乘在 NaN 误差后

NaN×0 仍为 NaN，反向也可能污染。先选择有限的有效输入，再做差、平方和归约。

### 只修日志均值，不修反向分母

损失缩放直接改变梯度。对照一次完整批次更新与分块更新，核查真正的参数位移而不只看显示数字。

## 原始资料

- [PyTorch：MSELoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.MSELoss.html)
- [PyTorch：HuberLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.HuberLoss.html)
- [PyTorch：Autograd mechanics — Division by zero](https://docs.pytorch.org/docs/stable/notes/autograd.html)
