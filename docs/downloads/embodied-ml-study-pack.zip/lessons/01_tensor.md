# 张量与广播

从 [B, T, D] 开始，把每一个维度读成实际含义。

在深度学习计算中，张量是带有确定形状的数值数组：标量、向量和矩阵分别对应零、一、二维，更高维数组还可以组织批量与序列。形状说明每个轴有多长，轴的语义说明这些数表示样本、时间还是特征；二者共同确定运算含义。本章先认识张量与轴，再追踪投影、轴变换、广播和汇总，最后核对元素身份是否保留。

## 学习目标

- 为视觉、状态与动作张量标注每个轴的含义
- 区分维度重排、形状重组和广播
- 用元素级检查验证批量运算没有混淆样本

## 轴语义与布局

轴是张量中一条独立的索引维度，布局是这些索引与元素存储顺序的对应方式。[B,T,D] 的三条轴可以分别表示样本、时间与特征，但这个含义需要我们声明。先给轴命名，才能判断后续操作是在变换特征还是在混合样本。





张量是按多个索引访问的数值数组。shape 描述每条索引轴的长度，但不告诉模型轴的含义。[B,T,D] 可以表示 B 条序列、每条 T 个时刻、每时刻 D 个特征，也可以被错误地解释成 B 个样本、T 个相机、D 个像素。两者元素数量一样，代码仍可能正常运行。因此在输入和输出旁同时写出“形状、轴名、单位、dtype、有效位”，比只打印一个 torch.Size 更有用。





Batch 轴通常表示独立样本。只沿最后一维执行 Linear 时，各样本没有发生混合；若把 Batch 轴当 token 轴送进 Attention，模型就可能读取同批次其他样本。排查这种错误可以固定一个样本，只替换同批次其他样本，检查它的输出是否改变。BatchNorm 等明确依赖批统计的算子需要另行解释；不能在未区分 train/eval 时将所有输出变化都判断为泄漏。





建立约定后，再从一个具体元素出发跟踪索引。例如给 x[b,t,d] 填入 \(100b+10t+d\)，可以直接观察一个变换后相邻的数来自同一时间还是不同样本。随机张量能检查数值范围，却不如编码索引适合发现轴被交换、展平顺序变化和视角拼接错误。









## 线性投影沿哪一维计算

线性投影用同一组权重，将一个特征向量映射到另一个特征空间；加上偏置后严格说是仿射映射。nn.Linear 作用于最后一条轴，其他轴只是重复使用这组参数的位置。它改变特征宽度，本身不在不同时间位置之间交换信息。





nn.Linear(D,H) 保存的 weight 形状是 [H,D]，计算 y=x@weight.T+b。输入可以是 [B,D]，也可以是 [B,T,D]；它仅替换最后一维，所以后一种输出为 [B,T,H]。这相当于对每个 b,t 位置复用同一组参数，不需要循环创建 T 个不同的层。参数总数为 \(DH+H\)，与 Batch 和序列长度无关；激活数量却会随 B、T 增长。





矩阵乘法中的收缩轴必须一一对应。对 x:[B,T,D] 与 W:[D,H]，可以写 einsum("btd,dh->bth",x,W)，其中 d 消失，说明对特征索引求和；b、t、h 保留。这个写法帮助表达计算含义，但并不自动比 matmul 更快。高阶 matmul 还会广播前面的批维度，因此先检查输出 shape，再逐项核对一两个元素，避免把合法广播误当成正确计算。





$$
y_{bth}=\sum_{d=1}^{D}x_{btd}W_{hd}+b_h
$$



### 例：手算一个共享线性层

1. 令一个 token 为 [1,2]，weight 两行为 [3,4]、[-1,2]，bias 为 [1,0]。

2. 第一个输出为 \(1\times3+2\times4+1=12\)，第二个为 \(1\times(-1)+2\times2=3\)。

3. 另一个 token 使用完全相同的 weight 和 bias；若输入形状为 [2,3,2]，输出为 [2,3,2]，参数共 6 个。

Linear 改变特征轴，不会自动混合时间或 Batch。

### 把“共享计算”与“共享数据”分开

同一个层可作用于所有位置，表示参数被复用；这些位置的输入仍各自独立。

用一个 token 的手算结果核对完整输出中的对应切片，并核查参数量。

## reshape、transpose 与内存布局各自改变什么

reshape 改变元素的分组形状，transpose 或 permute 改变轴的排列。两者都能改变 shape，却不表示同一种元素对应关系。理解这个区别，才能在拆分注意力头等操作中保留每个位置原有的通道。





reshape 重新解释当前逻辑顺序中的元素如何分组，transpose/permute 则重新安排索引轴。[B,T,D] 变成 [B,D,T] 需要交换轴；直接 reshape 虽然元素总数一致，却一般给出不同的元素对应关系。对注意力头，常见正确顺序是先把 D 拆成 \(Hd_h\)，得到 [B,T,H,d_h]，再转置成 [B,H,T,d_h]。shape 相同并不能证明路径等价。





底层 storage、stride 和 storage_offset 决定索引怎样映射到内存。permute 通常创建共享 storage 的视图，张量可能不再连续；view 只在布局兼容时成立，reshape 则可能返回视图或复制。不要依赖 reshape 必定共享内存，也不要随处加 contiguous 来掩盖轴语义错误。contiguous 解决的是布局要求，不会把已经错配的样本语义自动修正。







### 例：同样的 [3,2] 形状，元素不同

1. 从 [[0,1,2],[3,4,5]] 出发，直接 reshape(3,2) 得到 [[0,1],[2,3],[4,5]]。

2. transpose(0,1) 得到 [[0,3],[1,4],[2,5]]。

3. 两者都含 6 个数，形状也相同；只有逐项对应能判断哪一种是所需的轴交换。

形状检查是必要条件，索引语义检查才判断计算是否正确。

### 用 reshape 代替轴交换

reshape 不知道时间、相机、头数等语义，可能制造不报错的数据错配。

用 arange 或编码索引构造确定性输入，对照 permute 后的每一个位置。

## 广播从右向左对齐，不按变量名称对齐

广播是将不同形状的数组按兼容维度对齐、使逐元素运算能够执行的规则。长度为 1 或缺失的轴可以沿另一数组展开，但框架只比较尺寸，不理解“样本权重”等名称。它减少显式复制，也要求我们明确权重应沿哪条轴共享。





广播比较尾部各维：长度相同、其中一个为 1，或该维缺失时可以对齐。要给 [B,T,D] 每个样本一个权重，权重应显式为 [B,1,1]。直接用 [B] 会对齐最后的 D 轴；当 B 恰好等于 D 时不会报错，却会给特征维加权。测试时故意取 B、T、D 互不相等，可以尽早暴露这种巧合。





长度为 1 的维度表达“这一轴共享同一个值”。时间权重通常写成 [1,T,1]，特征尺度写成 [1,1,D]，有效时间 Mask 写成 [B,T,1]。expand 利用广播形成视图，多个位置可能共享同一存储；对这种视图做原地写入可能不合法或语义不清。若需要独立可写的副本，应明确复制，而不是假定每个广播位置都有单独内存。









### B 恰好等于 D 会掩盖广播错误

形状可广播只表示规则兼容，不说明权重加在了正确的轴。

把测试尺寸改为 B=2、T=3、D=5，并查看一个样本在全部位置上的缩放是否一致。

## 归约轴和分母共同决定平均了什么

归约是沿指定轴把多个元素汇成较少元素的操作，例如求和或求均值。归约轴决定合并哪些对象，分母决定每个对象的权重。先说清要平均样本、时间还是标量，才能让一个最终数值对应正确的统计问题。





sum 与 mean 都会消去指定的轴，keepdim=True 保留长度为 1 的占位，有助于后续广播。例如 x.mean(dim=1,keepdim=True) 对每条序列求时间均值，结果 [B,1,D]；若不保留维度，结果 [B,D] 与原 x 相减时可能错误广播。不要先把所有维度 mean 成一个标量，再猜它代表样本平均还是 token 平均。





带 Padding 的序列不能直接在 T 上平均。有效池化应先选出有效值，求和，再除以每条序列的有效长度。全无效序列需要明确返回值或拒绝输入。若无效位置含 NaN，先乘零并不能清除它；NaN×0 仍为 NaN，应该在归约前使用安全选择。输出形状、有效位和空序列策略应一起写进函数约定，否则同一段代码会在不同数据集上悄悄改变含义。





$$
\bar x_{bd}=\frac{\sum_t m_{bt}x_{btd}}{\sum_t m_{bt}},\qquad \sum_t m_{bt}>0
$$





## 索引、拼接与复制会影响语义和梯度

索引选择已有元素，拼接连接多个数组，复制则创建新的存储。cat 沿已有轴连接，stack 新建一条轴，因此它们保留样本和视角身份的方式不同。这里同时追踪数值的来源与梯度应回到的位置。





cat 沿已有轴连接，stack 创建新轴。两张 [B,C,H,W] 图像用 stack(dim=1) 得到 [B,2,C,H,W]，显式保留视角轴；cat(dim=0) 得到 [2B,C,H,W]，需要另存映射才能恢复原样本；cat(dim=1) 得到 [B,2C,H,W]，把两个视角解释成同一空间网格上的额外通道，是不同的模型假设。





普通切片经常共享原存储，高级索引常产生新张量；是否复制不能代替是否可微的判断。索引选出的数值通常仍能把梯度传回被选位置，重复索引会累加贡献；整数索引本身一般没有可学习梯度。detach 断开求导关系，clone 复制数据但通常保留求导路径。修改别名张量还可能触发 autograd 的版本检查，因此排查原地操作时必须同时查看数据共享关系。









## dtype、设备与连续性

dtype 指元素采用的数值类型，device 指张量所在的计算设备，连续性描述逻辑顺序与存储步幅是否符合连续布局。它们分别影响可表达的数、可执行的运算和数据访问方式，不能仅凭 shape 判断一个张量接口是否完整。





神经网络特征通常为浮点，类别索引和 Embedding 输入通常使用整数，Mask 通常为布尔。把标签随图像一起转成浮点，可能改变损失 API 选择的监督形式；把本应连续的特征转为整数，会丢失数值与梯度信息。device 不一致会产生显式错误，但隐式创建 CPU 常量也可能在循环中引入不必要的数据迁移。





创建辅助张量时优先从参考张量继承 dtype 和 device，例如 zeros_like、new_zeros；但索引仍应按索引约定选 long。浮点乘加存在舍入误差，不能要求不同内核和批处理方式逐位一致，测试使用合适的 atol 与 rtol。另一方面，容差不能替代 shape 检查：广播后的错误结果也可能在小样本上数值接近，应先保证形状完全一致，再判断误差。









## 张量计算的边界检查

单个形状下的成功运行容易被维度相等或批次较大等巧合掩盖。要判断函数是否实现了预期语义，需要设计会打破这些巧合的输入，并把形状检查、手算数值与不变量验证连成一组证据。





一个有效的张量测试需要覆盖典型输入和会破坏巧合的输入。除了正常 Batch，还应有 B=1、T=1、不等长序列、不同特征数和非连续张量。无参数 squeeze() 会删除所有长度为 1 的维度，常在 B=1 时让 Batch 轴消失；明确 squeeze(dim) 才能表达要删除哪条轴。一次固定尺寸通过并不等于函数支持题设的全部尺寸。





把测试分成三层：首先断言输出形状、dtype、设备及有限值；然后用小整数手算关键元素；最后用 Batch 扰动、Padding 扰动或等价重排验证语义不变性。若函数要求可微，再对输入与参数检查梯度。代码阅读时沿这三层逐步缩小问题，比只打印一个最终 loss 更能找到首次发生语义变化的位置。





逐项核对线性投影可以检验轴的含义：哪些轴保留、哪些轴收缩、哪些值被复用、是否发生了跨样本交互。把每项检查对应到一组具体索引，比只核对最后的 shape 更容易发现计算含义已经改变。





张量计算的核心是保留元素的身份：先声明轴与数值约定，再用投影、轴变换、广播和归约表达所需操作。形状通过检查以后，还应能指出一个输出元素来自哪些输入元素。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| x | [B, T, D] | 一批序列，每个时刻有 D 个特征 |
| W | [D, O] | 同一线性变换被应用到所有样本与时刻 |
| sample_weight | [B, 1, 1] | 只按样本加权，不混淆时间与特征 |

## 完整代码与精读

```python
import torch

torch.manual_seed(0)
# STEP 1: 用不相同的轴长度，让错误更容易暴露
B, T, D, O = 2, 3, 4, 2
x = torch.arange(B * T * D, dtype=torch.float32).reshape(B, T, D)
W = torch.randn(D, O)
bias = torch.tensor([0.1, -0.2])
y = x @ W + bias
assert y.shape == (B, T, O)
# einsum 直接在式子中标注被求和的 d 轴
y_check = torch.einsum("btd,do->bto", x, W) + bias
assert torch.allclose(y, y_check)
print("projection:", tuple(x.shape), "->", tuple(y.shape))

# STEP 2: 交换轴不是重新切分内存
xt = x.permute(0, 2, 1)
assert xt[1, 2, 0] == x[1, 0, 2]
assert torch.equal(xt.permute(0, 2, 1), x)
wrong = x.reshape(B, D, T)
print("reshape equals permute:", torch.equal(wrong, xt))
print("permuted is contiguous:", xt.is_contiguous())

# STEP 3: 每个样本的权重显式占据 B 轴
sample_weight = torch.tensor([1.0, 2.0])[:, None, None]
weighted = x * sample_weight
assert torch.equal(weighted[0], x[0])
assert torch.equal(weighted[1], x[1] * 2)
pooled = x.mean(dim=1)
assert pooled.shape == (B, D)
print("pooled first sample:", pooled[0].tolist())

```

- 第 4–15 行：矩阵乘法自动保留 B、T 两个批量轴，只沿 D 做乘加；einsum 提供独立表达以核对语义。
- 第 16–23 行：用一个具体索引确认 permute 的含义，随后故意比较形状相同但元素错位的 reshape。
- 第 24–31 行：两个 None 为广播添加长度为 1 的轴；mean(dim=1) 则把整段序列聚合成一个向量。

预期观察：projection 为 (2, 3, 4) -> (2, 3, 2)；reshape equals permute 为 False；第一个样本池化后是 [4.0, 5.0, 6.0, 7.0]。

## 浏览器 Python 练习

rows 是 [T, D] 的列表，valid 标记哪些时刻有效。只平均有效行；若没有有效行，抛出 ValueError。不要把 Padding 的数值平均进去。

```python
def masked_mean(rows, valid):
    # TODO: 找到有效行，对每个特征维度求平均
    raise NotImplementedError("请实现 masked_mean")

```

### 提示

- 先筛选有效行，分母是有效行的数量。
- 输出应保留 D 轴，而不是对所有数只求一个平均值。

### 参考实现与解释

```python
def masked_mean(rows, valid):
    chosen = [row for row, keep in zip(rows, valid) if keep]
    if not chosen:
        raise ValueError("没有有效时刻")
    width = len(chosen[0])
    return [sum(row[d] for row in chosen) / len(chosen) for d in range(width)]

```

这个练习对应后续对视觉 token 或历史状态做掩码池化。真实批量版本应独立计算每条样本的有效长度。

### 断言测试

```python
assert masked_mean([[1, 2], [3, 4], [999, 999]], [True, True, False]) == [2, 3]
assert masked_mean([[2, 4, 6]], [True]) == [2, 4, 6]
try:
    masked_mean([[1, 2]], [False])
except ValueError:
    pass
else:
    raise AssertionError("全无效输入必须显式处理")
print("通过：有效时刻平均、Padding 排除、空有效集处理。")

```

## 本地 PyTorch 练习

实现 [B,T,D] 的池化。x 是浮点 Tensor，有效位置数值有限，无效位置允许包含 NaN；mask 是同设备的布尔 Tensor [B,T]。每个样本只平均自己的有效时刻；任一样本没有有效时刻时抛出 ValueError。输出必须保留梯度，无效位置梯度为零。输入形状和有效位置的有限性由题设保证。

```python
import torch

def pool_valid(x, mask):
    # TODO: 用广播实现，不要转成列表或重新构造 Tensor
    raise NotImplementedError("请实现 pool_valid")

```

### 提示

- 把 [B,T] 的 mask 增加一个尾轴，才能沿 D 正确广播；分母独立统计每条样本的有效时间数。
- 先用 torch.where 选择有效输入，再求和。NaN 不能靠乘零清除，也不要转成列表或重建 Tensor。

### 参考实现与解释

```python
import torch

def pool_valid(x, mask):
    keep = mask.unsqueeze(-1)  # [B,T,1] 沿特征轴广播
    count = keep.sum(dim=1).to(dtype=x.dtype)  # [B,1]
    if torch.any(count == 0):
        raise ValueError("存在无有效时刻的样本")
    safe = torch.where(keep, x, torch.zeros_like(x))
    return safe.sum(dim=1) / count

```

pool_valid 用 torch.where 在归约之前将无效位置替换为零，分母保持 [B,1] 并沿特征轴广播。对样本 b 中每个有效时刻，输出和对输入的梯度为 1/n_b；无效位置的梯度为零，n_b 是该样本有效时间数。测试直接使用无效 NaN 并核对全部梯度，保证实现与正文的安全选择原则一致。全无效样本在本题中报错，避免用任意零向量掩盖数据缺失；实际任务可以另行规定缺失输入策略。

### 断言测试

```python
x = torch.tensor([[[1., 2.], [3., 4.], [float('nan'), float('nan')]],
                  [[5., 6.], [float('nan'), 9.], [9., float('nan')]]],
                 dtype=torch.float64, requires_grad=True)
m = torch.tensor([[True, True, False], [True, False, False]])
out = pool_valid(x, m)
assert out.shape == (2, 2)
torch.testing.assert_close(out, torch.tensor([[2., 3.], [5., 6.]], dtype=x.dtype))
assert torch.isfinite(out).all()
out.sum().backward()
expected_grad = m.to(dtype=x.dtype).unsqueeze(-1).expand_as(x)
expected_grad = expected_grad / m.sum(dim=1)[:, None, None]
torch.testing.assert_close(x.grad, expected_grad)
assert torch.isfinite(x.grad).all()
# 改变无效填充值不会影响结果，也不应改变有效样本的平均分母。
changed = x.detach().clone()
changed[~m] = 1e9
torch.testing.assert_close(pool_valid(changed, m), out.detach())
# 长度为 1 的 Batch 和时间轴仍应保留输出形状。
single = torch.tensor([[[2., 7.]]], dtype=torch.float64, requires_grad=True)
torch.testing.assert_close(pool_valid(single, torch.tensor([[True]])), single[:, 0])
try:
    pool_valid(x, torch.zeros_like(m))
except ValueError:
    pass
else:
    raise AssertionError("应拒绝无有效时刻的样本")
print("PyTorch 测试通过：有效平均、无效 NaN、全部输入梯度与单例轴。")

```

## 练习：推导与分析

### 为什么把 [B,T,D] 直接 reshape 成 [B,D,T]，尺寸对了却仍可能算错？

reshape 只按原有逻辑元素顺序重新分组，permute/transpose 才表达轴交换。一个操作前后的形状相同或元素数量相同，并不能保证同一个时间和特征仍被对应。

演示用连续编号验证 xt[1,2,0] == x[1,0,2]。先为每个轴标明语义，再检查几个具体索引；对非连续视图还应区分 reshape 可能复制与 view 的步长限制。

代码定位：演示 STEP 2 的 permute、reshape 和具体索引断言。

- 能用一个具体元素说明两种操作的不同。
- 能正确写出 [B,T,H,d] 到 [B,H,T,d] 的轴变换。

### 为什么样本权重要写成 [B,1,1]，而有效池化的分母不能直接用 T？

广播从末尾对齐。直接用 [B] 乘 [B,T,D] 时，B 会尝试对齐 D；当 B 恰好等于 D，代码可能成功但变成按特征加权。显式 [B,1,1] 才固定样本轴。

Padding 不是真实观测。池化分母是每条样本自己的有效时间数；使用固定 T 会让短序列被额外缩小。全无效样本必须按任务约定处理，本题选择抛错。

代码定位：sample_weight[:,None,None]；pool_valid 中 keep.sum(dim=1) 的分母与 torch.where 的安全选择。

- 能给样本权重与维度权重分别写出广播形状。
- 能解释短序列和全无效序列的分母处理。

## 练习：辨析与纠错

### 用全部相等的维度做测试

\(B=T=D\) 时，错误广播和错误交换可能同时被隐藏。使用互不相等的尺寸、可手算索引编码和 Batch 扰动测试，才能区分形状兼容与语义正确。

### 未指定轴的 squeeze 移除了 Batch 维

无参数 squeeze 会移除全部长度为 1 的轴。训练批次正常而最后一个 B=1 批次失败时，应检查是否只打算删某一单例维，并显式传 dim。

### 把无效位置乘零就认为安全

NaN 乘零仍为 NaN。先选择有效值，再归约；还要检查 Mask 的广播轴、有效分母和全无效输入策略。

### 将共享存储误认为独立副本

view、切片和 expand 可能共享数据。原地更改可能影响另一个变量或反向计算；按需要使用 clone，并区分复制数据与 detach 断图。

## 原始资料

- [PyTorch：Tensors](https://docs.pytorch.org/tutorials/beginner/basics/tensorqs_tutorial.html)
- [PyTorch：Broadcasting semantics](https://docs.pytorch.org/docs/stable/notes/broadcasting.html)
- [PyTorch：张量视图与共享存储](https://docs.pytorch.org/docs/stable/tensor_view.html)
