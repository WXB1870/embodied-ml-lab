# 训练显存与重计算

先知道内存花在哪里，再决定减 Batch、冻结还是重计算。

训练显存用于保存参数、梯度、优化器状态、激活和临时数据等对象。激活检查点（Activation Checkpointing）是一种少保存部分前向中间值、反向时重新计算它们的方法，以额外计算换取内存；它不同于把训练状态保存到磁盘的 checkpoint。本章先建立内存账目，再认识冻结、重计算和对象寿命，最后同时检验节省量与计算一致性。

## 学习目标

- 按参数、梯度、优化器状态和激活拆解训练内存。
- 正确使用非重入 activation checkpoint 并核对梯度。
- 区分逻辑保存量、实际张量内存与缓存预留内存。

前置知识：[PyTorch 自动微分与计算图](https://wxb1870.github.io/embodied-ml-lab/learn/autograd/) · [混合精度训练](https://wxb1870.github.io/embodied-ml-lab/learn/mixed-precision/)

## 训练内存由哪些对象组成

训练内存账目是按对象与生命周期统计当前计算需要保存哪些数值。常驻参数状态、反向激活和临时工作区有不同来源，因此需要不同节省方法。先分清对象，再估算参数数目以外的成本。





训练内存至少包括参数、梯度、优化器状态、为反向保存的激活、当前输入输出和算子临时工作区。若参数、梯度和 Adam 的两个矩都以 FP32 保存，仅这四项就约为 16P 字节，其中 P 是参数数目。这个估算不包括激活、临时张量、通信缓存或实现额外副本，因此不能用参数量乘固定系数直接保证模型一定装得下。



### 例：一个明确假设下的状态内存估算

1. 假设 P=100 万，参数、梯度、一阶矩、二阶矩都为 FP32，且没有其他副本。

2. 每类约 4 MB，四类合计约 16 MB（十进制）。

3. 前向激活、Batch、临时工作区和框架开销还需另外计算。

16P 是这组假设下的状态估计，不是普遍的训练峰值公式。

混合精度、分片优化器、参数冻结和融合内核会改变各项构成。有的配置保留 FP32 主参数，有的以 FP32 参数执行 autocast；二者不能重复或遗漏计数。估算时为每一类对象列出元素数、dtype、是否常驻和是否被分片，再对照实际测量。模型文件大小只对应保存格式，不等于峰值训练内存。





内存单位也要保持一致：MB/GB 按十进制，MiB/GiB 按二进制，工具显示口径可能不同。容量规划还需为峰值波动与运行时开销留余量；不能用四舍五入后的理论估计刚好贴满设备容量，再把偶发 OOM 归为不稳定。









## 激活为何随 Batch、序列和宽度增长

激活是前向产生的中间表示，自动微分还可能保存其中部分数据供反向使用。它的规模由批量、序列、宽度和具体算子共同决定。下面沿张量而非模型文件大小估算这部分内存。





一个 [B,T,D] 激活包含 BTD 个元素；同一网络中还可能有多个投影、中间 FFN、归一化和反向所需保存量。标准显式注意力分数为 [B,H,T,T]，序列长度翻倍会让这一个张量元素数约增四倍。使用不显式保存完整矩阵的优化算法可以改变实际内存行为，所以应同时区分数学计算复杂度和具体实现的保存策略。





增大图像分辨率、相机数或历史长度通常增加 token 数，从而影响后续多个模块。仅在最后增加一层小 MLP，新增参数可能不多，但前面的长序列激活仍是主要成本。减少微批大小主要降低激活峰值，不能消除常驻优化器状态；反之，LoRA 减少可训练参数状态，也不一定显著减少所有激活。





读内存问题时应先判断随哪一项配置增长：Batch 线性增长提示激活，参数数量变化提示状态，某段序列长度引起突增可能涉及注意力或临时工作区。这些只是定位线索，最终仍需逐阶段测量。









## 冻结能够省掉什么，不能省掉什么

冻结参数可免去其梯度和相应优化器状态，但不自动移除前向权重或求输入梯度所需的激活。是否能停止建图取决于上游还有没有可训练对象。下面按求导路径区分这些成本。





冻结参数通常无需为这些参数保存梯度和对应优化器状态，但其权重仍需参与前向。如果冻结模块之前还有可训练 Adapter，反向仍需要穿过它来计算输入梯度，相关激活不一定能全部省去。只有在没有必要上游梯度的边界停止建图，才可以避免该区域的反向保存；不恰当地使用 no_grad 会直接改变可训练路径。





参数冻结也不自动把模块切换到 eval，Dropout 或 BatchNorm 行为与梯度设置独立。离线缓存固定特征可能进一步减少训练计算，但它要求输入预处理、随机增强、条件和编码器状态都满足缓存有效性条件。缓存来自未来信息或不一致增强时，内存节省的同时改变了训练问题，应独立审查。









### 可训练参数少就认为激活内存必然很小

反向是否经过大骨干由计算依赖决定，不只由骨干参数 requires_grad 决定。

画出可训练模块的位置，分别测冻结、停止建图和真正裁断前置梯度的影响。

## allocated、reserved 与峰值测量

allocated 统计活跃张量等已分配内存，reserved 还包含缓存分配器为复用而保留的内存块，峰值则记录某区间的最高占用。它们是不同测量口径。先固定口径，再判断内存增长与释放。





设备内存的已分配量通常指仍被活跃张量占用的部分，缓存分配器预留量还包含可复用的内存块。预留量高不等于全部都是泄漏；调用 empty_cache 可以释放部分空闲缓存给其他使用者，却不能释放仍被张量引用的内存。把清缓存放进每个训练步，也可能增加分配开销而不解决活跃对象过大的根因。





峰值应覆盖完整训练步，并明确统计从什么时候开始。先预热模型，必要时同步设备，重置峰值统计，再测前向、反向和 step；优化器状态可能在第一次 step 才创建，所以只测前向会低估。计时同样需要处理异步执行，不能用 CPU 调用返回时间直接当作 GPU 运算耗时。









### 按阶段记录内存，而不是只看一张显卡截图

前向、反向和 optimizer.step 的峰值来源可以不同。

在固定输入上分别记录 allocated/reserved/peak，并说明预热、同步与首次状态创建。

## 激活重计算用额外计算换取更少保存量

激活重计算是在反向需要中间量时，重新执行选定前向区段来恢复它们的机制。它减少保存量，却要求重算仍对应原来的函数。先看保存与重算怎样配合，再讨论区段选择。





普通反向需要某些前向中间值，激活 checkpointing 选择只保存区段边界等必要信息，在 backward 时重新执行部分前向来恢复中间量。它不会从磁盘读取 checkpoint，也不等于训练断点保存；两者名称相近，但用途不同。被重计算的函数必须在两次执行中代表同一个计算，否则输出或梯度可能改变。



### 例：为什么保留边界仍能反向

1. 设一段计算 \(x\to h_1\to h_2\to y\)，普通反向可能保存 \(h_1\) 与 \(h_2\)。

2. 重计算策略保存 x 和必要状态，反向需要 \(h_1\text{ / }h_2\) 时再从 x 重做这段前向。

3. 节省的是部分中间保存，增加的是再次求值；x、参数、梯度与优化器状态仍要存在。

激活重计算改变保存策略，不改变期望优化的数学函数。

PyTorch 提供不同重计算实现，示例显式使用 use_reentrant=False，避免依赖默认选择。分段长度越大，保存边界可能越少，但需要重算的工作也可能更多；实际实现还可能提前停止已不需要的重算。选择区域应根据激活成本、计算成本和依赖关系，不能假定包住整个网络就获得最佳时间—内存折中。





重算的收益取决于哪些中间量本来需要保存。一个几乎不保存大激活的廉价算子，包住后可能只有管理开销；含大型中间投影的块则可能收益明显。先用保存量和 profiler 定位，再选择分段，能够避免把更多计算花在没有实际内存节省的位置。









## 随机状态与副作用是重计算的高频陷阱

随机状态决定 Dropout 等随机计算的结果，副作用是函数对返回值之外状态的修改。重计算会再执行前向区段，因此两者都可能使它偏离原计算。需要定义哪些状态被保留或再次更新。





如果区段包含 Dropout，重算必须采用与原前向相容的随机结果，才能恢复相同函数；框架通常提供随机状态保留机制，但跨设备、特殊随机源或自定义实现仍需核验。一个函数在前向时增加全局计数、更新外部缓存或改变隐藏状态，重算可能再次执行副作用，不能把它视为纯函数。





BatchNorm 运行统计、依赖全局变量的分支和在区段中迁移设备，都可能让第二次求值与第一次不同。默认一致性检查未必逐元素比较完整数值，不能把“不报错”当作严格等价证明。对计划重计算的模块，固定权重与输入，对照输出、每个参数梯度、必要的输入梯度以及状态 buffer，才能发现静默偏差。









### 包进 checkpoint 后只检查输出形状

状态副作用或随机差异可能保持相同 shape，却改变反向结果。

对照无重算与重算路径的数值、逐参数梯度和状态变化；避免不可重入副作用。

## 内存增长可能来自对象生命周期

对象生命周期决定一个带图张量何时仍被引用、其相关存储何时可被释放。持续保存损失或激活可能延长整段计算图寿命。下面区分必要日志、快照与不必要的图引用。





把 loss、预测或带图激活不断放进列表，会让其引用链延长，某些保存对象无法及时释放。日志应保存 item 或 detach 后的必要摘要；若还需要长期保留数据，明确拷贝到合适设备并控制容量。hook 闭包、异常 traceback 和缓存字典也可能持有大 Tensor，不能只检查显式的训练变量。





原地操作、del 和 empty_cache 都不是通用修复。del 只移除一个引用，其他对象仍持有同一存储时不会释放；视图可能共享大张量存储，保留一个小切片也可能间接保留原数据。连续运行相同形状步骤，观察峰值是否稳定，再逐项关闭日志和缓存，是区分常驻峰值与持续增长的有效对照。









## 验证节省量时同时验证计算保持

保存量减少并不自动说明方案可用，梯度改变或重算耗时过大都会影响训练。以同一模型和数据为参照，同时核验计算结果、实际峰值及完整步耗时，才能解释获得的资源收益。





配套代码使用 saved_tensors_hooks 统计为反向保存的逻辑字节，比较普通路径和重计算路径的输出及参数梯度。这个计数不是 CUDA 峰值：同一存储可能被多次逻辑保存，临时工作区与缓存分配器也不在同一口径。CPU 示例能验证保存策略与梯度关系，不能直接声称节省了某个比例的真实 GPU 显存。





检查梯度保持时最好比较全部参数，而不只看最终输出或总范数。重算若在某个分支漏掉依赖，输出可能仍完全相同，却让一个子模块梯度错误。若输入前面有可训练模块，还需同时检查输入梯度，这一点与冻结模块的反向边界相通。





在目标硬件进一步评估时，应比较相同 Batch、序列形状、精度和模型模式，记录完整 step 的峰值、耗时和吞吐。选择收益明确且状态简单的区段，逐步增加覆盖，不要同时改变 Batch 和重计算区域后把所有差异归因于一种技巧。若内存瓶颈主要是优化器状态，激活重计算的收益也会有限。 同时记录额外重算耗时，并说明按相同墙钟时间还是相同训练步数比较收益。





最终方案可能组合较小微批与累积、混合精度、激活重计算和参数状态分片。每项策略都针对不同内存项，先定位再组合，才能解释资源收益及额外通信、计算和实现复杂度。





训练内存优化先问对象在哪里产生、必须保留到何时，再选择冻结、分块或重计算。重计算真正交换的是保存量与计算工作；节省多少和是否仍计算同一目标，应使用各自口径验证。









## 张量形状

| 变量 | 形状 | 含义 |
|---|---|---|
| 总参数与训练参数 | P / Pₜ 个标量 | 冻结影响训练状态数量，但权重通常仍驻留。 |
| 保存张量 | 各层不同 | 反向所需的前向中间结果；重计算减少保存项。 |
| 演示输入 | [32,64] | CPU 上对比同一个 MLP 的输出、梯度与逻辑保存量。 |

## 完整代码与精读

```python
import torch
from torch import nn
from torch.utils.checkpoint import checkpoint

torch.manual_seed(32)
# STEP 1: 两次运行使用同一个模型和同一数据，不进行参数更新
block = nn.Sequential(nn.Linear(64, 128), nn.GELU(),
                      nn.Linear(128, 128), nn.GELU(), nn.Linear(128, 16))
x = torch.randn(32, 64)
target = torch.randn(32, 16)

# STEP 2: hook 统计为反向保存的逻辑字节；这不是 GPU 峰值
def run(use_checkpoint):
    block.zero_grad(set_to_none=True)
    local_x = x.detach().clone().requires_grad_(True)
    saved_bytes = []
    def pack(tensor):
        saved_bytes.append(tensor.numel() * tensor.element_size())
        return tensor
    def unpack(tensor):
        return tensor
    with torch.autograd.graph.saved_tensors_hooks(pack, unpack):
        if use_checkpoint:
            output = checkpoint(block, local_x, use_reentrant=False)
        else:
            output = block(local_x)
        loss = (output - target).square().mean()
    loss.backward()
    grads = [p.grad.detach().clone() for p in block.parameters()]
    return output.detach(), grads, sum(saved_bytes)

# STEP 3: 节省保存量的同时，应保留目标计算与梯度
plain, grad_plain, bytes_plain = run(False)
remat, grad_remat, bytes_remat = run(True)
torch.testing.assert_close(plain, remat)
for a, b in zip(grad_plain, grad_remat):
    torch.testing.assert_close(a, b)
assert bytes_remat < bytes_plain
print('普通前向逻辑保存字节:', bytes_plain)
print('重计算逻辑保存字节:', bytes_remat)
print('通过：输出和参数梯度一致；此数值不是 CUDA 峰值显存')

```

- 第 1–11 行：不调用 optimizer.step，避免两次运行参数不同。模型无随机层，先用最清晰的条件核对重计算机制。
- 第 12–31 行：saved_tensors_hooks 观察反向保存事件；pack 返回原张量，未改变计算。统计可能包含同一存储的多次逻辑引用，不等同于实际内存分配。
- 第 32–41 行：非重入 checkpoint 与普通前向逐输出、逐参数梯度对齐，并显式检查保存量下降。真实 GPU 还要测 memory_allocated、reserved 与峰值。

预期观察：两种前向的输出和全部参数梯度一致；checkpoint 路径的逻辑保存字节更少。数字用于解释机制，不宣称 GPU 节省比例。

## 浏览器 Python 练习

实现 adam_state_bytes(total_params, trainable_params)。两个输入都是非负整数，且训练参数量不大于总量。按 FP32 权重、FP32 梯度、两个 FP32 Adam 矩估计，返回 weights、gradients、moments、total 四个字节数。状态已初始化，不计激活、缓存或临时工作区。非法输入抛 ValueError。

```python
def adam_state_bytes(total_params, trainable_params):
     # TODO: 权重覆盖所有参数；梯度与两个矩估计仅覆盖训练参数
     raise NotImplementedError('请实现 adam_state_bytes')

```

### 提示

- 一个 FP32 标量占 4 字节，Adam 的一阶与二阶矩各一份。
- 冻结不会让模型权重消失；只在本题假设下减少相应梯度与状态。

### 参考实现与解释

```python
def adam_state_bytes(total_params, trainable_params):
    if (not isinstance(total_params, int) or not isinstance(trainable_params, int)
            or total_params < 0 or trainable_params < 0 or trainable_params > total_params):
        raise ValueError('参数数量不合法')
    weights = 4 * total_params
    gradients = 4 * trainable_params
    moments = 8 * trainable_params
    return dict(weights=weights, gradients=gradients, moments=moments,
                total=weights + gradients + moments)

```

本题是注明假设的状态内存账单。全量 FP32 Adam 的这个简化部分是每参数 16 字节，但真实峰值还取决于激活、优化器实现和工作区；不能用计算结果判断一个真实模型一定能装进某张卡。

### 断言测试

```python
assert adam_state_bytes(1000, 100) == dict(weights=4000, gradients=400, moments=800, total=5200)
assert adam_state_bytes(1000, 1000)['total'] == 16000
assert adam_state_bytes(1000, 0)['total'] == 4000
for args in [(1, 2), (-1, 0), (2.5, 1)]:
    try:
        adam_state_bytes(*args)
    except ValueError:
        pass
    else:
        raise AssertionError('应拒绝非法参数数量')
print('通过：全量训练、冻结与数量边界')

```

## 本地 PyTorch 练习

实现 checkpointed_forward(block, x)，调用 activation checkpoint 并返回与 block(x) 等价的结果。要求 use_reentrant=False、保留随机数状态；x 可以不需要梯度，但 block 参数需要梯度。测试包含 Dropout、无输入梯度和保存量检查，不能直接返回普通前向冒充重计算。

```python
import torch
from torch.utils.checkpoint import checkpoint

def checkpointed_forward(block, x):
   # TODO: 使用非重入 checkpoint，保留随机状态
   raise NotImplementedError('请实现 checkpointed_forward')

```

### 提示

- 使用 use_reentrant=False，使 x 不带梯度时仍可训练 block 的参数。
- 随机层的重算需要与第一次使用同一随机状态；保留默认状态或显式 preserve_rng_state=True。

### 参考实现与解释

```python
import torch
from torch.utils.checkpoint import checkpoint

def checkpointed_forward(block, x):
   return checkpoint(block, x, use_reentrant=False, preserve_rng_state=True)

```

单看输出相等不能证明启用了重计算，所以测试额外比较保存事件的逻辑字节。固定种子让普通前向和 checkpoint 的 Dropout 对齐，再比较梯度，能识别反向重算使用错误随机状态的问题。共享存储和缓存没有计入真实峰值。

### 断言测试

```python
torch.manual_seed(320)
block = torch.nn.Sequential(torch.nn.Linear(8, 32), torch.nn.Dropout(0.3),
                            torch.nn.GELU(), torch.nn.Linear(32, 4))
x = torch.randn(5, 8)  # 故意不要求输入梯度
def evaluate(fn):
    block.zero_grad(set_to_none=True)
    sizes = []
    def pack(t):
        sizes.append(t.numel() * t.element_size())
        return t
    torch.manual_seed(321)
    with torch.autograd.graph.saved_tensors_hooks(pack, lambda t: t):
        out = fn(block, x)
        loss = out.square().mean()
    loss.backward()
    return out.detach(), [p.grad.clone() for p in block.parameters()], sum(sizes)
a, ga, na = evaluate(lambda m, v: m(v))
b, gb, nb = evaluate(checkpointed_forward)
torch.testing.assert_close(a, b)
for p, q in zip(ga, gb):
    torch.testing.assert_close(p, q)
assert nb < na, '应真正减少反向保存量'
assert not x.requires_grad
print('PyTorch 通过：无输入梯度、Dropout 一致性与实际重计算')

```

## 练习：推导与分析

### 为什么冻结了大部分参数，训练仍可能占很多显存？

权重本身仍然存在，输入、激活和算子临时内存也没有自动消失。若冻结层上游还有可训练 Adapter，梯度必须穿过冻结层，相关前向信息可能仍要保存。

显存估算把总参数 P 和训练参数 Pₜ 分开；CPU hook 另外观察反向保存量。应先分清参数状态和激活哪个主导，再选择冻结、减序列、减微批次或重计算。

代码定位：adam_state_bytes 的 \(4P\) 与 \(12P_t\)；演示 saved_tensors_hooks。

- 能写出参数状态估算的假设与遗漏项。
- 能解释冻结权重但保留输入梯度的情况。

### 如何证明 checkpoint 既节省保存量，又没有悄悄改变训练？

先固定参数、输入和随机状态，比较普通前向与 checkpoint 的输出及每个训练参数的梯度。再在实际设备上测峰值分配和运行时间，而不是只看到程序能运行。

演示的逻辑保存量说明机制，练习进一步加入 Dropout 和不带梯度的输入，覆盖重算一致性与非重入语义。带全局副作用或可变状态的模块仍需额外审查，因为重算可能不再等价。

代码定位：run(False/True) 与 checkpointed_forward 的梯度、Dropout 和保存量断言。

- 能区分正确性验证和硬件收益测量。
- 能说出至少一种导致重算不一致的状态变化。

## 练习：辨析与纠错

### 模型文件大小乘固定倍数就断言显存够用

状态 dtype、激活、工作区和通信都会改变峰值。列出内存构成并测完整训练步。

### 每步 empty_cache 解决 OOM

它不能释放活跃张量，也可能降低性能。先定位对象生命周期和实际最大分配。

### 重计算区段包含不可重复副作用

重算会再次执行函数，可能改变状态和梯度。检查随机性、buffer 更新与外部缓存，做等价对照。

### 把 saved_tensors_hooks 总字节当显卡峰值

统计口径不同，可能重复计算共享存储且遗漏工作区。标明逻辑保存量，并在 GPU 上独立测峰值。

## 原始资料

- [PyTorch：torch.utils.checkpoint](https://docs.pytorch.org/docs/stable/checkpoint.html)
- [PyTorch：CUDA memory management](https://docs.pytorch.org/docs/stable/notes/cuda.html#memory-management)
- [PyTorch：Activation Checkpointing Techniques](https://pytorch.org/blog/activation-checkpointing-techniques/)
