# 核心专题学习包

MLP、CNN、Transformer、Flow Matching。每个专题的讲义包含推导、代码说明、练习和参考答案。

Python 练习只用标准库；PyTorch 示例默认在 CPU 运行。运行完整文件中的断言来检查结果，正文中的短代码用于验证对应的数学关系。
