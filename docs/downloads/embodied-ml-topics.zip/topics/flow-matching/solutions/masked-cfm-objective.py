# Flow Matching · 手写条件 FM 训练一步：安全 Mask 与条件梯度
# 保留两个明确职责：实现 `cfm_loss(model, noise, actions, t, condition, valid)`，再实现 `cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid)`。形状约定：端点为同 dtype/device 的浮点 \([B,H,D]\)，时间为有限 \([B]\) 且 \(0\le t\le1\)，原始观测为 \([B,C_{\rm in}]\)，`encoder(observations)` 为有限 \([B,C]\)。`valid` 是同设备 bool，可广播为 \([B,H,D]\)，例如 \([B,H,1]\)；本题把它定义为调用方已知的结构有效位，网络接口为 `model(xt,t,condition,expanded_valid)`，输出有限 \([B,H,D]\)。若某个有效位仅在未来轨迹结束后才知道，它只应控制监督，不能直接当作部署可用的输入条件，本题不覆盖这种数据协议。
# 
# 噪声端为 \(t=0\)，数据端为 \(t=1\)。无效端点允许含 NaN，必须在插值乘法、目标减法之前安全替换，不能靠最终乘零掩盖。只平均有效动作标量，拒绝全空监督、非法时间、有效 NaN、错误形状或非有限预测。普通精度的一步训练需要清理旧梯度、编码条件、构造目标、反向和一次更新；保留条件编码器的计算图，返回更新前 loss 的 Python float。优化器由调用者建立，并已包含两个模块中计划训练的全部参数；这里不实现 AMP、累积或自动采样噪声/时间。

import torch


def cfm_loss(model, noise, actions, t, condition, valid):
    if (noise.ndim != 3 or noise.shape != actions.shape or noise.numel() == 0
            or not noise.is_floating_point() or noise.dtype != actions.dtype
            or noise.device != actions.device):
        raise ValueError("noise/actions 必须是同 dtype/device 的非空浮点 [B,H,D]")
    batch = noise.shape[0]
    if (t.shape != (batch,) or t.dtype != noise.dtype or t.device != noise.device
            or not torch.isfinite(t).all() or not ((0 <= t) & (t <= 1)).all()):
        raise ValueError("t 必须是同 dtype/device 的有限 [B]，且在 [0,1]")
    if valid.dtype != torch.bool or valid.device != noise.device:
        raise ValueError("valid 必须是同设备 bool 张量")
    try:
        mask = torch.broadcast_to(valid, noise.shape)
    except RuntimeError as error:
        raise ValueError("valid 不能广播到 [B,H,D]") from error
    count = mask.sum()
    if count.item() == 0:
        raise ValueError("整个更新没有有效监督")
    if (condition.ndim != 2 or condition.shape[0] != batch
            or not torch.isfinite(condition).all()):
        raise ValueError("condition 必须为有限 [B,C]")

    # 在乘法/减法之前选择：无效端点可为 NaN，进入网络的占位统一为 0。
    safe_noise = torch.where(mask, noise, torch.zeros_like(noise))
    safe_actions = torch.where(mask, actions, torch.zeros_like(actions))
    if not torch.isfinite(safe_noise).all() or not torch.isfinite(safe_actions).all():
        raise ValueError("有效端点必须有限")
    time = t[:, None, None]  # 只为路径运算扩维；网络仍接收原始 [B] 时间。
    xt = (1 - time) * safe_noise + time * safe_actions
    target = safe_actions - safe_noise
    prediction = model(xt, t, condition, mask)
    if prediction.shape != actions.shape or not torch.isfinite(prediction).all():
        raise ValueError("网络必须返回有限 [B,H,D]；Loss Mask 不能修复网络内部非法运算")
    # 同样先选元素，再相减/平方。分母统计广播后的有效标量。
    return (prediction[mask] - target[mask]).square().sum() / count


def cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid):
    model.train()
    encoder.train()
    optimizer.zero_grad(set_to_none=True)
    condition = encoder(observations)  # 不 detach：目标必须能训练条件编码器。
    loss = cfm_loss(model, noise, actions, t, condition, valid)
    loss.backward()
    for group in optimizer.param_groups:
        for parameter in group["params"]:
            if parameter.grad is not None and not torch.isfinite(parameter.grad).all():
                raise FloatingPointError("非有限参数梯度；不执行更新")
    optimizer.step()
    return float(loss.detach())  # 更新前目标的数值，不保留日志计算图。


# 断言测试
torch.manual_seed(20261106)
torch.set_num_threads(1)


class ToyVelocity(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.x_weight = torch.nn.Parameter(torch.tensor([.5, -.3], dtype=torch.float64))
        self.c_weight = torch.nn.Parameter(torch.tensor([.2, .4], dtype=torch.float64))
        self.t_weight = torch.nn.Parameter(torch.tensor([.1, -.2], dtype=torch.float64))

    def forward(self, x, t, c, valid):
        assert x.shape == (2, 3, 2) and t.shape == (2,) and c.shape == (2, 1)
        assert valid.shape == x.shape and valid.dtype == torch.bool
        assert torch.isfinite(x).all() and (x[~valid] == 0).all()
        self.last_x, self.last_time, self.last_condition = x, t, c
        return x * self.x_weight + c[:, None, :] * self.c_weight + t[:, None, None] * self.t_weight


encoder = torch.nn.Linear(2, 1, bias=False).double()
with torch.no_grad():
    encoder.weight.copy_(torch.tensor([[.4, -.2]], dtype=torch.float64))
model = ToyVelocity()
observations = torch.tensor([[1., .5], [-.5, 2.]], dtype=torch.float64)
noise = (torch.arange(12, dtype=torch.float64).reshape(2, 3, 2) / 5 - .6)
actions = torch.tensor([[[1., -.2], [.1, .5], [.4, -.7]],
                        [[2., .6], [-.5, 1.2], [-1., .4]]], dtype=torch.float64)
valid = torch.tensor([[[True], [False], [True]], [[False], [True], [False]]])
expanded = valid.expand_as(actions)
noise[~expanded] = float("nan")
actions[~expanded] = float("nan")
# 数据通常不求梯度；这里故意开启以揭示“算出 NaN 后再屏蔽”的隐蔽反向错误。
noise.requires_grad_()
actions.requires_grad_()
t = torch.tensor([.25, .8], dtype=torch.float64, requires_grad=True)
parameters = dict(model.named_parameters())
parameters["encoder.weight"] = encoder.weight
optimizer = torch.optim.SGD(list(parameters.values()), lr=.05)


def manual_reference():
    # 逐标量、用普通数值求导；不对同一向量化实现再调用 Autograd 冒充独立答案。
    n = int(expanded.sum())
    grads = {name: torch.zeros_like(p) for name, p in parameters.items()}
    gn, ga, gt = torch.zeros_like(noise), torch.zeros_like(actions), torch.zeros_like(t)
    total = 0.
    for b in range(2):
        cb = sum(encoder.weight[0, j].item() * observations[b, j].item() for j in range(2))
        tb = t[b].item()
        for h in range(3):
            for d in range(2):
                if not expanded[b, h, d]:
                    continue
                nb, ab = noise[b, h, d].item(), actions[b, h, d].item()
                xt = (1 - tb) * nb + tb * ab
                wx, wc, wt = (getattr(model, name)[d].item()
                              for name in ("x_weight", "c_weight", "t_weight"))
                residual = wx * xt + wc * cb + wt * tb - (ab - nb)
                total += residual * residual / n
                g = 2 * residual / n
                grads["x_weight"][d] += g * xt
                grads["c_weight"][d] += g * cb
                grads["t_weight"][d] += g * tb
                for j in range(2):
                    grads["encoder.weight"][0, j] += g * wc * observations[b, j].item()
                gn[b, h, d] = g * (wx * (1 - tb) + 1)
                ga[b, h, d] = g * (wx * tb - 1)
                gt[b] += g * (wx * (ab - nb) + wt)
    return total, grads, gn, ga, gt


model.eval()
encoder.eval()
for parameter in parameters.values():
    parameter.grad = torch.full_like(parameter, 123.)  # 必须清除旧梯度。
for step in range(2):
    expected_loss, grads, gn, ga, gt = manual_reference()
    before = {name: p.detach().clone() for name, p in parameters.items()}
    noise.grad = actions.grad = t.grad = None
    actual = cfm_train_step(model, encoder, optimizer, observations, noise, actions, t, valid)
    assert isinstance(actual, float) and abs(actual - expected_loss) < 1e-12
    assert model.training and encoder.training
    assert model.last_time is t and model.last_condition.grad_fn is not None
    for name, parameter in parameters.items():
        torch.testing.assert_close(parameter.grad, grads[name], atol=1e-12, rtol=1e-12)
        torch.testing.assert_close(parameter, before[name] - .05 * grads[name], atol=1e-12, rtol=1e-12)
        assert not torch.equal(parameter, before[name])
    for actual_grad, expected_grad in [(noise.grad, gn), (actions.grad, ga), (t.grad, gt)]:
        assert torch.isfinite(actual_grad).all()
        torch.testing.assert_close(actual_grad, expected_grad, atol=1e-12, rtol=1e-12)
    assert (noise.grad[~expanded] == 0).all() and (actions.grad[~expanded] == 0).all()
    print("step", step + 1, "loss", round(actual, 9), "encoder_grad", encoder.weight.grad.tolist())


# 解析平移场：每个条件使数据等于噪声加 c，所以真实速度恒为 c。
class TranslationField(torch.nn.Module):
    def __init__(self, sign=1.):
        super().__init__()
        self.sign = sign
    def forward(self, x, t, c, valid):
        self.last_x = x
        return self.sign * c[:, None, :].expand_as(x)


z = torch.randn(2, 3, 2, dtype=torch.float64)
c = torch.tensor([[2., -1.], [-.5, 3.]], dtype=torch.float64)
a = z + c[:, None, :]
end_times = torch.tensor([0., 1.], dtype=torch.float64)
all_valid = torch.ones(2, 3, 1, dtype=torch.bool)
oracle = TranslationField()
assert cfm_loss(oracle, z, a, end_times, c, all_valid).item() < 1e-28
torch.testing.assert_close(oracle.last_x[0], z[0])
torch.testing.assert_close(oracle.last_x[1], a[1])
wrong = cfm_loss(TranslationField(-1.), z, a, end_times, c, all_valid)
torch.testing.assert_close(wrong, 4 * c.square().mean())

# 坐标有效位不能退化为“每个时间都算 D 个有效元素”。
coordinate_valid = all_valid.expand_as(z).clone()
coordinate_valid[0, 0, 1] = False
coordinate_valid[1, 1:, 0] = False
masked_noise = z.masked_fill(~coordinate_valid, float("nan"))
masked_actions = a.masked_fill(~coordinate_valid, float("nan"))
assert cfm_loss(oracle, masked_noise, masked_actions, end_times, c, coordinate_valid).item() < 1e-28

for bad_time, bad_valid, bad_actions in [
        (end_times, torch.zeros_like(all_valid), a),
        (torch.tensor([-.1, 1.], dtype=torch.float64), all_valid, a),
        (end_times, all_valid, a.clone().index_fill(0, torch.tensor([0]), float("nan"))),
        (end_times, torch.ones(2, 4, dtype=torch.bool), a)]:
    try:
        cfm_loss(oracle, z, bad_actions, bad_time, c, bad_valid)
    except ValueError:
        pass
    else:
        raise AssertionError("未拒绝空监督、非法时间、有效 NaN 或错误 Mask 形状")
print("通过：NaN 前选择、广播、手算梯度、条件编码器更新、两步清零、端点与方向反例")

