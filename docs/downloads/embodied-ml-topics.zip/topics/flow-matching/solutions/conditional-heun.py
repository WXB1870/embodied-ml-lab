# Flow Matching · 实现支持非均匀网格的条件 Heun 采样器
# 实现 `heun_sample(velocity,noise,times,condition)`。`velocity(x,t_batch,condition)` 返回与 \(x\) 同形的速度，`t_batch` 形状为 \([B]\)。times 是至少两个有限且严格单调的时间点，可递增或递减。每步在当前点和候选点各求一次速度；不修改初始输入，采样不记录梯度。用两个解析场分别检验时间与状态依赖。

import torch

@torch.no_grad()
def heun_sample(velocity, noise, times, condition):
    if noise.ndim < 2 or not noise.is_floating_point():
        raise ValueError("noise 必须含 Batch 轴且为浮点张量")
    grid = torch.as_tensor(times,dtype=noise.dtype,device=noise.device)
    if grid.ndim != 1 or grid.numel() < 2 or not torch.isfinite(grid).all():
        raise ValueError("需要至少两个有限时间点")
    deltas = grid[1:]-grid[:-1]
    if not ((deltas > 0).all() or (deltas < 0).all()):
        raise ValueError("时间网格必须严格单调")
    x = noise.clone()
    for left,right in zip(grid[:-1],grid[1:]):
        h = right-left
        t0 = x.new_full((x.shape[0],),left.item())
        t1 = x.new_full((x.shape[0],),right.item())
        k1 = velocity(x,t0,condition)
        if k1.shape != x.shape:
            raise ValueError("速度形状必须等于状态形状")
        candidate = x+h*k1
        k2 = velocity(candidate,t1,condition)
        if k2.shape != x.shape:
            raise ValueError("速度形状必须等于状态形状")
        x = x+0.5*h*(k1+k2)
    return x


# 断言测试
x0 = torch.tensor([[.5,-.2],[1.,2.],[.1,-.3]],dtype=torch.float64,requires_grad=True)
c = torch.tensor([[1.,2.],[0.,-1.],[.5,-.5]],dtype=torch.float64)
original = x0.detach().clone()
calls = []
def time_field(x,t,cond):
    calls.append(t.clone())
    assert cond is c
    return 2*t[:,None]+cond
# dx/dt=2t+c 的解析增量为 (t1²-t0²)+(t1-t0)c。
forward = heun_sample(time_field,x0,[0.,.05,.4,1.],c)
torch.testing.assert_close(forward,original+1+c)
assert len(calls) == 6 and not forward.requires_grad
reverse = heun_sample(time_field,forward,[1.,.8,.3,0.],c)
torch.testing.assert_close(reverse,original)
torch.testing.assert_close(x0,original)
# dx/dt=x：第二阶段必须使用候选状态，不能复用 k1。
steps = 8; h = 1/steps
result = heun_sample(lambda x,t,c:x,x0,torch.linspace(0,1,steps+1,dtype=torch.float64),c)
expected = original*(1+h+h*h/2)**steps
torch.testing.assert_close(result,expected)
for grid in [[0.],[0.,.5,.4,1.],[0.,0.,1.]]:
    try:
        heun_sample(time_field,x0,grid,c)
    except ValueError:
        pass
    else:
        raise AssertionError("非单调或不足的网格未拒绝")
print("通过：非均匀步长、时间依赖、状态依赖、条件、反向积分与 NFE")

