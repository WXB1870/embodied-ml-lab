"""Train conditional 2D flow matching and export reproducible numerical evidence."""
import argparse
import json
import math
import time
from pathlib import Path

import torch
from torch import nn

SEED = 20261106
MEANS = torch.tensor([[[-1.6, -0.6], [1.6, 0.6]],
                      [[-0.6, 1.6], [0.6, -1.6]]])
WEIGHTS = torch.tensor([[0.35, 0.65], [0.65, 0.35]])
DATA_STD = 0.28


# 1. The same condition still has two modes; endpoints are independently paired.
def sample_data(condition, generator=None):
    first = torch.rand(len(condition), generator=generator) < WEIGHTS[condition, 0]
    component = (~first).long()
    return MEANS[condition, component] + DATA_STD * torch.randn(
        len(condition), 2, generator=generator)


def sample_pairs(batch, generator=None):
    condition = torch.randint(2, (batch,), generator=generator)
    noise = torch.randn(batch, 2, generator=generator)
    data = sample_data(condition, generator)
    t = torch.rand(batch, 1, generator=generator)
    return (1 - t) * noise + t * data, t, condition, data - noise


# 2. A learned field and an analytic marginal field, not the sampled pair target.
class Velocity(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, t, condition):
        clock = torch.cat([t, torch.sin(math.pi * t), torch.cos(math.pi * t)], -1)
        context = torch.nn.functional.one_hot(condition, 2).to(x.dtype)
        return self.net(torch.cat([x, clock, context], -1))


def oracle_velocity(x, t, condition):
    means = MEANS.to(x)[condition]                         # [B, K=2, D=2]
    q = (1 - t).square() + (t * DATA_STD).square()          # [B, 1]
    displacement = x[:, None, :] - t[:, :, None] * means
    log_weights = WEIGHTS.to(x)[condition].log()
    logits = log_weights - displacement.square().sum(-1) / (2 * q)
    posterior = logits.softmax(-1)                        # p(component | x,t,c)
    coefficient = (t * DATA_STD**2 - (1 - t)) / q
    component_field = means + coefficient[:, :, None] * displacement
    return (posterior[:, :, None] * component_field).sum(1)


# 3. Both solvers integrate the same field and use the same initial noise.
@torch.no_grad()
def integrate(field, noise, condition, steps, method, record=False):
    if steps < 1 or method not in ("euler", "heun"):
        raise ValueError("positive steps and euler/heun are required")
    x = noise.clone()
    path = [{"t": 0.0, "points": x[:24].tolist()}] if record else []
    h = 1.0 / steps
    for k in range(steps):
        t = x.new_full((len(x), 1), k * h)
        first = field(x, t, condition)
        if method == "heun":
            second = field(x + h * first, t + h, condition)
            x = x + h * (first + second) / 2
        else:
            x = x + h * first
        if record and (k + 1) % max(1, steps // 16) == 0:
            path.append({"t": (k + 1) * h, "points": x[:24].tolist()})
    return x, path


def rms(x, y):
    return (x - y).square().mean().sqrt().item()


# 4. Fixed projections give a finite-sample distribution comparison, not a proof.
def sliced_w2(x, y, directions):
    xp = (x @ directions.T).sort(dim=0).values
    yp = (y @ directions.T).sort(dim=0).values
    return rms(xp, yp)


def run(output, train_steps=1800):
    started = time.perf_counter()
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    model = Velocity()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.002)
    probe = sample_pairs(4096, torch.Generator().manual_seed(SEED + 1))
    with torch.no_grad():
        initial_mse = (model(*probe[:3]) - probe[3]).square().mean().item()
    curve = []
    model.train()
    for step in range(train_steps):
        xt, t, condition, target = sample_pairs(256)
        optimizer.zero_grad(set_to_none=True)
        loss = (model(xt, t, condition) - target).square().mean()
        assert torch.isfinite(loss)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        if (step + 1) % 100 == 0:
            curve.append({"step": step + 1, "batch_mse": loss.item()})
    model.eval()
    with torch.no_grad():
        predicted = model(*probe[:3])
        analytic = oracle_velocity(*probe[:3])
        final_mse = (predicted - probe[3]).square().mean().item()
        oracle_mse = (analytic - probe[3]).square().mean().item()
        field_mse = (predicted - analytic).square().mean().item()
    assert final_mse < initial_mse

    evaluation_rng = torch.Generator().manual_seed(SEED + 2)
    condition = torch.arange(1024) % 2
    noise = torch.randn(1024, 2, generator=evaluation_rng)
    target = sample_data(condition, evaluation_rng)
    directions = torch.randn(32, 2, generator=evaluation_rng)
    directions = directions / directions.norm(dim=-1, keepdim=True)
    # A finite reference also has integration error: check a finer grid.
    learned_reference, _ = integrate(model, noise, condition, 512, "heun")
    learned_finer, _ = integrate(model, noise, condition, 1024, "heun")
    oracle_reference, _ = integrate(oracle_velocity, noise, condition, 1024, "heun")
    oracle_finer, _ = integrate(oracle_velocity, noise, condition, 2048, "heun")
    reference_check = {"learned_512_to_1024_rms": rms(learned_reference, learned_finer),
                       "oracle_1024_to_2048_rms": rms(oracle_reference, oracle_finer)}
    metrics = []
    for method in ("euler", "heun"):
        for steps in (4, 8, 16, 32, 64):
            sampled, _ = integrate(model, noise, condition, steps, method)
            sw = [sliced_w2(sampled[condition == c], target[condition == c], directions)
                  for c in (0, 1)]
            metrics.append({"method": method, "steps": steps,
                            "nfe": steps * (1 if method == "euler" else 2),
                            "solver_rms": rms(sampled, learned_reference),
                            "oracle_rms": rms(sampled, oracle_reference),
                            "conditional_sliced_w2": sw})
    sampled, trajectories = integrate(model, noise, condition, 64, "heun", record=True)
    assert torch.isfinite(sampled).all()
    again, _ = integrate(model, noise, condition, 64, "heun")
    torch.testing.assert_close(sampled, again)
    # An independent scalar ODE checks the solver formulas without any learning.
    scalar = torch.ones(3, 1)
    field = lambda x, t, c: x
    euler, _ = integrate(field, scalar, torch.zeros(3).long(), 8, "euler")
    heun, _ = integrate(field, scalar, torch.zeros(3).long(), 8, "heun")
    exact = torch.full_like(scalar, math.e)
    assert rms(heun, exact) < rms(euler, exact)

    conditions = []
    for c in (0, 1):
        selected = condition == c
        generated = sampled[selected]
        nearest = (generated[:, None, :] - MEANS[c]).square().sum(-1).argmin(-1)
        conditions.append({"id": c, "means": MEANS[c].tolist(),
                           "target_weights": WEIGHTS[c].tolist(),
                           "nearest_mode_fractions": torch.bincount(
                               nearest, minlength=2).div(len(generated)).tolist(),
                           "noise": noise[selected][:200].tolist(),
                           "data": target[selected][:200].tolist(),
                           "generated": generated[:200].tolist()})
    grid = torch.cartesian_prod(torch.linspace(-2.7, 2.7, 11),
                                torch.linspace(-2.7, 2.7, 11))
    fields = []
    with torch.no_grad():
        for c in (0, 1):
            labels = torch.full((len(grid),), c)
            for t_value in (0.2, 0.5, 0.8):
                t = torch.full((len(grid), 1), t_value)
                fields.append({"condition": c, "t": t_value, "points": grid.tolist(),
                               "learned": model(grid, t, labels).tolist(),
                               "oracle": oracle_velocity(grid, t, labels).tolist()})
    # These straight paths are training pairs, distinct from the learned ODE paths.
    pair_rng = torch.Generator().manual_seed(SEED + 3)
    pair_condition = torch.arange(12) % 2
    pair_noise = torch.randn(12, 2, generator=pair_rng)
    pair_data = sample_data(pair_condition, pair_rng)
    result = {
        "seed": SEED, "torch": torch.__version__, "device": "cpu", "dtype": "float32",
        "train_steps": train_steps, "batch_size": 256, "hidden_width": 64,
        "data_std": DATA_STD, "training_curve": curve,
        "probe": {"before_mse": initial_mse, "after_mse": final_mse,
                  "oracle_target_mse": oracle_mse, "learned_to_oracle_field_mse": field_mse},
        "reference_check": reference_check, "metrics": metrics,
        "model_flow_rms": rms(learned_reference, oracle_reference),
        "conditions": conditions, "fields": fields,
        "trajectories": {"condition": condition[:24].tolist(), "states": trajectories},
        "training_pairs": {"condition": pair_condition.tolist(),
                           "noise": pair_noise.tolist(), "data": pair_data.tolist()},
        "seconds": time.perf_counter() - started,
        "limits": [
            "Single seeded CPU experiment; these values are observations, not guarantees.",
            "solver_rms compares to a finite fine-grid solution of the same learned field.",
            "model_flow_rms compares learned and analytic marginal fields with common noise.",
            "Sliced W2 uses 32 fixed directions and 512 samples per condition.",
            "Nearest-mode fractions are a diagnostic, not exact mixture component labels.",
        ],
    }
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"probe": result["probe"], "reference_check": reference_check,
                      "model_flow_rms": result["model_flow_rms"],
                      "metrics": metrics, "seconds": result["seconds"]}, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="fm_mixture_results.json")
    parser.add_argument("--train-steps", type=int, default=1800)
    args = parser.parse_args()
    run(args.output, args.train_steps)

