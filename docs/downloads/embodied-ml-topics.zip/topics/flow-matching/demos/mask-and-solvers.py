import math
import torch

torch.manual_seed(52)
torch.set_num_threads(1)

# 1. 对有效标量元素求均值；先安全选择，再相减与平方。
def masked_mse(prediction, target, valid):
    if prediction.shape != target.shape or valid.dtype != torch.bool:
        raise ValueError("prediction/target 同形，valid 必须为布尔张量")
    valid = torch.broadcast_to(valid, prediction.shape)
    count = valid.sum()
    if count.item() == 0:
        raise ValueError("没有有效监督")
    safe_pred = torch.where(valid, prediction, torch.zeros_like(prediction))
    safe_target = torch.where(valid, target, torch.zeros_like(target))
    if not torch.isfinite(safe_pred).all() or not torch.isfinite(safe_target).all():
        raise ValueError("有效元素必须有限")
    return (safe_pred-safe_target).square().sum() / count

# 2. 两条轨迹分别有 2 和 3 个有效动作标量。
noise = torch.randn(2, 3, 2, dtype=torch.float64)
actions = torch.randn(2, 3, 2, dtype=torch.float64)
t = torch.tensor([0.2, 0.8], dtype=torch.float64)[:, None, None]
xt = (1-t)*noise + t*actions
target = actions-noise
valid_time = torch.tensor([[True, False, False], [True, True, True]])[..., None]
valid_dim = torch.tensor([[True, True], [True, False]])[:, None, :]
valid = valid_time & valid_dim
prediction = torch.zeros_like(xt, requires_grad=True)
loss = masked_mse(prediction, target, valid)
loss.backward()
expected_grad = torch.where(valid, 2*(prediction.detach()-target)/5, 0.)
torch.testing.assert_close(prediction.grad, expected_grad)
assert valid.sum().item() == 5
assert (prediction.grad[~valid] == 0).all()

# 3. 局部均值需按有效元素数加权，才能得到全局均值。
counts = valid.sum((1, 2))
local = torch.stack([masked_mse(prediction[b], target[b], valid[b]) for b in range(2)])
weighted = (local*counts).sum()/counts.sum()
torch.testing.assert_close(weighted, loss)
assert not torch.isclose(local.mean(), loss)
poisoned = target.clone()
poisoned[~valid] = float("nan")
torch.testing.assert_close(masked_mse(prediction, poisoned, valid), loss)
print(f"effective counts={counts.tolist()}, global loss={loss.item():.5f}")

# 4. 解析场 dx/dt=x，用来隔离模型误差与数值积分误差。
@torch.no_grad()
def solve_linear(x0, steps, method):
    if steps <= 0 or method not in ("euler", "heun"):
        raise ValueError("需要正步数和已知方法")
    x = x0.clone()
    h = 1.0/steps
    for _ in range(steps):
        k1 = x
        if method == "euler":
            x = x+h*k1
        else:
            candidate = x+h*k1
            k2 = candidate  # 第二次求值必须在候选点上。
            x = x+0.5*h*(k1+k2)
    return x

initial = torch.tensor([1., -2.], dtype=torch.float64)
exact = initial*math.e
for steps in (4, 8, 16):
    euler_error = (solve_linear(initial, steps, "euler")-exact).abs().max().item()
    heun_error = (solve_linear(initial, steps, "heun")-exact).abs().max().item()
    assert heun_error < euler_error
    print(f"steps={steps}, Euler NFE={steps}, error={euler_error:.6f}; "
          f"Heun NFE={2*steps}, error={heun_error:.6f}")
assert torch.allclose(solve_linear(initial, 1, "euler"), initial*2)
assert torch.allclose(solve_linear(initial, 1, "heun"), initial*2.5)
print("通过：有效分母、Mask 梯度、NaN Padding 隔离和两种积分器")

