import math
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(41)
torch.set_num_threads(1)
MEANS = torch.tensor([[-1.5, -0.7], [1.5, 0.7]])
DATA_STD = 0.35

# 1. 条件数据、独立端点与随机生成时间。
def sample_pairs(batch, generator=None):
    c = torch.randint(0, 2, (batch,), generator=generator)
    x0 = torch.randn(batch, 2, generator=generator)
    x1 = MEANS[c] + DATA_STD * torch.randn(batch, 2, generator=generator)
    t = torch.rand(batch, 1, generator=generator)
    xt = (1 - t) * x0 + t * x1
    return xt, t, c, x1 - x0

# 2. x 为二维向量，时间三维特征，条件为二类 one-hot。
class Velocity(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(7, 64), nn.SiLU(),
                                 nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))

    def forward(self, x, t, c):
        time_features = torch.cat([t, torch.sin(math.pi*t), torch.cos(math.pi*t)], -1)
        condition = F.one_hot(c, num_classes=2).to(x.dtype)
        return self.net(torch.cat([x, time_features, condition], -1))

# 3. 固定独立探针；它不参与参数更新。
model = Velocity()
optimizer = torch.optim.Adam(model.parameters(), lr=0.003)
probe = sample_pairs(2048, torch.Generator().manual_seed(202))
with torch.no_grad():
    before = F.mse_loss(model(*probe[:3]), probe[3]).item()

model.train()
for step in range(500):
    xt, t, c, target = sample_pairs(128)
    optimizer.zero_grad(set_to_none=True)
    loss = F.mse_loss(model(xt, t, c), target)
    assert torch.isfinite(loss)
    loss.backward()
    nn.utils.clip_grad_norm_(model.parameters(), 5.0)
    optimizer.step()

model.eval()
with torch.no_grad():
    after = F.mse_loss(model(*probe[:3]), probe[3]).item()
assert after < before  # 仅是这个固定合成问题的最小训练检查。
print(f"probe MSE: {before:.4f} -> {after:.4f}")

# 4. 本合成高斯例的精确边际速度；不是某个端点配对的专属速度。
def gaussian_velocity(x, t, c):
    mean = MEANS[c]
    variance = (1-t).square() + (t*DATA_STD).square()
    coefficient = (t*DATA_STD**2 - (1-t)) / variance
    return mean + coefficient * (x - t*mean)

with torch.no_grad():
    oracle_loss = F.mse_loss(gaussian_velocity(*probe[:3]), probe[3]).item()
print(f"analytic marginal-field MSE: {oracle_loss:.4f} (not generally zero)")

# 5. 采样只接收初始噪声、条件和网络，不接收真实目标动作。
@torch.no_grad()
def euler_sample(velocity, noise, condition, steps=64):
    if steps <= 0:
        raise ValueError("steps 必须为正")
    x = noise.clone()
    for k in range(steps):
        t = x.new_full((x.shape[0], 1), k / steps)
        x = x + velocity(x, t, condition) / steps
    return x

generator = torch.Generator().manual_seed(303)
noise = torch.randn(1024, 2, generator=generator)
c = torch.arange(1024) % 2
sampled = euler_sample(model, noise, c)
torch.testing.assert_close(sampled, euler_sample(model, noise, c))
assert torch.isfinite(sampled).all()
for label in (0, 1):
    points = sampled[c == label]
    print(f"condition={label}, mean={points.mean(0).tolist()}, std={points.std(0).tolist()}")

# 6. 解析场的流为 t*mean+sqrt(variance)*noise；用它单独检查积分误差。
oracle_samples = euler_sample(gaussian_velocity, noise, c, steps=256)
exact_terminal = MEANS[c] + DATA_STD * noise
error = (oracle_samples - exact_terminal).abs().max().item()
assert error < 0.04
print(f"analytic-field Euler max error: {error:.5f}")
print("通过：训练更新、确定性采样、条件分组和解析 ODE 对照")

