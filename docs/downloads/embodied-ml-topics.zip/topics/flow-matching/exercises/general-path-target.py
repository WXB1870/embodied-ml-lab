# Flow Matching · 手写一般概率路径：系数导数与 Gaussian 边际场
# 实现 `affine_path(noise, data, t, schedule)` 和 `gaussian_marginal_velocity(x, t, mean, std, schedule)`。端点与状态为有限浮点 \([B,H,D]\)，时间为同 dtype/device 的 \([B]\) 且在 \([0,1]\)。`schedule(t)` 返回四个同形 \([B]\) 张量，依次表示 \(\alpha(t),\sigma(t),\dot\alpha(t),\dot\sigma(t)\)；导数已经给定，不允许把一般路径硬编码成 `data-noise`。第一函数返回 \(X_t=\alpha_tX_1+\sigma_tX_0\) 及其固定端点时间导数，保持 \([B,H,D]\)。
# 
# 第二函数假设 \(X_0\sim\mathcal N(0,I)\)、\(X_1\sim\mathcal N(\mu,\operatorname{diag}(s^2))\)，端点相互独立；`mean/std` 均为 \([D]\)，标准差严格为正。请从联合高斯条件均值推导并实现边际速度，不能用当前采样端点的单条速度代替它。逐坐标路径方差 \(q_d(t)=\sigma_t^2+\alpha_t^2s_d^2\) 必须有限且为正。默认生成方向要求 \((\alpha_0,\sigma_0)=(0,1)\)、\((\alpha_1,\sigma_1)=(1,0)\)；函数本身根据传入系数计算，反向时钟测试会明确调换这一方向。形状不符或退化方差应拒绝。 本题将整个 \(H D\) 维动作块展平理解：每个端点内部的全部时间位置与坐标均相互独立，`mean/std` 在 \(H\) 轴共享，分别广播至 \([B,H,D]\)。不能将逐坐标公式直接用于带跨时刻协方差的联合动作分布。

import torch


def affine_path(noise, data, t, schedule):
    # TODO: 验证四组 [B] 系数，扩展到 [B,1,1]。
    # TODO: 分别组合状态和固定端点的时间导数。
    raise NotImplementedError("请实现一般仿射条件路径")


def gaussian_marginal_velocity(x, t, mean, std, schedule):
    # TODO: 推导 E[X_t]、E[U_t]、Var(X_t) 和 Cov(U_t,X_t)。
    # TODO: 用联合高斯条件均值；不要除以 alpha 或 sigma 来制造端点奇异。
    raise NotImplementedError("请实现对应的 Gaussian 边际速度")


# 断言测试
import math

torch.manual_seed(20261107)
torch.set_num_threads(1)
noise = torch.randn(2, 3, 4, dtype=torch.float64)
data = torch.randn_like(noise) + .7
t = torch.tensor([.2, .7], dtype=torch.float64)


def linear(t):
    return t, 1 - t, torch.ones_like(t), -torch.ones_like(t)


def cosine(t):
    angle = math.pi * t / 2
    return angle.sin(), angle.cos(), (math.pi / 2) * angle.cos(), -(math.pi / 2) * angle.sin()


# 路径导数来自固定端点求导；非线性系数不能继续返回 data-noise。
xt, velocity = affine_path(noise, data, t, cosine)
eps = 1e-6
left = affine_path(noise, data, t - eps, cosine)[0]
right = affine_path(noise, data, t + eps, cosine)[0]
torch.testing.assert_close(velocity, (right - left) / (2 * eps), atol=1e-8, rtol=1e-8)
assert not torch.allclose(velocity, data - noise)
for endpoint, expected in [(0., noise), (1., data)]:
    state, _ = affine_path(noise, data, torch.full_like(t, endpoint), cosine)
    torch.testing.assert_close(state, expected, atol=1e-14, rtol=1e-14)

# 时间重参数化 t=s²；速度需要链式法则因子 2s。
def quadratic(s):
    return s.square(), 1 - s.square(), 2 * s, -2 * s


state_s, speed_s = affine_path(noise, data, t, quadratic)
state_t, speed_t = affine_path(noise, data, t.square(), linear)
torch.testing.assert_close(state_s, state_t)
torch.testing.assert_close(speed_s, 2 * t[:, None, None] * speed_t)

# 反向时钟 s=1-t：端点与速度同时转换，负步长把样本送往数据。
def reversed_linear(s):
    return 1 - s, s, -torch.ones_like(s), torch.ones_like(s)


reverse_x, reverse_v = affine_path(noise, data, 1 - t, reversed_linear)
forward_x, forward_v = affine_path(noise, data, t, linear)
torch.testing.assert_close(reverse_x, forward_x)
torch.testing.assert_close(reverse_v, -forward_v)
torch.testing.assert_close(noise + (-1.) * reverse_v, data)
assert not torch.allclose(noise + reverse_v, data)

# 独立 Gaussian 端点的解析流，直接对轨迹做差分来核对边际场。
mean = torch.tensor([1., -.5, .3, 2.], dtype=torch.float64)
std = torch.tensor([.4, 1.2, .7, 1.5], dtype=torch.float64)
z = torch.randn_like(noise)

def exact_flow(time):
    alpha, sigma, _, _ = cosine(time)
    alpha, sigma = alpha[:, None, None], sigma[:, None, None]
    variance = sigma.square() + alpha.square() * std.square()
    return alpha * mean + variance.sqrt() * z


state = exact_flow(t)
field = gaussian_marginal_velocity(state, t, mean, std, cosine)
finite_difference = (exact_flow(t + eps) - exact_flow(t - eps)) / (2 * eps)
torch.testing.assert_close(field, finite_difference, atol=1e-8, rtol=1e-8)
# alpha=0 或 sigma=0 不自动导致此公式奇异；关键是总路径方差 q>0。
for endpoint in (0., 1.):
    time = torch.full_like(t, endpoint)
    assert torch.isfinite(gaussian_marginal_velocity(exact_flow(time), time, mean, std, cosine)).all()
# 相同单位方差端点的线性路径在 t=.5 处协方差斜率为零，速度恒为 mean。
mid = torch.full_like(t, .5)
mid_field = gaussian_marginal_velocity(state, mid, mean, torch.ones_like(std), linear)
torch.testing.assert_close(mid_field, mean.expand_as(state))

def degenerate(t):
    zero = torch.zeros_like(t)
    return zero, zero, zero, zero


for call in [lambda: gaussian_marginal_velocity(state, t, mean, std, degenerate),
             lambda: gaussian_marginal_velocity(state, t, mean, torch.zeros_like(std), cosine),
             lambda: affine_path(noise, data, t, lambda time: (time[:1],) * 4)]:
    try:
        call()
    except ValueError:
        pass
    else:
        raise AssertionError("未拒绝退化方差、零标准差或错误 Batch 系数")
print("通过：一般路径导数、端点、时间链式法则、方向反例和解析 Gaussian 边际场")

