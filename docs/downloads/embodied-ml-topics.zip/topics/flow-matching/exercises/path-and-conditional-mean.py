# Flow Matching · 手写条件路径与加权最优速度
# 仅用 Python 标准库实现 `linear_path(noise,data,t)`，返回线性插值和对 \(t\) 的速度；再实现 `conditional_mean_velocity(velocities,weights)`。weights 表示在给定 \(x\),\(t\),\(c\) 下各隐藏端点配对的相对后验权重，需返回平方误差下的最优速度。拒绝维度不一致、负权重、零总权重或越界时间。

import math

def linear_path(noise, data, t):
    # TODO: 插值与时间导数
    raise NotImplementedError("请实现线性条件路径")

def conditional_mean_velocity(velocities, weights):
    # TODO: 每个速度分量按条件权重求平均
    raise NotImplementedError("请实现条件平均速度")


# 断言测试
noise, data = [-1.,2.], [3.,0.]
assert linear_path(noise,data,0)[0] == noise
assert linear_path(noise,data,1)[0] == data
xt, velocity = linear_path(noise,data,.25)
assert xt == [0.,1.5] and velocity == [4.,-2.]
eps = 1e-5
left, _ = linear_path(noise,data,.4-eps)
right, _ = linear_path(noise,data,.4+eps)
assert all(abs((r-l)/(2*eps)-v) < 1e-8 for l,r,v in zip(left,right,velocity))
# 给定同一 x,t,c 后，两个隐藏配对的后验权重为 1:3。
mean = conditional_mean_velocity([[2.,0.],[-4.,4.]],[1.,3.])
assert mean == [-2.5,3.]
assert conditional_mean_velocity([[2.,0.],[-4.,4.]],[2.,6.]) == mean
def risk(v):
    return sum(w*sum((p-u)**2 for p,u in zip(v,target))
               for w,target in zip([1.,3.],[[2.,0.],[-4.,4.]]))/4
assert risk(mean) < risk([-1.,2.])  # 无权平均并不是这个分布的最优解。
for call in [lambda:linear_path([0.],[1.],1.1),
             lambda:conditional_mean_velocity([[1.]],[0.]),
             lambda:conditional_mean_velocity([[1.],[2.]],[1.,-1.])]:
    try:
        call()
    except ValueError:
        pass
    else:
        raise AssertionError("无效输入未拒绝")
print("通过：端点、时间导数、条件加权平均与边界")

