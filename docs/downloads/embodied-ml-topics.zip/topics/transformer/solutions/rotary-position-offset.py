# Transformer：注意力、残差与序列建模 · 手写 RoPE：通道配对、相对位置与缓存偏移
# 实现 `rotary_pairs(x,positions,base=10000.0)`，输入为有限浮点 `[B,H,T,d_h]`，头宽为正偶数，positions 为长度 T 的一维全局位置。对相邻通道 (0,1)、(2,3)… 使用 \(\omega_r=\mathrm{base}^{-2r/d_h}\) 旋转，保持形状和计算图，不调用现成 RoPE 或复数快捷实现。输出仍是 `[B,H,T,d_h]`；位置可从非零值开始。非法头宽、位置长度与非正或非有限 base 抛 ValueError。
# 
# 先完成代码，再解释：为什么同一段历史 Key 不能重复旋转？为什么拼接两个局部从零编号的片段，不等价于全局编号？共同平移的点积不变性需要固定哪些内容？

import math
import torch

def rotary_pairs(x, positions, base=10000.0):
    if x.ndim != 4 or x.shape[-1] < 2 or x.shape[-1] % 2:
        raise ValueError("x must be [B,H,T,even_dh]")
    if positions.ndim != 1 or len(positions) != x.shape[-2]:
        raise ValueError("positions must have one entry per token")
    if not math.isfinite(base) or base <= 0:
        raise ValueError("base must be finite and positive")
    freq = base ** (-torch.arange(0, x.shape[-1], 2,
                                  device=x.device, dtype=x.dtype) / x.shape[-1])
    angle = positions.to(device=x.device, dtype=x.dtype)[:, None] * freq[None, :]
    cos, sin = angle.cos()[None, None], angle.sin()[None, None]
    even, odd = x[..., 0::2], x[..., 1::2]
    return torch.stack((even*cos - odd*sin, even*sin + odd*cos), -1).flatten(-2)


# 断言测试
torch.manual_seed(37)
torch.set_num_threads(1)
dtype=torch.float64
x=torch.randn(2, 2, 4, 4, dtype=dtype, requires_grad=True)
positions=torch.arange(7,11)
y=rotary_pairs(x,positions)
# Independent reference uses explicit 2x2 matrices, not even/odd broadcasting.
reference=[]
for t,p in enumerate(positions.tolist()):
    pairs=[]
    for r in range(2):
        angle=p * 10000.0 ** (-2*r/4)
        c,s=math.cos(angle),math.sin(angle)
        rotation=torch.tensor([[c,-s],[s,c]],dtype=dtype)
        pairs.append(x[:,:,t,2*r:2*r+2] @ rotation.T)
    reference.append(torch.cat(pairs,-1))
reference=torch.stack(reference,dim=2)
torch.testing.assert_close(y,reference,atol=1e-12,rtol=1e-10)
torch.testing.assert_close(y.square().sum(-1),x.square().sum(-1))
probe=torch.randn_like(y)
g1=torch.autograd.grad((y*probe).sum(),x,retain_graph=True)[0]
g2=torch.autograd.grad((reference*probe).sum(),x)[0]
torch.testing.assert_close(g1,g2,atol=1e-12,rtol=1e-10)
# Cached pieces use global positions 7..8 and 9..10, never 0..1 twice.
chunked=torch.cat([rotary_pairs(x[:,:,:2],positions[:2]),
                   rotary_pairs(x[:,:,2:],positions[2:])],dim=2)
torch.testing.assert_close(chunked,y)
wrong=rotary_pairs(x[:,:,2:],torch.arange(2))
assert not torch.allclose(wrong,y[:,:,2:])
# Hold q,k content fixed. A common shift preserves every cross-position dot.
q=torch.randn(2,2,4,4,dtype=dtype)
k=torch.randn(2,2,4,4,dtype=dtype)
q0,k0=rotary_pairs(q,positions),rotary_pairs(k,positions)
q1,k1=rotary_pairs(q,positions+5),rotary_pairs(k,positions+5)
torch.testing.assert_close(q0@k0.transpose(-2,-1),q1@k1.transpose(-2,-1),
                           atol=1e-12,rtol=1e-10)
for bad, pos in [(torch.zeros(1,1,2,3),torch.arange(2)),
                 (torch.zeros(1,1,2,4),torch.arange(3))]:
    try:
        rotary_pairs(bad,pos)
        raise AssertionError("invalid shape must fail")
    except ValueError:
        pass
print("passed: explicit rotations, norm, gradients, global offset, relative shift")

