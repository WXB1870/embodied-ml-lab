# Transformer：注意力、残差与序列建模 · 修复 KV Cache 的非方形因果偏移
# 实现 `append_causal_attention(q_new,k_new,v_new,past_k=None,past_v=None)`，返回当前 Query 输出及追加后的 K/V 缓存。采用标准 MHA，所有 token 有效、无 Dropout；本次 Q/K/V 长度相同，可能一次追加多个 token。输入已完成位置编码与投影，函数只负责缓存和带全局偏移的因果 Mask。不原地改旧缓存，不 `detach`，以便用梯度检查分块等价性。

import torch
from torch.nn import functional as F

def append_causal_attention(q_new, k_new, v_new, past_k=None, past_v=None):
    if (past_k is None) != (past_v is None):
        raise ValueError("both caches must be provided together")
    if q_new.shape[-2] != k_new.shape[-2] or k_new.shape[-2] < 1:
        raise ValueError("need matching nonempty new query/key lengths")
    if k_new.shape[:3] != v_new.shape[:3]:
        raise ValueError("new key/value batch, heads and length must match")
    past_len = 0 if past_k is None else past_k.shape[-2]
    keys = k_new if past_k is None else torch.cat([past_k,k_new],dim=-2)
    values = v_new if past_v is None else torch.cat([past_v,v_new],dim=-2)
    q_pos = past_len + torch.arange(q_new.shape[-2],device=q_new.device)
    k_pos = torch.arange(keys.shape[-2],device=q_new.device)
    allowed = k_pos[None,:] <= q_pos[:,None]
    output = F.scaled_dot_product_attention(
        q_new,keys,values,attn_mask=allowed,dropout_p=0.0)
    return output,keys,values


# 断言测试
torch.manual_seed(34)
q = torch.randn(2,2,6,4,dtype=torch.float64,requires_grad=True)
k = torch.randn(2,2,6,4,dtype=torch.float64,requires_grad=True)
v = torch.randn(2,2,6,3,dtype=torch.float64,requires_grad=True)
full = F.scaled_dot_product_attention(q,k,v,is_causal=True,dropout_p=0.0)
pk = pv = None
pieces = []
start = 0
for size in (2,1,3):
    old_k = None if pk is None else pk.detach().clone()
    old_handle = pk
    z,pk,pv = append_causal_attention(q[:,:,start:start+size],
        k[:,:,start:start+size],v[:,:,start:start+size],pk,pv)
    if old_k is not None:
        torch.testing.assert_close(old_handle,old_k)
    pieces.append(z)
    start += size
    assert pk.shape[-2] == start and pv.shape[-2] == start
streamed = torch.cat(pieces,dim=2)
torch.testing.assert_close(streamed,full,atol=1e-10,rtol=1e-8)
probe = torch.randn_like(full)
g_stream = torch.autograd.grad((streamed*probe).sum(),(q,k,v),retain_graph=True)
g_full = torch.autograd.grad((full*probe).sum(),(q,k,v))
for a,b in zip(g_stream,g_full):
    assert torch.isfinite(a).all()
    torch.testing.assert_close(a,b,atol=1e-10,rtol=1e-8)
# P=3,L=1: zero scores imply a mean over all four values, not just key zero.
qn = torch.zeros(1,1,1,2,dtype=torch.float64)
kn = torch.zeros_like(qn)
vn = torch.tensor([[[[40.]]]],dtype=torch.float64)
old_k = torch.zeros(1,1,3,2,dtype=torch.float64)
old_v = torch.tensor([[[[10.],[20.],[30.]]]],dtype=torch.float64)
answer,_,_ = append_causal_attention(qn,kn,vn,old_k,old_v)
torch.testing.assert_close(answer,torch.tensor([[[[25.]]]],dtype=torch.float64))
try:
    append_causal_attention(qn,kn,vn,old_k,None)
    raise AssertionError("partial cache must be rejected")
except ValueError:
    pass
print("passed: multi-chunk forward, gradients, history offset, immutable cache")

