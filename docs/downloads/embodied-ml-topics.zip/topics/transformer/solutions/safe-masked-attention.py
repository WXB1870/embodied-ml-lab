# Transformer：注意力、残差与序列建模 · 实现具有空行处理约定的注意力核心
# 实现 `masked_attention(q,k,v,allowed)`。输入 `q:[B,H,L,E]`、`k:[B,H,S,E]`、`v:[B,H,S,E_v]` 为有限浮点数，\(S,E>0\)；`allowed` 是可广播到 `[B,H,L,S]` 的布尔 Tensor，`True` 为可见。沿 Key 维稳定归一化，返回 `[B,H,L,E_v]`；没有可见 Key 的 Query 返回零，前向和反向都不能产生 NaN。不得调用 SDPA 或 MultiheadAttention。

import math
import torch

def masked_attention(q, k, v, allowed):
    if q.ndim != 4 or k.ndim != 4 or v.ndim != 4:
        raise ValueError("expected [B,H,length,features] tensors")
    if q.shape[:2] != k.shape[:2] or k.shape[:3] != v.shape[:3]:
        raise ValueError("batch/head/key lengths must match")
    if q.shape[-1] != k.shape[-1] or q.shape[-1] < 1 or k.shape[-2] < 1:
        raise ValueError("need matching nonempty query/key features and keys")
    if allowed.dtype != torch.bool:
        raise ValueError("allowed must be boolean: True means visible")
    scores = q @ k.transpose(-2, -1) / math.sqrt(q.shape[-1])
    allowed = torch.broadcast_to(allowed, scores.shape)
    has_key = allowed.any(-1, keepdim=True)
    masked = scores.masked_fill(~allowed, float("-inf"))
    safe = torch.where(has_key, masked, torch.zeros_like(masked))
    weights = safe.softmax(-1).masked_fill(~allowed, 0.0)
    return weights @ v


# 断言测试
torch.manual_seed(21)
q = torch.randn(2,2,3,3,dtype=torch.float64,requires_grad=True)
k = torch.randn(2,2,4,3,dtype=torch.float64,requires_grad=True)
v = torch.randn(2,2,4,2,dtype=torch.float64,requires_grad=True)
allowed = torch.ones(2,1,3,4,dtype=torch.bool)
allowed[..., -1] = False
allowed[0,:,0,1:] = False
allowed[1,:,-1,:] = False
actual = masked_attention(q,k,v,allowed)
# Independent oracle: select only legal keys before normalizing.
expanded = allowed.expand(2,2,3,4)
batches = []
for b in range(2):
    heads = []
    for h in range(2):
        rows = []
        for i in range(3):
            indices = expanded[b,h,i].nonzero().flatten()
            if len(indices):
                score = k[b,h,indices] @ q[b,h,i] / math.sqrt(3)
                row = (score.softmax(0)[:,None] * v[b,h,indices]).sum(0)
            else:
                zero = (q[b,h,i].sum()+k[b,h].sum()+v[b,h].sum())*0
                row = zero.expand(v.shape[-1])
            rows.append(row)
        heads.append(torch.stack(rows))
    batches.append(torch.stack(heads))
reference = torch.stack(batches)
torch.testing.assert_close(actual,reference,atol=1e-10,rtol=1e-8)
probe = torch.randn_like(actual)
g_actual = torch.autograd.grad((actual*probe).sum(),(q,k,v),retain_graph=True)
g_reference = torch.autograd.grad((reference*probe).sum(),(q,k,v))
for a,b in zip(g_actual,g_reference):
    assert torch.isfinite(a).all()
    torch.testing.assert_close(a,b,atol=1e-10,rtol=1e-8)
assert torch.equal(actual[1,:,-1],torch.zeros(2,2,dtype=torch.float64))
changed_k,changed_v = k.detach().clone(),v.detach().clone()
changed_k[:,:,-1] += 1000
changed_v[:,:,-1] -= 1000
torch.testing.assert_close(masked_attention(q.detach(),changed_k,changed_v,allowed),
                           actual.detach(),atol=1e-10,rtol=1e-8)
# A 2D mask must broadcast over independent samples and heads.
small = torch.tensor([[True,False,False,False]]*3)
broadcast_result = masked_attention(q.detach(),k.detach(),v.detach(),small)
torch.testing.assert_close(broadcast_result,v.detach()[:,:,:1].expand(2,2,3,2))
print("passed: selected-key oracle, gradients, empty rows, padding, broadcasting")

