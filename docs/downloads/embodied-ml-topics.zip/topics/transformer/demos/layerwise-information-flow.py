import math
import torch
from torch.nn import functional as F

torch.manual_seed(43)
torch.set_num_threads(1)
dtype = torch.float64
T, D, P = 4, 4, 2  # one sample; token, channel, prefix lengths
x = torch.randn(T, D, dtype=dtype)
weights = []
for _ in range(2):
    weights.append({name: torch.randn(*shape, dtype=dtype) / math.sqrt(shape[-1])
                    for name, shape in [('q',(D,D)), ('k',(D,D)), ('v',(D,D)),
                                        ('o',(D,D)), ('up',(8,D)), ('down',(D,8))]})

def block(z, allowed, w):
    normalized = F.layer_norm(z, (D,))  # each token separately
    q, k, v = [F.linear(normalized, w[name]) for name in ('q','k','v')]
    logits = q @ k.T / math.sqrt(D)
    assert bool(allowed.any(-1).all())
    attention = logits.masked_fill(~allowed, float('-inf')).softmax(-1)
    h = z + 0.25 * F.linear(attention @ v, w['o'])
    return h + 0.1 * F.linear(F.gelu(F.linear(F.layer_norm(h, (D,)), w['up'])), w['down'])

def forward(z, masks):
    states = [z]
    for allowed, w in zip(masks, weights):
        states.append(block(states[-1], allowed, w))
    return states

def possible_dependencies(masks):
    # Boolean-semiring composition; rows are output tokens, columns input tokens.
    reach = torch.eye(T, dtype=torch.bool)
    identity = torch.eye(T, dtype=torch.bool)
    for mask in masks:
        local = mask | identity  # residual preserves the same position
        reach = (local.to(torch.int64) @ reach.to(torch.int64)) > 0
    return reach

def token_jacobian_norms(masks):
    jac = torch.autograd.functional.jacobian(lambda z: forward(z, masks)[-1], x)
    # jac: [out_token,out_channel,in_token,in_channel]
    norm = jac.permute(0, 2, 1, 3).abs().amax(dim=(-1, -2))
    return jac, norm

causal = torch.ones(T, T, dtype=torch.bool).tril()
leaky_first = causal.clone()
leaky_first[0, 3] = True  # layer one writes future token 3 into token 0
safe_masks, leaky_masks = [causal, causal], [leaky_first, causal]
jsafe, nsafe = token_jacobian_norms(safe_masks)
jleak, nleak = token_jacobian_norms(leaky_masks)
for masks, norms in [(safe_masks, nsafe), (leaky_masks, nleak)]:
    reachable = possible_dependencies(masks)
    assert bool((norms[~reachable] < 1e-12).all())
assert not bool(causal[1, 3]) and bool(possible_dependencies(leaky_masks)[1, 3])
assert nsafe[1, 3] == 0 and nleak[1, 3] > 1e-8

changed = x.clone()
changed[3, 0] += 0.7
before, after = forward(x, safe_masks)[-1], forward(changed, safe_masks)[-1]
torch.testing.assert_close(before[:3], after[:3], atol=1e-12, rtol=1e-10)
assert (forward(x, leaky_masks)[-1][1] - forward(changed, leaky_masks)[-1][1]).norm() > 1e-8
# A finite-difference probe independently checks one indirect derivative.
epsilon = 1e-5
plus, minus = x.clone(), x.clone()
plus[3, 0] += epsilon
minus[3, 0] -= epsilon
fd = (forward(plus, leaky_masks)[-1][1, 0] - forward(minus, leaky_masks)[-1][1, 0]) / (2 * epsilon)
torch.testing.assert_close(fd, jleak[1, 0, 3, 0], atol=1e-8, rtol=1e-5)

# Fixed-prefix cache: both prefix states and projected K/V must stay invariant.
prefix_mask = torch.ones(T, T, dtype=torch.bool)
prefix_mask[:P, P:] = False
bad_prefix_mask = prefix_mask.clone()
bad_prefix_mask[0, -1] = True

def prefix_kv_after_first(z, first_mask):
    first = block(z, first_mask, weights[0])
    normalized_prefix = F.layer_norm(first[:P], (D,))
    return [F.linear(normalized_prefix, weights[1][name]) for name in ('k','v')]

for a, b in zip(prefix_kv_after_first(x, prefix_mask),
                prefix_kv_after_first(changed, prefix_mask)):
    torch.testing.assert_close(a, b, atol=1e-12, rtol=1e-10)
bad_a = prefix_kv_after_first(x, bad_prefix_mask)
bad_b = prefix_kv_after_first(changed, bad_prefix_mask)
assert all((a-b).abs().max() > 1e-8 for a,b in zip(bad_a,bad_b))
print('causal future derivative:', nsafe[1, 3].item())
print('indirect future derivative:', nleak[1, 3].item())
print('finite-difference error:', abs(fd-jleak[1, 0, 3, 0]).item())
print('passed: reachability, Jacobian support, perturbation, prefix KV invariance')

