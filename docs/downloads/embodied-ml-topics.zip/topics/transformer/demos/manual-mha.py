import math
import torch
from torch.nn import functional as F

torch.manual_seed(7)
torch.set_num_threads(1)
DTYPE = torch.float64

def split_heads(x, heads):
    b, length, width = x.shape
    if width % heads:
        raise ValueError("width must be divisible by heads")
    return x.reshape(b, length, heads, width // heads).transpose(1, 2)

def attention_core(q, k, v, allowed, backend):
    # allowed: [B, 1, L, S], True means visible.
    has_key = allowed.any(-1, keepdim=True)
    if backend == "manual":
        score = (q @ k.transpose(-2, -1)) / math.sqrt(q.shape[-1])
        score = score.masked_fill(~allowed, float("-inf"))
        safe_score = torch.where(has_key, score, torch.zeros_like(score))
        weight = safe_score.softmax(-1).masked_fill(~allowed, 0.0)
        return weight @ v, weight
    if backend != "sdpa":
        raise ValueError("unknown backend")
    # Give empty rows one temporary key, then explicitly zero their output.
    first_key = torch.arange(k.shape[-2], device=k.device) == 0
    safe_allowed = allowed | (~has_key & first_key)
    z = F.scaled_dot_product_attention(
        q, k, v, attn_mask=safe_allowed, dropout_p=0.0)
    return torch.where(has_key, z, torch.zeros_like(z)), None

def multihead(x, context, wq, wk, wv, wo, allowed, heads, backend):
    q = split_heads(F.linear(x, wq), heads)
    k = split_heads(F.linear(context, wk), heads)
    v = split_heads(F.linear(context, wv), heads)
    per_head, weights = attention_core(q, k, v, allowed, backend)
    b, _, length, _ = per_head.shape
    merged = per_head.transpose(1, 2).reshape(b, length, -1)
    # No output bias: our zero-attention row stays exactly zero here.
    return F.linear(merged, wo), weights

b, l, s, d, heads = 2, 3, 4, 8, 2
raw = [torch.randn(b, l, d, dtype=DTYPE),
       torch.randn(b, s, d, dtype=DTYPE)]
raw += [torch.randn(d, d, dtype=DTYPE) / math.sqrt(d) for _ in range(4)]
left = [x.clone().requires_grad_() for x in raw]
right = [x.clone().requires_grad_() for x in raw]
allowed = torch.ones(b, 1, l, s, dtype=torch.bool)
allowed[0, :, 0, 1:] = False  # One query can read only the first key.
allowed[1, :, :, -1] = False  # Last context token is padding.
allowed[1, :, -1, :] = False # One query has no valid keys.

manual, weight = multihead(*left, allowed, heads, "manual")
reference, _ = multihead(*right, allowed, heads, "sdpa")
torch.testing.assert_close(manual, reference, atol=1e-10, rtol=1e-8)
expected_row_sum = allowed.any(-1).expand(b, heads, l).to(DTYPE)
torch.testing.assert_close(weight.sum(-1), expected_row_sum)
assert torch.equal(manual[1, -1], torch.zeros(d, dtype=DTYPE))

probe = torch.randn_like(manual)
grad_manual = torch.autograd.grad((manual * probe).sum(), left)
grad_reference = torch.autograd.grad((reference * probe).sum(), right)
for a, z in zip(grad_manual, grad_reference):
    assert torch.isfinite(a).all()
    torch.testing.assert_close(a, z, atol=1e-10, rtol=1e-8)

# A masked context key must not influence any output.
changed_context = raw[1].clone()
changed_context[1, -1] += 1000
changed, _ = multihead(raw[0], changed_context, *raw[2:],
                       allowed, heads, "manual")
torch.testing.assert_close(changed, manual.detach(), atol=1e-10, rtol=1e-8)
# A different sample must not influence sample zero.
changed_x = raw[0].clone()
changed_x[1] += 50
changed, _ = multihead(changed_x, raw[1], *raw[2:],
                       allowed, heads, "manual")
torch.testing.assert_close(changed[0], manual.detach()[0])
print("passed: forward, all six gradients, mask perturbation, batch isolation")
print("Q/K lengths:", l, s, "; output shape:", tuple(manual.shape))

