import json
import math
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(19)
torch.set_num_threads(1)


def apply_rope(x, positions, base=10000.0):
    # x: [B,H,T,dh]. Adjacent channel pairs, column-vector rotation convention.
    if x.shape[-1] % 2 or positions.shape != (x.shape[-2],):
        raise ValueError("RoPE needs an even head width and one position per token")
    inv_freq = base ** (-torch.arange(0, x.shape[-1], 2,
                                    device=x.device, dtype=x.dtype) / x.shape[-1])
    angles = positions.to(dtype=x.dtype)[:, None] * inv_freq[None, :]
    cos, sin = angles.cos()[None, None], angles.sin()[None, None]
    even, odd = x[..., 0::2], x[..., 1::2]
    return torch.stack((even * cos - odd * sin,
                        even * sin + odd * cos), dim=-1).flatten(-2)


class CausalAttention(nn.Module):
    def __init__(self, width=8, heads=2, dropout=0.1):
        super().__init__()
        if width % heads or (width // heads) % 2:
            raise ValueError("width / heads must be an even integer")
        self.heads, self.head_dim = heads, width // heads
        self.dropout_p = dropout
        self.qkv = nn.Linear(width, 3 * width)
        self.out = nn.Linear(width, width)

    def forward(self, x, valid, past=None, inspect=False):
        b, t, d = x.shape
        past_len = 0 if past is None else past[0].shape[-2]
        positions = past_len + torch.arange(t, device=x.device)
        packed = self.qkv(x)  # [B,T,3D] = [2,4,24] in a full pass
        q, k, v = [z.reshape(b, t, self.heads, self.head_dim).transpose(1, 2)
                   for z in packed.chunk(3, dim=-1)]
        q, k = apply_rope(q, positions), apply_rope(k, positions)
        # Cache rotated K, unrotated V. Never rotate old keys a second time.
        keys = k if past is None else torch.cat((past[0], k), dim=-2)
        values = v if past is None else torch.cat((past[1], v), dim=-2)
        key_valid = torch.cat((torch.ones(b, past_len, device=x.device,
                                         dtype=torch.bool), valid), dim=-1)
        key_positions = torch.arange(keys.shape[-2], device=x.device)
        causal = key_positions[None, :] <= positions[:, None]
        allowed = (causal[None, None] & key_valid[:, None, None, :]
                   & valid[:, None, :, None])
        scores = (q @ keys.transpose(-2, -1)) / math.sqrt(self.head_dim)
        has_key = allowed.any(-1, keepdim=True)
        masked = scores.masked_fill(~allowed, -torch.inf)
        safe = torch.where(has_key, masked, torch.zeros_like(masked))
        weights = safe.softmax(-1).masked_fill(~allowed, 0.0)
        per_head = F.dropout(weights, self.dropout_p, self.training) @ values
        merged = per_head.transpose(1, 2).reshape(b, t, d)
        out = self.out(merged).masked_fill(~valid[..., None], 0.0)
        detail = dict(packed=packed, q=q, k=keys, v=values, scores=scores,
                      allowed=allowed, weights=weights, per_head=per_head,
                      merged=merged, attention_output=out) if inspect else None
        return out, (keys, values), detail


class Block(nn.Module):
    def __init__(self, width=8, heads=2, hidden=32):
        super().__init__()
        self.norm1, self.norm2 = nn.LayerNorm(width), nn.LayerNorm(width)
        self.attn = CausalAttention(width, heads)
        self.up, self.down = nn.Linear(width, hidden), nn.Linear(hidden, width)
        self.drop = nn.Dropout(0.1)

    def forward(self, x, valid, past=None, inspect=False):
        n1 = self.norm1(x)
        update, present, detail = self.attn(n1, valid, past, inspect)
        h = x + self.drop(update)
        n2 = self.norm2(h)  # The FFN reads the UPDATED residual state.
        hidden = F.gelu(self.up(n2))
        y = (h + self.drop(self.down(hidden))).masked_fill(~valid[..., None], 0.0)
        if inspect:
            detail.update(norm1=n1, residual1=h, norm2=n2, ffn_hidden=hidden,
                          output=y)
        return y, present, detail


class TinyLM(nn.Module):
    def __init__(self, vocab=7):
        super().__init__()
        self.token = nn.Embedding(vocab, 8)
        self.blocks = nn.ModuleList([Block() for _ in range(2)])
        self.norm = nn.LayerNorm(8)
        self.readout = nn.Linear(8, vocab, bias=False)

    def forward(self, ids, valid=None, past=None, inspect=False):
        if ids.ndim != 2 or ids.shape[1] == 0 or ids.dtype != torch.long:
            raise ValueError("ids must be nonempty int64 [B,T]")
        b, t = ids.shape
        valid = torch.ones_like(ids, dtype=torch.bool) if valid is None else valid
        if valid.dtype != torch.bool or valid.shape != ids.shape:
            raise ValueError("valid must be boolean [B,T]")
        if not bool(valid[:, 0].all()) or bool((valid[:, 1:] & ~valid[:, :-1]).any()):
            raise ValueError("full passes support nonempty, right-padded sequences")
        if past is not None:
            if len(past) != 2 or not bool(valid.all()):
                raise ValueError("cached passes need two layers and no padding")
            lengths = {k.shape[-2] for k, _ in past}
            if len(lengths) != 1:
                raise ValueError("all layers must cache the same history length")
            for k, v in past:
                if k.shape != v.shape or k.shape[:2] != (b, 2) or k.shape[-1] != 4:
                    raise ValueError("each K/V cache must have shape [B,2,P,4]")
        x = self.token(ids).masked_fill(~valid[..., None], 0.0)
        record = dict(embedding=x, blocks=[]) if inspect else None
        presents = []
        for i, block in enumerate(self.blocks):
            x, cache, detail = block(x, valid, None if past is None else past[i], inspect)
            presents.append(cache)
            if inspect:
                record["blocks"].append(detail)
        normalized = self.norm(x)
        logits = self.readout(normalized).masked_fill(~valid[..., None], 0.0)
        if inspect:
            record.update(final_norm=normalized, logits=logits)
        # Padded caches need stored validity/individual position metadata.
        # This small interface returns no reusable cache for a padded pass.
        return logits, (presents if bool(valid.all()) else None), record


def streamed(model, inputs, chunks):
    pieces, cache, start = [], None, 0
    if sum(chunks) != inputs.shape[1] or min(chunks) < 1:
        raise ValueError("chunks must partition the nonempty sequence")
    for size in chunks:
        logits, cache, _ = model(inputs[:, start:start + size], past=cache)
        pieces.append(logits)
        start += size
    return torch.cat(pieces, dim=1), cache


vocab, B, T, D, H, N_LAYERS = 7, 2, 4, 8, 2, 2
sequence = torch.tensor([[0, 1, 2, 3, 4], [3, 4, 5, 6, 0]])
inputs, labels = sequence[:, :-1], sequence[:, 1:]  # Exactly one shift.
model = TinyLM(vocab).double().eval()
full, _, trace = model(inputs, inspect=True)
assert full.shape == (B, T, vocab)
assert trace["blocks"][0]["q"].shape == (B, H, T, D // H)
assert trace["blocks"][0]["ffn_hidden"].shape == (B, T, 32)

# Same network and weights: full, one-token and multi-token cached passes.
cache_errors = {}
for chunks in ((1, 1, 1, 1), (2, 2), (1, 3)):
    cached, cache = streamed(model, inputs, chunks)
    torch.testing.assert_close(cached, full, atol=2e-10, rtol=2e-8)
    assert all(k.shape == v.shape == (B, H, T, D // H) for k, v in cache)
    cache_errors[str(chunks)] = (cached - full).abs().max().item()

# A single scalar probe compares ALL parameter gradients, not only outputs.
probe = torch.randn_like(full)
full_grads = torch.autograd.grad((full * probe).sum(), tuple(model.parameters()),
                                retain_graph=True)
cached, _ = streamed(model, inputs, (1, 3))
cache_grads = torch.autograd.grad((cached * probe).sum(), tuple(model.parameters()))
for a, b in zip(full_grads, cache_grads):
    torch.testing.assert_close(a, b, atol=3e-10, rtol=3e-8)
gradient_error = max((a - b).abs().max().item() for a, b in zip(full_grads, cache_grads))

# Future changes and other batch rows cannot affect earlier predictions.
changed = inputs.clone()
changed[:, 2:] = (changed[:, 2:] + 2) % vocab
torch.testing.assert_close(model(changed)[0][:, :2], full[:, :2])
changed = inputs.clone()
changed[1] = (changed[1] + 1) % vocab
torch.testing.assert_close(model(changed)[0][0], full[0])
g_input = torch.autograd.grad(full[0, :2].square().sum(), trace["embedding"])[0]
assert torch.count_nonzero(g_input[0, 2:]) == 0
assert torch.count_nonzero(g_input[1]) == 0
valid = torch.tensor([[1, 1, 1, 1], [1, 1, 0, 0]], dtype=torch.bool)
padded, padded_cache, _ = model(inputs, valid)
assert padded_cache is None and torch.count_nonzero(padded[1, 2:]) == 0

# Tiny optimization task; a falling CE verifies this training path only.
optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
def evaluate_loss():
    model.eval()
    with torch.no_grad():
        return F.cross_entropy(model(inputs)[0].reshape(-1, vocab), labels.reshape(-1)).item()

before = evaluate_loss()
for _ in range(120):
    model.train()
    optimizer.zero_grad(set_to_none=True)
    logits, _, _ = model(inputs)
    loss = F.cross_entropy(logits.reshape(-1, vocab), labels.reshape(-1))
    loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    optimizer.step()
after = evaluate_loss()
assert after < before * 0.25

# Autoregressive decoding feeds the model's own output back as the next input.
with torch.no_grad():
    generated = inputs[:, :2].clone()
    logits, cache, _ = model(generated)
    for _ in range(3):
        next_id = logits[:, -1].argmax(-1, keepdim=True)
        generated = torch.cat((generated, next_id), dim=1)
        logits, cache, _ = model(next_id, past=cache)
        recomputed = model(generated)[0][:, -1:]
        torch.testing.assert_close(logits, recomputed, atol=2e-10, rtol=2e-8)

summary = dict(seed=19, dimensions=dict(B=B, T=T, D=D, H=H, layers=N_LAYERS),
               block0_shapes={k: list(v.shape) for k, v in trace["blocks"][0].items()},
               parameter_gradient_groups=len(full_grads), cache_errors=cache_errors,
               max_parameter_gradient_error=gradient_error,
               future_input_gradient_max=g_input[0, 2:].abs().max().item(),
               synthetic_ce_before=before, synthetic_ce_after=after,
               greedy_sequences=generated.tolist())
print("TINY_LM_VALIDATION " + json.dumps(summary, sort_keys=True))

