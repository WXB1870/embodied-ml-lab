# Transformer：注意力、残差与序列建模 · 手写 Pre-LN Transformer Block：两条残差与 FFN
# 在题面提供的手写 `ManualSelfAttention` 上实现 `ManualPreLNBlock(width, heads, ff_width, eps)`。MHA 辅助类已完整提供，使本题能独立运行；只需补全 Block。禁止用 `nn.Transformer`、`nn.TransformerEncoderLayer`、`nn.MultiheadAttention` 或 SDPA 代替实现；允许 `nn.LayerNorm`、`nn.Linear` 和 `functional.gelu`。
# 
# 输入／输出均为 `[B,T,D]`，Mask 与前题相同。实现 \(h=x+\operatorname{MHA}(\operatorname{LN}_1(x))\)，再实现 \(y=h+W_2\operatorname{GELU}(W_1\operatorname{LN}_2(h)+b_1)+b_2\)。两次 LayerNorm 仅沿最后通道维归一化，并含独立可训练仿射参数；FFN 中间宽度为 \(D_{\mathrm{ff}}>0\)，使用精确 GELU，无 Dropout，无末尾归一化。注意第二个分支读取更新后的 \(h\)，而不是原输入。
# 
# 沿用题面参数名，校验正整数 `ff_width` 和有限正 `eps`，输入校验同前题。无效位置在完整 Block 输出处清零，全 Padding 输出和梯度仍应有限且为零。参考测试使用官方 Block 只作数值判据，不可在解答中调用。

# Provided helper from the preceding exercise; implement only ManualPreLNBlock.
import math
import torch
from torch import nn


class ManualSelfAttention(nn.Module):
    def __init__(self, width, heads):
        super().__init__()
        if (type(width) is not int or type(heads) is not int
                or width <= 0 or heads <= 0 or width % heads):
            raise ValueError("width/heads must be positive integers, width % heads == 0")
        self.width, self.heads = width, heads
        # Packed row order: Q, K, V; all three projections have a bias.
        self.qkv = nn.Linear(width, 3 * width, bias=True)
        self.out_proj = nn.Linear(width, width, bias=True)

    def forward(self, x, valid=None, causal=False):
        if (x.ndim != 3 or x.shape[-1] != self.width
                or x.shape[0] == 0 or x.shape[1] == 0
                or not x.is_floating_point()):
            raise ValueError("x must be floating [B,T,width], with B,T > 0")
        if type(causal) is not bool:
            raise ValueError("causal must be bool")
        batch, steps, _ = x.shape
        if valid is None:
            valid = torch.ones(batch, steps, dtype=torch.bool, device=x.device)
        if (valid.dtype != torch.bool or valid.shape != (batch, steps)
                or valid.device != x.device):
            raise ValueError("valid must be bool [B,T] on x.device")
        head_dim = self.width // self.heads
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        # Split the channel axis before exchanging token and head axes.
        q, k, v = [z.reshape(batch, steps, self.heads, head_dim)
                    .transpose(1, 2) for z in (q, k, v)]
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(head_dim)
        allowed = valid[:, None, :, None] & valid[:, None, None, :]
        if causal:
            pos = torch.arange(steps, device=x.device)
            allowed = allowed & (pos[None, :] <= pos[:, None])[None, None]
        # Softmax(-inf,...,-inf) is undefined. Normalize a safe row, then
        # set every disallowed weight to zero, including empty query rows.
        has_key = allowed.any(dim=-1, keepdim=True)
        masked = scores.masked_fill(~allowed, -torch.inf)
        safe = torch.where(has_key, masked, torch.zeros_like(masked))
        weights = safe.softmax(dim=-1).masked_fill(~allowed, 0.0)
        per_head = weights @ v
        merged = per_head.transpose(1, 2).reshape(batch, steps, self.width)
        # Mask AFTER the output bias: an empty attention core is insufficient.
        output = self.out_proj(merged).masked_fill(~valid[..., None], 0.0)
        return output, weights


class ManualPreLNBlock(nn.Module):
    def __init__(self, width, heads, ff_width, eps=1e-5):
        super().__init__()
        # TODO 1: validate ff_width and eps; ManualSelfAttention validates width/heads.
        # Preserve names for comparison tests; LayerNorm is over channels only.
        self.attention = ManualSelfAttention(width, heads)
        self.norm1 = nn.LayerNorm(width, eps=eps)
        self.norm2 = nn.LayerNorm(width, eps=eps)
        self.up = nn.Linear(width, ff_width, bias=True)
        self.down = nn.Linear(ff_width, width, bias=True)

    def forward(self, x, valid=None, causal=False):
        # TODO 2: validate nonempty floating x [B,T,D] before applying norms.
        # TODO 3: h = x + MHA(LN1(x)); propagate valid and causal.
        # TODO 4: y = h + down(GELU(up(LN2(h)))); no final normalization.
        # TODO 5: clear invalid positions at the complete block boundary.
        raise NotImplementedError


# 断言测试
# Append below your implementation. The official block is an oracle ONLY.
import json

torch.manual_seed(73)
torch.set_num_threads(1)
dtype = torch.float64
summary = {"seed": 73, "official_cases": [], "checks": []}


def close(a, b):
    torch.testing.assert_close(a, b, atol=3e-10, rtol=3e-8)


for causal in (False, True):
    model = ManualPreLNBlock(6, 3, 11, eps=1e-4).to(dtype=dtype)
    ref = nn.TransformerEncoderLayer(6, 3, dim_feedforward=11,
        dropout=0.0, activation="gelu", layer_norm_eps=1e-4,
        batch_first=True, norm_first=True, bias=True, dtype=dtype)
    # Non-default affine parameters make omitted/reordered norms observable.
    with torch.no_grad():
        for norm in (model.norm1, model.norm2):
            norm.weight.uniform_(0.7, 1.3)
            norm.bias.normal_(0.0, 0.2)
    pairs = [
        (model.attention.qkv.weight, ref.self_attn.in_proj_weight),
        (model.attention.qkv.bias, ref.self_attn.in_proj_bias),
        (model.attention.out_proj.weight, ref.self_attn.out_proj.weight),
        (model.attention.out_proj.bias, ref.self_attn.out_proj.bias),
        (model.norm1.weight, ref.norm1.weight), (model.norm1.bias, ref.norm1.bias),
        (model.norm2.weight, ref.norm2.weight), (model.norm2.bias, ref.norm2.bias),
        (model.up.weight, ref.linear1.weight), (model.up.bias, ref.linear1.bias),
        (model.down.weight, ref.linear2.weight), (model.down.bias, ref.linear2.bias)]
    assert len(pairs) == len(list(model.parameters())) == 12
    with torch.no_grad():
        for own, official in pairs:
            official.copy_(own)
    x = torch.randn(2, 6, 5, dtype=dtype).transpose(1, 2).detach().requires_grad_()
    xr = x.detach().clone().requires_grad_()
    valid = torch.tensor([[1, 1, 1, 1, 1], [1, 1, 1, 0, 0]], dtype=torch.bool)
    blocked = torch.ones(5, 5, dtype=torch.bool).triu(1) if causal else None
    y = model(x, valid, causal)
    yr = ref(xr, src_mask=blocked, src_key_padding_mask=~valid)
    yr = yr.masked_fill(~valid[..., None], 0.0)
    close(y, yr)
    probe = torch.randn_like(y)
    gs = torch.autograd.grad((y * probe).sum(), [x, *[a for a, _ in pairs]])
    grs = torch.autograd.grad((yr * probe).sum(), [xr, *[b for _, b in pairs]])
    for g, gr in zip(gs, grs):
        assert torch.isfinite(g).all()
        close(g, gr)
    summary["official_cases"].append({
        "causal": causal, "gradient_groups": len(gs),
        "max_output_error": (y - yr).abs().max().item(),
        "max_gradient_error": max((g - gr).abs().max().item() for g, gr in zip(gs, grs))})

model = ManualPreLNBlock(6, 3, 11).to(dtype=dtype)
x = torch.randn(2, 5, 6, dtype=dtype, requires_grad=True)
y = model(x, causal=True)
changed = x.detach().clone()
changed[0, 3:] += torch.tensor([4., -1., 3., -2., 5., 1.], dtype=dtype)
yc = model(changed, causal=True)
close(y[0, :3], yc[0, :3])
assert (y[0, 3:] - yc[0, 3:]).abs().max() > 1e-5
gx = torch.autograd.grad((y[0, :3] * torch.randn_like(y[0, :3])).sum(), x)[0]
assert torch.count_nonzero(gx[0, 3:]) == 0
assert torch.count_nonzero(gx[1]) == 0
changed = x.detach().clone()
changed[1] += 50 * torch.randn_like(changed[1])
close(model(x)[0], model(changed)[0])
summary["checks"].append("whole-block causal perturbation, future gradients and batch isolation")

valid = torch.tensor([[1, 0, 1, 1, 0], [0, 0, 0, 0, 0]], dtype=torch.bool)
y = model(x, valid, causal=True)
changed = x.detach().clone()
changed[~valid] += 100 * torch.randn_like(changed[~valid])
close(y, model(changed, valid, causal=True))
assert torch.isfinite(y).all() and torch.count_nonzero(y[~valid]) == 0
summary["checks"].append("invalid values cannot leak through attention, norm or residual branches")

empty_x = torch.randn(1, 3, 6, dtype=dtype, requires_grad=True)
empty_y = model(empty_x, torch.zeros(1, 3, dtype=torch.bool), causal=True)
empty_grads = torch.autograd.grad(empty_y.sum(), [empty_x, *model.parameters()])
assert torch.count_nonzero(empty_y) == 0
assert all(torch.isfinite(g).all() and torch.count_nonzero(g) == 0 for g in empty_grads)
summary["checks"].append("all-padding output and all thirteen input/parameter gradients are zero")

# With both branch OUTPUT maps zero (including biases), Pre-LN is identity
# on valid positions. This would be false for a final Post-LN operation.
with torch.no_grad():
    model.attention.out_proj.weight.zero_()
    model.attention.out_proj.bias.zero_()
    model.down.weight.zero_()
    model.down.bias.zero_()
z = torch.randn(2, 5, 6, dtype=dtype, requires_grad=True)
zi = model(z, valid, causal=True)
close(zi, z.masked_fill(~valid[..., None], 0.0))
probe = torch.randn_like(zi)
gz = torch.autograd.grad((zi * probe).sum(), z)[0]
close(gz, probe.masked_fill(~valid[..., None], 0.0))
summary["checks"].append("zero branches recover identity forward and identity input Jacobian")


def must_reject(call):
    try:
        call()
    except ValueError:
        return
    raise AssertionError("invalid contract was accepted")


for ff in (0, -2, True, 3.5):
    must_reject(lambda ff=ff: ManualPreLNBlock(6, 3, ff))
for eps in (0.0, -1e-5, float("nan"), float("inf")):
    must_reject(lambda eps=eps: ManualPreLNBlock(6, 3, 11, eps))
must_reject(lambda: model(torch.randn(2, 5, 7, dtype=dtype)))
must_reject(lambda: model(torch.randn(2, 0, 6, dtype=dtype)))
must_reject(lambda: model(x, valid.to(dtype)))
summary["checks"].append("FFN/epsilon and input contracts rejected when invalid")
print("BLOCK_VALIDATION " + json.dumps(summary, sort_keys=True))

