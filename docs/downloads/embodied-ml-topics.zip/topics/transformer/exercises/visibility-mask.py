# Transformer：注意力、残差与序列建模 · 构造前缀与动作区的可见性矩阵
# 只用 Python 标准库，实现 `prefix_action_mask(prefix_len,action_len,mode)`。返回 `[P+A,P+A]` 的布尔嵌套列表，`True` 表示可见。前缀内部双向、前缀不能读动作；动作总能读前缀。`mode="denoise"` 时动作区内部双向，`mode="causal"` 时动作位置只能读取自身及更早动作。要求 \(P\ge0\)、\(A\ge1\)，非法长度或模式抛 `ValueError`。

def prefix_action_mask(prefix_len, action_len, mode="denoise"):
    # TODO: separate query region from key region.
    raise NotImplementedError("implement the information-flow contract")


# 断言测试
expected = [
    [True, True, False, False, False],
    [True, True, False, False, False],
    [True, True, True, True, True],
    [True, True, True, True, True],
    [True, True, True, True, True],
]
assert prefix_action_mask(2, 3, "denoise") == expected
causal = prefix_action_mask(2, 3, "causal")
assert causal[:2] == expected[:2]
assert causal[2] == [True, True, True, False, False]
assert causal[3] == [True, True, True, True, False]
assert causal[4] == [True] * 5
assert prefix_action_mask(0, 1) == [[True]]
assert prefix_action_mask(0, 3, "causal") == [
    [True, False, False], [True, True, False], [True, True, True]]
for prefix, actions, mode in [(-1, 2, "denoise"), (2, 0, "denoise"),
                               (2, 2, "unknown"), (1.5, 2, "causal")]:
    try:
        prefix_action_mask(prefix, actions, mode)
        raise AssertionError("invalid contract must be rejected")
    except ValueError:
        pass
print("passed: prefix isolation, bidirectional actions, causal actions, boundaries")

