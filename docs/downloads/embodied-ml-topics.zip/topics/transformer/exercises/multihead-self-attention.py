# Transformer：注意力、残差与序列建模 · 手写多头自注意力：从 X 到输出投影
# 实现 `ManualSelfAttention(width, heads)`，不能调用 `nn.MultiheadAttention`、SDPA、`nn.Transformer` 或相关封装。允许使用 `nn.Linear` 和张量算子。输入 \(X\in\mathbb{R}^{B\times T\times D}\)，其中 \(B,T>0\)、\(D=H d_h\)；构造函数要求正整数宽度与头数，布尔值不算整数。`qkv` 是带偏置的 `Linear(D,3D)`，打包顺序固定为 Q、K、V；`out_proj` 是带偏置的 `Linear(D,D)`。
# 
# `valid` 为 `None` 或与输入同设备的布尔 `[B,T]`，`True` 表示有效位置；无效 Key 不参与读取，无效 Query 的权重和最终输出必须精确为零。`causal` 是布尔值，开启时仅允许 \(j\le i\)。返回输出 `[B,T,D]` 和未跨头平均的权重 `[B,H,T,T]`，保留二者的计算图。支持非连续输入、内部 Padding 和全 Padding 样本；全遮蔽行采用零权重、零输出、有限零梯度约定。输入、投影和分数均假定有限，输入的浮点类型、设备与参数一致；不要求实现 NaN 清洗、Dropout、RoPE、GQA 或缓存。错误维度、Mask 类型／形状与非布尔 `causal` 应抛出 `ValueError`。
# 
# 依次完成投影、分头、缩放、Mask、Softmax、Value 读出、合头与输出投影。

import math
import torch
from torch import nn


class ManualSelfAttention(nn.Module):
    def __init__(self, width, heads):
        super().__init__()
        # TODO 1: validate positive integer dimensions and divisibility.
        # Keep these attributes/parameter names for the comparison tests.
        self.width, self.heads = width, heads
        self.qkv = nn.Linear(width, 3 * width, bias=True)
        self.out_proj = nn.Linear(width, width, bias=True)

    def forward(self, x, valid=None, causal=False):
        # TODO 2: validate x [B,T,D], valid bool [B,T], and causal bool.
        # TODO 3: project X -> Q,K,V, then split channels and exchange axes.
        # TODO 4: construct key + query validity and optional causal visibility.
        # TODO 5: scaled logits -> safe masked softmax along the key axis.
        # TODO 6: read V, merge heads, project with Wo, clear invalid queries.
        # Return output [B,T,D], weights [B,H,T,T]; do not detach either.
        raise NotImplementedError


# 断言测试
# Append below your implementation. Official operators are an oracle ONLY.
import json

torch.manual_seed(71)
torch.set_num_threads(1)
dtype = torch.float64
summary = {"seed": 71, "official_cases": [], "checks": []}


def close(a, b):
    torch.testing.assert_close(a, b, atol=2e-10, rtol=2e-8)


def must_reject(call):
    try:
        call()
    except ValueError:
        return
    raise AssertionError("invalid contract was accepted")


for heads in (1, 3):
    for causal in (False, True):
        model = ManualSelfAttention(6, heads).to(dtype=dtype)
        ref = nn.MultiheadAttention(6, heads, dropout=0.0, bias=True,
                                   batch_first=True, dtype=dtype)
        with torch.no_grad():
            ref.in_proj_weight.copy_(model.qkv.weight)
            ref.in_proj_bias.copy_(model.qkv.bias)
            ref.out_proj.weight.copy_(model.out_proj.weight)
            ref.out_proj.bias.copy_(model.out_proj.bias)
        # Unequal B/T/H dimensions, non-contiguous X, right padding.
        # Every oracle query has >= 1 visible key, even at padded query slots.
        x = torch.randn(2, 6, 5, dtype=dtype).transpose(1, 2).detach().requires_grad_()
        assert not x.is_contiguous()
        xr = x.detach().clone().requires_grad_()
        valid = torch.tensor([[1, 1, 1, 1, 1], [1, 1, 1, 0, 0]], dtype=torch.bool)
        blocked = torch.ones(5, 5, dtype=torch.bool).triu(1) if causal else None
        y, weights = model(x, valid, causal)
        yr, wr = ref(xr, xr, xr, key_padding_mask=~valid, attn_mask=blocked,
                     need_weights=True, average_attn_weights=False)
        # PyTorch's key_padding_mask does not zero padded QUERY outputs.
        yr = yr.masked_fill(~valid[..., None], 0.0)
        wr = wr.masked_fill(~valid[:, None, :, None], 0.0)
        close(y, yr)
        close(weights, wr)
        close(weights.sum(-1), valid[:, None, :].expand(2, heads, 5).to(dtype))
        yp, wp = torch.randn_like(y), torch.randn_like(weights)
        # Include returned weights: detaching weights must also be detected.
        loss = (y * yp).sum() + 0.07 * (weights * wp).sum()
        loss_ref = (yr * yp).sum() + 0.07 * (wr * wp).sum()
        left = [x, model.qkv.weight, model.qkv.bias,
                model.out_proj.weight, model.out_proj.bias]
        right = [xr, ref.in_proj_weight, ref.in_proj_bias,
                 ref.out_proj.weight, ref.out_proj.bias]
        grads, grads_ref = torch.autograd.grad(loss, left), torch.autograd.grad(loss_ref, right)
        for g, gr in zip(grads, grads_ref):
            assert torch.isfinite(g).all()
            close(g, gr)
        summary["official_cases"].append({
            "heads": heads, "causal": causal, "gradient_groups": len(grads),
            "max_output_error": (y - yr).abs().max().item(),
            "max_weight_error": (weights - wr).abs().max().item(),
            "max_gradient_error": max((g - gr).abs().max().item()
                                      for g, gr in zip(grads, grads_ref))})

model = ManualSelfAttention(6, 3).to(dtype=dtype)
x = torch.randn(2, 5, 6, dtype=dtype, requires_grad=True)
y, _ = model(x, causal=True)
changed = x.detach().clone()
changed[0, 3:] += torch.tensor([3., -2., 5., 1., -4., 2.], dtype=dtype)
y_changed, _ = model(changed, causal=True)
close(y[0, :3], y_changed[0, :3])
assert (y[0, 3:] - y_changed[0, 3:]).abs().max() > 1e-5
probe = torch.randn_like(y[0, :3])
gx = torch.autograd.grad((y[0, :3] * probe).sum(), x)[0]
assert torch.count_nonzero(gx[0, 3:]) == 0
assert torch.count_nonzero(gx[1]) == 0
changed = x.detach().clone()
changed[1] += 100 * torch.randn_like(changed[1])
close(model(x)[0][0], model(changed)[0][0])
summary["checks"].append("causal perturbation, future gradients and batch isolation")

# Internal padding holes and an entirely padded sample: no oracle behavior
# is assumed for its empty softmax rows.
valid = torch.tensor([[1, 0, 1, 1, 0], [0, 0, 0, 0, 0]], dtype=torch.bool)
y, weights = model(x, valid, causal=True)
changed = x.detach().clone()
changed[~valid] += 100 * torch.randn_like(changed[~valid])
yc, wc = model(changed, valid, causal=True)
close(y, yc)
close(weights, wc)
assert torch.count_nonzero(y[~valid]) == 0
assert torch.count_nonzero(weights.masked_select(~valid[:, None, :, None])) == 0
assert torch.count_nonzero(weights.masked_select(~valid[:, None, None, :])) == 0
assert torch.isfinite(y).all() and torch.isfinite(weights).all()
summary["checks"].append("padding values cannot leak; empty rows stay finite and zero")

empty_x = torch.randn(1, 3, 6, dtype=dtype, requires_grad=True)
empty_valid = torch.zeros(1, 3, dtype=torch.bool)
ey, ew = model(empty_x, empty_valid, causal=True)
eg = torch.autograd.grad(ey.sum() + ew.sum(), [empty_x, *model.parameters()])
assert torch.count_nonzero(ey) == 0 and torch.count_nonzero(ew) == 0
assert all(torch.isfinite(g).all() and torch.count_nonzero(g) == 0 for g in eg)
summary["checks"].append("all-padding output and all five input/parameter gradient groups are zero")

# One token has weight 1. Its output is exactly Wo(Wv x + bv) + bo.
single = torch.randn(2, 1, 6, dtype=dtype)
sy, sw = model(single, causal=True)
expected = model.out_proj(torch.nn.functional.linear(
    single, model.qkv.weight[12:], model.qkv.bias[12:]))
close(sy, expected)
close(sw, torch.ones_like(sw))
summary["checks"].append("single-token analytic value readout")

for dims in ((6, 0), (5, 3), (0, 1), (6, True), (6.0, 2)):
    must_reject(lambda dims=dims: ManualSelfAttention(*dims))
must_reject(lambda: model(torch.randn(2, 6, dtype=dtype)))
must_reject(lambda: model(torch.randn(2, 0, 6, dtype=dtype)))
must_reject(lambda: model(torch.randn(2, 5, 7, dtype=dtype)))
must_reject(lambda: model(x, torch.ones(2, 5, dtype=dtype)))
must_reject(lambda: model(x, torch.ones(2, 4, dtype=torch.bool)))
must_reject(lambda: model(x, causal=1))
summary["checks"].append("invalid dimensions, mask dtype/shape and causal flag rejected")
print("MHA_VALIDATION " + json.dumps(summary, sort_keys=True))

