# CNN：卷积、采样与空间表示 · 推导非方形卷积尺寸与多层感受野
# 用标准库实现 conv_geometry(input_hw,kernel_hw,stride_hw=(1,1),padding_hw=(0,0),dilation_hw=(1,1))，返回 (Hout,Wout)；实现 receptive_field(layers)，layers 是单个空间轴上的 (kernel,stride,dilation) 列表，返回 (理论跨度,累计步长)。要求长度/核/步长/dilation 为正整数，padding 为非负整数；没有输出位置时抛 ValueError。

def conv_geometry(input_hw, kernel_hw, stride_hw=(1, 1), padding_hw=(0, 0), dilation_hw=(1, 1)):
    items = [input_hw, kernel_hw, stride_hw, padding_hw, dilation_hw]
    if any(len(values) != 2 for values in items):
        raise ValueError("几何参数必须为二维")
    output = []
    for length, kernel, stride, padding, dilation in zip(*items):
        if any(type(v) is not int or v <= 0 for v in (length, kernel, stride, dilation)):
            raise ValueError("长度、核、步长和 dilation 必须为正整数")
        if type(padding) is not int or padding < 0:
            raise ValueError("padding 必须为非负整数")
        size = (length + 2 * padding - dilation * (kernel - 1) - 1) // stride + 1
        if size <= 0:
            raise ValueError("没有有效输出位置")
        output.append(size)
    return tuple(output)

def receptive_field(layers):
    receptive, jump = 1, 1
    for kernel, stride, dilation in layers:
        if any(type(v) is not int or v <= 0 for v in (kernel, stride, dilation)):
            raise ValueError("核、步长和 dilation 必须为正整数")
        receptive += (kernel - 1) * dilation * jump
        jump *= stride
    return receptive, jump


# 断言测试
assert conv_geometry((7, 9), (3, 2), (2, 1), (1, 0), (2, 1)) == (3, 8)
assert conv_geometry((8, 10), (3, 3), (2, 2), (1, 1)) == (4, 5)
assert conv_geometry((5, 5), (1, 1)) == (5, 5)
assert receptive_field([(3, 2, 1), (3, 1, 1)]) == (7, 2)
assert receptive_field([(3, 1, 2), (3, 2, 1)]) == (7, 2)
assert receptive_field([]) == (1, 1)
for args in [((2, 2), (5, 5)), ((7, 9), (3, 2), (0, 1)), ((7, 9), (3, 2), (1, 1), (-1, 0))]:
    try:
        conv_geometry(*args)
        raise AssertionError("应拒绝无效几何")
    except ValueError:
        pass
try:
    receptive_field([(3, 0, 1)])
    raise AssertionError("应拒绝零步长")
except ValueError:
    pass
print("通过：非方形尺寸、向下取整、dilation 与感受野递推。")

