# CNN：卷积、采样与空间表示 · 实现分组卷积并核对前向和梯度
# 实现 grouped_conv(x,weight,bias=None,stride=1,padding=0,dilation=1,groups=1)。允许 F.unfold 与 einsum / matmul，不得调用 conv2d。输入为 NCHW，权重为 [Cout,Cin/groups,Kh,Kw]；stride/padding/dilation 支持整数或二元 tuple，采用对称零填充。保留所有输入梯度连接。

import torch
from torch.nn import functional as F

def grouped_conv(x, weight, bias=None, stride=1, padding=0, dilation=1, groups=1):
    pair = lambda v: (v, v) if isinstance(v, int) else tuple(v)
    sh, sw = pair(stride)
    ph, pw = pair(padding)
    dh, dw = pair(dilation)
    batch, cin, height, width = x.shape
    cout, cin_group, kh, kw = weight.shape
    if groups <= 0 or cin % groups or cout % groups or cin_group != cin // groups:
        raise ValueError("分组通道不匹配")
    if min(sh, sw, dh, dw) <= 0 or min(ph, pw) < 0:
        raise ValueError("无效几何参数")
    oh = (height + 2 * ph - dh * (kh - 1) - 1) // sh + 1
    ow = (width + 2 * pw - dw * (kw - 1) - 1) // sw + 1
    if min(oh, ow) <= 0:
        raise ValueError("没有有效输出")
    columns = F.unfold(x, (kh, kw), dilation=(dh, dw), padding=(ph, pw), stride=(sh, sw))
    columns = columns.reshape(batch, groups, cin_group * kh * kw, oh * ow)
    kernels = weight.reshape(groups, cout // groups, cin_group * kh * kw)
    output = torch.einsum("goc,bgcl->bgol", kernels, columns).reshape(batch, cout, oh, ow)
    if bias is not None:
        if bias.shape != (cout,):
            raise ValueError("偏置形状错误")
        output = output + bias[None, :, None, None]
    return output


# 断言测试
torch.manual_seed(29)
for groups, cin, cout in [(1, 3, 4), (2, 4, 6), (4, 4, 8)]:
    x = torch.randn(2, cin, 7, 9, dtype=torch.float64, requires_grad=True)
    w = torch.randn(cout, cin // groups, 3, 2, dtype=torch.float64, requires_grad=True)
    b = torch.randn(cout, dtype=torch.float64, requires_grad=True)
    options = dict(stride=(2, 1), padding=(1, 0), dilation=(2, 1), groups=groups)
    actual = grouped_conv(x, w, b, **options)
    expected = F.conv2d(x, w, b, **options)
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)
    upstream = torch.randn_like(actual)
    ours = torch.autograd.grad((actual * upstream).sum(), (x, w, b))
    reference = torch.autograd.grad((expected * upstream).sum(), (x, w, b))
    for left, right in zip(ours, reference):
        torch.testing.assert_close(left, right, rtol=1e-10, atol=1e-10)
# 无偏置、整数参数以及 1×1 特例。
x = torch.randn(1, 2, 4, 5, dtype=torch.float64)
w = torch.randn(3, 2, 1, 1, dtype=torch.float64)
torch.testing.assert_close(grouped_conv(x, w), F.conv2d(x, w))
try:
    grouped_conv(x, w, groups=2)
    raise AssertionError("应拒绝 Cout 不能被 groups 整除")
except ValueError:
    pass
print("通过：普通、分组、depthwise、无偏置与三组梯度。")

