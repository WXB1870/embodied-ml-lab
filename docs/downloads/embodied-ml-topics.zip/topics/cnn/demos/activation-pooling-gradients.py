import torch
import torch.nn.functional as F

torch.manual_seed(31)
torch.set_num_threads(1)
dtype = torch.float64

# 1. ReLU: local derivative, including the framework's zero convention.
pre = torch.tensor([-2., 0., 3.], dtype=dtype, requires_grad=True)
relu_grad, = torch.autograd.grad(pre.relu().sum(), pre)
torch.testing.assert_close(relu_grad, torch.tensor([0., 0., 1.], dtype=dtype))

# 2. BatchNorm2d: explicit batch/spatial statistics and all input gradients.
x = torch.randn(2, 3, 2, 2, dtype=dtype, requires_grad=True)
bn = torch.nn.BatchNorm2d(3, eps=0.03, momentum=0.3).to(dtype=dtype)
with torch.no_grad():
    bn.weight.copy_(torch.tensor([1.2, -0.7, 0.5], dtype=dtype))
    bn.bias.copy_(torch.tensor([0.1, 0.2, -0.4], dtype=dtype))
axes = (0, 2, 3)                   # B, H, W; leave channel C intact.
mu = x.mean(axes, keepdim=True)
var = (x - mu).square().mean(axes, keepdim=True)
r = (var + bn.eps).sqrt()
z = (x - mu) / r
gamma = bn.weight[None, :, None, None]
beta = bn.bias[None, :, None, None]
expected = gamma * z + beta
y = bn(x)
torch.testing.assert_close(y, expected)
g = torch.linspace(-1.1, 2.3, x.numel(), dtype=dtype).reshape_as(x)
dx, dgamma, dbeta = torch.autograd.grad(
    (y * g).sum(), (x, bn.weight, bn.bias), retain_graph=True)
q = g * gamma
manual_dx = (q - q.mean(axes, keepdim=True)
             - z * (q * z).mean(axes, keepdim=True)) / r
torch.testing.assert_close(dx, manual_dx, rtol=1e-10, atol=1e-10)
torch.testing.assert_close(dgamma, (g * z).sum(axes))
torch.testing.assert_close(dbeta, g.sum(axes))

# Running variance uses correction=1; training forward uses correction=0.
N = x.numel() // x.shape[1]
torch.testing.assert_close(bn.running_mean, 0.3 * mu.flatten())
torch.testing.assert_close(bn.running_var,
                           0.7 * torch.ones(3, dtype=dtype)
                           + 0.3 * var.flatten() * N / (N - 1))
one_grad, = torch.autograd.grad(y[0, 0, 0, 0], x)
assert one_grad[1, 0].abs().max().item() > 1e-8  # Cross-sample dependence.
torch.testing.assert_close(one_grad[:, 1:], torch.zeros_like(one_grad[:, 1:]))

# 3. Eval fixes the statistics; freezing parameters alone does not do this.
bn.eval()
xe = x.detach().clone().requires_grad_(True)
ye = bn(xe)
eval_grad, = torch.autograd.grad(ye[0, 0, 0, 0], xe)
expected_grad = torch.zeros_like(xe)
expected_grad[0, 0, 0, 0] = bn.weight[0] / (bn.running_var[0] + bn.eps).sqrt()
torch.testing.assert_close(eval_grad, expected_grad)
for parameter in bn.parameters():
    parameter.requires_grad_(False)
bn.train()
old_running_mean = bn.running_mean.clone()
with torch.no_grad():
    bn(x.detach() + 2.)
assert not torch.equal(old_running_mean, bn.running_mean)

# 4. Pooling: unique maximum and accumulation from overlapping windows.
window = torch.tensor([[[[1., 4.], [3., 2.]]]], dtype=dtype,
                      requires_grad=True)
avg_grad, = torch.autograd.grad(F.avg_pool2d(window, 2).sum(), window)
max_grad, = torch.autograd.grad(F.max_pool2d(window, 2).sum(), window)
torch.testing.assert_close(avg_grad, torch.full_like(window, 0.25))
torch.testing.assert_close(max_grad, torch.tensor([[[[0., 1.], [0., 0.]]]],
                                                dtype=dtype))
overlap = torch.tensor([[[1., 3., 2.]]], dtype=dtype, requires_grad=True)
oa, = torch.autograd.grad(F.avg_pool1d(overlap, 2, stride=1).sum(), overlap)
om, = torch.autograd.grad(F.max_pool1d(overlap, 2, stride=1).sum(), overlap)
torch.testing.assert_close(oa, torch.tensor([[[0.5, 1., 0.5]]], dtype=dtype))
torch.testing.assert_close(om, torch.tensor([[[0., 2., 0.]]], dtype=dtype))

# 5. GAP cannot distinguish these maps; subsampling depends on phase.
maps = torch.tensor([[[[4., 0.], [0., 0.]]],
                     [[[0., 0.], [0., 4.]]]], dtype=dtype)
assert not torch.equal(maps[0], maps[1])
torch.testing.assert_close(F.adaptive_avg_pool2d(maps, 1),
                           torch.ones(2, 1, 1, 1, dtype=dtype))
alternating = torch.tensor([[[1., -1., 1., -1., 1., -1., 1., -1.]]], dtype=dtype)
shifted = alternating.roll(1, dims=-1)
assert not torch.equal(alternating[..., ::2], shifted[..., ::2])
torch.testing.assert_close(F.avg_pool1d(alternating, 2),
                           F.avg_pool1d(shifted, 2))
# Equal averages on this signal do not prove arbitrary shift invariance.
periodic = torch.tensor([[[0., 2., 1., 0.]]], dtype=dtype)
assert not torch.equal(F.max_pool1d(periodic, 2),
                       F.max_pool1d(periodic.roll(1, dims=-1), 2))

# 6. Boundary rules change the averaging divisor and maximum selection.
single = torch.ones(1, 1, 1, 1, dtype=dtype)
torch.testing.assert_close(F.avg_pool2d(single, 3, stride=1, padding=1), single / 9)
torch.testing.assert_close(F.avg_pool2d(single, 3, stride=1, padding=1,
                                       count_include_pad=False), single)
torch.testing.assert_close(F.max_pool2d(-single, 3, stride=1, padding=1), -single)
print("通过：ReLU、BN 前向/反向/运行统计、池化梯度、GAP、采样相位与边界约定。")
print("BN 输入梯度最大绝对误差：", (dx - manual_dx).abs().max().item())

