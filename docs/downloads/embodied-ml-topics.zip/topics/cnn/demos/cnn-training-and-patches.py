import copy
import torch
from torch import nn
from torch.nn import functional as F

torch.manual_seed(31)
torch.set_num_threads(1)

# 不依赖外部图像：RGB 三通道共享同一条亮线，颜色不作为标签捷径。
count, side = 160, 12
images = .04 * torch.randn(count, 3, side, side)
labels = torch.arange(count) % 2  # 0=竖线，1=横线。
positions = torch.randint(3, 8, (count,))
for index, position in enumerate(positions.tolist()):
    if labels[index] == 0:
        images[index, :, 2:10, position:position + 2] += 1.
    else:
        images[index, :, position:position + 2, 2:10] += 1.
order = torch.randperm(count)
images, labels = images[order], labels[order]
train_x, test_x = images[:120], images[120:]
train_y, test_y = labels[:120], labels[120:]
assert train_x.shape == (120, 3, 12, 12)

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 8, 3, padding=1), nn.ReLU(),
            nn.Conv2d(8, 12, 3, padding=1), nn.ReLU())
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Linear(12, 2)

    def forward(self, x):
        feature_map = self.features(x)  # B,12,H,W；两层卷积的局部感受野为 5×5。
        pooled = self.pool(feature_map).flatten(1)
        return self.classifier(pooled)  # 原始 logits，不提前 Softmax。

model = SmallCNN()
# 在同一个 SmallCNN 上追踪前向、参数量、MACs 与反向，不另建架构。
def trace_network(original, sample, target):
    network = copy.deepcopy(original)
    x = sample.detach().clone().requires_grad_()
    values = [("input", x)]
    h = x
    total_parameters, total_macs = 0, 0
    r, j = 1, 1
    for index, layer in enumerate(network.features):
        h = layer(h)
        h.retain_grad()
        values.append((f"features.{index}", h))
        parameters = sum(p.numel() for p in layer.parameters())
        macs = 0
        if isinstance(layer, nn.Conv2d):
            k, s, d = layer.kernel_size[0], layer.stride[0], layer.dilation[0]
            r += (k - 1) * d * j
            j *= s
            macs = h.shape[-2] * h.shape[-1] * layer.out_channels * layer.in_channels * k * k
        total_parameters += parameters
        total_macs += macs
        print(values[-1][0], tuple(h.shape), "params", parameters, "MAC/sample", macs, "r,j", r, j)
    assert (r, j) == (5, 1)
    pooled = network.pool(h).flatten(1)
    pooled.retain_grad()
    logits = network.classifier(pooled)
    logits.retain_grad()
    loss = F.cross_entropy(logits, target)
    loss.backward()
    # CE -> Linear -> GAP，梯度在每个通道的 144 个位置均分。
    upstream = logits.detach().softmax(-1)
    upstream[torch.arange(len(target)), target] -= 1
    upstream /= len(target)
    torch.testing.assert_close(logits.grad, upstream)
    expected_pooled = upstream @ network.classifier.weight.detach()
    torch.testing.assert_close(pooled.grad, expected_pooled)
    torch.testing.assert_close(h.grad, (expected_pooled[:, :, None, None] / 144).expand_as(h))
    for name, value in values:
        assert value.grad is not None and torch.isfinite(value.grad).all()
        print("activation gradient", name, "shape", tuple(value.grad.shape), "norm", value.grad.norm().item())
    for name, parameter in network.named_parameters():
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all()
        print("parameter gradient", name, tuple(parameter.grad.shape), parameter.grad.norm().item())
    total_parameters += sum(p.numel() for p in network.classifier.parameters())
    total_macs += 12 * 2
    assert total_parameters == 1126 and total_macs == 155544
    # 此处考察局部卷积输出，不是含 GAP 的分类 loss。
    local_x = sample[:1].detach().clone().requires_grad_()
    local = network.features[:3](local_x)
    local_gradient, = torch.autograd.grad(local[0, :, 6, 6].sum(), local_x)
    outside = torch.ones_like(local_gradient, dtype=torch.bool)
    outside[:, :, 4:9, 4:9] = False
    assert torch.count_nonzero(local_gradient[outside]) == 0
    assert torch.count_nonzero(local_gradient) > 0
    print("local output support within 5x5; total params=1126, MAC/sample=155544")

trace_network(model, train_x[:4], train_y[:4])
optimizer = torch.optim.Adam(model.parameters(), lr=.01)
with torch.no_grad():
    initial = F.cross_entropy(model(train_x), train_y).item()
original_weight = model.features[0].weight.detach().clone()
model.train()
for step in range(100):
    optimizer.zero_grad(set_to_none=True)
    logits = model(train_x)
    loss = F.cross_entropy(logits, train_y)
    loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    optimizer.step()

model.eval()
with torch.no_grad():
    final = F.cross_entropy(model(train_x), train_y).item()
    holdout_logits = model(test_x)
    holdout_loss = F.cross_entropy(holdout_logits, test_y).item()
    holdout_accuracy = (holdout_logits.argmax(-1) == test_y).float().mean().item()
    assert model(torch.randn(2, 3, 10, 14)).shape == (2, 2)
assert final < initial * .3  # 仅验证固定条纹任务的训练链路。
assert not torch.equal(original_weight, model.features[0].weight)
assert sum(p.numel() for p in model.parameters()) == 1126
print(f"train CE: {initial:.6f} -> {final:.6f}")
print(f"holdout CE: {holdout_loss:.6f}, accuracy: {holdout_accuracy:.3f}")

# 再验证 ViT 常见的 patch embedding：不重叠 patch 的共享线性映射。
patch_size, embedding_dim = 4, 7
patch_layer = nn.Conv2d(3, embedding_dim, patch_size, stride=patch_size)
sample = test_x[:2]
conv_tokens = patch_layer(sample).flatten(2).transpose(1, 2)
patches = F.unfold(sample, kernel_size=patch_size, stride=patch_size).transpose(1, 2)
linear_tokens = F.linear(patches, patch_layer.weight.flatten(1), patch_layer.bias)
assert conv_tokens.shape == (2, 9, 7)
torch.testing.assert_close(conv_tokens, linear_tokens, rtol=1e-5, atol=1e-6)
# 第一片按 C、局部 H、局部 W 展平，与 F.unfold 的列顺序一致。
torch.testing.assert_close(patches[0, 0], sample[0, :, :4, :4].reshape(-1))
print("通过：卷积分类训练、独立留出评价、参数量与 patch 线性投影等价。")
print("此处输入尺寸可变仅是形状性质，不代表对新分辨率的泛化保证。")

