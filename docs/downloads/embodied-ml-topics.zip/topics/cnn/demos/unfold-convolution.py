import torch
from torch.nn import functional as F

torch.manual_seed(23)
torch.set_num_threads(1)

# 教学实现：支持二维整数 tuple、对称零填充和分组，不处理字符串 padding。
def pair(value):
    return (value, value) if isinstance(value, int) else tuple(value)

def unfold_conv(x, weight, bias=None, stride=1, padding=0, dilation=1, groups=1):
    sh, sw = pair(stride)
    ph, pw = pair(padding)
    dh, dw = pair(dilation)
    batch, channels, height, width = x.shape
    out_channels, per_group, kh, kw = weight.shape
    if groups <= 0 or channels % groups or out_channels % groups:
        raise ValueError("输入输出通道必须能被 groups 整除")
    if per_group != channels // groups:
        raise ValueError("权重第二维必须等于 Cin/groups")
    if min(sh, sw, dh, dw, kh, kw) <= 0 or min(ph, pw) < 0:
        raise ValueError("卷积几何参数无效")
    oh = (height + 2 * ph - dh * (kh - 1) - 1) // sh + 1
    ow = (width + 2 * pw - dw * (kw - 1) - 1) // sw + 1
    if min(oh, ow) <= 0:
        raise ValueError("没有有效输出位置")
    # B,Cin*Kh*Kw,L：最后一轴是输出位置，每列是一个局部窗口。
    columns = F.unfold(x, (kh, kw), dilation=(dh, dw), padding=(ph, pw), stride=(sh, sw))
    assert columns.shape[-1] == oh * ow
    grouped_columns = columns.reshape(batch, groups, per_group * kh * kw, oh * ow)
    grouped_weights = weight.reshape(groups, out_channels // groups, per_group * kh * kw)
    output = torch.einsum("goc,bgcl->bgol", grouped_weights, grouped_columns)
    output = output.reshape(batch, out_channels, oh, ow)
    if bias is not None:
        if bias.shape != (out_channels,):
            raise ValueError("每个输出通道需要一个偏置")
        output = output + bias[None, :, None, None]
    return output

# 普通卷积、分组卷积、depthwise multiplier=2；均采用非方形核。
cases = [(1, 3, 5), (2, 4, 6), (4, 4, 8)]
for groups, cin, cout in cases:
    x = torch.randn(2, cin, 7, 9, dtype=torch.float64, requires_grad=True)
    weight = torch.randn(cout, cin // groups, 3, 2, dtype=torch.float64, requires_grad=True)
    bias = torch.randn(cout, dtype=torch.float64, requires_grad=True)
    options = dict(stride=(2, 1), padding=(1, 0), dilation=(2, 1), groups=groups)
    actual = unfold_conv(x, weight, bias, **options)
    reference = F.conv2d(x, weight, bias, **options)
    assert actual.shape == (2, cout, 3, 8)
    torch.testing.assert_close(actual, reference, rtol=1e-10, atol=1e-10)
    # 相同上游权重对应一个明确的向量—Jacobian 乘积。
    upstream = torch.linspace(.1, 1., actual.numel(), dtype=x.dtype).reshape_as(actual)
    actual_grads = torch.autograd.grad((actual * upstream).sum(), (x, weight, bias))
    reference_grads = torch.autograd.grad((reference * upstream).sum(), (x, weight, bias))
    for ours, expected in zip(actual_grads, reference_grads):
        torch.testing.assert_close(ours, expected, rtol=1e-10, atol=1e-10)
    print("groups =", groups, "shape =", tuple(actual.shape), "forward and gradients agree")

# 空间共享参数：固定一个卷积核，图像尺寸不进入参数总数。
layer = torch.nn.Conv2d(32, 64, kernel_size=3, bias=True)
assert sum(p.numel() for p in layer.parameters()) == 18496
# Unfold 会显式展开重叠窗口；这是理解用实现，不是性能优化建议。
example = torch.randn(1, 3, 16, 16)
expanded = F.unfold(example, kernel_size=3, padding=1)
print("unfold/input element ratio =", expanded.numel() / example.numel())
assert expanded.numel() == example.numel() * 9
print("通过：互相关、通道分组、非方形几何、输入/权重/偏置梯度。")

