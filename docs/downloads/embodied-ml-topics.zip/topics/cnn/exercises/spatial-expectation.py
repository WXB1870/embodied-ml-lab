# CNN：卷积、采样与空间表示 · 保留空间信息：从热图读出关键点坐标
# 实现 spatial_expectation(logits,temperature=1.0)，logits 为 [B,K,H,W]，每个关键点在 H×W 上独立 Softmax。返回 [B,K,2]，最后一维按 x,y 排列，坐标采用像素中心 \(\left(\frac{j+0.5}{W},\frac{i+0.5}{H}\right)\)。拒绝非正温度和非四维输入，保留梯度。

import torch

def spatial_expectation(logits, temperature=1.0):
    # TODO: 空间 Softmax，构造中心坐标网格，求期望。
    raise NotImplementedError("实现空间读出")


# 断言测试
uniform = torch.zeros(2, 3, 2, 4, dtype=torch.float64)
torch.testing.assert_close(spatial_expectation(uniform), torch.full((2, 3, 2), .5, dtype=torch.float64))
peaked = torch.full((1, 2, 2, 3), -40., dtype=torch.float64)
peaked[0, 0, 0, 2] = 40.
peaked[0, 1, 1, 0] = 40.
expected = torch.tensor([[[5/6, 1/4], [1/6, 3/4]]], dtype=torch.float64)
torch.testing.assert_close(spatial_expectation(peaked), expected)
# 两个等高峰的期望落在中间，说明返回的不是 argmax。
two_peaks = torch.tensor([[[[20., -20., 20.]]]], dtype=torch.float64)
torch.testing.assert_close(spatial_expectation(two_peaks), torch.tensor([[[.5, .5]]], dtype=torch.float64))
torch.manual_seed(37)
x = torch.randn(2, 2, 3, 5, dtype=torch.float64, requires_grad=True)
output = spatial_expectation(x, .7)
(output.square().sum()).backward()
assert torch.isfinite(x.grad).all() and torch.count_nonzero(x.grad) > 0
# 每张热图加常数不改变空间概率。
torch.testing.assert_close(spatial_expectation(x.detach() + 17., .7), output.detach())
for t in [0., -1.]:
    try:
        spatial_expectation(x.detach(), t)
        raise AssertionError("应拒绝非正温度")
    except ValueError:
        pass
print("通过：空间归约、非方形 xy 顺序、中心坐标和可微期望。")

