# CNN：卷积、采样与空间表示 · 推导非方形卷积尺寸与多层感受野
# 用标准库实现 conv_geometry(input_hw,kernel_hw,stride_hw=(1,1),padding_hw=(0,0),dilation_hw=(1,1))，返回 (Hout,Wout)；实现 receptive_field(layers)，layers 是单个空间轴上的 (kernel,stride,dilation) 列表，返回 (理论跨度,累计步长)。要求长度/核/步长/dilation 为正整数，padding 为非负整数；没有输出位置时抛 ValueError。

def conv_geometry(input_hw, kernel_hw, stride_hw=(1, 1), padding_hw=(0, 0), dilation_hw=(1, 1)):
    # TODO: 高和宽分别使用完整公式，不能假设方形。
    raise NotImplementedError("实现输出几何")

def receptive_field(layers):
    # TODO: 新增跨度用上一层 jump，然后再更新 jump。
    raise NotImplementedError("递推感受野")


# 断言测试
assert conv_geometry((7, 9), (3, 2), (2, 1), (1, 0), (2, 1)) == (3, 8)
assert conv_geometry((8, 10), (3, 3), (2, 2), (1, 1)) == (4, 5)
assert conv_geometry((5, 5), (1, 1)) == (5, 5)
assert receptive_field([(3, 2, 1), (3, 1, 1)]) == (7, 2)
assert receptive_field([(3, 1, 2), (3, 2, 1)]) == (7, 2)
assert receptive_field([]) == (1, 1)
for args in [((2, 2), (5, 5)), ((7, 9), (3, 2), (0, 1)), ((7, 9), (3, 2), (1, 1), (-1, 0))]:
    try:
        conv_geometry(*args)
        raise AssertionError("应拒绝无效几何")
    except ValueError:
        pass
try:
    receptive_field([(3, 0, 1)])
    raise AssertionError("应拒绝零步长")
except ValueError:
    pass
print("通过：非方形尺寸、向下取整、dilation 与感受野递推。")

