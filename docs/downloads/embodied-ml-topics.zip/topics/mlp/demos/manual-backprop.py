import torch
from torch import nn

torch.manual_seed(7)
torch.set_num_threads(1)
dtype = torch.float64
# 每一行是一条样本；参数形状与 nn.Linear 完全相同。
x = torch.tensor([[1., -2.], [.5, 1.], [-1., .25]], dtype=dtype)
y = torch.tensor([[.5, -.1], [.7, .4], [-.2, .8]], dtype=dtype)
w1 = torch.tensor([[.7, -.3], [-.4, .8], [.5, .2]], dtype=dtype)
b1 = torch.tensor([.2, .1, .4], dtype=dtype)
w2 = torch.tensor([[.6, -.2, .4], [-.3, .5, .7]], dtype=dtype)
b2 = torch.tensor([.1, -.2], dtype=dtype)

# 前向：B×2 -> B×3 -> B×2；平方误差对所有输出元素平均。
def forward(x, w1, b1, w2, b2):
    z = x @ w1.T + b1
    h = z.clamp_min(0)
    prediction = h @ w2.T + b2
    return prediction, z, h

prediction, z, h = forward(x, w1, b1, w2, b2)
error = prediction - y
loss = error.square().mean() / 2
assert z.abs().min() > 1e-3  # 有限差分不跨过 ReLU 的折点。

# 手写向量—Jacobian 乘积，不构造庞大的完整 Jacobian。
dprediction = error / error.numel()
dw2 = dprediction.T @ h
db2 = dprediction.sum(0)
dh = dprediction @ w2
dz = dh * (z > 0).to(dtype)
dw1 = dz.T @ x
db1 = dz.sum(0)
dx = dz @ w1
manual = [dx, dw1, db1, dw2, db2]
assert torch.equal(dz[z < 0], torch.zeros_like(dz[z < 0]))

# 独立让 autograd 求导；不要在手写结果上再调用 backward。
variables = [v.clone().requires_grad_() for v in (x, w1, b1, w2, b2)]
xa, wa1, ba1, wa2, ba2 = variables
reference, _, _ = forward(xa, wa1, ba1, wa2, ba2)
reference_loss = (reference - y).square().mean() / 2
automatic = torch.autograd.grad(reference_loss, variables)
for name, actual, expected in zip(("x", "w1", "b1", "w2", "b2"), manual, automatic):
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)
    print(name, tuple(actual.shape), "gradient agrees")

# 第三个证据：对第一层每个权重进行中心有限差分。
epsilon = 1e-6
finite = torch.zeros_like(w1)
for row in range(w1.shape[0]):
    for column in range(w1.shape[1]):
        plus, minus = w1.clone(), w1.clone()
        plus[row, column] += epsilon
        minus[row, column] -= epsilon
        p_plus = forward(x, plus, b1, w2, b2)[0]
        p_minus = forward(x, minus, b1, w2, b2)[0]
        l_plus = (p_plus - y).square().mean() / 2
        l_minus = (p_minus - y).square().mean() / 2
        finite[row, column] = (l_plus - l_minus) / (2 * epsilon)
torch.testing.assert_close(dw1, finite, rtol=1e-7, atol=1e-8)

# 将同一组参数装进 nn.Module，验证权重朝向和偏置广播。
model = nn.Sequential(nn.Linear(2, 3), nn.ReLU(), nn.Linear(3, 2)).to(dtype)
with torch.no_grad():
    model[0].weight.copy_(w1)
    model[0].bias.copy_(b1)
    model[2].weight.copy_(w2)
    model[2].bias.copy_(b2)
torch.testing.assert_close(model(x), prediction)
assert sum(p.numel() for p in model.parameters()) == 17
print("loss =", round(loss.item(), 6))
print("通过：前向、五组梯度、有限差分和 17 个参数。")

# 使用刚刚计算的旧参数梯度，同时更新四组参数；输入不由 optimizer 管理。
learning_rate = 0.1
expected_parameters = [parameter - learning_rate * gradient
                       for parameter, gradient in zip((w1, b1, w2, b2), (dw1, db1, dw2, db2))]
input_before = x.clone()
optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
optimizer.zero_grad(set_to_none=True)
module_loss = (model(x) - y).square().mean() / 2
module_loss.backward()
optimizer.step()
for actual, expected in zip(model.parameters(), expected_parameters):
    torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
torch.testing.assert_close(x, input_before, rtol=0, atol=0)
with torch.no_grad():
    updated_prediction = model(x)
    updated_loss = (updated_prediction - y).square().mean() / 2
assert abs(updated_loss.item() - 0.08276880316466285) < 1e-12
assert updated_loss < loss
print("one SGD step:", loss.item(), "->", updated_loss.item())
print("first updated prediction:", updated_prediction[0].tolist())
print("输入保持不变；四组参数的手写更新与 SGD 一致。")

