import torch
from torch import nn

torch.set_num_threads(1)
dtype = torch.float64

def interpolation_mlp(knots, values):
    """仅在 [knots[0], knots[-1]] 上使用；固定参数实现线性插值。"""
    if knots.ndim != 1 or values.shape != knots.shape or knots.numel() < 2:
        raise ValueError("需要至少两个一维节点和同形函数值")
    if not torch.all(knots[1:] > knots[:-1]):
        raise ValueError("节点必须严格递增")
    slopes = (values[1:] - values[:-1]) / (knots[1:] - knots[:-1])
    changes = torch.cat((slopes[:1], slopes[1:] - slopes[:-1]))
    net = nn.Sequential(nn.Linear(1, len(slopes)), nn.ReLU(), nn.Linear(len(slopes), 1)).to(dtype)
    with torch.no_grad():
        net[0].weight.fill_(1.)
        net[0].bias.copy_(-knots[:-1])
        net[2].weight.copy_(changes[None, :])
        net[2].bias.copy_(values[:1])
    return net

for intervals in (4, 8, 16):
    knots = torch.linspace(0., 1., intervals + 1, dtype=dtype)
    net = interpolation_mlp(knots, knots.square())
    torch.testing.assert_close(net(knots[:, None]).squeeze(-1), knots.square())
    midpoints = (knots[:-1] + knots[1:]) / 2
    error = net(midpoints[:, None]).squeeze(-1) - midpoints.square()
    # 对 x²，每一段中点误差恰好是 h²/4，并非从训练曲线拟合的经验率。
    torch.testing.assert_close(error, torch.full_like(error, 1 / (4 * intervals ** 2)))
    probe = (knots[:-1] + (knots[1:] - knots[:-1]) / 3).requires_grad_()
    slope = torch.autograd.grad(net(probe[:, None]).sum(), probe)[0]
    expected_slope = (knots[1:].square() - knots[:-1].square()) / (knots[1:] - knots[:-1])
    torch.testing.assert_close(slope, expected_slope)
    print(f"width={intervals}, max_error={error.max().item():.8f}, verified slopes")

print("这是构造性表示实验，没有执行优化；它不保证训练能找到这组参数，也不刻画区间外误差。")

