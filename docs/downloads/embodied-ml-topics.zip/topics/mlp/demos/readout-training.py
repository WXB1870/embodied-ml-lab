import torch
from torch import nn

torch.manual_seed(17)
torch.set_num_threads(1)

# 合成任务刻意只依赖有效 token 的均值，不能据此推断空间定位能力。
count, time, features = 192, 5, 4
raw = torch.randn(count, time, features) * torch.tensor([1., 10., .1, 3.])
lengths = torch.randint(1, time + 1, (count,))
valid = torch.arange(time)[None, :] < lengths[:, None]
raw = raw.masked_fill(~valid[..., None], 1000.)

def masked_mean(tokens, mask):
    if mask.dtype != torch.bool or mask.shape != tokens.shape[:2]:
        raise ValueError("mask 必须是与 B,T 对齐的 bool 张量")
    denominator = mask.sum(1, keepdim=True)
    if (denominator == 0).any():
        raise ValueError("每条样本至少需要一个有效 token")
    clean = tokens.masked_fill(~mask[..., None], 0)
    return clean.sum(1) / denominator

pooled = masked_mean(raw, valid)
base = pooled / torch.tensor([1., 10., .1, 3.])
target = torch.stack((.7 * base[:, 0].sin() + .3 * base[:, 1] * base[:, 2],
                      .5 * base[:, 2] - .4 * base[:, 3].square()), dim=-1)
train_x, test_x = pooled[:144], pooled[144:]
train_y, test_y = target[:144], target[144:]
# 只使用训练集统计；标准化目标也就明确了各输出维度的损失权重。
x_mean = train_x.mean(0)
x_std = train_x.std(0, correction=0).clamp_min(1e-6)
y_mean = train_y.mean(0)
y_std = train_y.std(0, correction=0).clamp_min(1e-6)

class Readout(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer("x_mean", x_mean.clone())
        self.register_buffer("x_std", x_std.clone())
        self.register_buffer("y_mean", y_mean.clone())
        self.register_buffer("y_std", y_std.clone())
        self.network = nn.Sequential(nn.Linear(features, 32), nn.SiLU(), nn.Linear(32, 2))
        for layer in self.network:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)

    def forward(self, x):
        return self.network((x - self.x_mean) / self.x_std)

    def predict(self, x):
        return self(x) * self.y_std + self.y_mean

model = Readout()
optimizer = torch.optim.AdamW(model.parameters(), lr=.02, weight_decay=1e-4)
normalized_target = (train_y - model.y_mean) / model.y_std
with torch.no_grad():
    initial = (model(train_x) - normalized_target).square().mean().item()
first_weight = model.network[0].weight.detach().clone()
model.train()
for step in range(240):
    optimizer.zero_grad(set_to_none=True)
    prediction = model(train_x)
    loss = (prediction - normalized_target).square().mean()
    loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    if step == 0:
        print("initial gradient norm =", model.network[0].weight.grad.norm().item())
    optimizer.step()

model.eval()
with torch.no_grad():
    final = (model(train_x) - normalized_target).square().mean().item()
    holdout_mse = (model.predict(test_x) - test_y).square().mean().item()
assert final < initial * .15  # 只检查这个固定合成任务的优化链路。
assert not torch.equal(first_weight, model.network[0].weight)
assert torch.isfinite(torch.tensor(holdout_mse))
# 将无效内容改成 NaN，仍应得到同一有效均值。
poisoned = raw.masked_fill(~valid[..., None], float("nan"))
torch.testing.assert_close(masked_mean(poisoned, valid), pooled)
# state_dict 同时包含网络参数和预处理统计。
restored = Readout()
restored.load_state_dict(model.state_dict())
with torch.no_grad():
    torch.testing.assert_close(restored.predict(test_x), model.predict(test_x))
print(f"train normalized MSE: {initial:.6f} -> {final:.6f}")
print(f"holdout MSE in original units: {holdout_mse:.6f}")
print("通过：有效池化、训练更新、有限验证损失与含统计量的恢复。")

