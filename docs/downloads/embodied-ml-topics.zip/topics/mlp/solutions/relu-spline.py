# MLP：表达、梯度与优化 · 从节点值构造一层 ReLU 插值网络
# 实现 relu_interpolator(knots,values)，返回由 Linear(1,K)、ReLU、Linear(K,1) 组成的 nn.Sequential，其中 K=节点数−1。knots 与 values 为同设备、同浮点类型的一维有限张量，节点严格递增；在闭区间内，网络必须精确实现给定节点的分段线性插值。参数直接由节点构造，不执行梯度更新，不调用插值算子；保留输入类型与设备。节点少于两个、形状不符或不严格递增时抛 ValueError。测试避开折点核对导数。

import torch
from torch import nn

def relu_interpolator(knots, values):
    if knots.ndim != 1 or knots.numel() < 2 or values.shape != knots.shape:
        raise ValueError("节点与函数值必须是一维同形张量，至少含两个节点")
    if not torch.all(knots[1:] > knots[:-1]):
        raise ValueError("节点必须严格递增")
    slope = (values[1:] - values[:-1]) / (knots[1:] - knots[:-1])
    coefficients = torch.cat((slope[:1], slope[1:] - slope[:-1]))
    width = knots.numel() - 1
    net = nn.Sequential(nn.Linear(1, width), nn.ReLU(), nn.Linear(width, 1))
    net = net.to(device=knots.device, dtype=knots.dtype)
    with torch.no_grad():
        net[0].weight.fill_(1.)
        net[0].bias.copy_(-knots[:-1])
        net[2].weight.copy_(coefficients[None, :])
        net[2].bias.copy_(values[:1])
    return net


# 断言测试
torch.manual_seed(31)
knots = torch.tensor([-1., -0.2, 0.5, 2.], dtype=torch.float64)
values = torch.tensor([2., -1., 0.4, 3.], dtype=knots.dtype)
net = relu_interpolator(knots, values)
assert sum(p.numel() for p in net.parameters()) == 3 * (len(knots) - 1) + 1
torch.testing.assert_close(net(knots[:, None]).squeeze(-1), values)
for fraction in (0.2, 0.5, 0.8):
    x = (knots[:-1] + fraction * (knots[1:] - knots[:-1])).requires_grad_()
    y = net(x[:, None]).squeeze(-1)
    expected = (1 - fraction) * values[:-1] + fraction * values[1:]
    torch.testing.assert_close(y, expected)
    actual_slope = torch.autograd.grad(y.sum(), x)[0]
    torch.testing.assert_close(actual_slope, (values[1:] - values[:-1]) / (knots[1:] - knots[:-1]))
k = torch.linspace(0., 1., 9, dtype=torch.float64)
quadratic = relu_interpolator(k, k.square())
m = (k[:-1] + k[1:]) / 2
torch.testing.assert_close(quadratic(m[:, None]).squeeze(-1) - m.square(), torch.full_like(m, 1 / 256))
for bad_k, bad_v in ((torch.tensor([0., 0.]), torch.ones(2)),
                     (torch.tensor([1.]), torch.ones(1)),
                     (torch.tensor([0., 1.]), torch.ones(3))):
    try:
        relu_interpolator(bad_k, bad_v)
    except ValueError:
        pass
    else:
        raise AssertionError("无效节点应抛 ValueError")
print("通过：非等距节点、分段前向与梯度、明确参数量、x² 误差界及无效输入")

