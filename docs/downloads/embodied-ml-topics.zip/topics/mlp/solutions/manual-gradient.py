# MLP：表达、梯度与优化 · 手写两层 ReLU 网络的全部梯度
# 实现 manual_gradients(x,target,w1,b1,w2,b2)，返回 loss 和字典 grads，键为 x、w1、b1、w2、b2。损失固定为 0.5*((prediction-target)**2).mean()。只使用张量计算，函数内不得调用 backward、autograd.grad 或有限差分；ReLU 在零点导数取 0。

import torch

def manual_gradients(x, target, w1, b1, w2, b2):
    z = x @ w1.T + b1
    hidden = z.clamp_min(0)
    prediction = hidden @ w2.T + b2
    if prediction.shape != target.shape:
        raise ValueError("预测和回归目标必须完全同形")
    error = prediction - target
    loss = error.square().mean() / 2
    upstream = error / error.numel()
    dz = (upstream @ w2) * (z > 0).to(z.dtype)
    grads = {"x": dz @ w1, "w1": dz.T @ x, "b1": dz.sum(0),
             "w2": upstream.T @ hidden, "b2": upstream.sum(0)}
    return loss, grads


# 断言测试
torch.manual_seed(11)
dtype = torch.float64
values = [torch.randn(4, 3, dtype=dtype), torch.randn(5, 3, dtype=dtype),
          torch.randn(5, dtype=dtype), torch.randn(2, 5, dtype=dtype),
          torch.randn(2, dtype=dtype)]
target = torch.randn(4, 2, dtype=dtype)
loss, result = manual_gradients(values[0], target, *values[1:])
auto_values = [v.clone().requires_grad_() for v in values]
x, w1, b1, w2, b2 = auto_values
prediction = torch.relu(x @ w1.T + b1) @ w2.T + b2
expected_loss = (prediction - target).square().mean() / 2
expected = torch.autograd.grad(expected_loss, auto_values)
torch.testing.assert_close(loss, expected_loss)
for key, gradient in zip(("x", "w1", "b1", "w2", "b2"), expected):
    torch.testing.assert_close(result[key], gradient, rtol=1e-10, atol=1e-10)
# 重复整个 Batch 不改变平均损失及参数梯度。
double_loss, double_grads = manual_gradients(values[0].repeat(2, 1), target.repeat(2, 1), *values[1:])
torch.testing.assert_close(double_loss, loss)
for key in ("w1", "b1", "w2", "b2"):
    torch.testing.assert_close(double_grads[key], result[key])
# 所有预激活都为负：第一层与第二层权重的梯度均为零，输出偏置仍可学习。
a = torch.ones(2, 3, dtype=dtype)
_, inactive = manual_gradients(a, torch.ones(2, 2, dtype=dtype),
    torch.zeros(4, 3, dtype=dtype), -torch.ones(4, dtype=dtype),
    torch.ones(2, 4, dtype=dtype), torch.zeros(2, dtype=dtype))
assert all(torch.count_nonzero(inactive[k]) == 0 for k in ("x", "w1", "b1", "w2"))
assert torch.count_nonzero(inactive["b2"]) == 2
print("通过：全部梯度、平均归约和失活支路。")

