# MLP：表达、梯度与优化 · 实现不受 Padding 污染的序列 MLP
# 实现 MaskedMeanHead(input_dim,hidden_dim,output_dim)。属性 network 必须为 Linear→GELU→Linear，两层 Linear 均带偏置，GELU 使用默认精确形式；forward(tokens,mask) 接收 [B,T,D] 和 bool [B,T]，先有效平均池化再过 network，返回 [B,O]。拒绝 Mask 形状错误或含全无效样本的 Batch。无效 token 即使含 NaN 也不能污染预测或输入梯度。

import torch
from torch import nn

class MaskedMeanHead(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super().__init__()
        # TODO: 注册 network。

    def forward(self, tokens, mask):
        # TODO: 检查合同、有效池化、MLP。
        raise NotImplementedError("实现 MaskedMeanHead")


# 断言测试
torch.manual_seed(5)
head = MaskedMeanHead(3, 5, 2).double()
assert isinstance(head.network, nn.Sequential) and len(head.network) == 3
assert isinstance(head.network[0], nn.Linear) and isinstance(head.network[1], nn.GELU)
assert isinstance(head.network[2], nn.Linear)
assert head.network[0].weight.shape == (5, 3)
assert head.network[2].weight.shape == (2, 5)
assert head.network[0].bias is not None and head.network[2].bias is not None
w1 = torch.tensor([[.6,-.2,.1],[-.3,.4,.5],[.2,.8,-.7],[-.9,.3,.2],[.5,-.4,.6]], dtype=torch.float64)
b1 = torch.tensor([-.2,.1,.3,-.1,.05], dtype=torch.float64)
w2 = torch.tensor([[.3,-.4,.2,.5,-.1],[-.6,.1,.4,-.2,.7]], dtype=torch.float64)
b2 = torch.tensor([.2,-.3], dtype=torch.float64)
with torch.no_grad():
    head.network[0].weight.copy_(w1)
    head.network[0].bias.copy_(b1)
    head.network[2].weight.copy_(w2)
    head.network[2].bias.copy_(b2)
mask = torch.tensor([[True, False, True], [False, True, False]])
x = torch.randn(2, 3, 3, dtype=torch.float64)
x[~mask] = float("nan")
x.requires_grad_()
y = head(x, mask)
expected_pool = torch.stack((x[0, [0, 2]].mean(0), x[1, 1]))
# 独立参考：不调用被测 network；用精确 GELU 的 erf 定义计算。
z = expected_pool @ w1.T + b1
hidden = .5 * z * (1 + torch.erf(z / (2 ** .5)))
expected = hidden @ w2.T + b2
torch.testing.assert_close(y, expected, rtol=1e-10, atol=1e-10)
assert y.shape == (2, 2) and torch.isfinite(y).all()
permutation = torch.tensor([2, 0, 1])
torch.testing.assert_close(head(x[:, permutation], mask[:, permutation]), y)
extra = torch.full((2, 4, 3), float("nan"), dtype=torch.float64)
extra_mask = torch.zeros(2, 4, dtype=torch.bool)
torch.testing.assert_close(head(torch.cat((x, extra), 1), torch.cat((mask, extra_mask), 1)), y)
y.square().sum().backward()
assert torch.isfinite(x.grad).all() and torch.count_nonzero(x.grad[~mask]) == 0
assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in head.parameters())
try:
    head(x.detach(), torch.zeros_like(mask))
    raise AssertionError("不能静默处理全无效样本")
except ValueError:
    pass
print("通过：指定 MLP、独立 GELU 参考、NaN Padding 隔离、每样本分母与梯度。")

