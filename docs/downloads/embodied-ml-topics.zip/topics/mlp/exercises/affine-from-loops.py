# MLP：表达、梯度与优化 · 用标准库写出仿射层并数参数
# 实现 affine_batch(x, weight, bias)，x 是 \(B\times D\) 列表，weight 使用 \(O\times D\) 约定，bias 为长度 O 列表；同时实现 parameter_count(widths)，统计全部相邻有偏置 Linear 的参数量。矩阵必须非空、每行长度一致，维度不匹配时抛 ValueError。不得使用第三方库。

def affine_batch(x, weight, bias):
    # TODO: 核对三个对象的形状，逐样本逐输出做内积。
    raise NotImplementedError("实现仿射层")

def parameter_count(widths):
    # TODO: 每层统计权重与偏置；widths 至少包含两个正整数。
    raise NotImplementedError("计算参数量")


# 断言测试
x = [[1., 2., -1.], [0., -2., 3.]]
w = [[2., -1., .5], [-3., 4., 1.]]
assert affine_batch(x, w, [.5, -1.]) == [[0., 3.], [4., -6.]]
assert affine_batch([[2.]], [[3.]], [-1.]) == [[5.]]
assert parameter_count([6, 8, 3]) == 83
assert parameter_count([2, 3, 2]) == 17
for bad_args in [([], w, [0, 0]), ([[1, 2]], w, [0, 0]), (x, w, [0])]:
    try:
        affine_batch(*bad_args)
        raise AssertionError("应拒绝无效形状")
    except ValueError:
        pass
for widths in [[], [2], [2, 0, 1], [2, 2.5, 1]]:
    try:
        parameter_count(widths)
        raise AssertionError("应拒绝无效网络宽度")
    except ValueError:
        pass
print("通过：非方形权重、Batch 共享、偏置和参数量。")

